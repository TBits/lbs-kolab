Release Notes
=============

* [`0.8.4`](https://github.com/basho/erlang_protobuffs/issues?q=milestone%3Aerlang_protobuffs-0.8.4)
 * Ensure `rebar.config` uses `https` dep URLs. `git://` may be blocked.
* [`0.8.3`](https://github.com/basho/erlang_protobuffs/issues?q=milestone%3Aerlang_protobuffs-0.8.3)
 * OTP 18 support.
