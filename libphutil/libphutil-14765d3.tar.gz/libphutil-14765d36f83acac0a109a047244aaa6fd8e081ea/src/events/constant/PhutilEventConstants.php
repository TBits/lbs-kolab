<?php

abstract class PhutilEventConstants extends Phobject {}
