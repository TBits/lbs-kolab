<?php

final class PhutilTestPhobject extends Phobject {}
