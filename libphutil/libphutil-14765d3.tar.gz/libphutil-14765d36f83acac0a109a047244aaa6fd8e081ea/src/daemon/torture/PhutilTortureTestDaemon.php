<?php

/**
 * Daemons which misbehave in specific ways.
 */
abstract class PhutilTortureTestDaemon extends PhutilDaemon {}
