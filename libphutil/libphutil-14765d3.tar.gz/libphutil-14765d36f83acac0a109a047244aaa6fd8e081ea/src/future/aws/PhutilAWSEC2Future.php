<?php

final class PhutilAWSEC2Future extends PhutilAWSFuture {

  public function getServiceName() {
    return 'ec2';
  }

}
