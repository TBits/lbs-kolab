<?php

final class PhutilAWSS3Future extends PhutilAWSFuture {

  public function getServiceName() {
    return 's3';
  }

}
