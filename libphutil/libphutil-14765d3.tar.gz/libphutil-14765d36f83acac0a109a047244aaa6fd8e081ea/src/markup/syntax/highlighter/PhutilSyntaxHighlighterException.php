<?php

final class PhutilSyntaxHighlighterException extends Exception {}
