<?php

final class PhutilLockException extends Exception {}
