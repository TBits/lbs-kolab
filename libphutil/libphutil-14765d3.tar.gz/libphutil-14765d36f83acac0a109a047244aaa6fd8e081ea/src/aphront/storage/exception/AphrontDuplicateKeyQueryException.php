<?php

final class AphrontDuplicateKeyQueryException extends AphrontQueryException {}
