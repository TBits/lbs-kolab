<?php

final class AphrontConnectionLostQueryException
  extends AphrontRecoverableQueryException {}
