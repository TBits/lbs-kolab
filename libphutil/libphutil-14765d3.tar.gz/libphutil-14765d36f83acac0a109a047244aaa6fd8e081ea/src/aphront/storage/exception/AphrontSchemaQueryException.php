<?php

final class AphrontSchemaQueryException extends AphrontQueryException {}
