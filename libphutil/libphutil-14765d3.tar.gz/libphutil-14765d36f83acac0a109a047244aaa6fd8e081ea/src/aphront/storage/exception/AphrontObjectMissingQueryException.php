<?php

final class AphrontObjectMissingQueryException extends AphrontQueryException {}
