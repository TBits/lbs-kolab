<?php

abstract class AphrontRecoverableQueryException extends AphrontQueryException {}
