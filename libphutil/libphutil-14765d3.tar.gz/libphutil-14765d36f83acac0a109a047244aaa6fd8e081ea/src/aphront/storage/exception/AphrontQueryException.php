<?php

/**
 * @concrete-extensible
 */
class AphrontQueryException extends Exception {}
