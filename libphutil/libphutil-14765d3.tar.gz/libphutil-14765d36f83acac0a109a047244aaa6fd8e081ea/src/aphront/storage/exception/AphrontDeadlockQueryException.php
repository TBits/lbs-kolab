<?php

final class AphrontDeadlockQueryException
  extends AphrontRecoverableQueryException {}
