<?php

final class AphrontLockTimeoutQueryException
  extends AphrontRecoverableQueryException {}
