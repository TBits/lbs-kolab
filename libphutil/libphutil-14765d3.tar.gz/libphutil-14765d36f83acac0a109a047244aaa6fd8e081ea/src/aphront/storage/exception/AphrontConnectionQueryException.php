<?php

final class AphrontConnectionQueryException extends AphrontQueryException {}
