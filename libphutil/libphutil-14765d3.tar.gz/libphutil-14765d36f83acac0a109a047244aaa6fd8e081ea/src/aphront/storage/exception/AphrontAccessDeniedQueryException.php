<?php

final class AphrontAccessDeniedQueryException
  extends AphrontRecoverableQueryException {}
