<?php

final class AphrontCharacterSetQueryException extends AphrontQueryException {}
