<?php

final class AphrontNotSupportedQueryException extends AphrontQueryException {}
