<?php

final class AphrontCountQueryException extends AphrontQueryException {}
