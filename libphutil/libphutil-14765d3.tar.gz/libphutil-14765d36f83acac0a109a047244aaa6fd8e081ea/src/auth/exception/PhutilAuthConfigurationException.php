<?php

/**
 * Authentication is not configured correctly.
 */
final class PhutilAuthConfigurationException extends PhutilAuthException {}
