<?php

/**
 * The user provided invalid credentials.
 */
final class PhutilAuthCredentialException extends PhutilAuthException {}
