<?php

final class PhutilInvalidRuleParserGeneratorException
  extends PhutilParserGeneratorException {}
