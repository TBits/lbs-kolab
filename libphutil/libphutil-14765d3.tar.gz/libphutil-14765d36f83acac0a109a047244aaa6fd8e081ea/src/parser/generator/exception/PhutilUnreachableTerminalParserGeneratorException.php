<?php

final class PhutilUnreachableTerminalParserGeneratorException
  extends PhutilParserGeneratorException {}
