<?php

final class PhutilIrreducibleRuleParserGeneratorException
  extends PhutilParserGeneratorException {}
