<?php

abstract class PhutilParserGeneratorException extends Exception {}
