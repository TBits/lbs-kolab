<?php

final class PhutilUnreachableRuleParserGeneratorException
  extends PhutilParserGeneratorException {}
