<?php

final class PhutilUnknownSymbolParserGeneratorException
  extends PhutilParserGeneratorException {}
