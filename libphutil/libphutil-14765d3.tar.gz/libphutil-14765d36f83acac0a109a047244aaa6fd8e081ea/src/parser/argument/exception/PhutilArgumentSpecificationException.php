<?php

final class PhutilArgumentSpecificationException
  extends PhutilArgumentParserException {}
