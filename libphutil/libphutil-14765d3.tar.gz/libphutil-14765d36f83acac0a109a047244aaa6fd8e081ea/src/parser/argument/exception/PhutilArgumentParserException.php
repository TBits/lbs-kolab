<?php

abstract class PhutilArgumentParserException extends Exception {}
