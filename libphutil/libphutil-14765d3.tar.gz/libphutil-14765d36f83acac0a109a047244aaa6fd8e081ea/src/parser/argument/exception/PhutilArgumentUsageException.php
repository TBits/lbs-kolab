<?php

final class PhutilArgumentUsageException
  extends PhutilArgumentParserException {}
