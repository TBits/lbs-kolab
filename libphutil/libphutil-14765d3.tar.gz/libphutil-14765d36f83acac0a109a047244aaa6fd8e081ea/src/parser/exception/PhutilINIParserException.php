<?php

final class PhutilINIParserException extends Exception {}
