# Changelog
All notable changes to this project will be documented in this file.

This project adheres to [Semantic Versioning](http://semver.org/).

## [Unreleased]
### Added
### Changed
### Deprecated
### Removed
### Fixed
### Security

## [0.9.0] - 2016-07-29
### Added
- bind to a network interface (rather than an IP/host) with net_iface

### Changed
- handle the implicit ssl upgrade a bit more manually, allowing faster
  replenish of the listener pool and simplifying socket setup code
- upgraded build to rebar3
- Upgraded eimap to 0.3.0

### Fixed
- fix CAPABILITY response (was CAPABILITIES)

## [0.8.3] - 2016-08-08
### Fixed
- always close ssl sockets as an ssl socket
- keep listen_socket separate from socket
- not required to make the socket active to accept connections
- ensure eimap processes are always terminated in all cases

## [0.8.2] - 2016-07-08
### Added
- listener_pool_size configuration option for listeners
### Changed
- Default size of listener pool drops to 10 from 20
- Rate limit (by introducing a short wait) connection accept()s
### Fixed
- Prevent starvation of the session pool due to clients dropping connections
  pre-accept()

## [0.8.1] - 2016-07-06
### Added
- ipv6 connections
### Changed
- update to eimap 0.2.5
### Fixed
- Ignore non-listing LIST commands (e.g. requests for the root/separator)
- Tidy up the server greetings

## [0.8.0] - 2016-06-08
### Added
- systemd service module
- sysv init script
### Changed
- Upgraded eimap to 0.2.4
### Fixed
- Support more variations of the LIST command args in the filter_groupware rule

