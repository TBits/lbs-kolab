# Changelog
All notable changes to this project will be documented in this file.

This project adheres to [Semantic Versioning](http://semver.org/).

## [Unreleased]
### Added
- bind to a network interface (rather than an IP/host) with net_iface
### Changed
- upgraded build to rebar3
### Deprecated
### Removed
### Fixed
### Security


## [0.8.0] - 2016-06-08
### Added
- systemd service module
- sysv init script
### Changed
- Upgraded eimap to 0.2.4
### Fixed
- Support more variations of the LIST command args in the filter_groupware rule

