defmodule <%= application_module %>.PageView do
  use <%= application_module %>.Web, :view
end
