defmodule <%= application_module %>.LayoutView do
  use <%= application_module %>.Web, :view
end
