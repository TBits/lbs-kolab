defmodule <%= application_module %>.LayoutViewTest do
  use <%= application_module %>.ConnCase, async: true
end
