defmodule <%= application_module %>.PageViewTest do
  use <%= application_module %>.ConnCase, async: true
end
