## mix phoenix.new

Provides `phoenix.new` installer as an archive. To build and install it locally:

    $ cd installer
    $ MIX_ENV=prod mix archive.build
    $ mix archive.install
