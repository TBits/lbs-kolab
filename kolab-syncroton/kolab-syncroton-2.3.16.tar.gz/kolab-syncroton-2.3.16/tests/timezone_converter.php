<?php

class timezone_converter extends PHPUnit_Framework_TestCase
{
    function setUp()
    {
    }


    function test_list_timezones()
    {
        date_default_timezone_set('America/Los_Angeles');

        $converter = timezone_converter_test::getInstance();

        $input  = 'AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAoAAAAEAAIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAMAAAAFAAEAAAAAAAAAxP///w==';
        $output = $converter->getListOfTimezones($input);

        $this->assertTrue(is_array($output));

        $converter = timezone_converter_test::getInstance();
        $output    = $converter->getListOfTimezones('xP///0MAZQBuAHQAcgBhAGwAIABFAHUAcgBvAHAAZQAgAFMAdABhAG4AZABhAHIAZAAgAFQAaQBtAGUAAAAAAAAAAAAAAAoAAAAFAAMAAAAAAAAAAAAAAEMAZQBuAHQAcgBhAGwAIABFAHUAcgBvAHAAZQAgAEQAYQB5AGwAaQBnAGgAdAAgAFQAaQBtAGUAAAAAAAAAAAAAAAMAAAAFAAIAAAAAAAAAxP///w==');

        $this->assertTrue(is_array($output));
        $this->assertTrue(isset($output['Europe/Warsaw']));

        $converter = timezone_converter_test::getInstance();
        $output    = $converter->getListOfTimezones('4AEAAFAAYQBjAGkAZgBpAGMAIABTAHQAYQBuAGQAYQByAGQAIABUAGkAbQBlAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAsAAAABAAIAAAAAAAAAAAAAAFAAYQBjAGkAZgBpAGMAIABEAGEAeQBsAGkAZwBoAHQAIABUAGkAbQBlAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAMAAAACAAIAAAAAAAAAxP///w==');

        $this->assertTrue(is_array($output));
        $this->assertTrue(isset($output['America/Los_Angeles']));
    }

    function test_get_timezone()
    {
        date_default_timezone_set('America/Los_Angeles');

        $converter = timezone_converter_test::getInstance();
        $datetime  = new DateTime('2017-01-01T12:00:00Z');

        $offsets = $converter->getOffsetsForTimezone('UTC', $datetime);
        $output  = $converter->getTimezone($offsets, 'UTC');

        $this->assertSame('UTC', $output);

        $offsets = $converter->getOffsetsForTimezone('Europe/Warsaw', $datetime);
        $output  = $converter->getTimezone($offsets, 'Europe/Warsaw');

        $this->assertSame('Europe/Warsaw', $output);

        $offsets = $converter->getOffsetsForTimezone('America/Los_Angeles', $datetime);
        $output  = $converter->getTimezone($offsets, 'America/Los_Angeles');

        $this->assertSame('America/Los_Angeles', $output);
    }

    function test_get_offsets_for_timezone()
    {
        date_default_timezone_set('America/Los_Angeles');

        $converter = timezone_converter_test::getInstance();
        $datetime  = new DateTime('2017-01-01T12:00:00Z');

        $output = $converter->getOffsetsForTimezone('UTC', $datetime);

        $this->assertSame($output['bias'], 0);
        $this->assertSame($output['standardBias'], 0);
        $this->assertSame($output['daylightBias'], 0);
        $this->assertSame($output['standardMonth'], 0);
        $this->assertSame($output['daylightMonth'], 0);

        $output = $converter->getOffsetsForTimezone('Europe/Warsaw', $datetime);

        $this->assertSame($output['standardBias'], 0);
        $this->assertSame($output['standardMonth'], 10);
        $this->assertSame($output['standardDay'], 5);
        $this->assertSame($output['standardHour'], 3);
        $this->assertSame($output['daylightBias'], -60);
        $this->assertSame($output['daylightMonth'], 3);
        $this->assertSame($output['daylightDay'], 5);
        $this->assertSame($output['daylightHour'], 2);

        $output = $converter->getOffsetsForTimezone('America/Los_Angeles', $datetime);

        $this->assertSame($output['bias'], 480);
        $this->assertSame($output['standardBias'], 0);
        $this->assertSame($output['standardMonth'], 11);
        $this->assertSame($output['standardDay'], 1);
        $this->assertSame($output['standardHour'], 2);
        $this->assertSame($output['daylightBias'], -60);
        $this->assertSame($output['daylightMonth'], 3);
        $this->assertSame($output['daylightDay'], 2);
        $this->assertSame($output['daylightHour'], 2);

        $output = $converter->getOffsetsForTimezone('Atlantic/Azores', $datetime);

        $this->assertSame($output['bias'], 60);
        $this->assertSame($output['standardBias'], 0);
        $this->assertSame($output['standardMonth'], 10);
        $this->assertSame($output['standardDay'], 5);
        $this->assertSame($output['standardHour'], 1);
        $this->assertSame($output['daylightBias'], -60);
        $this->assertSame($output['daylightMonth'], 3);
        $this->assertSame($output['daylightDay'], 5);
        $this->assertSame($output['daylightHour'], 0);
    }
}

class timezone_converter_test extends kolab_sync_timezone_converter
{
    // disable cache
    function getCache()
    {
        return null;
    }
}
