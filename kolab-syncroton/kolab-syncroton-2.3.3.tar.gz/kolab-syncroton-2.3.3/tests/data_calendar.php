<?php

class data_calendar extends PHPUnit_Framework_TestCase
{
    /**
     * Test for kolab_sync_data_calendar::from_kolab_alarm()
     */
    function test_from_kolab_alarm()
    {
        $obj = new kolab_sync_data_calendar_test;

        $result = $obj->from_kolab_alarm(array());
        $this->assertSame(null, $result);

        $event  = array('valarms' => array(array(
            'action'  => 'DISPLAY',
            'trigger' => 'PT5M',
        )));
        $result = $obj->from_kolab_alarm($event);
        $this->assertSame(null, $result);

        $event  = array('valarms' => array(array(
            'action'  => 'DISPLAY',
            'trigger' => '-PT5M',
        )));
        $result = $obj->from_kolab_alarm($event);
        $this->assertSame(5, $result);

        $event  = array('valarms' => array(array(
            'action'  => 'DISPLAY',
            'trigger' => 'PT0M',
        )));
        $result = $obj->from_kolab_alarm($event);
        $this->assertSame(0, $result);

        $event  = array('valarms' => array(array(
            'action'  => 'DISPLAY',
            'trigger' => '-PT0M',
        )));
        $result = $obj->from_kolab_alarm($event);
        $this->assertSame(0, $result);

        $event  = array('valarms' => array(array(
            'action'  => 'DISPLAY',
            'trigger' => 'PT0S',
        )));
        $result = $obj->from_kolab_alarm($event);
        $this->assertSame(0, $result);
    }

    /**
     * Test for kolab_sync_data_calendar::to_kolab_alarm()
     */
    function test_to_kolab_alarm()
    {
        $obj = new kolab_sync_data_calendar_test;

        $result = $obj->to_kolab_alarm(null, array());
        $this->assertSame(array(), $result);

        $result = $obj->to_kolab_alarm(0, array());
        $this->assertSame('-PT0M', $result[0]['trigger']);

        $result = $obj->to_kolab_alarm(15, array());
        $this->assertSame('-PT15M', $result[0]['trigger']);
        $this->assertSame('DISPLAY', $result[0]['action']);
    }
}

/**
 * kolab_sync_data_calendar wrapper, so we can test protected methods too
 */
class kolab_sync_data_calendar_test extends kolab_sync_data_calendar
{
    function __construct()
    {
    }

    public function from_kolab_alarm($value)
    {
        return parent::from_kolab_alarm($value);
    }

    public function to_kolab_alarm($value, $event)
    {
        return parent::to_kolab_alarm($value, $event);
    }
}
