ALTER TABLE `syncroton_modseq` CHANGE `synctime` `synctime` datetime DEFAULT NULL;
