{{name}}
=====

{{desc}}

Build
-----

    $ rebar3 escriptize

Run
---

    $ _build/default/bin/{{name}}
