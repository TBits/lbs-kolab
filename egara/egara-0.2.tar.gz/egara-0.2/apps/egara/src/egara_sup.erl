%% Copyright 2014 Kolab Systems AG (http://www.kolabsys.com)
%%
%% Aaron Seigo (Kolab Systems) <seigo a kolabsys.com>
%%
%% This program is free software: you can redistribute it and/or modify
%% it under the terms of the GNU General Public License as published by
%% the Free Software Foundation, either version 3 of the License, or
%% (at your option) any later version.
%%
%% This program is distributed in the hope that it will be useful,
%% but WITHOUT ANY WARRANTY; without even the implied warranty of
%% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%% GNU General Public License for more details.
%%
%% You should have received a copy of the GNU General Public License
%% along with this program.  If not, see <http://www.gnu.org/licenses/>.

-module(egara_sup).

-behaviour(supervisor).

%% API
-export([start_link/0]).

%% Supervisor callbacks
-export([init/1]).

%% Helper macro for declaring children of supervisor
-define(CHILD(Module, Type), { Module, { Module, start_link, []}, permanent, 5000, Type, [Module] }).
-define(RECEIVER_PREFIX, "egara_incoming_").

%% ===================================================================
%% API functions
%% ===================================================================

start_link() ->
    supervisor:start_link({local, ?MODULE}, ?MODULE, []).

%% ===================================================================
%% Supervisor callbacks
%% ===================================================================

init([]) ->
    lager:info("    Creating resource pools ..."),
    %% there is one more egara_imap process to allow non-egara_worker process access as needed through a shared one
    NodeType = application:get_env(egara, node_profile, sink),
    io:format("This is an Egara node of type ~p~n", [NodeType]),
    Pools = worker_pool_specs(NodeType, []),
    PoolSpecs = lists:map(fun({Name, Module, PoolConfig, WorkerArgs}) ->
                                  PoolArgs = [{ name, { local, Name } }, { worker_module, Module }],
                                  poolboy:child_spec(Name, PoolArgs ++ PoolConfig, WorkerArgs)
                          end, Pools),
    %lager:info("Pools: ~p", [PoolSpecs]),
    Children = notification_processes(NodeType, []),
    { ok, { { one_for_one, 5, 10}, PoolSpecs ++ Children } }.

worker_pool_specs(sink, Acc) ->
    WorkerSize = application:get_env(egara, worker_pool_size, erlang:system_info(schedulers_online) * 2),
    SinkPools =
    [{ egara_notification_workers, egara_worker, [ { size, WorkerSize }, { max_overflow, 0 }], [ ] },
     { egara_ldap_pool, egara_ldap, [ { size, WorkerSize }, { max_overflow, 0 }], [ ] }
     | Acc],
    worker_pool_specs(receiver, SinkPools);
worker_pool_specs(receiver, Acc) -> Acc.

notification_processes(sink, Acc) ->
    Children =
    [?CHILD(egara_riak_config, worker),
     ?CHILD(egara_notifications_processor, worker),
     ?CHILD(egara_notifications_receiver, worker) | Acc],
    notification_processes(receiver, Children);
notification_processes(receiver, Acc) ->
    spawn(fun() -> start_receivers() end),
    Acc.

start_receivers() ->
    timer:sleep(1000),
    start_receiver(application:get_env(egara, receivers, [])).

start_receiver([]) -> ok;
start_receiver([Module|Tail]) when is_atom(Module) -> Atom = list_to_atom(?RECEIVER_PREFIX ++ atom_to_list(Module)), Atom:start_reception(), start_receiver(Tail);
start_receiver([Module|Tail]) when is_list(Module) -> Atom = list_to_atom(?RECEIVER_PREFIX ++ Module), Atom:start_reception(), start_receiver(Tail);
start_receiver([_Module|Tail]) -> start_receiver(Tail);
start_receiver(_NotAList) -> ok.

