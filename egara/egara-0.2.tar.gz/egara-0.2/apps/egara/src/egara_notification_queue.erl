%% Copyright 2014 Kolab Systems AG (http://www.kolabsys.com)
%%
%% Aaron Seigo (Kolab Systems) <seigo a kolabsys.com>
%%
%% This program is free software: you can redistribute it and/or modify
%% it under the terms of the GNU General Public License as published by
%% the Free Software Foundation, either version 3 of the License, or
%% (at your option) any later version.
%%
%% This program is distributed in the hope that it will be useful,
%% but WITHOUT ANY WARRANTY; without even the implied warranty of
%% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%% GNU General Public License for more details.
%%
%% You should have received a copy of the GNU General Public License
%% along with this program.  If not, see <http://www.gnu.org/licenses/>.

-module(egara_notification_queue).
-export([ install/1, start/0,
          notification/1, next_unassigned/0,
          add/3, remove/1, remove_all/0,
          assign_one/1, assigned_to/1,
          release/1, release/2, release_orphaned/0, release_all/0,
          migrate_failures/0,
          max_key/0, list/0]).
-include_lib("stdlib/include/qlc.hrl").
-record(egara_incoming_notification, { id, node = undefined, claimed_by = undefined, fails = 0, term = undefined }).
-record(egara_incoming_notification_fails, { id, node, term }).
-define(MAX_FAILURES, 5).

install(Nodes) ->
    rpc:multicall(Nodes, application, stop, [mnesia]),
    %% TODO: tune mnesia for large batches of writes; see -> http://streamhacker.com/2008/12/10/how-to-eliminate-mnesia-overload-events/
    mnesia:create_schema(Nodes),
    rpc:multicall(Nodes, application, start, [mnesia]),
    %% create index for claimed_by
    try
        mnesia:create_table(egara_incoming_notification,
                            [{ attributes, record_info(fields, egara_incoming_notification) },
                             { type, ordered_set },
                             { disc_copies, Nodes }]),
        mnesia:create_table(egara_incoming_notification_fails,
                            [{ attributes, record_info(fields, egara_incoming_notification_fails) },
                             { disc_copies, Nodes }])
    of _ -> ok
    catch
        error:_ -> ok
    end.

start() ->
    mnesia:wait_for_tables([egara_incoming_notification], 5000).

add(Key, Node, Term) ->
    %lager:debug("Adding notification to the queue. Key: ~p => Value: ~p", [Key, Term]),
    F = fun() ->
                Rec = #egara_incoming_notification{ id = Key, node = Node, term = Term },
                mnesia:write(Rec)
        end,
    mnesia:activity(transaction, F).

remove(Key) ->
    F = fun() -> try mnesia:delete({ egara_incoming_notification, Key }) of
                     _ -> ok
                 catch
                     error:Error -> {error, caught, Error}
                 end
                 end,
    mnesia:activity(transaction, F).

remove_all() ->
    mnesia:clear_table(egara_incoming_notification).

notification(Key) ->
    F = fun() ->
                case mnesia:read(egara_incoming_notification, Key) of
                    [Record] -> Record;
                    [] -> #egara_incoming_notification{ id = 0 }
                end
        end,
    mnesia:activity(transaction, F).

release(Key, ProcessKey) ->
    %%TODO: make this more efficient by using qlc; currently scans whole table!
    Pattern = #egara_incoming_notification{ _ = '_', claimed_by = ProcessKey, id = Key },
    F = fun() ->
                %% check if claimed_by is set and if so if the process is still running
                case mnesia:match_object(Pattern) of
                    [#egara_incoming_notification{ term = Term }] -> mnesia:write(#egara_incoming_notification{ id = Key, term = Term, claimed_by = undefined });
                    [] -> { error, notfound}
                end
        end,
    mnesia:activity(transaction, F).

release(Key) ->
    F = fun() ->
                case mnesia:read(egara_incoming_notification, Key) of
                    [#egara_incoming_notification{ term = Term }] -> mnesia:write(#egara_incoming_notification{ id = Key, term = Term, claimed_by = undefined }), ok;
                    [] -> false
                end
        end,
    mnesia:activity(transaction, F).

release_orphaned() ->
    F = fun() ->
                QH = qlc:q([ Record || #egara_incoming_notification{ claimed_by = ProcessKey } = Record <- mnesia:table(egara_incoming_notification),
                             ProcessKey =/= undefined, syn:find_by_key(ProcessKey) =:= undefined ]),
                qlc:fold(fun(Record, N) ->
                                 Failed = Record#egara_incoming_notification.fails + 1,
                                 mnesia:write(Record#egara_incoming_notification{ claimed_by = undefined, fails = Failed }),
                                 N + 1
                         end,
                         0, QH)
        end,
    mnesia:activity(transaction, F).

migrate_failures() ->
    F = fun() ->
                Timestamp = egara_utils:current_timestamp(),
                QH = qlc:q([ Record || #egara_incoming_notification{ fails = Fails } = Record <- mnesia:table(egara_incoming_notification), Fails >= ?MAX_FAILURES ]),
                qlc:fold(fun(#egara_incoming_notification{ id = Key, node = Node, term = Term }, N) ->
                                 IntBin = egara_utils:as_binary(N),
                                 mnesia:write(#egara_incoming_notification_fails{ id = <<Timestamp/binary, "_", IntBin/binary>>,
                                                                                  node = Node,
                                                                                  term = Term }),
                                 remove(Key),
                                 N + 1 end,
                         0, QH)
        end,
    mnesia:activity(transaction, F).

release_all() ->
    F = fun() ->
                QH = qlc:q([ Rec|| Rec <- mnesia:table(egara_incoming_notification),
                             Rec#egara_incoming_notification.claimed_by =/= undefined ]),
                qlc:fold(fun(Rec, N) -> mnesia:write(Rec#egara_incoming_notification{ claimed_by = undefined }), N + 1 end, 0, QH)
        end,
    mnesia:activity(transaction, F).

assigned_to(Key) ->
    F = fun() ->
                QH = qlc:q([ Rec || Rec <- mnesia:table(egara_incoming_notification),
                             Rec#egara_incoming_notification.id =:= Key]),
                QC = qlc:cursor(QH),
                Answers = qlc:next_answers(QC, 1),
                case Answers of
                    [Record|_] -> Record#egara_incoming_notification.claimed_by;
                    _ -> notfound
                end
        end,
    mnesia:activity(transaction, F).

assign_one(ProcessKey) ->
    F = fun() ->
                QH = qlc:q([ Rec || Rec <- mnesia:table(egara_incoming_notification),
                             Rec#egara_incoming_notification.claimed_by =:= undefined, Rec#egara_incoming_notification.fails < ?MAX_FAILURES]),
                QC = qlc:cursor(QH),
                Answers = qlc:next_answers(QC, 1),
                case Answers of
                    [Record|_] ->
                        mnesia:write(Record#egara_incoming_notification{ claimed_by = ProcessKey }),
                        incoming_as_ext_tuple(Record);
                    _ -> notfound
                end
        end,
    mnesia:activity(transaction, F).

list() ->
    F = fun() ->
                QH = qlc:q([ Rec || Rec <- mnesia:table(egara_incoming_notification) ]),
                QC = qlc:cursor(QH),
                qlc:next_answers(QC)
        end,
    mnesia:activity(transaction, F).

incoming_as_ext_tuple(#egara_incoming_notification{ id = Id, node = undefined, term = Term }) -> { Id, node(), Term };
incoming_as_ext_tuple(#egara_incoming_notification{ id = Id, node = Node, term = Term }) -> { Id, Node, Term }.

next_unassigned([]) ->
    none;
next_unassigned([H|_]) ->
    H#egara_incoming_notification.id;
next_unassigned(_) ->
    error.
next_unassigned() ->
    F = fun() ->
                QH = qlc:q([ Rec || Rec <- mnesia:table(egara_incoming_notification),
                             Rec#egara_incoming_notification.claimed_by =:= undefined ]),
                QC = qlc:cursor(QH),
                Answers = qlc:next_answers(QC, 1),
                next_unassigned(Answers)
        end,
    mnesia:activity(transaction, F).

max_key() ->
    F = fun() ->
                case mnesia:last(egara_incoming_notification) of
                    '$end_of_table' -> 0;
                    Key -> Key
                end
        end,
    mnesia:activity(transaction, F).

