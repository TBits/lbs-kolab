%% Copyright 2014-2016 Kolab Systems AG (http://www.kolabsys.com)
%%
%% Aaron Seigo (Kolab Systems) <seigo a kolabsys.com>
%%
%% This program is free software: you can redistribute it and/or modify
%% it under the terms of the GNU General Public License as published by
%% the Free Software Foundation, either version 3 of the License, or
%% (at your option) any later version.
%%
%% This program is distributed in the hope that it will be useful,
%% but WITHOUT ANY WARRANTY; without even the implied warranty of
%% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%% GNU General Public License for more details.
%%
%% You should have received a copy of the GNU General Public License
%% along with this program.  If not, see <http://www.gnu.org/licenses/>.

-module(egara_payload_cyrus).
-export([remote_payload_for_message/5, async_payload_for_message/5, payload_for_message/4,
         remote_groupwareuid_for_message/5, async_groupwareuid_for_message/5, groupwareuid_for_message/4]).

remote_payload_for_message(Node, SharedPrefix, PathDelim, FolderUri, MessageUid) ->
    spawn_link(Node, ?MODULE, async_payload_for_messages, [self(), SharedPrefix, PathDelim, FolderUri, MessageUid]),
    %%TODO: error on timeout
    receive
        { payload_for_message, Response } -> Response
    end.

-spec async_payload_for_message(Pid :: pid(), SharedPrefix :: string(), PathDelim :: string(), FolderUri :: binary(), MessageUid :: integer()) -> list({ Key :: binary(), Value :: binary() }).
async_payload_for_message(Pid, SharedPrefix, PathDelim, FolderUri, MessageUid) ->
    Pid ! { payload_for_message, payload_for_message(SharedPrefix, PathDelim, FolderUri, MessageUid) }.

-spec payload_for_message(SharedPrefix :: string(), PathDelim :: string(), FolderUri :: binary(), MessageUid :: integer()) -> list({ Key :: binary(), Value :: binary() }).
payload_for_message(SharedPrefix, PathDelim, FolderUri, MessageUid) ->
    %%TODO determine if this can / should be cached to avoid repetition
    FsPath = filesystem_folder_path(SharedPrefix, PathDelim, FolderUri),
    FsFilePath = FsPath ++ "/" ++ integer_to_list(MessageUid) ++ ".",
    parse_payload(file:open(FsFilePath, [read, raw, binary])).

-spec parse_payload({ ok, IoDevice :: any() } | any()) -> binary().
parse_payload({ ok, IoDevice }) ->
    Rv = parse_payload_headers(IoDevice),
    file:close(IoDevice),
    Rv;
parse_payload(_) ->
    %% could not open file, just return nothing
    [ { flags, [] }, { headers, [] }, { message, <<"">> }].

parse_payload_headers(IoDevice) ->
    parse_payload_headers(IoDevice, [], [], <<>>, <<>>, file:read_line(IoDevice)).

parse_payload_headers(IoDevice, Flags, Headers, Body, CurrentHeader, { ok, <<"\n">> = Line }) ->
    parse_payload_body(IoDevice, Flags, add_header(CurrentHeader, Headers), <<Body/binary, Line/binary>>);
parse_payload_headers(IoDevice, Flags, Headers, Body, CurrentHeader, { ok, <<"--=", _Value/binary>> = Line}) ->
    parse_payload_body(IoDevice, Flags, add_header(CurrentHeader, Headers), <<Body/binary, Line/binary>>);
parse_payload_headers(IoDevice, Flags, Headers, Body, CurrentHeader, { ok, <<" ", Rest/binary>> = Line }) ->
    parse_payload_headers(IoDevice, Flags, Headers, <<Body/binary, Line/binary>>, <<CurrentHeader/binary, Rest/binary>>, file:read_line(IoDevice));
parse_payload_headers(IoDevice, Flags, Headers, Body, CurrentHeader, { ok, Line }) ->
    parse_payload_headers(IoDevice, Flags, add_header(CurrentHeader, Headers), <<Body/binary, Line/binary>>, Line, file:read_line(IoDevice));
parse_payload_headers(_IoDevice, Flags, Headers, Body, CurrentHeader, _) ->
    %% error or end of file
    [ { flags, Flags }, { headers, add_header(CurrentHeader, Headers) }, { message, Body }].

add_header(<<>>, Headers) ->
    Headers;
add_header(NewHeader, Headers) ->
    case binary:match(NewHeader, <<": ">>) of
        nomatch ->
            Headers;
        { Start, Length } ->
            [{ binary:part(NewHeader, 0, Start), binary:part(NewHeader, Start + Length, size(NewHeader) - Start - Length - 1) } | Headers]
    end.

parse_payload_body(IoDevice, Flags, Headers, Body) ->
    parse_payload_body(IoDevice, Flags, Headers, Body, file:read(IoDevice, 8 * 1024)).

parse_payload_body(IoDevice, Flags, Headers, Body, { ok, Data }) ->
    parse_payload_body(IoDevice, Flags, Headers, <<Body/binary, Data/binary>>, file:read(IoDevice, 8 * 1024));
parse_payload_body(_IoDevice, Flags, Headers, Body, _) ->
    [ { flags, Flags }, { headers, Headers }, { message, Body }].



-spec remote_groupwareuid_for_message(Node :: node(), SharedPrefix :: string(), PathDelim :: string(), FolderUri :: binary(), MessageUid :: integer()) -> binary().
remote_groupwareuid_for_message(Node, SharedPrefix, PathDelim, FolderUri, MessageUid) ->
    spawn_link(Node, ?MODULE, async_groupwareuid_for_message, [self(), SharedPrefix, PathDelim, FolderUri, MessageUid]),
    %%TODO: error on timeout
    receive
        { payload_for_message, Response } -> Response
    end.

-spec async_groupwareuid_for_message(Pid :: pid(), SharedPrefix :: string(), PathDelim :: string(), FolderUri :: binary(), MessageUid :: integer()) -> binary().
async_groupwareuid_for_message(Pid, SharedPrefix, PathDelim, FolderUri, MessageUid) ->
    Pid ! groupwareuid_for_message(SharedPrefix, PathDelim, FolderUri, MessageUid).

-spec groupwareuid_for_message(SharedPrefix :: string(), PathDelim :: string(), FolderUri :: binary(), MessageUid :: integer()) -> binary().
groupwareuid_for_message(SharedPrefix, PathDelim, FolderUri, MessageUid) ->
    %%TODO determine if this can / should be cached to avoid repetition
    FsPath = filesystem_folder_path(SharedPrefix, PathDelim, FolderUri),
    FsFilePath = FsPath ++ "/" ++ integer_to_list(MessageUid) ++ ".",
    find_groupwareuid_in_file(file:open(FsFilePath, [read, raw, binary])).

-spec filesystem_folder_path(SharedPrefix :: string(), PathDelim :: string(), FolderUri :: binary()) -> string().
filesystem_folder_path(SharedPrefix, PathDelim, FolderUri) ->
    FolderPath = http_uri:decode(binary_to_list(eimap_utils:extract_path_from_uri(SharedPrefix, PathDelim, FolderUri))),
    FsPathRaw = os:cmd(["/usr/lib/cyrus-imapd/mbpath", " ", FolderPath]),
    string:strip(FsPathRaw, right, $\n).

-spec find_groupwareuid_in_file({ ok, IoDevice :: any() } | any()) -> binary().
find_groupwareuid_in_file({ ok, IoDevice }) ->
    GroupwareUid = find_groupwareuid_in_file(IoDevice, unknown, unknown, file:read_line(IoDevice)),
    file:close(IoDevice),
    GroupwareUid;
find_groupwareuid_in_file(_) ->
    %% could not open file, just return nothing
    <<"">>.

-spec find_groupwareuid_in_file(IoDevice :: any(), Type :: unknown | binary(), Subject :: unknown | binary(), Line :: { ok, binary()} | { error, binary()} | eof) -> binary().
find_groupwareuid_in_file(IoDevice, _Type, Subject, { ok, <<"X-Kolab-Type: ", Value/binary>>}) ->
    case Subject of
        unknown -> find_groupwareuid_in_file(IoDevice, Value, Subject, file:read_line(IoDevice));
        _ -> Subject
    end;
find_groupwareuid_in_file(IoDevice, Type, _Subject, { ok, <<"Subject: ", Value/binary>> }) ->
    case Type of
        unknown -> find_groupwareuid_in_file(IoDevice, Type, Value, file:read_line(IoDevice));
        _ -> binary:part(Value, 0, size(Value) - 1)
    end;
find_groupwareuid_in_file(_IoDevice, _Type, _Subject, { ok, <<"--=", _Value/binary>>}) ->
    <<"">>;
find_groupwareuid_in_file(IoDevice, Type, Subject, { ok, _Line }) ->
    find_groupwareuid_in_file(IoDevice, Type, Subject, file:read_line(IoDevice));
find_groupwareuid_in_file(_IoDevice, _Type, _Subject, _) ->
    <<"">>.

