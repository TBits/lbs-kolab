%% Copyright 2014 Kolab Systems AG (http://www.kolabsys.com)
%%
%% Aaron Seigo (Kolab Systems) <seigo a kolabsys.com>
%%
%% This program is free software: you can redistribute it and/or modify
%% it under the terms of the GNU General Public License as published by
%% the Free Software Foundation, either version 3 of the License, or
%% (at your option) any later version.
%%
%% This program is distributed in the hope that it will be useful,
%% but WITHOUT ANY WARRANTY; without even the implied warranty of
%% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%% GNU General Public License for more details.
%%
%% You should have received a copy of the GNU General Public License
%% along with this program.  If not, see <http://www.gnu.org/licenses/>.

-module(egara_worker).

-behaviour(gen_server).

%% API
-export([start_link/1]).

%% gen_server callbacks
-export([init/1, handle_call/3, handle_cast/2, handle_info/2, terminate/2, code_change/3]).
-define(BATCH_SIZE, 500).

-record(state, { archival = [], event_mapping, storage, imap, user_blacklist, imap_path_delim = "/", imap_shared_prefix = none, process_key }).
-record(message_event_getfolderuid_data, { folder, notification_queue_key, source_node, notification, event_type }).
-record(message_event_getoldfolderuid_data, { folder_uid, uidset, source_node, notification_queue_key, notification, old_folder_path, old_uid_set }).

start_link(Args) -> gen_server:start_link(?MODULE, Args, []).

init(_Args) ->
    %% EventMapping is a map of event types (e.g. <<"FlagsClear">>) to the type of
    %% event (e.g. imap_mesage_event) for routing the notifications through the handler
    EventMapping = transform_events_config_to_dict(application:get_env(egara, events_to_track)),
    { ok, Storage } = egara_storage:start_link(),
    %% get the admin user, whose events we will ignore
    Archival = application:get_env(egara, archival, []),
    ImapConfig = application:get_env(egara, imap, []),
    UserBlacklist = lists:foldl(fun(User, Acc) -> [list_to_binary(User)|Acc] end, [], proplists:get_value(user_blacklist, ImapConfig, [])),
    ImapServerConfig = proplists:get_value(admin_connection, ImapConfig),
    Imap = start_imap(ImapServerConfig),
    ProcessKey = { node(),  erlang:unique_integer([monotonic]) },
    syn:register(ProcessKey, self()),
    State = #state{ archival = Archival, event_mapping = EventMapping, imap = Imap, storage = Storage, user_blacklist = UserBlacklist, process_key = ProcessKey },
    { ok, State }.

handle_call(_Request, _From, State) ->
    { reply, ok, State }.

handle_cast(process_events, State) ->
    process_as_many_events_as_possible(State, ?BATCH_SIZE),
    { noreply, State };

handle_cast(_Msg, State) ->
    { noreply, State }.

%%TODO: 4 of the handle_info variants are for mailbox metadata fetching; abstract & consolidate?
handle_info({ get_path_tokens, { SharedPrefix, Delim } }, State) ->
    NewState = State#state{ imap_shared_prefix = SharedPrefix, imap_path_delim = Delim },
    { noreply, NewState };
handle_info({ { imap_mailbox_metadata, Folder, NotificationQueueKey, Notification }, Metadata }, State) ->
    %lager:info("Got imap_mailbox_metadata ~p", [Metadata]),
    Uid = proplists:get_value(eimap_utils:header_name(mailbox_uid), Metadata, undefined),
    %%lager:info("Uid is ~p", [Uid]),
    NotificationWithMetadata = [ { <<"metadata">>, Metadata } | Notification ],
    Result = store_folder_notification_with_uid(Uid, Folder, NotificationWithMetadata, State#state.storage),
    notification_processing_result(NotificationQueueKey, Result, State),
    { noreply, State };
handle_info({ #message_event_getfolderuid_data{ folder = Folder, notification_queue_key = NotificationQueueKey,
                                                source_node = SourceNode, notification = Notification, event_type = EventType }, Metadata }, State) ->
    %%TODO: and if we somehow end up with a folder we can't find, or the uniqueid is not there?
    FolderUid = proplists:get_value(eimap_utils:header_name(mailbox_uid), Metadata),
    %%lager:info("Folder Uid to be stored ~p", [FolderUid]),
    egara_storage:store_folder_uid(State#state.storage, Folder, FolderUid),
    Result = store_message_event(State, FolderUid, SourceNode, Notification, EventType, NotificationQueueKey),
    notification_processing_result(NotificationQueueKey, Result, State),
    { noreply, State };
handle_info({ #message_event_getoldfolderuid_data{ folder_uid = FolderUid, uidset = UidSet,
                                                   notification_queue_key = NotificationQueueKey,
                                                   source_node = SourceNode,
                                                   notification = Notification,
                                                   old_folder_path = OldFolderPath, old_uid_set = OldUidSet}, Metadata }, State) ->
    OldFolderUid = proplists:get_value(<<"/vendor/cmu/cyrus-imapd/uniqueid">>, Metadata),
    egara_storage:store_folder_uid(State#state.storage, OldFolderPath, OldFolderUid),
    Timestamp = timestamp_from_notification(Notification),
    Result = store_history_with_archival(State, SourceNode, Notification, Timestamp, FolderUid, UidSet, OldFolderUid, OldUidSet, NotificationQueueKey),
    notification_processing_result(NotificationQueueKey, Result, State),
    { noreply, State };
handle_info(_Info, State) ->
    { noreply, State }.

terminate(_Reason, _State) ->
    ok.

code_change(_OldVsn, State, _Extra) ->
    { ok, State }.

%% private API

%% init() helpers
start_imap(ImapServerConfig) ->
    { ok, ImapSession } = eimap:start_link(ImapServerConfig),
    eimap:connect(ImapSession),
    %%eimap:starttls(ImapSession, undefined, undefined),
    eimap:login(ImapSession, undefined, undefined,
                proplists:get_value(user, ImapServerConfig, ""),
                proplists:get_value(pass, ImapServerConfig, "")),
    eimap:get_path_tokens(ImapSession, self(), get_path_tokens),
    ImapSession.

transform_events_config_to_dict({ ok, EventConfig }) ->
    lists:foldl(fun({ Type, Events }, EventMap) -> add_events_to_dict(Type, Events, EventMap) end, dict:new(), EventConfig);
transform_events_config_to_dict(_) ->
    dict:new(). %% return an empty map .. this is going to be boring

add_events_to_dict(Type, Events, EventMap) when is_list(Events) ->
    F = fun(Event, Map) ->
                EventBin = list_to_binary(Event),
                case dict:is_key(EventBin, Map) of
                   true -> dict:update(EventBin, Type, Map);
                   _ -> dict:store(EventBin, Type, Map)
                end
            end,
    lists:foldl(F, EventMap, Events);
add_events_to_dict(_Type, _Events, EventMap) ->
    EventMap.

%%
add_entry_to_notification(Key, undefined, Notification) when is_binary(Key) ->
    Notification;
add_entry_to_notification(headers, Value, Notification) when is_list(Value) ->
    NotificationWithGroupwareUid =
    case groupware_uid_from_headers(Value) of
        undefined -> Notification;
        GroupwareUid -> [{ <<"groupware_uid">>, GroupwareUid } | Notification]
    end,
    [{ <<"headers">>, Value } | NotificationWithGroupwareUid];
add_entry_to_notification(Atom, Value, Notification) when is_atom(Atom) ->
    Key = atom_to_binary(Atom, utf8),
    [{ Key, Value } | Notification];
add_entry_to_notification(Key, Value, Notification) when is_binary(Key) ->
    [{ Key, Value } | Notification].

groupware_uid_from_headers(Headers) when is_list(Headers) ->
    groupware_uid_from_headers(Headers, proplists:get_value(<<"X-Kolab-Type">>, Headers));
groupware_uid_from_headers(_) ->
    undefined.

groupware_uid_from_headers(_Headers, undefined) ->
    undefined;
groupware_uid_from_headers(Headers, _) ->
    proplists:get_value(<<"Subject">>, Headers).


store_folder_notification_with_uid(undefined, _Folder, Notification, _Storage) ->
    lager:warning("Could not find Uid for notification ~p", [Notification]),
    ok;
store_folder_notification_with_uid(Uid, Folder, Notification, Storage) ->
    Key = generate_folder_event_key(Uid, Notification),
    %%lager:info("Storing folder notification with key ~p", [Key]),
    egara_storage:store_folder_uid(Storage, Folder, Uid),
    egara_storage:store_notification(Storage, Key, Notification).

store_message_event(State, FolderUid, SourceNode, Notification, EventType, NotificationQueueKey)
    when EventType =:= <<"MessageNew">> orelse
         EventType =:= <<"MessageAppend">> orelse
         EventType =:= <<"MessageCopy">> orelse
         EventType =:= <<"MessageMove">> ->
    %lager:info("Storing a message event of type ~p", [EventType]),
    %% we need to fetch message content here and begin generating history events while doing so
    { NotificationWithUidSet, UidSet } = uidset_from_notification(Notification),
    OldFolderUri = proplists:get_value(<<"oldMailboxID">>, Notification),
    case old_location(State, Notification, OldFolderUri) of
        { undefined, OldUidSet } ->
            %% we don't have the UID for the older folder, let's go fetch it
            OldFolderPath = eimap_utils:extract_path_from_uri(State#state.imap_shared_prefix, State#state.imap_path_delim, OldFolderUri),
            lager:debug("Fetching folder UID for ~p", [OldFolderPath]),
            Data = #message_event_getoldfolderuid_data{ folder_uid = FolderUid,
                                                        uidset = UidSet,
                                                        notification_queue_key = NotificationQueueKey,
                                                        source_node = SourceNode,
                                                        notification = NotificationWithUidSet,
                                                        old_folder_path = OldFolderPath, old_uid_set = OldUidSet },
            start_imap_mailbox_metadata_fetch(Data, OldFolderPath, State);
        { OldFolderUid, OldUidSet } ->
            Timestamp = timestamp_from_notification(Notification),
            store_history_with_archival(State, SourceNode, NotificationWithUidSet, Timestamp, FolderUid, UidSet, OldFolderUid, OldUidSet, NotificationQueueKey)
    end;
store_message_event(State, FolderUid, _SourceNode, Notification, _EventType, _NotificationQueueKey) ->
    %lager:info("Storing a message event of type ~p", [EventType]),
    { NotificationWithUidSet, UidSet } = uidset_from_notification(Notification),
    Timestamp = timestamp_from_notification(Notification),
    %lager:info("storing an imap_message_event with uidset ~p", [UidSet]),
    store_next_message_event(State, NotificationWithUidSet, Timestamp, FolderUid, eimap_uidset:next_uid(UidSet)).

store_next_message_event(_State, _Notification, _Timestamp, _FolderUid, { none, _UidSet }) ->
    ok;
store_next_message_event(#state{ storage = Storage } = State, Notification, Timestamp, FolderUid, { MessageUid, UidSet } ) ->
    Key = generate_message_event_key(FolderUid, MessageUid, Timestamp),
    egara_storage:store_notification(Storage, Key, Notification),
    store_next_message_event(State, Notification, Timestamp, FolderUid, eimap_uidset:next_uid(UidSet)).

old_location(_State, _Notification, undefined) ->
    OldFolderUid = <<"">>,
    %% TODO: ugly magic value; next version of eimap has eimap_uidset:empty_uidset()
    OldUidSet = eimap_uidset:parse(<<",">>),
    { OldFolderUid, OldUidSet };
old_location(State, Notification, OldFolderUri) ->
    OldUidSet = eimap_uidset:parse(proplists:get_value(<<"vnd.cmu.oldUidset">>, Notification)),
    OldFolderPath = eimap_utils:extract_path_from_uri(State#state.imap_shared_prefix, State#state.imap_path_delim, OldFolderUri),
    OldFolderUid = egara_storage:fetch_folder_uid(State#state.storage, OldFolderPath),
    { OldFolderUid, OldUidSet }.

uidset_from_notification(Notification) ->
    uidset_from_notification(Notification, proplists:get_value(<<"uidset">>, Notification)).

uidset_from_notification(Notification, undefined) ->
    UidSetString = eimap_utils:extract_uidset_from_uri(proplists:get_value(<<"uri">>, Notification, <<>>)),
    { [{ <<"uidset">>, UidSetString }|Notification], eimap_uidset:parse(UidSetString) };
uidset_from_notification(Notification, UidSetString) ->
    { Notification, eimap_uidset:parse(UidSetString) }.

processing_done() ->
    poolboy:checkin(egara_notification_workers, self()),
    egara_notifications_processor:queue_drained(),
    ok.

process_as_many_events_as_possible(_State, 0) ->
    processing_done();
process_as_many_events_as_possible(#state { process_key = ProcessKey } = State, N) ->
    Status = egara_notification_queue:assign_one(ProcessKey),
    lager:debug("~p (~p) is starting to process:  ~p", [ProcessKey, self(), Status]),
    case notification_assigned(State, Status) of
        again ->
            process_as_many_events_as_possible(State, N - 1);
        _ ->
            processing_done()
    end.

notification_assigned(_State, notfound) ->
    %%lager:info("Checking in ~p", [self()]),
    done;
notification_assigned(State, { QueueKey, SourceNode, Notification } ) ->
    EventType = proplists:get_value(<<"event">>, Notification),
    EventCategory = dict:find(EventType, State#state.event_mapping),
    %%lager:info("Type is ~p which maps to ~p", [EventType, EventCategory]),
    Result = process_notification_by_category(State, SourceNode, Notification, EventCategory, EventType, QueueKey),
    notification_processing_result(QueueKey, Result, State).

notification_processing_result(QueueKey, ok, _State) ->
    %%lager:info("Done with ~p", [QueueKey]),
    egara_notification_queue:remove(QueueKey),
    again;
notification_processing_result(QueueKey, unrecoverable_error, _State) ->
    lager:error("Event ~p could not be processed, dropping on floor", [QueueKey]),
    egara_notification_queue:remove(QueueKey),
    again;
notification_processing_result(QueueKey, ignore, _State) ->
    %%lager:info("Ignoring ~p", [QueueKey]),
    egara_notification_queue:remove(QueueKey),
    again;
notification_processing_result(_, continuing, _State) ->
    again;
notification_processing_result(QueueKey, _, _State) ->
    egara_notification_queue:release(QueueKey, self()),
    error.

process_notification_by_category(State, SourceNode, Notification, { ok, Category }, Type, QueueKey) ->
    %% this version, with the { ok, _ } tuple is called due to maps:find returning { ok, Value }
    %% it is essentially a forwarder to other impls below
    case ensure_username(State, Notification, proplists:get_value(<<"user">>, Notification)) of
        ignore -> ignore;
        NotificationWithUsername ->
            process_notification_of_category(State, SourceNode, NotificationWithUsername, Category, Type, QueueKey)
    end;
process_notification_by_category(_State, _SourceNode, _Notification, _CategoryFail, _Type, _QueueKey) ->
    %% in here we have a notification that is not in our configuration
    ignore.

process_notification_of_category(State, SourceNode, Notification, imap_message_event, Type, QueueKey) ->
    case stored_folder_uid_from_notification(State, Notification) of
        notfound ->
            Folder = normalized_folder_path_from_notification(Notification, State),
            Data = #message_event_getfolderuid_data{ folder = Folder, notification_queue_key = QueueKey, source_node = SourceNode, notification = Notification, event_type = Type },
            start_imap_mailbox_metadata_fetch(Data, Folder, State),
            continuing;
        FolderUid ->
            store_message_event(State, FolderUid, SourceNode, Notification, Type, QueueKey)
    end;
process_notification_of_category(State, _SourceNode, Notification, imap_mailbox_event, _Type, QueueKey) ->
    case stored_folder_uid_from_notification(State, Notification) of
        notfound ->
            Folder = normalized_folder_path_from_notification(Notification, State),
            start_imap_mailbox_metadata_fetch({ imap_mailbox_metadata, Folder, QueueKey, Notification }, Folder, State),
            continuing;
        Uid ->
            Key = generate_folder_event_key(Uid, Notification),
            egara_storage:store_notification(State#state.storage, Key, Notification)
    end;
process_notification_of_category(State, _SourceNode, Notification, imap_session_event, Type, _QueueKey) ->
    Key = generate_session_event_key(Type, Notification),
    %%lager:info("storing an imap_session_event with key ~p", [Key]),
    egara_storage:store_notification(State#state.storage, Key, Notification);
process_notification_of_category(State, Notification, imap_quota_event, _Type, _QueueKey, _SourceNode) ->
    UserId = userid_from_notification(Notification),
    Timestamp = timestamp_from_notification(Notification),
    Key = <<"quota::", UserId/binary, "::", Timestamp/binary>>,
    %%lager:info("storing an imap_quota_event with key ~p", [Key]),
    egara_storage:store_notification(State#state.storage, Key, Notification);
process_notification_of_category(_State, _Notification, Category, Type, _QueueKey_, _SourceNode) ->
    lager:warning("We received a notification we are configured to process, but have no implementation to do so. Category: ~p, Type: ~p", [Category, Type]),
    ignore.

userid_from_notification(Notification) ->
    case proplists:get_value(<<"user_id">>, Notification, unknown) of
        unknown ->
            %lager:info("Couldn't find the user_id in ~p", [Notification]),
            proplists:get_value(<<"user">>, Notification, <<"unknown_user">>);
        UserId -> UserId
    end.

timestamp_from_notification(Notification) ->
    case proplists:get_value(<<"timestamp">>, Notification, unknown) of
        unknown -> egara_utils:current_timestamp();
        Timestamp -> egara_utils:normalize_timestamp(Timestamp)
    end.

ensure_username(_State, Notification, undefined) ->
    Notification;
ensure_username(State, Notification, UserLogin) ->
    case lists:member(UserLogin, State#state.user_blacklist) of
        false ->
            FromStorage = egara_storage:fetch_userdata_for_login(State#state.storage, UserLogin),
            %%lager:info("Storage said ... ~p", [FromStorage]),
            add_username_from_storage(State#state.storage, Notification, UserLogin, FromStorage);
        _ -> ignore
    end.

add_username_from_storage(Storage, Notification, UserLogin, notfound) ->
    LDAP = poolboy:checkout(egara_ldap_pool, false, 10),
    RV = query_ldap_for_username(Storage, Notification, UserLogin, LDAP),
    poolboy:checkin(egara_ldap_pool, LDAP),
    RV;
add_username_from_storage(_Storage, Notification, _UserLogin, UserData) ->
    [ { <<"user_id">>, egara_utils:as_binary(proplists:get_value(<<"id">>, UserData, <<"">>)) } | Notification ].

query_ldap_for_username(Storage, Notification, UserLogin, LDAP) when is_pid(LDAP) ->
    FromLDAP = egara_ldap:fetch_userdata_for_login(LDAP, UserLogin),
    add_username_from_ldap(Storage, Notification, UserLogin, FromLDAP);
query_ldap_for_username(_Storage, Notification, _UserLogin, _) ->
    lager:warning("Unable to get an LDAP worker"),
    Notification.

add_username_from_ldap(_Storage, Notification, _UserLogin, notfound) ->
    %%lager:info("LDAP said notfound"),
    Notification;
add_username_from_ldap(Storage, Notification, UserLogin, UserData) ->
    %%lager:info("LDAP gave us back ... ~p", [UserData]),
    egara_storage:store_userdata(Storage, UserLogin, UserData),
    UserIdTuple = { <<"user_id">>, egara_utils:as_binary(proplists:get_value(<<"id">>, UserData, <<"">>)) },
    [ UserIdTuple | Notification ].

normalized_folder_path_from_notification(Notification, State) ->
    Uri = proplists:get_value(<<"uri">>, Notification),
    eimap_utils:extract_path_from_uri(State#state.imap_shared_prefix, State#state.imap_path_delim, Uri).

stored_folder_uid_from_notification(State, Notification) ->
    %%TODO caching might help here to avoid hitting storage on every notification
    Folder = normalized_folder_path_from_notification(Notification, State),
    egara_storage:fetch_folder_uid(State#state.storage, Folder).

start_imap_mailbox_metadata_fetch(Data, Folder, #state{ imap = Imap }) ->
    %%lager:info("fetchng mailbox info over IMAP for ~p with data ~p", [Folder, Data]),
    eimap:get_folder_annotations(Imap, self(), Data, Folder).

store_history_with_archival(#state{ archival = Archival } = State, SourceNode, Notification, Timestamp, FolderUid, UidSet, OldFolderUid, OldUidSet, _NotificationQueueKey) ->
    case lists:member(groupware_object, Archival) of
        true ->
            %% need to perform archival, so hold up on storing the event until then
            store_message_history_entries(State, SourceNode, Notification, Timestamp, FolderUid, UidSet, OldFolderUid, OldUidSet, with_payload);
        _ ->
            store_message_history_entries(State, SourceNode, Notification, Timestamp, FolderUid, UidSet, OldFolderUid, OldUidSet, no_archival)
    end.

groupwareuid_for_message(#state{ imap_shared_prefix = SharedPrefix, imap_path_delim = PathDelim }, SourceNode, Notification, MessageUid) ->
    case proplists:get_value(<<"groupware_uid">>, Notification) of
        undefined ->
            FolderUri = proplists:get_value(<<"uri">>, Notification, <<>>),
            GroupwareUid = egara_payload_cyrus:remote_groupwareuid_for_message(SourceNode, SharedPrefix, PathDelim, FolderUri, MessageUid),
            { GroupwareUid, [{ <<"groupware_uid">>, GroupwareUid } | Notification] };
        Value -> { Value, Notification }
    end.

store_message_history_entries(State, SourceNode, Notification, Timestamp, FolderUid, UidSet, OldFolderUid, OldUidSet, WithPayload) ->
    %lager:info("*** Going to store using ~p ~p ~p", [UidSet, OldUidSet, Notification]),
    store_next_message_history_entry(State, SourceNode, Notification, Timestamp, FolderUid, eimap_uidset:next_uid(UidSet), OldFolderUid, eimap_uidset:next_uid(OldUidSet), WithPayload).

store_next_message_history_entry(_State, _SourceNode, _Notification, _Timestamp, _FolderUid, { none, _UidSet }, _OldFolderUid, { _OldMessageUid, _OldMessageUidSet }, _WithPayload) ->
    ok;
store_next_message_history_entry(#state{ storage = Storage } = State, SourceNode, Notification, Timestamp, FolderUid, { MessageUid, UidSet }, OldFolderUid, { OldMessageUid, OldUidSet }, WithPayload) ->
    NotificationWithPayload =
        case WithPayload of
            with_payload ->
                FolderUri = proplists:get_value(<<"uri">>, Notification, <<>>),
                Payload = egara_payload_cyrus:payload_for_message(SourceNode, State#state.imap_shared_prefix, State#state.imap_path_delim, FolderUri, MessageUid),
                lists:foldl(fun({ Key, Value }, Acc) -> add_entry_to_notification(Key, Value, Acc) end, Notification, Payload);
            _ ->
                Notification
        end,
    { GroupwareUid, StorableNotification } = groupwareuid_for_message(State, SourceNode, NotificationWithPayload, MessageUid),
    store_message_history_entry(Storage, Timestamp, GroupwareUid, FolderUid, MessageUid, OldFolderUid, OldMessageUid),
    Key = generate_message_event_key(FolderUid, MessageUid, Timestamp),
    egara_storage:store_notification(Storage, Key, StorableNotification),
    store_message_history_entries(State, SourceNode, StorableNotification, Timestamp, FolderUid, UidSet, OldFolderUid, OldUidSet, WithPayload).

store_message_history_entry(Storage, Timestamp, GroupwareUid, NewFolderUid, NewMessageUid, _OldFolderUid, none) ->
    NewMessageUidBin = integer_to_binary(NewMessageUid),
    Key = generate_history_key(Timestamp, GroupwareUid, NewFolderUid, NewMessageUidBin),
    ValueTerm = [{ <<"groupware_uid">>, GroupwareUid }, { <<"history">>, [] }],
    ValueJson = jsx:encode(ValueTerm),
    egara_storage:store_message_history_entry(Storage, Key, ValueJson);
store_message_history_entry(Storage, Timestamp, GroupwareUid, NewFolderUid, NewMessageUid, OldFolderUid, OldMessageUid) ->
    NewMessageUidBin = integer_to_binary(NewMessageUid),
    OldMessageUidBin = integer_to_binary(OldMessageUid),
    Key = generate_history_key(Timestamp, GroupwareUid, NewFolderUid, NewMessageUidBin),
    ValueTerm = [{<<"groupware_uid">>, GroupwareUid }, { <<"history">>, [{ <<"imap">>, [{ <<"previous_id">>, OldMessageUidBin }, { <<"previous_folder">>, OldFolderUid }] }] }],
    ValueJson = jsx:encode(ValueTerm),
    egara_storage:store_message_history_entry(Storage, Key, ValueJson).

%%
%% Generators of keys for use in key/value storage
%%

generate_history_key(Timestamp, undefined, FolderUid, MessageUid) ->
    <<"message::", FolderUid/binary, "::", MessageUid/binary, "::", Timestamp/binary, "::">>;
generate_history_key(Timestamp, GroupwareUid, FolderUid, MessageUid) ->
    <<"message::", FolderUid/binary, "::", MessageUid/binary, "::", Timestamp/binary, "::", GroupwareUid/binary>>.

generate_session_event_key(Type, Notification) ->
    UserId = userid_from_notification(Notification),
    Timestamp = timestamp_from_notification(Notification),
    generate_session_event_key(Type, UserId, Timestamp).

generate_session_event_key(<<"Login">>, UserId, Timestamp) -> generate_session_event_key_with_prefix(<<"session_login">>, UserId, Timestamp);
generate_session_event_key(<<"Logout">>, UserId, Timestamp) -> generate_session_event_key_with_prefix(<<"session_logout">>, UserId, Timestamp);
generate_session_event_key(_, UserId, Timestamp) -> generate_session_event_key_with_prefix(<<"session_event">>, UserId, Timestamp).

generate_session_event_key_with_prefix(Prefix, UserId, Timestamp) -> <<Prefix/binary, "::", UserId/binary, "::", Timestamp/binary>>.

generate_message_event_key(FolderUid, MessageUid, Timestamp) when is_integer(MessageUid) ->
    UidBin = integer_to_binary(MessageUid),
    <<"message::", FolderUid/binary, "::", UidBin/binary, "::", Timestamp/binary>>.

generate_folder_event_key(Uid, Notification) ->
    Timestamp = timestamp_from_notification(Notification),
    <<"mailbox::", Uid/binary, "::", Timestamp/binary>>.

