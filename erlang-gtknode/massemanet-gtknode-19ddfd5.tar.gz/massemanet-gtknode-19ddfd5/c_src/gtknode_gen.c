#include <stdlib.h>
#include "gtknode.h"
#include "../priv/generator/gtk_generated.h"
#include "../priv/generator/gdk_generated.h"
#include "../priv/generator/g_generated.h"
