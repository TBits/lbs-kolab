/* File: example.h */

extern int ivar;

int ifunc();
