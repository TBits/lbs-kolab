/*
 * Copyright (C) 2012  Christian Mollekopf <mollekopf@kolabsys.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#include "upgradeutilities.h"
#include <kolabobject.h>
#include <kcalconversion.h>
#include <kdebug.h>

#include <kolabevent.h>
#include <kolabformat.h>
#include <errorhandler.h>
#include <kcalcore/event.h>
#include <kdatetime.h>
#include <ksystemtimezone.h>

namespace Kolab {
    namespace Upgrade {

static void fixupIncidence(const KCalCore::Incidence::Ptr &incidence, UpgradeOptions upgradeOptions)
{
    if (upgradeOptions.fixUtcIncidences) {
        if (incidence->dtStart().isUtc()) {
            if (upgradeOptions.fixUtcIncidencesTimezone.isValid()) {
                incidence->shiftTimes(upgradeOptions.fixUtcIncidencesTimezone, KDateTime::Spec::ClockTime());
            } else if (upgradeOptions.fixUtcIncidencesWithOffset) {
                incidence->shiftTimes(KDateTime::Spec::OffsetFromUTC(upgradeOptions.fixUtcIncidencesOffset), KDateTime::Spec::ClockTime());
            } else {
                incidence->shiftTimes(KDateTime::Spec::LocalZone(), KDateTime::Spec::ClockTime());
            }
        }
    }
}

bool validateMessage(KMime::Message::Ptr msg, const QList<Kolab::ObjectType>  &expectedType)
{
    Kolab::KolabObjectReader reader;
    const Kolab::ObjectType type = reader.parseMimeMessage(msg);
    if (Kolab::ErrorHandler::errorOccured()) {
        Error() << "Error while parsing message.";
        return false;
    }
    if (!expectedType.isEmpty() && !expectedType.contains(type)) {
        Error() << "The object has the wrong type. Expected " << expectedType << " but got " << type;
        return false;
    }
    return true;
}

KMime::Message::Ptr upgradeMessage(KMime::Message::Ptr msg, UpgradeOptions upgradeOptions)
{
    Kolab::ObjectType overrideObjectType = upgradeOptions.overrideObjectType;
    Kolab::KolabObjectReader reader;
    if (overrideObjectType != Kolab::InvalidObject) {
        reader.setObjectType(overrideObjectType);
    }
    const Kolab::ObjectType type = reader.parseMimeMessage(msg);
    if (Kolab::ErrorHandler::errorOccured()) {
        Error() << "Error while parsing message.";
        return KMime::Message::Ptr();
    }
    KMime::Message::Ptr convertedMessage;
    switch (type) {
        case Kolab::EventObject: {
            KCalCore::Event::Ptr event = reader.getEvent();
            fixupIncidence(event, upgradeOptions);
            convertedMessage = Kolab::KolabObjectWriter::writeEvent(event);
        }
            break;
        case Kolab::TodoObject: {
            KCalCore::Todo::Ptr todo = reader.getTodo();
            fixupIncidence(todo, upgradeOptions);
            convertedMessage = Kolab::KolabObjectWriter::writeTodo(todo);
        }
            break;
        case Kolab::JournalObject: {
            KCalCore::Journal::Ptr journal = reader.getJournal();
            fixupIncidence(journal, upgradeOptions);
            convertedMessage = Kolab::KolabObjectWriter::writeJournal(journal);
        }
            break;
        case Kolab::ContactObject:
            convertedMessage = Kolab::KolabObjectWriter::writeContact(reader.getContact());
            break;
        case Kolab::DistlistObject:
            convertedMessage = Kolab::KolabObjectWriter::writeDistlist(reader.getDistlist());
            break;
        case Kolab::NoteObject:
            convertedMessage = Kolab::KolabObjectWriter::writeNote(reader.getNote());
            break;
        case Kolab::DictionaryConfigurationObject: {
            QString lang;
            const QStringList &dict = reader.getDictionary(lang);
            convertedMessage = Kolab::KolabObjectWriter::writeDictionary(dict, lang);
        }
            break;
        case Kolab::InvalidObject:
        default:
            //TODO handle configuration objects
            Error() << "failed to read mime file";
    }
    if (Kolab::ErrorHandler::errorOccured()) {
        Error() << "Error while writing out converted message.";
        return KMime::Message::Ptr();
    }
    return convertedMessage;
}
        
/**
 * Upgrades the format of a complete mime message containing a kolab object
 */
QString upgradeMime(const QByteArray &input, UpgradeOptions upgradeOptions)
{
    KMime::Message::Ptr msg = KMime::Message::Ptr(new KMime::Message);
    msg->setContent( KMime::CRLFtoLF(input) );
    msg->parse();
    msg->content(KMime::ContentIndex());
        
    KMime::Message::Ptr message = upgradeMessage(msg, upgradeOptions);
    if (!message) {
        return QString();
    }

    QString result;
    QTextStream s(&result);
    message->toStream(s);
    return result;
}



QString upgradeEventXML(const QByteArray &xmlData, QStringList &attachments)
{
    const KCalCore::Event::Ptr i = Kolab::readV2EventXML(xmlData, attachments);
    const Kolab::Event &event = Kolab::Conversion::fromKCalCore(*i);
    const std::string &v3String = Kolab::writeEvent(event);
    return QString::fromStdString(v3String);
}


    }
}
