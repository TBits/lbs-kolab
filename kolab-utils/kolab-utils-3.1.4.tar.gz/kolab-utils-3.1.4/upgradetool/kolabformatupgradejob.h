/*
    <one line to give the library's name and an idea of what it does.>
    Copyright (C) 2012  Christian Mollekopf <chrigi_1@fastmail.fm>

    This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU Affero General Public
    License as published by the Free Software Foundation; either
    version 2.1 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    Affero General Public License for more details.

    You should have received a copy of the GNU Affero General Public
    License along with this library; if not, write to the Free Software
    Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
*/


#ifndef KOLABFORMATUPGRADEJOB_H
#define KOLABFORMATUPGRADEJOB_H

#include <kjob.h>
#include <kolabobject.h>
#include <kimap/fetchjob.h>
#include "upgradeutilities.h"

class SequentialCompositeJob;
namespace KIMAP {
class Session;
}

class KolabFormatUpgradeJob : public KJob
{
    Q_OBJECT
public:
    explicit KolabFormatUpgradeJob(const QString &folder, KIMAP::Session *session, QObject* parent = 0);
    void setUpgradeOptions(const Kolab::Upgrade::UpgradeOptions &);
    void setFolderType(const QString &);
    virtual void start();
private slots:
    void onSelectDone(KJob*);
    void onHeadersReceived( const QString &mailBox, const QMap<qint64, qint64> &uids,
                                                   const QMap<qint64, qint64> &sizes,
                                                   const QMap<qint64, KIMAP::MessageFlags> &flags,
                                                   const QMap<qint64, KIMAP::MessagePtr> &messages );
    void onHeadersFetchDone( KJob *job );
    void onModifyFinished( KJob *job );
private:
    KIMAP::Session *m_session;
    QString m_folder;
    QString m_folderType;
    SequentialCompositeJob *seqJob;
    Kolab::Upgrade::UpgradeOptions m_upgradeOptions;
};

#endif // KOLABFORMATUPGRADEJOB_H
