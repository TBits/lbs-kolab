/*
    <one line to give the library's name and an idea of what it does.>
    Copyright (C) 2012  Christian Mollekopf <chrigi_1@fastmail.fm>

    This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU Affero General Public
    License as published by the Free Software Foundation; either
    version 2.1 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    Affero General Public License for more details.

    You should have received a copy of the GNU Affero General Public
    License along with this library; if not, write to the Free Software
    Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
*/


#include "kolabformatupgradejob.h"
#include "upgradeutilities.h"
#include "jobs/sequentialcompositejob.h"
#include "jobs/messagemodifyjob.h"
#include <kolabobject.h>
#include <kolabdefinitions.h>
#include <formathelpers.h>
#include <errorhandler.h>

#include <kimap/selectjob.h>
#include <kimap/fetchjob.h>
#include <kimap/expungejob.h>
#include <kimap/storejob.h>

#include <QStringList>
#include <QFile>
#include <QDir>

const char* FlagDeleted = "\\Deleted";

KolabFormatUpgradeJob::KolabFormatUpgradeJob(const QString& folder, KIMAP::Session* session, QObject* parent)
:   KJob(parent),
    m_session(session),
    m_folder(folder),
    seqJob(new SequentialCompositeJob(this))
{

}

void KolabFormatUpgradeJob::setUpgradeOptions(const Kolab::Upgrade::UpgradeOptions &upgradeOptions)
{
    m_upgradeOptions = upgradeOptions;
}

void KolabFormatUpgradeJob::setFolderType(const QString &folderType)
{
    m_folderType = folderType;
}

void KolabFormatUpgradeJob::start()
{
    Debug() << "Processing Mailbox....... " << m_folder << " of type: " << m_folderType;
    if (m_session->state() == KIMAP::Session::Disconnected) {
        Warning() << "Session is not connected, skipping";
        emitResult();
        return;
    }
    
    KIMAP::SelectJob *select = new KIMAP::SelectJob( m_session );
    select->setMailBox( m_folder );
    connect( select, SIGNAL(result(KJob*)), this, SLOT(onSelectDone(KJob*)) );
    select->start();
}

void KolabFormatUpgradeJob::onSelectDone(KJob *job)
{
    if ( job->error() ) {
        Error() << job->errorString();
        emitResult();
        return;
    }
    
    KIMAP::SelectJob *select = qobject_cast<KIMAP::SelectJob*>( job );
    Q_ASSERT(select);
    
    const int messageCount = select->messageCount();
    
    if (messageCount <= 0) {
        //empty, nothing to do
        emitResult();
        return;
    }
    
    KIMAP::FetchJob::FetchScope scope;
    scope.mode = KIMAP::FetchJob::FetchScope::Full;
        
    KIMAP::FetchJob *fetch = new KIMAP::FetchJob( m_session );
    fetch->setSequenceSet( KIMAP::ImapSet( 1, messageCount ) );
    fetch->setScope( scope );
    connect( fetch, SIGNAL( headersReceived( QString, QMap<qint64, qint64>, QMap<qint64, qint64>,
                                                QMap<qint64, KIMAP::MessageFlags>, QMap<qint64, KIMAP::MessagePtr> ) ),
                this, SLOT( onHeadersReceived( QString, QMap<qint64, qint64>, QMap<qint64, qint64>,
                                            QMap<qint64, KIMAP::MessageFlags>, QMap<qint64, KIMAP::MessagePtr> ) ) );
    connect( fetch, SIGNAL(result(KJob*)),
                this, SLOT(onHeadersFetchDone(KJob*)) );
    fetch->start();
}

static QList<Kolab::ObjectType> getExpectedTypeFromFolderType(const QString &folderType)
{
    switch(Kolab::folderTypeFromString(folderType.toStdString())) {
        case Kolab::MailType:
            return QList<Kolab::ObjectType>();
        case Kolab::ContactType:
            return QList<Kolab::ObjectType>() << Kolab::ContactObject << Kolab::DistlistObject;
        case Kolab::EventType:
            return QList<Kolab::ObjectType>() << Kolab::EventObject;
        case Kolab::TaskType:
            return QList<Kolab::ObjectType>() << Kolab::TodoObject;
        case Kolab::JournalType:
            return QList<Kolab::ObjectType>() << Kolab::JournalObject;
        case Kolab::NoteType:
            return QList<Kolab::ObjectType>() << Kolab::NoteObject;
        case Kolab::ConfigurationType:
            return QList<Kolab::ObjectType>() << Kolab::DictionaryConfigurationObject << Kolab::RelationConfigurationObject;
        case Kolab::FreebusyType:
            return QList<Kolab::ObjectType>() << Kolab::FreebusyObject;
        case Kolab::FileType:
            return QList<Kolab::ObjectType>();
        case Kolab::LastType:
            break;
    }
    return QList<Kolab::ObjectType>();
}

void KolabFormatUpgradeJob::onHeadersReceived( const QString &mailBox, 
                                           const QMap<qint64, qint64> &uids,
                                           const QMap<qint64, qint64> &/*sizes*/,
                                           const QMap<qint64, KIMAP::MessageFlags> &flags,
                                           const QMap<qint64, KIMAP::MessagePtr> &messages )
{
    foreach ( qint64 number, uids.keys() ) {
        const KMime::Message::Ptr &message = messages[number];
        if (m_upgradeOptions.validateMode) {
            const qint64 uid = uids[number];
            if (m_folderType.isEmpty() || m_folderType.contains("mail")) {
                //TODO validate emails if possible?
            } else {
                if (Kolab::Upgrade::validateMessage(message, getExpectedTypeFromFolderType(m_folderType))) {
                    Debug() << "Checked the message with the uid " << uid;
                } else {
                    Error() << "The message with the uid " << uid << " in the folder: " << m_folder << " is invalid!";
                    if (!m_upgradeOptions.saveTo.isEmpty()) {
                        const QString directory = m_upgradeOptions.saveTo + "/" + m_folder;
                        const QString path = directory + "/" + QString::number(uid) + ".eml";
                        Debug() << "Saving message to: " << path;
                        QDir dir;
                        if (!dir.mkpath(directory)) {
                            Warning() << "Failed to create the directory " << directory;
                        }
                        QFile file(path);
                        if (!file.open(QIODevice::WriteOnly|QIODevice::Text)) {
                            Warning() << "Failed to store the message" << uid;
                        } else {
                            QTextStream out(&file);
                            out << message->encodedContent();
                        }
                    }
                    if (!m_upgradeOptions.noDelete) {
                        Debug() << "Deleting message " << uid;

                        KIMAP::StoreJob *store = new KIMAP::StoreJob( m_session );
                        store->setUidBased( true );
                        store->setSequenceSet( KIMAP::ImapSet(uid) );
                        store->setFlags( QList<QByteArray>() << FlagDeleted );
                        store->setMode( KIMAP::StoreJob::AppendFlags );
                        seqJob->addSubjob(store);
                    }
                }
            }
        } else {
            Debug() << "Upgrading message";
            //TODO implement different target folder
            KMime::Message::Ptr msg = Kolab::Upgrade::upgradeMessage(message, m_upgradeOptions);
            //Skip messages that we're already kolabv3
            if (!msg.get()) {
                Error() << "failed to convert message with uid " << QString::number(uids[number]);
                continue;
            }
            seqJob->addSubjob(new MessageModifyJob(msg, mailBox, flags[number], uids[number], m_session, this));
        }
    }
}

void KolabFormatUpgradeJob::onHeadersFetchDone( KJob *job )
{
    if ( job->error() ) {
        Error() << job->errorString();
        emitResult();
        return;
    }

    if (m_upgradeOptions.validateMode) {
        Debug() << "Finished validating the folder: " << m_folder;
    }

    //Run expunge after every modify, while the folder is still selected
    Q_ASSERT(m_session->state() & KIMAP::Session::Selected);
    seqJob->addSubjob(new KIMAP::ExpungeJob(m_session));

    connect(seqJob, SIGNAL(finished(KJob*)), this, SLOT(onModifyFinished(KJob*)));
    seqJob->start();
}

void KolabFormatUpgradeJob::onModifyFinished( KJob *job )
{
//     Debug() << "upgrade done";
    if ( job->error() ) {
        Error() << job->errorString();
    }
    emitResult();
}
