/*
 * Copyright (C) 2012  Christian Mollekopf <mollekopf@kolabsys.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef SETUPKOLABFOLDERSJOB_H
#define SETUPKOLABFOLDERSJOB_H
#include <kjob.h>
#include <qstringlist.h>
#include <qmap.h>

namespace KIMAP {
class Session;
}


class SetupKolabFoldersJob : public KJob
{
    Q_OBJECT
public:
    explicit SetupKolabFoldersJob(const QStringList &serverCapabilities, QString rootFolder, KIMAP::Session *session, QObject* parent = 0);
    virtual void start();

    /**
     * Folders to create as KOLAB_FOLDER_TYPE_* from kolabdefinitions.h
     */
    void setKolabFolders(const QStringList &);
    
    QMap<QString, QString> createdFolders() const;
private slots:
    void onSelectDone(KJob*);
    void onCreateDone(KJob*);

private:
    void createNext();
    void createMailbox(const QString &folderType);
    KIMAP::Session *m_session;
    QStringList m_folderTypes;
    QString m_rootFolder;
    QStringList m_serverCapabilities;
    QMap<QString, QString> m_createdFolders;

};

#endif // SETUPKOLABFOLDERSJOB_H
