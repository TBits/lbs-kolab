/*
 * Copyright (C) 2013  Christian Mollekopf <mollekopf@kolabsys.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "createkolabfolderjob.h"

#include <kimap/createjob.h>
#include <kimap/setmetadatajob.h>
#include <QStringList>

#include <errorhandler.h>
#include <kolabdefinitions.h>

CreateKolabFolderJob::CreateKolabFolderJob(const QString& name, const QByteArray& sharedAnnotation, const QByteArray& privateAnnotation, CreateKolabFolderJob::MetadataCapability cap, KIMAP::Session* session, QObject* parent)
:   KJob(parent),
    m_session(session),
    m_name(name),
    m_sharedAnnotation(sharedAnnotation),
    m_privateAnnotation(privateAnnotation),
    m_metadataCapability(cap)
{

}

void CreateKolabFolderJob::start()
{
    KIMAP::CreateJob *createJob = new KIMAP::CreateJob(m_session);
    createJob->setMailBox(m_name);
    connect(createJob, SIGNAL(result(KJob*)), this, SLOT(onCreateDone(KJob*)));
    createJob->start();
}

CreateKolabFolderJob::MetadataCapability CreateKolabFolderJob::capablitiesFromString(const QString &cap)
{
    if (cap.contains(QLatin1String("ANNOTATEMORE"))) {
        return Annotatemore;
    }
    return Metadata;
}

CreateKolabFolderJob::MetadataCapability CreateKolabFolderJob::capablitiesFromString(const QStringList &cap)
{
    if (cap.contains(QLatin1String("ANNOTATEMORE"))) {
        return Annotatemore;
    }
    return Metadata;
}

void CreateKolabFolderJob::onCreateDone(KJob *job)
{
    if (job->error()) {
        Warning() << job->errorString() << "Trying to fix the metadata";
    } else {
        KIMAP::CreateJob *createJob = static_cast<KIMAP::CreateJob*>(job);
        Debug() << "Created folder " << createJob->mailBox();
    }

    KIMAP::SetMetaDataJob *setMetadataJob = new KIMAP::SetMetaDataJob(m_session);
    setMetadataJob->setMailBox(m_name);
    if ( m_metadataCapability == Metadata ) {
        setMetadataJob->setServerCapability( KIMAP::MetaDataJobBase::Metadata );
        if (!m_sharedAnnotation.isEmpty()) {
            setMetadataJob->addMetaData("/shared" KOLAB_FOLDER_TYPE_ANNOTATION, m_sharedAnnotation);
        }
        if (!m_privateAnnotation.isEmpty()) {
            setMetadataJob->addMetaData("/private" KOLAB_FOLDER_TYPE_ANNOTATION, m_privateAnnotation);
        }
    } else {
        setMetadataJob->setServerCapability( KIMAP::MetaDataJobBase::Annotatemore );
        setMetadataJob->setEntry( KOLAB_FOLDER_TYPE_ANNOTATION );
        if (!m_sharedAnnotation.isEmpty()) {
            setMetadataJob->addMetaData("value.shared", m_sharedAnnotation);
        }
        if (!m_privateAnnotation.isEmpty()) {
            setMetadataJob->addMetaData("value.priv", m_privateAnnotation);
        }
    }
    connect(setMetadataJob, SIGNAL(result(KJob*)), this, SLOT(onMetadataSetDone(KJob*)));
    setMetadataJob->start();
}

void CreateKolabFolderJob::onMetadataSetDone(KJob *job)
{
    if ( job->error() ) {
        Warning() << job->errorString();
        setErrorText("Failed to create folder: " + m_name);
        setError(KJob::UserDefinedError);
    }
    emitResult();
}

QString CreateKolabFolderJob::folder() const
{
    return m_name;
}

