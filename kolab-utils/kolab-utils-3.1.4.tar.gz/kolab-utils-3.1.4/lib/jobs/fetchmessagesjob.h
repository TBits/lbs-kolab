/*
 * Copyright (C) 2012  Christian Mollekopf <mollekopf@kolabsys.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef FETCHMESSAGESJOB_H
#define FETCHMESSAGESJOB_H
#include <kjob.h>
#include <kmime/kmime_message.h>
#include <kimap/session.h>
#include <kimap/fetchjob.h>
#include <object.h>

class FetchMessagesJob: public KJob
{
    Q_OBJECT
public:
    explicit FetchMessagesJob(const QString &folder, KIMAP::Session *, QObject* parent = 0);
    virtual void start();
    void setMaxNumberOfMessagesToFetch(int);
    void setUidsToFetch(const QList<qint64> &uids);
    void setUidsToSkip(const QList<qint64> &uids);
    KIMAP::FetchJob::FetchScope &fetchScope();
    
    //Controls wether mapping are collected or not (otherwise the functions below return nothing)
    void setTransient(bool transient);
    QList<KMime::Message::Ptr> getMessages() const;
    QList<qint64> getImapUids() const;
    KIMAP::MessageFlags getFlags(KMime::Message::Ptr) const;
    qint64 getImapUid(KMime::Message::Ptr) const;
    
Q_SIGNALS:
    void messagesReceived(QString, QList<Object>);
private Q_SLOTS:
    void onSelectDone(KJob *job);
    void onHeadersReceived( const QString &mailBox,
                            const QMap<qint64, qint64> &uids,
                            const QMap<qint64, qint64> &sizes,
                            const QMap<qint64, KIMAP::MessageFlags> &flags,
                            const QMap<qint64, KIMAP::MessagePtr> &messages );
    void onHeadersFetchDone( KJob *job );
    void onMessagesReceived( const QString &mailBox,
                            const QMap<qint64, qint64> &uids,
                            const QMap<qint64, qint64> &sizes,
                            const QMap<qint64, KIMAP::MessageFlags> &flags,
                            const QMap<qint64, KIMAP::MessagePtr> &messages );
    void onMessagesFetchDone( KJob *job );
private:
    void fetchNextBatch();
    KIMAP::Session *mSession;
    KIMAP::FetchJob::FetchScope mFetchScope;
    QString mFolder;

    QMap<qint64, qint64> mUids;
    QMap<qint64, KIMAP::MessageFlags> mFlags;
    QMap<qint64, KIMAP::MessagePtr> mMessages;
    QList<qint64> mUidsToFetch;
    QList<qint64> mUidsToSkip;
    int mNumberOfMessagesToFetch;
    bool mTransient;
    KIMAP::ImapSet mTempSet;
    qint64 mBatchSizeLimit;
    qint64 mBatchSize;
    QList<KIMAP::ImapSet> mBatches;
};

#endif // FETCHMESSAGESJOB_H
