/*
 * Copyright (C) 2012  Christian Mollekopf <mollekopf@kolabsys.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef PROBEKOLABSERVERJOB_H
#define PROBEKOLABSERVERJOB_H
#include <QStringList>
#include <QHash>
#include <kimap/session.h>
#include <kimap/listjob.h>

/**
 * Probeserver for supported IMAP features and existing kolab folders
 */
class ProbeKolabServerJob: public KJob
{
    Q_OBJECT
public:
    explicit ProbeKolabServerJob(KIMAP::Session *, QObject* parent = 0);
    virtual ~ProbeKolabServerJob();
    virtual void start();

    QList<KIMAP::MailBoxDescriptor> personalNamespace() const;
    QList<KIMAP::MailBoxDescriptor> excludedNamespaces() const;
    QStringList capabilities() const;
    QMultiHash<QString, QString> kolabFolders() const;
    QMultiHash<QString, QString> allFolders() const;

    void fetchSharedFolders(bool fetch);

protected Q_SLOTS:
    void onProbeJobDone(KJob *job);
    void findKolabFoldersDone(KJob*);

private:
    KIMAP::Session *mSession;
    QStringList mCapabilities;
    QList<KIMAP::MailBoxDescriptor> mPersonalNamespace;
    QList<KIMAP::MailBoxDescriptor> mExcludedNamespace;
    QMultiHash<QString, QString> mKolabFolders;
    QMultiHash<QString, QString> mAllFolders;
    bool mFetchSharedFolders;
};

#endif // PROBEKOLABSERVERJOB_H
