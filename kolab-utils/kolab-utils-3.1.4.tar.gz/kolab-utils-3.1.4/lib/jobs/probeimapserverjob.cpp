
/*
 * Copyright (C) 2012  Christian Mollekopf <mollekopf@kolabsys.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "probeimapserverjob.h"
#include <kimap/capabilitiesjob.h>
#include <kimap/namespacejob.h>
#include <errorhandler.h>

ProbeIMAPServerJob::ProbeIMAPServerJob(KIMAP::Session *session, QObject* parent)
:   KJob(parent),
    mSession(session)
{

}

ProbeIMAPServerJob::~ProbeIMAPServerJob()
{

}

void ProbeIMAPServerJob::start()
{
    KIMAP::CapabilitiesJob *capabilities = new KIMAP::CapabilitiesJob(mSession);
    connect(capabilities, SIGNAL(result(KJob*)), this, SLOT(onCapabilitiesTestDone(KJob*)));
    capabilities->start();
}

void ProbeIMAPServerJob::onCapabilitiesTestDone(KJob* job)
{
    if ( job->error() ) {
        Warning() << job->errorString();
        setError(KJob::UserDefinedError);
        emitResult();
        return;
    }
    KIMAP::CapabilitiesJob *capabilitiesJob = qobject_cast<KIMAP::CapabilitiesJob*>( job );
    Q_ASSERT(capabilitiesJob);
    mCapabilities = capabilitiesJob->capabilities();
    if ( mCapabilities.contains( "NAMESPACE" ) ) {
        KIMAP::NamespaceJob *nsJob = new KIMAP::NamespaceJob( mSession );
        QObject::connect( nsJob, SIGNAL(result(KJob*)), SLOT(onNamespacesTestDone(KJob*)) );
        nsJob->start();
        return;
    } else {
        emitResult();
    }
}

void ProbeIMAPServerJob::onNamespacesTestDone( KJob *job )
{
    if ( job->error() ) {
        Warning() << job->errorString();
        setError(KJob::UserDefinedError);
        emitResult();
        return;
    }
    KIMAP::NamespaceJob *nsJob = qobject_cast<KIMAP::NamespaceJob*>( job );
    Q_ASSERT(nsJob);
    mPersonalNamespace = nsJob->personalNamespaces();
    mExcludedNamespace = nsJob->userNamespaces() + nsJob->sharedNamespaces();
    mSharedNamespace = nsJob->sharedNamespaces();

    emitResult();
}

QStringList ProbeIMAPServerJob::capabilities() const
{
    return mCapabilities;
}

QList< KIMAP::MailBoxDescriptor > ProbeIMAPServerJob::personalNamespace() const
{
    return mPersonalNamespace;
}

QList< KIMAP::MailBoxDescriptor > ProbeIMAPServerJob::excludedNamespaces() const
{
    return mExcludedNamespace;
}

QList< KIMAP::MailBoxDescriptor > ProbeIMAPServerJob::sharedNamespaces() const
{
    return mSharedNamespace;
}
