/*
 * Copyright (C) 2012  Christian Mollekopf <mollekopf@kolabsys.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "migrateuserjob.h"
#include "migratefolderjob.h"
#include "sourceaccount.h"
#include "kolabaccount.h"
#include <errorhandler.h>

MigrateUserJob::MigrateUserJob(const QList<SourceAccount*> &sourceAccounts, KolabAccount *kolabAccount, QObject* parent)
:   KJob(parent),
    mSourceAccounts(sourceAccounts),
    mCurrentSourceAccount(0),
    mKolabAccount(kolabAccount)
{
}

void MigrateUserJob::start()
{
    if (!mKolabAccount || mSourceAccounts.isEmpty()) {
        setError(KJob::UserDefinedError);
        setErrorText("Failed to get source or target account");
        emitResult();
        return;
    }
    mKolabAccount->cleanAccount();
    mKolabAccount->setupFolders();
    migrateNextAccount();
}

void MigrateUserJob::migrateNextAccount()
{
    if (mCurrentSourceAccount) {
        mCurrentSourceAccount->deleteLater();
    }
    if (mSourceAccounts.isEmpty()) {
        KJob *logoutJob = mKolabAccount->logout();
        if (logoutJob) {
            Debug() << "running target logout job";
            connect(logoutJob, SIGNAL(result(KJob*)), this, SLOT(onLogoutDone(KJob*)));
            logoutJob->start();
        } else {
            onLogoutDone(0);
        }
        return;
    }
    mCurrentSourceAccount = mSourceAccounts.takeFirst();
    KJob *loginJob = mCurrentSourceAccount->login();
    Q_ASSERT(loginJob);
    connect(loginJob, SIGNAL(result(KJob*)), this, SLOT(onLoginDone(KJob*)));
    loginJob->start();
}

void MigrateUserJob::onLoginDone(KJob *job)
{
    if (job->error()) {
        Error() << "Failed to login in source account: " << job->errorString();
        emitResult();
        return;
    }
    Debug() << "login successful";
    //Go to eventloop first, to ensure the session is fully initialized before running further jobs
    QMetaObject::invokeMethod(this, "fetchFolders", Qt::QueuedConnection);
}

void MigrateUserJob::onLogoutDone(KJob *job)
{
    if (job && job->error()) {
        Error() << "Failed to logout" << job->errorString();
    }
    emitResult();
}

void MigrateUserJob::fetchFolders()
{
    FetchFoldersJob *fetchJob = mCurrentSourceAccount->fetchFolderList();
    if (!fetchJob) {
        mFolderQueue = mCurrentSourceAccount->lookupFolderList();
        migrateNextFolder();
    } else {
       connect(fetchJob, SIGNAL(foldersReceived(QStringList)), this, SLOT(onFoldersReceived(QStringList)));
       connect(fetchJob, SIGNAL(result(KJob*)), this, SLOT(onFoldersFetched(KJob*)));
       fetchJob->start();
    }
}

void MigrateUserJob::onFoldersReceived(const QStringList &folders)
{
    mFolderQueue.append(folders);
}

void MigrateUserJob::onFoldersFetched(KJob* )
{
    migrateNextFolder();
}

void MigrateUserJob::migrateNextFolder()
{
    if (!mCurrentFolder.isEmpty()) {
        Warning() << "already migrating a folder";
        return;
    }
    if (mFolderQueue.isEmpty()) {
        Debug() << "Account migrated, logging out";
        KJob *logoutJob = mCurrentSourceAccount->logout();
        if (logoutJob) {
            connect(logoutJob, SIGNAL(result(KJob*)), this, SLOT(migrateNextAccount()));
            logoutJob->start();
        } else {
            QMetaObject::invokeMethod(this, "migrateNextAccount", Qt::QueuedConnection);
        }
        return;
    }
    mCurrentFolder = mFolderQueue.takeFirst();
    if (isIgnored(mCurrentFolder)) {
        Debug() << "Skipping source folder: " << mCurrentFolder;
        mCurrentFolder.clear();
        migrateNextFolder();
        return;
    }

    MigrateFolderJob *job = new MigrateFolderJob(mCurrentFolder, mCurrentSourceAccount, mKolabAccount, this);
    connect(job, SIGNAL(result(KJob*)), this, SLOT(onFolderMigrated(KJob*)));
    job->start();
}

void MigrateUserJob::onFolderMigrated(KJob *job)
{
    if (job->error()) {
        Error() << "Failed to migrate folder: " << mCurrentFolder;
        Error() << job->errorString();
    }
    mCurrentFolder.clear();
    migrateNextFolder();
}

bool MigrateUserJob::isIgnored(const QString &sourceFolder) const
{
    foreach (const QString &ignoredFolder, mCurrentSourceAccount->ignoredFolders()) {
        if (sourceFolder.contains(ignoredFolder)) {
            return true;
        }
    }
    return false;
}
