/*
 * Copyright (C) 2012  Christian Mollekopf <mollekopf@kolabsys.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include <QtCore/qcoreapplication.h>
#include <QtGui/QApplication>
#include <QtCore/QStringList>
#include <QtCore/qfile.h>
#include <kcmdlineargs.h>
#include <errorhandler.h>

#include "coordinationjob.h"
#include "sourceserver.h"
#include "kolabserver.h"
#ifdef BUILD_GOOGLESUPPORT
#include "googlesourceserver.h"
#endif
#include "kolabutils-version.h"

KIMAP::LoginJob::EncryptionMode getEncryptionMode(const QString &encrypt)
{
    KIMAP::LoginJob::EncryptionMode encryptionMode = KIMAP::LoginJob::TlsV1;
    if (encrypt == "NONE") {
        encryptionMode = KIMAP::LoginJob::Unencrypted;
    } else if (encrypt == "SSL") {
        encryptionMode = KIMAP::LoginJob::AnySslVersion;
    } else if (encrypt == "TLS") {
        encryptionMode = KIMAP::LoginJob::TlsV1;
    } else {
        Error() << "unknown encryption mode";
    }
    return encryptionMode;
}

KIMAP::LoginJob::AuthenticationMode getAuthenticationMode(const QString &auth)
{
    KIMAP::LoginJob::AuthenticationMode authenticationMode = KIMAP::LoginJob::Plain;
    if (auth == "PLAIN") {
        authenticationMode = KIMAP::LoginJob::Plain;
    } else if (auth == "LOGIN") {
        authenticationMode = KIMAP::LoginJob::Login;
    } else if (auth == "CRAMMD5") {
        authenticationMode = KIMAP::LoginJob::CramMD5;
    } else if (auth == "DIGESTMD5") {
        authenticationMode = KIMAP::LoginJob::DigestMD5;
    } else if (auth == "NTLM") {
        authenticationMode = KIMAP::LoginJob::NTLM;
    } else if (auth == "GSSAPI") {
        authenticationMode = KIMAP::LoginJob::GSSAPI;
    } else if (auth == "ANONYMOUS") {
        authenticationMode = KIMAP::LoginJob::Anonymous;
    } else if (auth == "CLEARTEXT") {
        authenticationMode = KIMAP::LoginJob::ClearText;
    } else {
        Error() << "unknown authentication mode";
    }
    return authenticationMode;
}

/**
 * kolab-migrate --from caldav --to kolab (implied?)
 * --caldav-host caldav.example.org --caldav-authn <admin> --caldav-authz <user> --caldav-pass <pass>
 * --<folder-selection> --<folder-mapping>
 * --kolab-host kolab.example.org
 * --kolab-authn <admin> --kolab-authz <user> --kolab-pass <pass>
 * --regextrans2 '/Public Folders/shared/' Regex transformation of folder paths
 * Incremental conversion (folder by folder or even by batch of messages)
 * Save state persistently and resume from there after interruption (Wipe before starting and start all over as first step)
 */
int main(int argc, char *argv[])
{
    KCmdLineArgs::init(argc, argv, "migrationutility", "migrationutility",ki18n("migrationutility"),  KOLABUTILS_VERSION);
    
    KCmdLineOptions options;
    options.add("dry", ki18n("Dry run, doesn't change anything on the server, but only prints what would be done (Use with care until this is well tested)."));
    options.add("wipeTargetFolders", ki18n("Wipe and recreate target folders (Will only wipe folders in the personal namespace)."));
    options.add("statefile", ki18n("Resume from migration-state file"), "/tmp/kolabmigration.state");
    options.add("skipFolder <sourcefolder>", ki18n("Source-folders to skip. Uses a simple \"contains\"-filter. Can be stated multiple times."));
    options.add("objectType <type>", ki18n("Objects types to migrate (MAIL, CONTACTS, EVENTS, TASKS). By default all types are migrated. Can be stated multiple times. Currently only implemented for the google source type."));
    options.add("regextrans2 <s/MATCH/REPLACE/>", ki18n("Allows to translate target folder names. Use --dry to figure out the names that are used by default. Wilcards can be used in the MATCH part, and prefixes can be created in the REPLACE part using \"prefix/*\"."));

    options.add("from <type>", ki18n("Source host type (kolab2, kolab3, exchangeimap, google)"));
    
    options.add("from-host <host>", ki18n("Source host"));
    options.add("from-port <port>", ki18n("Port"), "143");
    options.add("from-user <loginname>", ki18n("Username for single-user migration"));
    options.add("from-proxyauth <loginname>", ki18n("Username to be used for authentication together with password (optional, works with PLAIN/SASL authentication)"));
    options.add("from-password <password>", ki18n("Password"));
    options.add("from-encrypt <mode>", ki18n("Encryption mode to be used (NONE, TLS, SSL)"), "TLS");
    options.add("from-auth <mode>", ki18n("Authentication mode to be used (PLAIN, LOGIN, CRAMMD5, DIGESTMD5, NTLM, GSSAPI, ANONYMOUS, CLEARTEXT)"), "PLAIN");
    
    options.add("to <type>", ki18n("Target host type (kolab2, kolab3)"));
    
    options.add("to-host <host>", ki18n("Target host"));
    options.add("to-port <port>", ki18n("Port"), "143");
    options.add("to-user <loginname>", ki18n("Username for single-user migration"));
    options.add("to-proxyauth <loginname>", ki18n("Username to be used for authentication together with password (optional, works with PLAIN/SASL authentication)"));
    options.add("to-password <password>", ki18n("Password"));
    options.add("to-encrypt <mode>", ki18n("Encryption mode to be used (NONE, TLS, SSL)"), "TLS");
    options.add("to-auth <mode>", ki18n("Authentication mode to be used (PLAIN, LOGIN, CRAMMD5, DIGESTMD5, NTLM, GSSAPI, ANONYMOUS, CLEARTEXT)"), "PLAIN");

    KCmdLineArgs::addCmdLineOptions( options );
    QApplication app(argc, argv);
    
    KCmdLineArgs *args = KCmdLineArgs::parsedArgs();

    SourceServer *sourceServer = 0;
    if (!args->getOption("from").compare("kolab2", Qt::CaseInsensitive)) {
        Debug() << "From Kolab2 Server";
        KolabSourceServer *kolabSourceServer = new KolabSourceServer(&app);
        kolabSourceServer->setHost(args->getOption("from-host"), args->getOption("from-port").toInt());
        kolabSourceServer->setAdminCredentials(args->getOption("from-proxyauth"), args->getOption("from-password"));
        kolabSourceServer->setEncryption(getEncryptionMode(args->getOption("from-encrypt")));
        kolabSourceServer->setAuthentication(getAuthenticationMode(args->getOption("from-auth")));
        if (args->isSet("from-user")) {
            kolabSourceServer->setSingleUser(args->getOption("from-user"));
        }
        sourceServer = kolabSourceServer;
    } else if (!args->getOption("from").compare("kolab3", Qt::CaseInsensitive)) {
        Debug() << "From Kolab3 Server";
        KolabSourceServer *kolabSourceServer = new KolabSourceServer(&app);
        kolabSourceServer->setHost(args->getOption("from-host"), args->getOption("from-port").toInt());
        kolabSourceServer->setAdminCredentials(args->getOption("from-proxyauth"), args->getOption("from-password"));
        kolabSourceServer->setEncryption(getEncryptionMode(args->getOption("from-encrypt")));
        kolabSourceServer->setAuthentication(getAuthenticationMode(args->getOption("from-auth")));
        if (args->isSet("from-user")) {
            kolabSourceServer->setSingleUser(args->getOption("from-user"));
        }
        sourceServer = kolabSourceServer;
    } else if (!args->getOption("from").compare("exchangeimap", Qt::CaseInsensitive)) {
        Debug() << "From Exchange IMAP Server";
        ExchangeIMAPSourceServer *source = new ExchangeIMAPSourceServer(&app);
        source->setHost(args->getOption("from-host"), args->getOption("from-port").toInt());
        source->setAdminCredentials(args->getOption("from-proxyauth"), args->getOption("from-password"));
        source->setEncryption(getEncryptionMode(args->getOption("from-encrypt")));
        source->setAuthentication(getAuthenticationMode(args->getOption("from-auth")));
        if (args->isSet("from-user")) {
            source->setSingleUser(args->getOption("from-user"));
        }
        sourceServer = source;
    }
#ifdef BUILD_GOOGLESUPPORT
    else if (!args->getOption("from").compare("google", Qt::CaseInsensitive)) {
        Debug() << "From Google Server";
        GoogleSourceServer *source = new GoogleSourceServer(&app);
        source->setHost("imap.googlemail.com", 993);
        source->setAdminCredentials(args->getOption("from-proxyauth"), args->getOption("from-password"));
        source->setEncryption(KIMAP::LoginJob::AnySslVersion);
        source->setAuthentication(KIMAP::LoginJob::ClearText);
        source->setIgnoredFolders(QStringList() << QLatin1String("[Gmail]")); //ignore the virtual folders
        source->setSingleUser(args->getOption("from-user"));
        sourceServer = source;
    }
#endif //BUILD_GOOGLESUPPORT
    else if (!args->getOption("from").compare("imap", Qt::CaseInsensitive)) {
        Debug() << "From IMAP Server";
        IMAPSourceServer *source = new IMAPSourceServer(&app);
        source->setHost(args->getOption("from-host"), args->getOption("from-port").toInt());
        source->setAdminCredentials(args->getOption("from-proxyauth"), args->getOption("from-password"));
        source->setEncryption(getEncryptionMode(args->getOption("from-encrypt")));
        source->setAuthentication(getAuthenticationMode(args->getOption("from-auth")));
        if (args->isSet("from-user")) {
            source->setSingleUser(args->getOption("from-user"));
        }
        sourceServer = source;
    }

    KolabServer *kolabServer = 0;
    if (!args->getOption("to").compare("kolab2", Qt::CaseInsensitive)) {
        Debug() << "To Kolab2 Server";
        kolabServer = new KolabServer(&app);
        kolabServer->setHost(args->getOption("to-host"), args->getOption("to-port").toInt());
        kolabServer->setAdminCredentials(args->getOption("to-proxyauth"), args->getOption("to-password"));
        kolabServer->setEncryption(getEncryptionMode(args->getOption("to-encrypt")));
        kolabServer->setAuthentication(getAuthenticationMode(args->getOption("to-auth")));
        if (args->isSet("to-user")) {
            kolabServer->addTargetUserForSource(args->getOption("from-user"), args->getOption("to-user"));
        }
        kolabServer->setVersion(Kolab::KolabV2);
    } else if (!args->getOption("to").compare("kolab3", Qt::CaseInsensitive)) {
        Debug() << "To Kolab3 Server";
        kolabServer = new KolabServer(&app);
        kolabServer->setHost(args->getOption("to-host"), args->getOption("to-port").toInt());
        kolabServer->setAdminCredentials(args->getOption("to-proxyauth"), args->getOption("to-password"));
        kolabServer->setEncryption(getEncryptionMode(args->getOption("to-encrypt")));
        kolabServer->setAuthentication(getAuthenticationMode(args->getOption("to-auth")));
        if (args->isSet("to-user")) {
            kolabServer->addTargetUserForSource(args->getOption("from-user"), args->getOption("to-user"));
        }
        kolabServer->setVersion(Kolab::KolabV3);
    }

    if (!sourceServer || !kolabServer) {
        Error() << "Target or Source-Server not specified";
        return -1;
    }
    if (args->isSet("dry")) {
        kolabServer->setDryRun(true);
    }
    if (args->isSet("wipeTargetFolders")) {
        kolabServer->setWipeTargetFolders(true);
    }
    if (!args->getOptionList("regextrans2").isEmpty()) {
        kolabServer->setRegextrans(args->getOptionList("regextrans2"));
    }
    if (args->isSet("statefile")) {
        sourceServer->setStatefile(args->getOption("statefile"));
    }
    if (!args->getOptionList("skipFolder").isEmpty()) {
        sourceServer->setIgnoredFolders(args->getOptionList("skipFolder"));
    }
    if (!args->getOptionList("objectType").isEmpty()) {
        sourceServer->setObjectTypesToMigrate(args->getOptionList("objectType"));
    }
    CoordinationJob *job = new CoordinationJob(sourceServer, kolabServer, &app);
    QObject::connect(job, SIGNAL(finished(KJob*)), &app, SLOT(quit()));
    job->start();
    app.exec();
    
    if (Kolab::ErrorHandler::instance().error() >= Kolab::ErrorHandler::Error) {
        Error() << Kolab::ErrorHandler::instance().errorMessage();
        return -1;
    }
    return 0;
}

