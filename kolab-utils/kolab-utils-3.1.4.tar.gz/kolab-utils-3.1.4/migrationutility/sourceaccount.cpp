/*
 * Copyright (C) 2012  Christian Mollekopf <mollekopf@kolabsys.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "sourceaccount.h"
#include "uiproxy.h"
#include <jobs/fetchmessagesjob.h>
#include <jobs/probekolabserverjob.h>
#include <kimap/session.h>
#include <kimap/listjob.h>
#include <kimap/logoutjob.h>
#include <kimap/capabilitiesjob.h>
#include <kimap/namespacejob.h>
#include <errorhandler.h>
#include <kolabobject.h>
#include <kabc/vcardconverter.h>
#include <kcalcore/memorycalendar.h>
#include <kcalcore/icalformat.h>

FetchObjectsJob::FetchObjectsJob(QObject* parent)
: KJob(parent)
{

}

FetchFoldersJob::FetchFoldersJob(QObject* parent)
: KJob(parent)
{

}


SourceAccount::SourceAccount(QObject* parent)
:   QObject(parent)
{

}

KJob* SourceAccount::login()
{
    return 0;
}

QStringList SourceAccount::lookupFolderList()
{
    return QStringList();
}

FetchFoldersJob* SourceAccount::fetchFolderList()
{
    return 0;
}

QList<Object> SourceAccount::getObjects(const QString &folder)
{
    mObjectList.clear();
    FetchObjectsJob *job = fetchObjects(folder);
    connect(job, SIGNAL(objectsReceived(QString,QList<Object>)), this, SLOT(onObjectsReceived(QString,QList<Object>)));
    job->exec();
    QList<Object> objects;
    foreach (const Object &object, mObjectList) {
        objects.append(convertObject(object, folder));
    }
    mObjectList.clear();
    return objects;
}

void SourceAccount::onObjectsReceived(const QString &, const QList<Object> &objects)
{
    mObjectList.append(objects);
}

KJob *SourceAccount::logout()
{
    return 0;
}

QPair<Kolab::FolderType, QString> SourceAccount::translateFolder(const QString& folder)
{
    return QPair<Kolab::FolderType, QString>(Kolab::MailType, folder);
}

void SourceAccount::setStatefile(const StateFile &statefile)
{
    mStatefile = statefile;
}

void SourceAccount::recordSuccessfulMigration(const Object &object, const QString &folder)
{
    recordSuccessfulMigration(QList<Object>() << object, folder);
}

void SourceAccount::recordSuccessfulMigration(const QList<Object> &/* object */, const QString &/* folder */)
{
}

void SourceAccount::setIgnoredFolders(const QStringList &ignoredFolders)
{
    mIgnoredFolders = ignoredFolders;
}

QStringList SourceAccount::ignoredFolders() const
{
    return mIgnoredFolders;
}


FetchObjectsJob* SourceAccount::fetchObjects(const QString& /* folder */)
{
    return 0;
}

Object SourceAccount::convertObject(const Object &object, const QString &) const
{
    return object;
}

TestAccount::TestAccount(QObject* parent)
    : SourceAccount(parent)
{
    mFolderList << QLatin1String("folder1");
    mFolderList << QLatin1String("folder2");
    mFolderList << QLatin1String("folder3");
}

QStringList TestAccount::lookupFolderList()
{
    return mFolderList;
}

FetchObjectsJob* TestAccount::fetchObjects(const QString& sourceFolder)
{
    Debug() << sourceFolder;
    Q_ASSERT(mFolderList.removeAll(sourceFolder) == 1);
    return 0;
}

KJob* TestAccount::login()
{
    return new DummyJob;
}

