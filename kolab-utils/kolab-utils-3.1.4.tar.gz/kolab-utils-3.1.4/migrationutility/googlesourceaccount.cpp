/*
 * Copyright (C) 2013  Christian Mollekopf <mollekopf@kolabsys.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "googlesourceaccount.h"

#include <libkgapi2/contacts/contact.h>
#include <libkgapi2/contacts/contactfetchjob.h>
#include <libkgapi2/calendar/calendar.h>
#include <libkgapi2/calendar/calendarfetchjob.h>
#include <libkgapi2/calendar/event.h>
#include <libkgapi2/calendar/eventfetchjob.h>
#include <libkgapi2/tasks/tasklistfetchjob.h>
#include <libkgapi2/tasks/task.h>
#include <libkgapi2/tasks/taskfetchjob.h>
#include <libkgapi2/tasks/tasklist.h>
#include <libkgapi2/authjob.h>
#include <libkgapi2/account.h>
#include <quuid.h>

#include <errorhandler.h>

GoogleFetchObjectsJob::GoogleFetchObjectsJob(const QString &currentFolder, const KGAPI2::AccountPtr& account, QObject* parent)
:   FetchObjectsJob(parent),
    mAccount(account),
    mCurrentFolder(currentFolder)
{

}

void GoogleFetchObjectsJob::start()
{
    if (mAccount.isNull()) {
        Error() << "Error: Please authenticate first";
        setError(KJob::UserDefinedError);
        setErrorText("Error: Please authenticate first");
        emitResult();
        return;
    }

    KGAPI2::FetchJob *fetchJob = getFetchJob(mAccount, mCurrentFolder);
    connect(fetchJob, SIGNAL(finished(KGAPI2::Job*)), this, SLOT(slotFetchJobFinished(KGAPI2::Job*)));
}


void GoogleFetchObjectsJob::slotFetchJobFinished(KGAPI2::Job* job)
{
    KGAPI2::FetchJob *fetchJob = qobject_cast<KGAPI2::FetchJob*>(job);
    Q_ASSERT(fetchJob);
    fetchJob->deleteLater();

    if (fetchJob->error() != KGAPI2::NoError) {
        Error() << fetchJob->errorString();
        setError(KJob::UserDefinedError);
        setErrorText(fetchJob->errorString());
        emitResult();
        return;
    }

    QList<Object> objects;
    foreach (const KGAPI2::ObjectPtr &i, fetchJob->items()) {
        objects << getObject(i);
    }
    emit objectsReceived(mCurrentFolder, objects);
    emitResult();
}

GoogleFetchFoldersJob::GoogleFetchFoldersJob(const KGAPI2::AccountPtr& account, QObject* parent)
:   FetchFoldersJob(parent),
    mAccount(account)
{

}

void GoogleFetchFoldersJob::start()
{
    if (mAccount.isNull()) {
        Error() << "Error: Please authenticate first";
        setError(KJob::UserDefinedError);
        setErrorText("Error: Please authenticate first");
        emitResult();
        return;
    }

    KGAPI2::FetchJob *fetchJob = getFetchJob(mAccount);
    connect(fetchJob, SIGNAL(finished(KGAPI2::Job*)), this, SLOT(slotFetchJobFinished(KGAPI2::Job*)));
}


void GoogleFetchFoldersJob::slotFetchJobFinished(KGAPI2::Job* job)
{
    KGAPI2::FetchJob *fetchJob = qobject_cast<KGAPI2::FetchJob*>(job);
    Q_ASSERT(fetchJob);
    fetchJob->deleteLater();

    if (fetchJob->error() != KGAPI2::NoError) {
        Error() << fetchJob->errorString();
        setError(KJob::UserDefinedError);
        setErrorText(fetchJob->errorString());
        emitResult();
        return;
    }

    QStringList folders;
    foreach (const KGAPI2::ObjectPtr &i, fetchJob->items()) {
        const QPair<QString, QString> folder = getFolder(i);
        folders << folder.first;
        mNames.insert(folder.first, folder.second);
    }
    emit foldersReceived(folders);
    emitResult();
}



FetchContactObjectsJob::FetchContactObjectsJob(const KGAPI2::AccountPtr &account, QObject* parent)
:   GoogleFetchObjectsJob(QLatin1String("Contacts"), account, parent)
{

}

KGAPI2::FetchJob* FetchContactObjectsJob::getFetchJob(const KGAPI2::AccountPtr& account, const QString& folder)
{
    Q_UNUSED(folder);
    return new KGAPI2::ContactFetchJob(account, this);
}

Object FetchContactObjectsJob::getObject(const KGAPI2::ObjectPtr& object)
{
    KABC::Addressee contact = *object.dynamicCast<KGAPI2::Contact>();
    //The returned uid's are of format: http://www.google.com/m8/feeds/contacts/NAME%40gmail.com/base/21042a1f892367ee
    //We generate a new one that is RFC4122 compliant to avoid incompatibilities
    contact.setUid( QUuid::createUuid().toString().mid(1, 36) );
//     Debug() << "contact: " << contact.name();
//     qDebug() << contact.emails();
    Object obj;
    obj.object = QVariant::fromValue(contact);
    return obj;
}

FetchCalendarObjectsJob::FetchCalendarObjectsJob(const QString &calendarId, const KGAPI2::AccountPtr& account, QObject* parent)
:   GoogleFetchObjectsJob(calendarId, account, parent)
{
}

KGAPI2::FetchJob* FetchCalendarObjectsJob::getFetchJob(const KGAPI2::AccountPtr &account, const QString& folder)
{
    return new KGAPI2::EventFetchJob(folder, account, this);
}

Object FetchCalendarObjectsJob::getObject(const KGAPI2::ObjectPtr &object)
{
    KCalCore::Incidence::Ptr event(object.dynamicCast<KGAPI2::Event>()->clone());
//     Debug() << event->uid() << event->summary();
    Object obj;
    obj.object = QVariant::fromValue(event);
    return obj;
}



FetchCalendarFoldersJob::FetchCalendarFoldersJob(const KGAPI2::AccountPtr& account, QObject* parent)
:   GoogleFetchFoldersJob(account, parent)
{
}

KGAPI2::FetchJob* FetchCalendarFoldersJob::getFetchJob(const KGAPI2::AccountPtr& account)
{
    return new KGAPI2::CalendarFetchJob(account, this);
}

QPair<QString, QString> FetchCalendarFoldersJob::getFolder(const KGAPI2::ObjectPtr& object)
{
    const KGAPI2::Calendar &calendar = *object.dynamicCast<KGAPI2::Calendar>();
    //TODO prefix with Calendar/
    QString name = calendar.title();
//     Debug() << "calendar: " << calendar.title();
    return qMakePair<QString, QString>(calendar.uid(), calendar.title());
}

FetchTaskObjectsJob::FetchTaskObjectsJob(const QString &tasklistId, const KGAPI2::AccountPtr& account, QObject* parent)
:   GoogleFetchObjectsJob(tasklistId, account, parent)
{
}

KGAPI2::FetchJob* FetchTaskObjectsJob::getFetchJob(const KGAPI2::AccountPtr &account, const QString& folder)
{
    return new KGAPI2::TaskFetchJob(folder, account, this);
}

Object FetchTaskObjectsJob::getObject(const KGAPI2::ObjectPtr &object)
{
    KCalCore::Incidence::Ptr task(object.dynamicCast<KGAPI2::Task>()->clone());
//     Debug() << task->uid() << task->summary();
    Object obj;
    obj.object = QVariant::fromValue(task);
    return obj;
}

FetchTaskListsJob::FetchTaskListsJob(const KGAPI2::AccountPtr& account, QObject* parent)
:   GoogleFetchFoldersJob(account, parent)
{
}

KGAPI2::FetchJob* FetchTaskListsJob::getFetchJob(const KGAPI2::AccountPtr& account)
{
    return new KGAPI2::TaskListFetchJob(account, this);
}

QPair<QString, QString> FetchTaskListsJob::getFolder(const KGAPI2::ObjectPtr& object)
{
    const KGAPI2::TaskList &list = *object.dynamicCast<KGAPI2::TaskList>();
    //TODO prefix with Task/
    QString name = list.title();
    //normalize so it works as imap mailbox name
    name.replace(QLatin1String("@"), QLatin1String("at"));
    Debug() << "task list: " << name;
    return qMakePair<QString, QString>(list.uid(), name);
}

LoginJob::LoginJob(const KGAPI2::AccountPtr &account, QObject* parent)
:   KJob(parent),
    mAccount(account)
{

}

void LoginJob::start()
{
//     Debug() << "login";
    /* Create AuthJob to retrieve OAuth tokens for the account */
    KGAPI2::AuthJob *authJob = new KGAPI2::AuthJob(
        mAccount,
        QLatin1String("583467588400.apps.googleusercontent.com"),
        QLatin1String("_AwtLuOqS5JcCHWGpq8fxKdd"), this);
    connect(authJob, SIGNAL(finished(KGAPI2::Job*)), this, SLOT(slotAuthJobFinished(KGAPI2::Job*)));
}

void LoginJob::slotAuthJobFinished(KGAPI2::Job *job)
{
//     Debug() << "login done";
    KGAPI2::AuthJob *authJob = qobject_cast<KGAPI2::AuthJob*>(job);
    Q_ASSERT(authJob);
    authJob->deleteLater();

    if (authJob->error() != KGAPI2::NoError) {
        setError(KJob::UserDefinedError);
        setErrorText(authJob->errorString());
    }
    emitResult();
}


GoogleSourceAccount::GoogleSourceAccount(QObject* parent)
:   SourceAccount(parent),
    mAccount(new KGAPI2::Account)
{

}

QPair<Kolab::FolderType, QString> GoogleSourceAccount::translateFolder(const QString& folder)
{
    return QPair<Kolab::FolderType, QString>(Kolab::ContactType, folder);
}

void GoogleSourceAccount::setUser(const QString& username)
{
    mUser = username;
}

void GoogleSourceAccount::setAccount(const KGAPI2::AccountPtr& account)
{
    mAccount = account;
}

KGAPI2::AccountPtr GoogleSourceAccount::account()
{
    return mAccount;
}

KJob* GoogleSourceAccount::login()
{
    if (mAccount->accessToken().isEmpty()) {
        mAccount->setScopes(QList<QUrl>() << KGAPI2::Account::contactsScopeUrl() << KGAPI2::Account::calendarScopeUrl() << KGAPI2::Account::tasksScopeUrl());
        mAccount->setAccountName(mUser);

        LoginJob *authJob = new LoginJob(mAccount, this);
        return authJob;
    } else {
        return new DummyJob();
    }
}

KJob *GoogleSourceAccount::logout()
{
    mAccount.clear();
    return 0;
}


GoogleContactsSourceAccount::GoogleContactsSourceAccount(QObject* parent)
: GoogleSourceAccount(parent)
{
}

QStringList GoogleContactsSourceAccount::lookupFolderList()
{
    return QStringList() << "Contacts";
}

FetchObjectsJob* GoogleContactsSourceAccount::fetchObjects(const QString &/*folder*/)
{
    return new FetchContactObjectsJob(mAccount, this);
}


GoogleCalendarSourceAccount::GoogleCalendarSourceAccount(QObject* parent)
: GoogleSourceAccount(parent)
{
}

FetchFoldersJob* GoogleCalendarSourceAccount::fetchFolderList()
{
    FetchCalendarFoldersJob *job = new FetchCalendarFoldersJob(mAccount, this);
    connect(job, SIGNAL(result(KJob*)), this, SLOT(onFetchedCalendars(KJob*)));
    return job;
}

void GoogleCalendarSourceAccount::onFetchedCalendars(KJob *job)
{
    if (!job->error()) {
        FetchCalendarFoldersJob *calendarFolderJob = static_cast<FetchCalendarFoldersJob*>(job);
        mCalendarNames = calendarFolderJob->mNames;
    }
}

FetchObjectsJob* GoogleCalendarSourceAccount::fetchObjects(const QString& folder)
{
    return new FetchCalendarObjectsJob(folder, mAccount, this);
}

QPair< Kolab::FolderType, QString > GoogleCalendarSourceAccount::translateFolder(const QString& folder)
{
    return QPair<Kolab::FolderType, QString>(Kolab::EventType, mCalendarNames.value(folder));
}


GoogleTasksSourceAccount::GoogleTasksSourceAccount(QObject* parent)
: GoogleSourceAccount(parent)
{
}

FetchFoldersJob* GoogleTasksSourceAccount::fetchFolderList()
{
    FetchTaskListsJob *job = new FetchTaskListsJob(mAccount, this);
    connect(job, SIGNAL(result(KJob*)), this, SLOT(onFetchedTasklists(KJob*)));
    return job;
}

void GoogleTasksSourceAccount::onFetchedTasklists(KJob* job)
{
    if (!job->error()) {
        FetchTaskListsJob *fetchJob = static_cast<FetchTaskListsJob*>(job);
        mTasklists = fetchJob->mNames;
    }
}

FetchObjectsJob* GoogleTasksSourceAccount::fetchObjects(const QString& folder)
{
    return new FetchTaskObjectsJob(folder, mAccount, this);
}

QPair< Kolab::FolderType, QString > GoogleTasksSourceAccount::translateFolder(const QString& folder)
{
    return QPair<Kolab::FolderType, QString>(Kolab::TaskType, mTasklists.value(folder));
}

