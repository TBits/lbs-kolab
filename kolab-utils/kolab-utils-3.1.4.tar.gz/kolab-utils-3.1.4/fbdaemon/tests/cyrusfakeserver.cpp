/*
 * Copyright (C) 2014  Sandro Knauß <knauss@kolabsys.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "cyrusfakeserver.h"

#include <QDebug>
#include <QRegExp>
#include <QFile>
#include <QTest>

CyrusFakeServer::CyrusFakeServer(QObject* parent)
    : FakeServer(parent)
{

}

QByteArray tagReplace(QString line, int tagCount)
{
    QRegExp tag(" A[0-9]{6} ");
    QRegExp tag2("\nA[0-9]{6} ");

    line.replace(tag, " A" + QByteArray::number(tagCount).rightJustified(6, '0') + " ");
    line.replace(tag2, "\nA" + QByteArray::number(tagCount).rightJustified(6, '0') + " ");
    return line.toUtf8().trimmed();

}

void CyrusFakeServer::addScenarioFromFile(const QString &fileName)
{
    QFile file(fileName);
    if (!file.exists()) {
        qWarning() << "File: " << fileName << "does not exist.";
    }
    file.open(QFile::ReadOnly);

    QList<QByteArray> scenario;

    // When loading from files we never have the authentication phase
    // force jumping directly to authenticated state.
    scenario << greeting()
             << "C: A000001 AUTHENTICATE PLAIN"
             << "S: A000001 OK";

    QString line, newLine;
    int tagCount = 1;
    QString type;

    QRegExp server("^>[0-9]{10}>");
    QRegExp client("^<[0-9]{10}<");

    while (!file.atEnd()) {
        newLine = file.readLine();
        if (client.indexIn(newLine) > -1) {
            //qDebug() << line.trimmed();
            if (!line.trimmed().isEmpty()) {
                scenario << tagReplace(line, tagCount);
            }
            tagCount++;
            type = "C: ";
            line = newLine.replace(client, type);
        } else if (server.indexIn(newLine) > -1) {
            //qDebug() << line.trimmed();
            if (!line.trimmed().isEmpty()) {
                scenario << tagReplace(line, tagCount);
            }
            type = "S: ";
            line = newLine.replace(server, type);
        } else if (!type.isEmpty()) {
            if (newLine.startsWith("* ")) {
                line = line;
                scenario << tagReplace(line, tagCount);
                line = type;
            }
            line += newLine;
        }

    }
    //qDebug() << line.trimmed();
    if (!line.trimmed().isEmpty()) {
        scenario << tagReplace(line, tagCount);
    }

    file.close();

    addScenario(scenario);
}

void CyrusFakeServer::compareReceived(const QByteArray& received, const QByteArray& expected) const
{
    QRegExp append("^C: A[0-9]{6} APPEND \"Freebusy\"");
    if (append.indexIn(expected) == 0) {
        QVERIFY(append.indexIn(received) == 0);
    } else {
        FakeServer::compareReceived(received, expected);
    }
}


#include "cyrusfakeserver.moc"