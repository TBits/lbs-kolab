/*
 * Copyright (C) 2012  Christian Mollekopf <mollekopf@kolabsys.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#include "fbgeneratortest.h"

#include <QTest>
#include <QDebug>
#include <QDir>
#include <iostream>

#include <xmlobject.h>
#include <kolabobject.h>
#include <freebusy.h>
#include <kcalconversion.h>
#include "settings.h"
#include "kolabaccount.h"

FBGeneratorTest::FBGeneratorTest(QObject* parent)
    : QObject(parent),
      user("john.doe@example.org")
{
    Settings::instance().setAuthorizationUser("cyrus-admin");
    Settings::instance().setTestMode(true);
    Settings::instance().setPassword("admin");
    Settings::instance().setServerUri("127.0.0.1:5989");
    Settings::instance().setThreshold(10);
    Settings::instance().setTimeframe(60);
    Settings::instance().setAggregatedICalOutputDirectory(QDir::tempPath());
}

Kolab::Freebusy FBGeneratorTest::executeGeneration(bool saveObject, KDateTime start, KDateTime end)
{

    SessionSettings sessionSettings = Settings::instance().getSessionSettings();
    sessionSettings.userName = user;

    QObject obj;
    FBGeneratorJob *job = new FBGeneratorJob(sessionSettings, saveObject, &obj);
    job->setTimeFrame(start, end);
    job->exec();

    return job->getFreebusy();
}

void FBGeneratorTest::compareFreeBusy(Kolab::Freebusy fb1, Kolab::Freebusy fb2)
{
    QCOMPARE((int)fb1.periods().size(), (int)fb2.periods().size());
    QCOMPARE(fb1.organizer(), fb2.organizer());
    QCOMPARE(fb1.start(), fb2.start());
    QCOMPARE(fb1.end(), fb2.end());
    for (std::size_t i = 0; i < fb1.periods().size(); i++) {
        std::cout << i;
        QCOMPARE(fb1.periods().at(i), fb2.periods().at(i));
    }
}



void FBGeneratorTest::testGenerator()
{
    QDir dir(QLatin1String(SCENARIO_DATA_DIR));
    fakeServer.addScenarioFromFile(dir.path() + "/generator/imap-6398");
    fakeServer.addScenarioFromFile(dir.path() + "/generator/imap-6398.withoutattach");
    fakeServer.startAndWait();

    KDateTime start;
    KDateTime end;
    Kolab::cDateTime s(2014, 6, 12, 11, 2, 38, true);
    Kolab::cDateTime e(2014, 6, 12, 12, 2, 38, true);
    Kolab::Period period(s, e);
    start.setTime_t(1400604981);
    end.setTime_t(1405788981);
    Kolab::Freebusy fb1 = executeGeneration(true, start, end);
    Kolab::Freebusy fb2 = executeGeneration(false, start, end);

    QCOMPARE(fb1.organizer(), Kolab::ContactReference(user.toUtf8().constData()));
    QCOMPARE(Kolab::Conversion::toDate(fb1.start()), start);
    QCOMPARE(Kolab::Conversion::toDate(fb1.end()), end);
    QCOMPARE((int)fb1.periods().size(), 1);
    QCOMPARE((int)fb1.periods().at(0).periods().size(), 1);
    QCOMPARE(fb1.periods().at(0).periods().at(0), period);
    compareFreeBusy(fb2, fb1);

    QVERIFY(fakeServer.isAllScenarioDone());
    fakeServer.quit();
}

void FBGeneratorTest::testSetTimeframe()
{
    SessionSettings sessionSettings = Settings::instance().getSessionSettings();
    QObject obj;
    FBGeneratorJob job(sessionSettings, true, &obj);

    QVERIFY(job.mStartOfTimeFrame.secsTo(KDateTime::currentUtcDateTime()) < 2);  // $now
    QCOMPARE(job.mStartOfTimeFrame.daysTo(job.mEndOfTimeFrame), Settings::instance().getTimeframe()); // $now+$defaultvalue

    KDateTime start;
    KDateTime end;
    start.setTime_t(12345);
    end.setTime_t(67890);
    job.setTimeFrame(start, end);

    QCOMPARE(job.mStartOfTimeFrame, start);
    QCOMPARE(job.mEndOfTimeFrame, end);
}

QTEST_MAIN(FBGeneratorTest)

#include "fbgeneratortest.moc"
