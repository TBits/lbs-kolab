#ifndef DAEMONTEST_H
#define DAEMONTEST_H

#include "fbdaemonconnection.h"

#include <QObject>
#include <QSignalSpy>
#include "testlib/testutils.h"

class ConnectionTest: public QObject
{
    Q_OBJECT
public:
    explicit ConnectionTest(QObject* parent = 0);

private Q_SLOTS:
    void testDoubleCommand();
    void testBadCommand();
    void testBadUser();
    void testBadMethod();
    void testBadTimeslot();
    void testValidateTimeslot();
    void testParseTimeslot();
    void testGeneratorUserJob();
    void testGeneratorFolderJob();
    /*
     * two commands: first fails, sencond is okay
     */

    void testFailingFirst();

    /*
     * parser can handle spaces in folder names
     * and escaped \" -> "
     */
    void testParser();
private:
    FbDaemonConnection* createConnection();
    void compareSendData(const QString &);
    QSignalSpy* mSpySendData;
};

#endif
