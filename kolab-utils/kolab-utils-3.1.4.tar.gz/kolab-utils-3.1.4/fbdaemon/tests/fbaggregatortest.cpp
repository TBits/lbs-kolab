/*
 * Copyright (C) 2012  Christian Mollekopf <mollekopf@kolabsys.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "fbaggregatortest.h"

#include <QTest>
#include <QDebug>
#include <QDir>
#include <kcalcore/memorycalendar.h>
#include <kcalcore/icalformat.h>
#include <freebusy.h>
#include <kcalconversion.h>
#include <kolabobject.h>
#include "fbdaemon/fbgeneratorjob.h"
#include "fbdaemon/fbaggregatorjob.h"
#include "settings.h"
#include "kolabaccount.h"
#include "testlib/testutils.h"

FBAggregatorTest::FBAggregatorTest(QObject* parent)
    : QObject(parent),
      user("john.doe@example.org")
{
    Settings::instance().setAuthorizationUser("cyrus-admin");
    Settings::instance().setTestMode(true);
    Settings::instance().setPassword("admin");
    Settings::instance().setServerUri("127.0.0.1:5989");
    Settings::instance().setThreshold(10);
    Settings::instance().setTimeframe(60);
    Settings::instance().setAggregatedICalOutputDirectory(QDir::tempPath());

    Object fbObj1;
    Kolab::Freebusy fb;
    fb.setOrganizer(Kolab::ContactReference(user.toAscii().data(), "john doe"));
    fb.setStart(Kolab::Conversion::fromDate(KDateTime::currentUtcDateTime()));
    fb.setEnd(Kolab::Conversion::fromDate(KDateTime::currentUtcDateTime().addDays(60)));
    fbObj1.object = QVariant::fromValue(Kolab::KolabObjectWriter::writeFreebusy(fb, Kolab::KolabV3, "fbtest"));

    Object fbObj2;
    Kolab::Freebusy fb2;
    fb2.setStart(Kolab::Conversion::fromDate(KDateTime::currentUtcDateTime()));
    fb2.setEnd(Kolab::Conversion::fromDate(KDateTime::currentUtcDateTime().addDays(60)));
    fbObj2.object = QVariant::fromValue(Kolab::KolabObjectWriter::writeFreebusy(fb2, Kolab::KolabV3, "fbtest"));

    folders << Folder("Freebusy", Kolab::FreebusyType, QList<Object>() << fbObj1 << fbObj2);
}

void FBAggregatorTest::executeAggregation()
{
    SessionSettings sessionSettings = Settings::instance().getSessionSettings();
    sessionSettings.userName = user;

    QObject obj;
    FBAggregatorJob *job = new FBAggregatorJob(sessionSettings, &obj);
    job->exec();
    generatedFile = job->generatedFile();
}

void FBAggregatorTest::checkFbObject()
{
    QVERIFY(QFileInfo(generatedFile).exists());
    QFile file(generatedFile);
    QVERIFY(file.open(QIODevice::ReadOnly | QIODevice::Text));
    QTextStream in(&file);
    QString data = in.readAll();

    KCalCore::ICalFormat format;
    KCalCore::Calendar::Ptr cal(new KCalCore::MemoryCalendar(KDateTime::Spec::UTC()));
    KCalCore::ScheduleMessage::Ptr msg = format.parseScheduleMessage(cal, data);
    QVERIFY(msg);
    QCOMPARE(msg->method(), KCalCore::iTIPPublish);
    QCOMPARE(format.timeSpec(), KDateTime::Spec::UTC());
    QVERIFY(msg->event());
    QCOMPARE(msg->event()->organizer()->email(), user);
    QVERIFY(!msg->event()->uid().isEmpty());
    //QVERIFY(msg->event()->lastModified().isValid());
    //TODO:test content of aggregated file
}

void FBAggregatorTest::testGenerator()
{
    QDir dir(QLatin1String(SCENARIO_DATA_DIR));
    fakeServer.addScenarioFromFile(dir.path() + "/aggregator/imap-28470");
    fakeServer.startAndWait();

    executeAggregation();
    checkFbObject();

    QVERIFY(fakeServer.isAllScenarioDone());
    fakeServer.quit();
}

QTEST_MAIN(FBAggregatorTest)

#include "fbaggregatortest.moc"
