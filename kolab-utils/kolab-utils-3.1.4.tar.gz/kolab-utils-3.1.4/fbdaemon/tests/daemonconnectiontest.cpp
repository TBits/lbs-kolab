/*
   Copyright (C) 2013 Christian Mollekopf <mollekopf@kolabsys.com>

   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU General Public
   License as published by the Free Software Foundation; either
   version 2 of the License, or (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
*/

#include "daemonconnectiontest.h"
#include "fbdaemonthread.h"
#include "fbgeneratorjob.h"
#include "fbgeneratorfolderjob.h"
#include "cyrusfakeserver.h"
#include "settings.h"

#include <kcalcore/memorycalendar.h>
#include <kcalcore/icalformat.h>

#include <kimaptest/fakeserver.h>
#include <xmlobject.h>
#include <kcalconversion.h>
#include <kolabformat.h>

#include <QTcpSocket>
#include <QtTest>
#include <QDebug>

ConnectionTest::ConnectionTest(QObject* parent): QObject(parent)
{
    Settings::instance().setAuthorizationUser("cyrus-admin");
    Settings::instance().setTestMode(true);
    Settings::instance().setPassword("admin");
    Settings::instance().setServerUri("127.0.0.1:5989");
    Settings::instance().setThreshold(10);
    Settings::instance().setTimeframe(60);
    Settings::instance().setAggregatedICalOutputDirectory(QDir::tempPath());
}


FbDaemonConnection* ConnectionTest::createConnection()
{
    FbDaemonThread* thread(new FbDaemonThread(0));
    FbDaemonConnection* connection(new FbDaemonConnection(thread));
    mSpySendData = new QSignalSpy(connection, SIGNAL(sendData(QByteArray)));
    return connection;
}


void ConnectionTest::compareSendData(const QString& sendData)
{
    QCOMPARE(mSpySendData->count(), 1);
    QList<QVariant> arguments = mSpySendData->takeFirst();
    QCOMPARE(arguments.at(0).type(), QVariant::ByteArray);
    QCOMPARE(arguments.at(0).toString(), sendData);
}


void ConnectionTest::testDoubleCommand()
{
    FbDaemonConnection* connection(createConnection());

    SessionSettings settings = Settings::instance().getSessionSettings();
    FBGeneratorJob *generator = new FBGeneratorJob(settings, false, this);
    connection->setJob(generator);

    connection->onNewLine("IFB USER test@example.com");

    compareSendData("BAD Can only process one command after another\r\n\r\n");
}

void ConnectionTest::testBadCommand()
{
    FbDaemonConnection* connection(createConnection());
    connection->onNewLine("IFB UNKNOWN test@example.com");
    compareSendData("BAD IFB unknown command: UNKNOWN\r\n\r\n");
    connection->onNewLine("IFB USER test@example.com asdfaesf");
    compareSendData("BAD IFB unknown parameter\r\n\r\n");
}

void ConnectionTest::testBadMethod()
{
    FbDaemonConnection* connection(createConnection());
    connection->onNewLine("UNKNOWN USER test@example.com");
    compareSendData("BAD UNKNOWN method not valid\r\n\r\n");
}

void ConnectionTest::testBadUser()
{
    FbDaemonConnection* connection(createConnection());
    connection->onNewLine("IFB USER qasdfaserdsfsar");
    compareSendData("BAD IFB emailaddress not valid\r\n\r\n");
}

void ConnectionTest::testBadTimeslot()
{
    FbDaemonConnection* connection(createConnection());
    connection->onNewLine("IFB USER test@example.com slot:asdsadf-xxxx");
    compareSendData("BAD IFB malformed timeslot\r\n\r\n");
}

void ConnectionTest::testValidateTimeslot()
{
    FbDaemonConnection* connection(createConnection());
    QCOMPARE(connection->validateTimeslot("slot:interval-1402593346"), true);
    QCOMPARE(connection->validateTimeslot("slot:interval-interval"), true);
    QCOMPARE(connection->validateTimeslot("slot:1402593346-interval"), true);
    QCOMPARE(connection->validateTimeslot("slot:xxxx-ffff"), false);
}

void ConnectionTest::testParseTimeslot()
{
    FbDaemonConnection* connection(createConnection());
    Timeslot slot;

    slot = connection->parseTimeslot("");
    QVERIFY(slot.start.secsTo(KDateTime::currentUtcDateTime()) < 2);  // $now
    QCOMPARE(slot.start.daysTo(slot.end), Settings::instance().getTimeframe()); // $now+$defaultvalue

    slot = connection->parseTimeslot("slot:interval-interval");
    QVERIFY(slot.start.secsTo(KDateTime::currentUtcDateTime()) < 2);  // $now
    QCOMPARE(slot.start.daysTo(slot.end), Settings::instance().getTimeframe()); // $now+$defaultvalue

    slot = connection->parseTimeslot("slot:1402593346-interval");
    QCOMPARE(slot.start.dateTime(), QDateTime::fromTime_t(1402593346));
    QCOMPARE(slot.start.daysTo(slot.end), Settings::instance().getTimeframe()); // $now+$defaultvalue

    slot = connection->parseTimeslot("slot:interval-1402593346");
    QCOMPARE(slot.end.dateTime(), QDateTime::fromTime_t(1402593346));
    QCOMPARE(slot.start.daysTo(slot.end), Settings::instance().getTimeframe());  // 1402593346 - $defaultvalue

    slot = connection->parseTimeslot("slot:1402500000-1402593346");
    QCOMPARE(slot.start.dateTime(), QDateTime::fromTime_t(1402500000));
    QCOMPARE(slot.end.dateTime(), QDateTime::fromTime_t(1402593346));
}

void ConnectionTest::testGeneratorUserJob()
{
    CyrusFakeServer fakeServer;
    QDir dir(QLatin1String(SCENARIO_DATA_DIR));
    fakeServer.addScenarioFromFile(dir.path() + "/generator/imap-6398.withoutattach");
    fakeServer.startAndWait();

    QEventLoop loop(this);
    KDateTime start;
    KDateTime end;
    start.setTime_t(1400604981);
    end.setTime_t(1405788981);
    FbDaemonConnection* connection(createConnection());
    connection->onNewLine("IFB USER john.doe@example.com slot:1400604981-1405788981");
    connect(connection->job, SIGNAL(result(KJob*)),
            &loop, SLOT(quit()));
    loop.exec();

    QRegExp ifb("\\* \\(\\{([0-9]+)\\} \r\n(.*)\\)");

    QCOMPARE(mSpySendData->count(), 1);
    QList<QVariant> arguments = mSpySendData->takeFirst();
    QCOMPARE(arguments.at(0).type(), QVariant::ByteArray);
    QCOMPARE(ifb.indexIn(arguments.at(0).toString()), 0);
    QCOMPARE(ifb.cap(1).toInt(), ifb.cap(2).size());    // Object size == expected size
    const QString sFb = ifb.cap(2);

    KCalCore::ICalFormat format;
    KCalCore::Calendar::Ptr cal(new KCalCore::MemoryCalendar(KDateTime::Spec::UTC()));
    KCalCore::ScheduleMessage::Ptr msg = format.parseScheduleMessage(cal, sFb);
    QVERIFY(msg);
    QCOMPARE(msg->method(), KCalCore::iTIPPublish);
    QCOMPARE(format.timeSpec(), KDateTime::Spec::UTC());
    QVERIFY(msg->event());

    KCalCore::FreeBusy::Ptr event = msg->event().staticCast<KCalCore::FreeBusy>();
    QCOMPARE(event->organizer()->email(), QLatin1String("john.doe@example.com"));

    QCOMPARE(event->dtStart(), start);
    QCOMPARE(event->dtEnd(), end);

    QVERIFY(!event->uid().isEmpty());

    QVERIFY(fakeServer.isAllScenarioDone());
    fakeServer.quit();
}

void ConnectionTest::testGeneratorFolderJob()
{
    CyrusFakeServer fakeServer;
    QDir dir(QLatin1String(SCENARIO_DATA_DIR));
    fakeServer.addScenarioFromFile(dir.path() + "/generatefolder/normal.log");
    fakeServer.startAndWait();

    QEventLoop loop(this);
    KDateTime start;
    KDateTime end;
    start.setTime_t(1400604981);
    end.setTime_t(1405788981);
    FbDaemonConnection* connection(createConnection());
    connection->onNewLine("IFB FOLDER shared/Resources/mybeamer@example.com slot:1400604981-1405788981");
    connect(connection->job, SIGNAL(result(KJob*)),
            &loop, SLOT(quit()));
    loop.exec();

    QRegExp ifb("\\* \\(\\{([0-9]+)\\} \r\n(.*)\\)");

    QCOMPARE(mSpySendData->count(), 1);
    QList<QVariant> arguments = mSpySendData->takeFirst();
    QCOMPARE(arguments.at(0).type(), QVariant::ByteArray);
    QCOMPARE(ifb.indexIn(arguments.at(0).toString()), 0);
    QCOMPARE(ifb.cap(1).toInt(), ifb.cap(2).size());    // Object size == expected size

    const QString sFb = ifb.cap(2);

    KCalCore::ICalFormat format;
    KCalCore::Calendar::Ptr cal(new KCalCore::MemoryCalendar(KDateTime::Spec::UTC()));
    KCalCore::ScheduleMessage::Ptr msg = format.parseScheduleMessage(cal, sFb);
    QVERIFY(msg);
    QCOMPARE(msg->method(), KCalCore::iTIPPublish);
    QCOMPARE(format.timeSpec(), KDateTime::Spec::UTC());
    QVERIFY(msg->event());
    KCalCore::FreeBusy::Ptr event = msg->event().staticCast<KCalCore::FreeBusy>();
    QCOMPARE(event->organizer()->email(), QLatin1String("fbdaemon@localhost"));

    QCOMPARE(event->dtStart(), start);
    QCOMPARE(event->dtEnd(), end);

    QVERIFY(!event->uid().isEmpty());

    QVERIFY(fakeServer.isAllScenarioDone());
    fakeServer.quit();
}

void ConnectionTest::testFailingFirst()
{
    CyrusFakeServer fakeServer;
    QDir dir(QLatin1String(SCENARIO_DATA_DIR));
    fakeServer.addScenarioFromFile(dir.path() + "/generatefolder/notfound.log");
    fakeServer.addScenarioFromFile(dir.path() + "/generatefolder/empty.log");
    fakeServer.startAndWait();

    QEventLoop loop(this);
    KDateTime start;
    KDateTime end;
    start.setTime_t(1400604981);
    end.setTime_t(1405788981);
    FbDaemonConnection* connection(createConnection());
    connection->onNewLine("IFB FOLDER shared/Resources/bla@example.com");
    connect(connection->job, SIGNAL(result(KJob*)),
            &loop, SLOT(quit()));
    loop.exec();

    compareSendData("BAD IFB MyRights failed, server replied: A000005 NO Mailbox does not exist \r\n\r\n");

    connection->onNewLine("IFB FOLDER shared/Resources/mybeamer@example.com slot:1400604981-1405788981");
    connect(connection->job, SIGNAL(result(KJob*)),
            &loop, SLOT(quit()));
    loop.exec();

    QRegExp ifb("\\* \\(\\{([0-9]+)\\} \r\n(.*)\\)");
    QCOMPARE(mSpySendData->count(), 1);
    QList<QVariant> arguments = mSpySendData->takeFirst();
    QCOMPARE(arguments.at(0).type(), QVariant::ByteArray);
    QCOMPARE(ifb.indexIn(arguments.at(0).toString()), 0);
    QCOMPARE(ifb.cap(1).toInt(), ifb.cap(2).size());    // Object size == expected size

    const QString sFb = ifb.cap(2);

    KCalCore::ICalFormat format;
    KCalCore::Calendar::Ptr cal(new KCalCore::MemoryCalendar(KDateTime::Spec::UTC()));
    KCalCore::ScheduleMessage::Ptr msg = format.parseScheduleMessage(cal, sFb);
    QVERIFY(msg);
    QCOMPARE(msg->method(), KCalCore::iTIPPublish);
    QCOMPARE(format.timeSpec(), KDateTime::Spec::UTC());
    QVERIFY(msg->event());
    KCalCore::FreeBusy::Ptr event = msg->event().staticCast<KCalCore::FreeBusy>();
    QCOMPARE(event->organizer()->email(), QLatin1String("fbdaemon@localhost"));

    QCOMPARE(event->dtStart(), start);
    QCOMPARE(event->dtEnd(), end);

    QVERIFY(!event->uid().isEmpty());

    QVERIFY(fakeServer.isAllScenarioDone());
    fakeServer.quit();
}

void ConnectionTest::testParser()
{
    QEventLoop loop(this);
    FbDaemonConnection* connection(createConnection());

    connection->onNewLine("IFB FOLDER shared/Resources/bla@example.com");
    FBGeneratorFolderJob *fbJob = qobject_cast<FBGeneratorFolderJob*>(connection->job);
    QCOMPARE(fbJob->getFolder(), QString("shared/Resources/bla@example.com"));
    connect(connection->job, SIGNAL(result(KJob*)),
            &loop, SLOT(quit()));
    loop.exec();

    connection->onNewLine("IFB FOLDER \"shared/Resources/bla@example.com\"");
    fbJob = qobject_cast<FBGeneratorFolderJob*>(connection->job);
    QCOMPARE(fbJob->getFolder(), QString("shared/Resources/bla@example.com"));
    connect(connection->job, SIGNAL(result(KJob*)),
            &loop, SLOT(quit()));
    loop.exec();

    connection->onNewLine("IFB FOLDER \"shared/My Resources/bla@example.com\"");
    fbJob = qobject_cast<FBGeneratorFolderJob*>(connection->job);
    QCOMPARE(fbJob->getFolder(), QString("shared/My Resources/bla@example.com"));
    connect(connection->job, SIGNAL(result(KJob*)),
            &loop, SLOT(quit()));
    loop.exec();

    connection->onNewLine("IFB FOLDER \">test\\\" blabla \\\"<\"");
    fbJob = qobject_cast<FBGeneratorFolderJob*>(connection->job);
    QCOMPARE(fbJob->getFolder(), QString(">test\" blabla \"<"));
    connect(connection->job, SIGNAL(result(KJob*)),
            &loop, SLOT(quit()));
    loop.exec();
}

QTEST_MAIN(ConnectionTest)

#include "daemonconnectiontest.moc"
