/*
    Copyright (C) 2014 Sandro Knauß <knauss@kolabsys.com>

    This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU Affero General Public
    License as published by the Free Software Foundation; either
    version 2.1 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    Affero General Public License for more details.

    You should have received a copy of the GNU Affero General Public
    License along with this library; if not, write to the Free Software
    Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
*/


#include "fbgeneratorfolderjob.h"

#include "settings.h"
#include "generatefbjob.h"
#include <jobs/getuserlistjob.h>
#include <kimap/setacljob.h>
#include <kimap/myrightsjob.h>
#include <kimap/listjob.h>
#include <kolabdefinitions.h>
#include <commonconversion.h>

FBGeneratorFolderJob::FBGeneratorFolderJob(const SessionSettings &settings, QString folder, QObject* parent)
    :   KolabJob(settings, parent),
        mFolder(folder),
        resetRights(false)
{
    mStartOfTimeFrame = KDateTime::currentUtcDateTime();
    mEndOfTimeFrame = mStartOfTimeFrame.addDays(Settings::instance().getTimeframe());
}

void FBGeneratorFolderJob::startWork()
{
    KIMAP::MyRightsJob *rightsJob = new KIMAP::MyRightsJob(mSession);
    rightsJob->setMailBox(mFolder);
    connect(rightsJob, SIGNAL(result(KJob*)), this, SLOT(onMyRightsDone(KJob*)));
    rightsJob->start();
}

void FBGeneratorFolderJob::onMyRightsDone(KJob* job)
{
    if (job->error()) {
        qWarning() << job->errorString();
        setError(KJob::UserDefinedError);
        setErrorText(job->errorString());
        logout();
        return;
    }

    KIMAP::MyRightsJob *rightsJob = qobject_cast<KIMAP::MyRightsJob*>(job);
    Q_ASSERT(rightsJob);

    if (!rightsJob->hasRightEnabled(KIMAP::Acl::Lookup)
            || !rightsJob->hasRightEnabled(KIMAP::Acl::Read)
            || !rightsJob->hasRightEnabled(KIMAP::Acl::KeepSeen)) {

        rights = rightsJob->rights();

        KIMAP::SetAclJob * aclJob = new KIMAP::SetAclJob(mSession);
        aclJob->setRights(KIMAP::AclJobBase::Add, KIMAP::Acl::Lookup | KIMAP::Acl::Read | KIMAP::Acl::KeepSeen);
        aclJob->setMailBox(mFolder);
        connect(aclJob, SIGNAL(result(KJob*)), this, SLOT(onSetAclDone(KJob*)));
        aclJob->start();
    } else {
        startGenerateFBJob();
    }
}

void FBGeneratorFolderJob::onSetAclDone(KJob* job)
{
    qDebug() << "setAclDone" ;
    if (job->error()) {
        qWarning() << job->errorString();
        setError(KJob::UserDefinedError);
        logout();
        return;
    }
    resetRights = true;
    startGenerateFBJob();

}

void FBGeneratorFolderJob::startGenerateFBJob()
{
    QStringList folders;
    folders << mFolder;
    GenerateFBJob *fbJob = new GenerateFBJob(folders, mStartOfTimeFrame, mEndOfTimeFrame, mSession, this);
    QObject::connect(fbJob, SIGNAL(result(KJob*)), this, SLOT(onGenerateFBDone(KJob*)));
    fbJob->start();
}


void FBGeneratorFolderJob::onGenerateFBDone(KJob* job)
{
    if (job->error()) {
        qWarning() << "Error " << job->errorString();
        setError(KJob::UserDefinedError);
        logout();
        return;
    }
    GenerateFBJob *fbJob = qobject_cast<GenerateFBJob*>(job);
    Q_ASSERT(fbJob);

    mFreebusy = fbJob->getFreebusy();

    const Kolab::ContactReference org(Kolab::ContactReference::EmailReference, Kolab::Conversion::toStdString(QLatin1String("fbdaemon@localhost")));
    mFreebusy.setOrganizer(org);

    logout();
}

void FBGeneratorFolderJob::logout()
{
    if (resetRights) {
        KIMAP::SetAclJob * aclJob = new KIMAP::SetAclJob(mSession);
        aclJob->setRights(KIMAP::AclJobBase::Add, rights);
        aclJob->setMailBox(mFolder);
        connect(aclJob, SIGNAL(result(KJob*)), this, SLOT(onResetAclDone(KJob*)));
        aclJob->start();
    } else {
        KolabJob::logout();
    }
}

void FBGeneratorFolderJob::onResetAclDone(KJob* job)
{
    if (job->error()) {
        qWarning() << "Error " << job->errorString();
        setError(KJob::UserDefinedError);
    }
    KolabJob::logout();
}


void FBGeneratorFolderJob::setTimeFrame(const KDateTime& start, const KDateTime& end)
{
    mStartOfTimeFrame = start;
    mEndOfTimeFrame = end;
}

Kolab::Freebusy FBGeneratorFolderJob::getFreebusy() const
{
    return mFreebusy;
}

const QString& FBGeneratorFolderJob::getFolder() const
{
    return mFolder;
}

