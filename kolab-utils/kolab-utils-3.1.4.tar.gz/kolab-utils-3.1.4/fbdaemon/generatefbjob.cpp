/*
 * Copyright (C) 2012  Christian Mollekopf <mollekopf@kolabsys.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "generatefbjob.h"
#include <jobs/fetchmessagesjob.h>
#include <kimap/fetchjob.h>
#include <kimap/selectjob.h>

#include <freebusy.h>
#include <kolabobject.h>
#include <errorhandler.h>
#include <kcalconversion.h>

GenerateFBJob::GenerateFBJob(const QStringList &kolabEventFolders, const KDateTime &start, const KDateTime &end, KIMAP::Session *session, QObject* parent)
:   KJob(parent),
    mKolabEventFolders(kolabEventFolders),
    mSession(session),
    mStart(start),
    mEnd(end)
{

}

void GenerateFBJob::start()
{
    const QString mailbox = mKolabEventFolders.takeFirst();
    Debug() << "Generate f/b from mailbox: " << mailbox;
    Debug() << "from: " << mStart.toString() << " to: " << mEnd.toString();
    FetchMessagesJob *fetchJob = new FetchMessagesJob(mailbox, mSession, this);
    connect( fetchJob, SIGNAL(result(KJob*)), this, SLOT(onFetchDone(KJob*)) );
    fetchJob->start();
    mTime.start();
}

static void mergeEventsToFB(Kolab::Freebusy &freebusy, const QList<KMime::Message::Ptr> &messages, const KDateTime &start, const KDateTime &end)
{
    QList<KCalCore::Event::Ptr> events;
    Q_FOREACH ( const KMime::Message::Ptr &message, messages ) {
//         kDebug() << message->encodedContent();
        const Kolab::KolabObjectReader reader(message);
        if (Kolab::ErrorHandler::instance().errorOccured()) {
            Debug() << "Error occurrend, skipping";
            continue;
        }
        if (reader.getType() != Kolab::EventObject) {
            Error() << "wrong object type in calendar, skipping";
            continue;
        }
        events.append(reader.getEvent());
    }
    const Kolab::Freebusy &fb = Kolab::FreebusyUtils::generateFreeBusy(events, start, end, KCalCore::Person::Ptr());
    if (!freebusy.isValid()) {
        freebusy = fb;
    } else {
        //TODO replace by kcalcore merging
        std::vector <Kolab::FreebusyPeriod > periods = freebusy.periods();
        foreach (const Kolab::FreebusyPeriod &period, fb.periods()) {
            periods.push_back(period);
        }
        freebusy.setPeriods(periods);
    }
}

void GenerateFBJob::onFetchDone(KJob *job)
{
    if ( job->error() ) {
        Warning() << job->errorString();
        setError(KJob::UserDefinedError);
        emitResult();
        return;
    }

    FetchMessagesJob *fetch = qobject_cast<FetchMessagesJob*>( job );
    Q_ASSERT(fetch);

    Debug() << "found " << fetch->getMessages().size() << " messages";

    if (fetch->getMessages().isEmpty()) {
        mFreebusy = Kolab::FreebusyUtils::generateFreeBusy(QList<KCalCore::Event::Ptr>(), mStart, mEnd, KCalCore::Person::Ptr());
        checkJobDone();
        return;
    }
    
    mergeEventsToFB(mFreebusy, fetch->getMessages(), mStart, mEnd);
//     kDebug() << QString::fromStdString(Kolab::FreebusyUtils::toIFB(mFreebusy));

    checkJobDone();
}

void GenerateFBJob::checkJobDone()
{
    if (!mKolabEventFolders.isEmpty()) {
        start();
        return;
    }

    Debug() << "Generating is done";
    Debug() << "elapsed time [s]: " << static_cast<double>(mTime.elapsed())/1000.0;
    emitResult();
}

Kolab::Freebusy GenerateFBJob::getFreebusy() const
{
    return mFreebusy;
}

