/*
 * Copyright (C) 2014 Sandro Knauß <knauss@kolabsys.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "fbdaemonserver.h"
#include <QThread>

FbDaemonServer::FbDaemonServer(QObject *parent)
    : QTcpServer(parent)
{
}

FbDaemonServer::~FbDaemonServer()
{
    foreach(QThread * thread, mThreads) {
        thread->quit();
    }
    foreach(QThread * thread, mThreads) {
        thread->wait();
        delete thread;
    }
}

void FbDaemonServer::workerFinished(QThread *workerThread)
{
    //The worker thread is no longer necessary, so let's clean up.
    //The worker object is cleaned up by the signal connected to deleteLater().
    mThreads.remove(mThreads.indexOf(workerThread));
    workerThread->quit();
    workerThread->wait();
    delete workerThread;
}

void FbDaemonServer::incomingConnection(int socketDescriptor)
{
    /**
     * The concept is:
     * Hand off the worker QObject to the worker thread, and never again touch it.
     * All interaction is potentially from the wrong thread, so we're safer by not touch it.
     * Everything that is happening in the worker object is happening from the worker thread =>
     * we don't need to pay attention.
     *
     * By managing the thread from outside the object we can again ignore threading issues inside the object
     * and keep the doors open to recycle threads in a thread pool.
     */
    FbDaemonThread *worker = new FbDaemonThread(socketDescriptor);
    QThread *workerThread = new QThread();
    worker->moveToThread(workerThread);
    //Makes sure the FBDaemonThread is freed once the thread finishes and that the destructor is called from the worker thread
    connect(workerThread, SIGNAL(finished()), worker, SLOT(deleteLater()));
    connect(worker, SIGNAL(finished(QThread*)), this, SLOT(workerFinished(QThread*)));
    //Starts the work in the new thread
    QMetaObject::invokeMethod(worker, "start", Qt::QueuedConnection);
    mThreads << workerThread;
    workerThread->start();
}