/*
 * Copyright (C) 2012  Christian Mollekopf <mollekopf@kolabsys.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#ifndef FBCOORDINATOR_H
#define FBCOORDINATOR_H
#include <QObject>
#include <qqueue.h>
#include <QTime>
#include <kjob.h>

/**
 * Waits for jobs, and distributes them
 */
class FBCoordinator: public QObject
{
    Q_OBJECT
public:
    explicit FBCoordinator(QObject* parent = 0);

    /**
     * Gets a list of all available users and triggers a generate job
     */
    void generateForAllUsers(const QString &domain);

    /**
     * Generates and aggregates f/b for the @param user
     */
    void generateAllForUser(const QString &user);
    
    /**
     * Generates a partial f/b list for the @param user
     */
    void generateForUser(const QString &user);
    
    /**
     * Aggregates the partial f/b lists of the @param user
     */
    void aggregateForUser(const QString &user);
    
signals:
    void quit();
private slots:
    void onGeneratorDone(KJob*);
    void onGenerateAllResult(KJob*);
public slots:
    void onGotUserList(KJob*);
private:
    void continueProcessing();
    QTime mTimer;
    bool mTimerIsRunning;
    QTime mUserTimer;
    int mProgressCounter;
    int mTotalUsers;
    bool processQueue();
    QQueue<QString> mUserQueue;
};

#endif // FBCOORDINATOR_H
