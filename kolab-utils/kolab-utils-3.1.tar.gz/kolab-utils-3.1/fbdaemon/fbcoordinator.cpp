/*
 * Copyright (C) 2012  Christian Mollekopf <mollekopf@kolabsys.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#include "fbcoordinator.h"
#include "fbgeneratorjob.h"
#include "settings.h"
#include <jobs/getuserlistjob.h>
#include "fbaggregatorjob.h"
#include "authenticationjob.h"
#include <errorhandler.h>
#include <jobs/sequentialcompositejob.h>
#include <kimap/logoutjob.h>

FBCoordinator::FBCoordinator(QObject* parent)
:   QObject(parent),
    mTimerIsRunning(false),
    mProgressCounter(0),
    mTotalUsers(0)
{
    //TODO get user from job (trigger)
}

class UiProxy: public KIMAP::SessionUiProxy {
  public:
    bool ignoreSslError(const KSslErrorUiData& /* errorData */) {
//        Warning() << "Error during ssl";
        return true;
    }
};

void FBCoordinator::generateForAllUsers(const QString &filter)
{
    if (!mUserQueue.isEmpty()) {
        Warning() << "there is an existing processing queue, aborting";
        return;
    }
    mTimer.start();
    mTimerIsRunning = true;
    SessionSettings settings;
    settings.authenticationMode = Settings::instance().getAuthenticationMode();
    settings.encryptionMode = Settings::instance().getEncryptionMode();
    settings.userName = Settings::instance().getAuthorizationUser(); //Login as admin
    settings.host = Settings::instance().getServerUri(settings.port);
    SequentialCompositeJob *sequentialJob = new SequentialCompositeJob(true, this);
    KIMAP::Session *mSession = new KIMAP::Session( settings.host, settings.port, this );
    mSession->setUiProxy( KIMAP::SessionUiProxy::Ptr(new UiProxy()) );
//     QObject::connect( mSession, SIGNAL(stateChanged(KIMAP::Session::State,KIMAP::Session::State)),
//                       this, SLOT(onSessionStateChanged(KIMAP::Session::State,KIMAP::Session::State)) );

    
    AuthenticationJob *authJob = new AuthenticationJob(settings, mSession, this);
    sequentialJob->addSubjob(authJob);
    
    GetUserListJob *getUsersJob = new GetUserListJob(mSession, this);
    getUsersJob->setFilterDomain(filter);
    sequentialJob->addSubjob(getUsersJob);
    connect(getUsersJob, SIGNAL(result(KJob*)), this, SLOT(onGotUserList(KJob*)));

    KIMAP::LogoutJob *logoutjob = new KIMAP::LogoutJob(mSession);
    sequentialJob->addSubjob(logoutjob);

    connect(sequentialJob, SIGNAL(result(KJob*)), this, SLOT(onGenerateAllResult(KJob*)));
    sequentialJob->start();
}

void FBCoordinator::onGenerateAllResult(KJob *job)
{
    if (job->error()) {
        Warning() << "Error while generating for all users: " << job->errorString();
        continueProcessing();
    }
}

void FBCoordinator::onGotUserList(KJob *job)
{
    GetUserListJob *getUsersJob = static_cast<GetUserListJob*>(job);
    foreach(const QString &user, getUsersJob->getUserList()) {
//        Debug() << user;
        mUserQueue.enqueue(user);
    }
    mTotalUsers = mUserQueue.size();
    Debug() << "Found " << mUserQueue.size() << " users";
    continueProcessing();
}

bool FBCoordinator::processQueue()
{
    if (mUserQueue.isEmpty()) {
        return false;
    }
    
    const QString user = mUserQueue.dequeue();
    generateAllForUser(user);
    return true;
}

void FBCoordinator::continueProcessing()
{
    if (processQueue()) {
        return;
    }
    Debug() << "All done. Total time elapsed [s]: " << static_cast<double>(mTimer.elapsed())/1000.0;
    emit quit();
}

void FBCoordinator::generateAllForUser(const QString& user)
{
    if (!mTimerIsRunning) {
        mTimer.start();
    }
    Debug() << "Starting generation for user: " << user;
    SequentialCompositeJob *userJob = new SequentialCompositeJob(true, this);
    SessionSettings settings = Settings::instance().getSessionSettings();
    settings.userName = user;
    userJob->addSubjob(new FBGeneratorJob(settings, userJob));
    userJob->addSubjob(new FBAggregatorJob(settings, userJob));
    connect(userJob, SIGNAL(result(KJob*)), this, SLOT(onGeneratorDone(KJob*)));
    mUserTimer.start();
    userJob->start();
}

void FBCoordinator::generateForUser(const QString& user)
{
    Debug() << "Starting generation for user: " << user;
    mTimer.start();
    SessionSettings settings = Settings::instance().getSessionSettings();
    settings.userName = user;
    FBGeneratorJob *generator = new FBGeneratorJob(settings, this);
    connect(generator, SIGNAL(result(KJob*)), this, SLOT(onGeneratorDone(KJob*)));
    generator->start();
}

void FBCoordinator::aggregateForUser(const QString& user)
{
    Debug() << "Starting aggregation for user";
    mTimer.start();
    SessionSettings settings = Settings::instance().getSessionSettings();
    settings.userName = user;
    FBAggregatorJob *generator = new FBAggregatorJob(settings, this);
    connect(generator, SIGNAL(result(KJob*)), this, SLOT(onGeneratorDone(KJob*)));
    generator->start();
}

void FBCoordinator::onGeneratorDone(KJob *job)
{
    if (job->error()) {
        Warning() << "Error: " << job->errorString();
    }
    mProgressCounter++;
    if (mTotalUsers > 0) {
        Debug() << "Time elapsed for user [s]: " << static_cast<double>(mUserTimer.elapsed())/1000.0;
        Debug() << mProgressCounter << " out of " << mTotalUsers;
    }
    continueProcessing();
}


