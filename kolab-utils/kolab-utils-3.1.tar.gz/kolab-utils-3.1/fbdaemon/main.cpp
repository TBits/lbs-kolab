/*
 * Copyright (C) 2012  Christian Mollekopf <mollekopf@kolabsys.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include <QtCore/qcoreapplication.h>
#include <qsettings.h>
#include <QDir>
#include <kcmdlineargs.h>
#include <kdebug.h>
#include <kglobal.h>
#include "fbcoordinator.h"
#include "settings.h"
#include "kolabutils-version.h"

int main(int argc, char *argv[])
{
    //Init for ki18n calls
    KGlobal::locale();

    KCmdLineArgs::init(argc, argv, argv[0], QByteArray(), ki18n("freebusy"),  KOLABUTILS_VERSION, ki18n("kolab freebusy generator"), KCmdLineArgs::CmdLineArgNone);

    KCmdLineOptions options;
    options.add("c").add("configuration <file>", ki18n("Configuration file"), "/etc/kolab/kolab.conf");
    options.add("g").add("generate", ki18n("Generate partial f/b lists for user"));
    options.add("a").add("aggregate", ki18n("Aggregate partial f/b lists for user"));
    options.add("d").add("daemon", ki18n("Run daemon (todo)"));
    options.add("generateall", ki18n("Generate and aggregate for all users within domain"));
    options.add("+[user/filter]", ki18n("User for generation/aggregation | Contains-Filter for userlist for which freebusy is generated (leave empty to generate for all)"));

    KCmdLineArgs::addCmdLineOptions( options );
    
    QCoreApplication app(argc, argv);

    QCoreApplication::setOrganizationName("Kolab");
    QCoreApplication::setOrganizationDomain("kolab.org");
    QCoreApplication::setApplicationName("Freebusy Daemon");

    KCmdLineArgs *args = KCmdLineArgs::parsedArgs();

    //Make config file path absolute in case we change the directory
    Settings::instance().setFile(QDir().absoluteFilePath(args->getOption("configuration")));

    FBCoordinator coordinator(&app);
    QObject::connect(&coordinator, SIGNAL(quit()), &app, SLOT(quit()));
    bool nothingTodo = false;
    if (args->isSet("generateall")) {
        if (args->count()) {
            coordinator.generateForAllUsers(args->arg(0));
        } else {
            coordinator.generateForAllUsers(QString());
        }
    } else {
        if (args->count() == 0) {
            kWarning() << "nothing to do";
            return 0;
        }
        if (args->isSet("generate") && args->isSet("aggregate")) {
            coordinator.generateAllForUser(args->arg(0));
        } else if (args->isSet("generate")) {
            coordinator.generateForUser(args->arg(0));
        } else if (args->isSet("aggregate")) {
            coordinator.aggregateForUser(args->arg(0));
        } else {
            nothingTodo = true;
        }
        
    }
    if (args->isSet("daemon")) {

    }
    if (!nothingTodo) {
        app.exec();
    }

    return 0;
}
