/*
 * Copyright (C) 2012  Christian Mollekopf <mollekopf@kolabsys.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef KOLABJOB_H
#define KOLABJOB_H
#include <kimap/session.h>
#include <QStringList>
#include <QHash>
#include <kimap/listjob.h>
#include <sessionsettings.h>

#define X_ORIGIN_HEADER "X-Freebusy-Origin"

class ProbeKolabServerJob;
class KolabJob: public KJob
{
    Q_OBJECT
public:
    explicit KolabJob(const SessionSettings &settings, QObject* parent = 0);
    virtual void start();
    
private Q_SLOTS:
    void onSessionStateChanged(KIMAP::Session::State newState, KIMAP::Session::State oldState);
    void onAuthDone(KJob*);
    void onProbeDone(KJob* job);
    void onLogoutDone(KJob*);
    void onSetupDone(KJob*);

protected:
    virtual QStringList requiredFolders();
    virtual void startWork() = 0;
    void logout();
    SessionSettings mSessionSettings;

    QString mFreebusyFolder;

    KIMAP::Session *mSession;
    QMultiHash<QString, QString> mKolabFolders;
};

#endif // KOLABJOB_H
