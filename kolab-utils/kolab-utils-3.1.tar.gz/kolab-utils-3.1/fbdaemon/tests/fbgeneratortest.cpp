/*
 * Copyright (C) 2012  Christian Mollekopf <mollekopf@kolabsys.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#include "fbgeneratortest.h"

#include <QTest>
#include <QDebug>
#include <QDir>
#include <kolabobject.h>
#include <freebusy.h>
#include <kcalconversion.h>
#include "fbdaemon/fbgeneratorjob.h"
#include "settings.h"
#include "kolabaccount.h"

FBGeneratorTest::FBGeneratorTest(QObject* parent)
    : QObject(parent),
        targethost("192.168.122.10"),
        user("john.doe@example.org"),
        admin("cyrus-admin"),
        adminpw("admin"),
        port(143)
{
    Object calObj1;
    KCalCore::Event::Ptr event(new KCalCore::Event());
    event->setUid("uid1");
    event->setDtStart(KDateTime::currentUtcDateTime());
    event->setDtEnd(KDateTime::currentUtcDateTime().addSecs(3600));
    calObj1.object = QVariant::fromValue(Kolab::KolabObjectWriter::writeEvent(event, Kolab::KolabV3, "fbtest"));
    folders << Folder("Calendar", Kolab::EventType, QList<Object>() << calObj1);

//         folders << Folder("Freebusy", Kolab::FreebusyType, QList<Object>()/* << fbObj1*/);
}

void FBGeneratorTest::setupTargetAccount()
{
    QObject obj;
    KolabAccount *account = new KolabAccount(&obj);
    account->setHost(targethost, port);
    account->setCredentials(user, adminpw, admin);
    QVERIFY(account->init());

    account->cleanAccount();
    createFolders(account, folders);
}

void FBGeneratorTest::executeGeneration()
{
    Settings::instance().setAuthorizationUser(admin);
    Settings::instance().setPassword(adminpw);
    Settings::instance().setServerUri(targethost);
    Settings::instance().setThreshold(10);
    Settings::instance().setTimeframe(60);
    Settings::instance().setAggregatedICalOutputDirectory(QDir::tempPath());
    SessionSettings sessionSettings = Settings::instance().getSessionSettings();
    sessionSettings.userName = user;

    QObject obj;
    FBGeneratorJob *job = new FBGeneratorJob(sessionSettings, &obj);
    job->exec();
}
    
void FBGeneratorTest::checkFolders(KolabAccount *account, const QList<Folder> &folders)
{
    const QStringList &receivedFolders = account->lookupFolderList();
    qDebug() << receivedFolders;
    foreach(const Folder &folder, folders) {
        qDebug() << folder.name;
        QVERIFY(receivedFolders.contains(folder.name));
        const QList<Object> &objects = account->getObjects(folder.name);
        QCOMPARE(objects.size(), folder.objects.size());

        QList<Object>::const_iterator recObjIt = objects.constBegin();
        QList<Object>::const_iterator objIt = folder.objects.constBegin();
        for (;objIt != folder.objects.constEnd() && recObjIt != objects.constEnd(); ++objIt, ++recObjIt) {
            //TODO Check fb objects
        }
    }
}

void FBGeneratorTest::checkTargetAccount()
{
    //Check that fb-object and aggregated fb object has been created
    QObject obj;
    KolabAccount *account = new KolabAccount(&obj);
    account->setHost(targethost, port);
    account->setCredentials(user, adminpw, admin);
    account->init();


    Object fbObj1;
    Kolab::Freebusy fb;
    fb.setStart(Kolab::Conversion::fromDate(KDateTime::currentUtcDateTime()));
    fb.setEnd(Kolab::Conversion::fromDate(KDateTime::currentUtcDateTime().addDays(60)));
    fbObj1.object = QVariant(Kolab::KolabObjectWriter::writeFreebusy(fb, Kolab::KolabV3, "fbtest"));

    QList<Folder> targetFolders;
    targetFolders << Folder("Freebusy", Kolab::FreebusyType, QList<Object>() << fbObj1);
    checkFolders(account, targetFolders);
    account->logout();
}
    
void FBGeneratorTest::testGenerator()
{
    setupTargetAccount();
    executeGeneration();
    checkTargetAccount();
}

QTEST_MAIN( FBGeneratorTest )

#include "fbgeneratortest.moc"