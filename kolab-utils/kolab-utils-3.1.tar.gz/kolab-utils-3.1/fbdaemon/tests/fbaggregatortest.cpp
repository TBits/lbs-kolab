/*
 * Copyright (C) 2012  Christian Mollekopf <mollekopf@kolabsys.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "fbaggregatortest.h"

#include <QTest>
#include <QDebug>
#include <QDir>
#include <kcalcore/memorycalendar.h>
#include <kcalcore/icalformat.h>
#include <freebusy.h>
#include <kcalconversion.h>
#include <kolabobject.h>
#include "fbdaemon/fbgeneratorjob.h"
#include "fbdaemon/fbaggregatorjob.h"
#include "settings.h"
#include "kolabaccount.h"
#include "testlib/testutils.h"

FBAggregatorTest::FBAggregatorTest(QObject* parent)
    : QObject(parent),
        targethost("192.168.122.10"),
        user("john.doe@example.org"),
        admin("cyrus-admin"),
        adminpw("admin"),
        port(143)
{
    Object fbObj1;
    Kolab::Freebusy fb;
    fb.setOrganizer(Kolab::ContactReference("mail@example.com", "john doe"));
    fb.setStart(Kolab::Conversion::fromDate(KDateTime::currentUtcDateTime()));
    fb.setEnd(Kolab::Conversion::fromDate(KDateTime::currentUtcDateTime().addDays(60)));
    fbObj1.object = QVariant::fromValue(Kolab::KolabObjectWriter::writeFreebusy(fb, Kolab::KolabV3, "fbtest"));

    Object fbObj2;
    Kolab::Freebusy fb2;
    fb2.setStart(Kolab::Conversion::fromDate(KDateTime::currentUtcDateTime()));
    fb2.setEnd(Kolab::Conversion::fromDate(KDateTime::currentUtcDateTime().addDays(60)));
    fbObj2.object = QVariant::fromValue(Kolab::KolabObjectWriter::writeFreebusy(fb2, Kolab::KolabV3, "fbtest"));

    folders << Folder("Freebusy", Kolab::FreebusyType, QList<Object>() << fbObj1 << fbObj2);
}

void FBAggregatorTest::setupTargetAccount()
{
    QObject obj;
    KolabAccount *account = new KolabAccount(&obj);
    account->setHost(targethost, port);
    account->setCredentials(user, adminpw, admin);
    account->setEncryptionMode(KIMAP::LoginJob::TlsV1);
    QVERIFY(account->init());

    account->cleanAccount();
    createFolders(account, folders);
}

void FBAggregatorTest::executeAggregation()
{
    Settings::instance().setAuthorizationUser(admin);
    Settings::instance().setPassword(adminpw);
    Settings::instance().setServerUri(targethost);
    Settings::instance().setThreshold(10);
    Settings::instance().setTimeframe(60);
    Settings::instance().setAggregatedICalOutputDirectory(QDir::tempPath());
    SessionSettings sessionSettings = Settings::instance().getSessionSettings();
    sessionSettings.userName = user;

    QObject obj;
    FBAggregatorJob *job = new FBAggregatorJob(sessionSettings, &obj);
    job->exec();
    generatedFile = job->generatedFile();
}

void FBAggregatorTest::checkFbObject()
{
    QVERIFY(QFileInfo(generatedFile).exists());
    QFile file(generatedFile);
    QVERIFY(file.open(QIODevice::ReadOnly|QIODevice::Text));
    QTextStream in(&file);
    QString data = in.readAll();

    qDebug() << data;

    KCalCore::ICalFormat format;
    KCalCore::Calendar::Ptr cal(new KCalCore::MemoryCalendar(KDateTime::Spec::UTC()));
    KCalCore::ScheduleMessage::Ptr msg = format.parseScheduleMessage(cal, data);
    QVERIFY(msg);
    QCOMPARE(msg->method(), KCalCore::iTIPPublish);
    QCOMPARE(format.timeSpec(), KDateTime::Spec::UTC());
    QVERIFY(msg->event());
    QCOMPARE(msg->event()->organizer()->email(), QLatin1String("john.doe@example.org"));
    QVERIFY(!msg->event()->uid().isEmpty());
    QVERIFY(msg->event()->lastModified().isValid());

    //Check that aggregated fb object has been created
}
    
void FBAggregatorTest::testGenerator()
{
    setupTargetAccount();
    executeAggregation();
    checkFbObject();
}

QTEST_MAIN(FBAggregatorTest)

#include "fbaggregatortest.moc"