
/*
 * Copyright (C) 2013  Christian Mollekopf <mollekopf@kolabsys.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef PROBEIMAPSERVERJOB_H
#define PROBEIMAPSERVERJOB_H
#include <kcompositejob.h>
#include <QStringList>
#include <QHash>
#include <kimap/session.h>
#include <kimap/listjob.h>

/**
 * Probeserver for supported IMAP features
 */
class ProbeIMAPServerJob: public KJob
{
    Q_OBJECT
public:
    explicit ProbeIMAPServerJob(KIMAP::Session *, QObject* parent = 0);
    virtual ~ProbeIMAPServerJob();
    virtual void start();

    QList<KIMAP::MailBoxDescriptor> personalNamespace() const;
    QList<KIMAP::MailBoxDescriptor> excludedNamespaces() const;
    QStringList capabilities() const;

protected Q_SLOTS:
    void onCapabilitiesTestDone(KJob *);
    void onNamespacesTestDone(KJob *);

private:
    KIMAP::Session *mSession;
    QStringList mCapabilities;
    QList<KIMAP::MailBoxDescriptor> mPersonalNamespace;
    QList<KIMAP::MailBoxDescriptor> mExcludedNamespace;
};

#endif
