/*
 * Copyright (C) 2012  Christian Mollekopf <mollekopf@kolabsys.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef KOLABACCOUNT_H
#define KOLABACCOUNT_H
#include <QObject>
#include <formathelpers.h>
#include <kolabobject.h>
#include <kimap/loginjob.h>
#include <kimap/listjob.h>
#include <kmime/kmime_message.h>
#include "object.h"

namespace KIMAP {
class Session;
}

class KolabAccount: public QObject
{
    Q_OBJECT
public:
    explicit KolabAccount(QObject* parent = 0);
    virtual ~KolabAccount();
    
    void setHost(const QString &host, qint16 port);
    void setCredentials(const QString &username, const QString &pw, const QString &authorizationName);
    void setEncryptionMode(KIMAP::LoginJob::EncryptionMode);
    void setAuthenticationMode(KIMAP::LoginJob::AuthenticationMode);
    bool init();

    void cleanAccount();
    void setupFolders();
    void appendObjectSync(Object obj, const QString &folder);
    KJob *appendObject(Object obj, const QString &folder);
    void createFolder(const QString &name, Kolab::FolderType folderType);
    void createFolder(const QString &name, const QByteArray &annotation);
    void setDryRun(bool);
    void setWipeTargetFolders(bool);
    void setRegextrans(const QStringList &);

    KJob *logout();
    
    QList<Object> getObjects(const QString& folder);
    QStringList lookupFolderList();

    void setVersion(Kolab::Version);
    
    QString getUsername() const;

    /**
     * Applies any target folder name transformations.
     * This includes:
     * * user-specified regextrans2 transformations
     * * normalizations to get a valid name according to the IMAP specification
     */
    QString applyTargetFolderTransformations(const QString &) const;
    
private slots:
    void mailBoxesReceived(const QList<KIMAP::MailBoxDescriptor> &descriptors, const QList< QList< QByteArray > > &flags);
private:
    KMime::Message::Ptr writeObject(const Object &obj);
    KIMAP::Session *mSession;
    QString mHost;
    int mPort;
    QString mAuthorizationName;
    QString mUsername;
    QString mPw;
    KIMAP::LoginJob::EncryptionMode mEncryptionMode;
    KIMAP::LoginJob::AuthenticationMode mAuthenticationMode;
    QList<KIMAP::MailBoxDescriptor> mMailboxes;
    QList<KIMAP::MailBoxDescriptor> mPersonalNamespaces;
    QList<KIMAP::MailBoxDescriptor> mExcludedNamespaces;
    QStringList mFolders;
    QStringList mCapabilities;
    bool mDryRun;
    bool mWipeTargetFolders;
    Kolab::Version mVersion;
    QMap<QString, QString> mRegextrans;
};

#endif // KOLABACCOUNT_H
