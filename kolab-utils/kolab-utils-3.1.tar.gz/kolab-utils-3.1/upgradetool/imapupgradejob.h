/*
    <one line to give the library's name and an idea of what it does.>
    Copyright (C) 2012  Christian Mollekopf <chrigi_1@fastmail.fm>

    This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU Affero General Public
    License as published by the Free Software Foundation; either
    version 2.1 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    Affero General Public License for more details.

    You should have received a copy of the GNU Affero General Public
    License along with this library; if not, write to the Free Software
    Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
*/


#ifndef IMAPUPGRADER_H
#define IMAPUPGRADER_H
#include <QObject>
#include <QStringList>
#include <kjob.h>
#include <kolabobject.h>
#include <kimap/session.h>
#include <kimap/loginjob.h>

namespace KIMAP {
struct MailBoxDescriptor;
}

class ImapUpgradeJob: public KJob
{
    Q_OBJECT
public:
    explicit ImapUpgradeJob(QObject* parent = 0);
    virtual ~ImapUpgradeJob();

    void setOverrideObjectType(const Kolab::ObjectType type);
    void setFolderToUpgrade(const QString &);
    void connectToAccount(const QString &hostName, qint16 port, const QString &username, const QString &proxyauth, const QString &pw, KIMAP::LoginJob::EncryptionMode, KIMAP::LoginJob::AuthenticationMode);

    virtual void start(){};
private slots:
    void onSessionStateChanged(KIMAP::Session::State newState, KIMAP::Session::State oldState);
    void onLoginDone( KJob *job );
    void onProbeDone( KJob *job );
    void modifyDone( KJob *job );
private:

    KIMAP::Session *m_session;
    bool m_requireEncryption;
    QString m_folderToUpgrade;
    Kolab::ObjectType m_overrideObjectType;
};

#endif // IMAPUPGRADER_H
