/*
    <one line to give the library's name and an idea of what it does.>
    Copyright (C) 2012  Christian Mollekopf <chrigi_1@fastmail.fm>

    This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU Affero General Public
    License as published by the Free Software Foundation; either
    version 2.1 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    Affero General Public License for more details.

    You should have received a copy of the GNU Affero General Public
    License along with this library; if not, write to the Free Software
    Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
*/


#include "kolabformatupgradejob.h"
#include "upgradeutilities.h"
#include "jobs/sequentialcompositejob.h"
#include "jobs/messagemodifyjob.h"
#include <kolabobject.h>
#include <errorhandler.h>

#include <kimap/selectjob.h>
#include <kimap/fetchjob.h>
#include <kimap/expungejob.h>

#include <QStringList>

KolabFormatUpgradeJob::KolabFormatUpgradeJob(const QString& folder, KIMAP::Session* session, QObject* parent)
:   KJob(parent),
    m_session(session),
    m_folder(folder),
    seqJob(new SequentialCompositeJob(this)),
    m_overrideObjectType(Kolab::InvalidObject)
{

}

void KolabFormatUpgradeJob::setOverrideObjectType(Kolab::ObjectType type)
{
    m_overrideObjectType = type;
}

void KolabFormatUpgradeJob::start()
{
    Debug() << "Processing Mailbox....... " << m_folder;
    
    KIMAP::SelectJob *select = new KIMAP::SelectJob( m_session );
    select->setMailBox( m_folder );
    connect( select, SIGNAL(result(KJob*)), this, SLOT(onSelectDone(KJob*)) );
    select->start();
}

void KolabFormatUpgradeJob::onSelectDone(KJob *job)
{
    if ( job->error() ) {
        Error() << job->errorString();
        emitResult();
        return;
    }
    
    KIMAP::SelectJob *select = qobject_cast<KIMAP::SelectJob*>( job );
    Q_ASSERT(select);
    
    const int messageCount = select->messageCount();
    
    if (messageCount <= 0) {
        //empty, nothing to do
        emitResult();
        return;
    }
    
    KIMAP::FetchJob::FetchScope scope;
    scope.mode = KIMAP::FetchJob::FetchScope::Full;
        
    KIMAP::FetchJob *fetch = new KIMAP::FetchJob( m_session );
    fetch->setSequenceSet( KIMAP::ImapSet( 1, messageCount ) );
    fetch->setScope( scope );
    connect( fetch, SIGNAL( headersReceived( QString, QMap<qint64, qint64>, QMap<qint64, qint64>,
                                                QMap<qint64, KIMAP::MessageFlags>, QMap<qint64, KIMAP::MessagePtr> ) ),
                this, SLOT( onHeadersReceived( QString, QMap<qint64, qint64>, QMap<qint64, qint64>,
                                            QMap<qint64, KIMAP::MessageFlags>, QMap<qint64, KIMAP::MessagePtr> ) ) );
    connect( fetch, SIGNAL(result(KJob*)),
                this, SLOT(onHeadersFetchDone(KJob*)) );
    fetch->start();
}

void KolabFormatUpgradeJob::onHeadersReceived( const QString &mailBox, 
                                           const QMap<qint64, qint64> &uids,
                                           const QMap<qint64, qint64> &/*sizes*/,
                                           const QMap<qint64, KIMAP::MessageFlags> &flags,
                                           const QMap<qint64, KIMAP::MessagePtr> &messages )
{    
//     Debug() << mailBox;
    foreach ( qint64 number, uids.keys() ) {
//         Debug() << "preparing for upgrade " << uids[number];
        const KMime::Message::Ptr &message = messages[number];
        //TODO implement different target folder
        KMime::Message::Ptr msg = Kolab::Upgrade::upgradeMessage(message, m_overrideObjectType);
        if (!msg.get()) {
            Error() << "failed to convert message with uid " << QString::number(uids[number]);
            continue;
        }
        seqJob->addSubjob(new MessageModifyJob(msg, mailBox, flags[number], uids[number], m_session, this));
    }
}

void KolabFormatUpgradeJob::onHeadersFetchDone( KJob *job )
{
    if ( job->error() ) {
        Error() << job->errorString();
        emitResult();
        return;
    }
    
    //Run expunge after every modify, while the folder is still selected
    Q_ASSERT(m_session->state() & KIMAP::Session::Selected);
    seqJob->addSubjob(new KIMAP::ExpungeJob(m_session));
    
    connect(seqJob, SIGNAL(finished(KJob*)), this, SLOT(onModifyFinished(KJob*)));
    seqJob->start();
}

void KolabFormatUpgradeJob::onModifyFinished( KJob *job )
{
//     Debug() << "upgrade done";
    if ( job->error() ) {
        Error() << job->errorString();
    }
    emitResult();
}
