/*
 * Copyright (C) 2012  Christian Mollekopf <mollekopf@kolabsys.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#include "upgradeutilities.h"
#include <kolabobject.h>
#include <kcalconversion.h>
#include <kdebug.h>

#include <kolabevent.h>
#include <kolabformat.h>
#include <errorhandler.h>

namespace Kolab {
    namespace Upgrade {

KMime::Message::Ptr upgradeMessage(KMime::Message::Ptr msg, Kolab::ObjectType overrideObjectType)
{
    Kolab::KolabObjectReader reader;
    if (overrideObjectType != Kolab::InvalidObject) {
        reader.setObjectType(overrideObjectType);
    }
    const Kolab::ObjectType type = reader.parseMimeMessage(msg);
    if (Kolab::ErrorHandler::errorOccured()) {
        Error() << "error while parsing message";
        return KMime::Message::Ptr();
    }
    switch (type) {
        case Kolab::EventObject:
            return Kolab::KolabObjectWriter::writeEvent(reader.getEvent());
        case Kolab::TodoObject:
            return Kolab::KolabObjectWriter::writeTodo(reader.getTodo());
        case Kolab::JournalObject:
            return Kolab::KolabObjectWriter::writeJournal(reader.getJournal());
        case Kolab::ContactObject:
            return Kolab::KolabObjectWriter::writeContact(reader.getContact());
        case Kolab::DistlistObject:
            return Kolab::KolabObjectWriter::writeDistlist(reader.getDistlist());
        case Kolab::NoteObject:
            return Kolab::KolabObjectWriter::writeNote(reader.getNote());
        case Kolab::DictionaryConfigurationObject: {
            QString lang;
            const QStringList &dict = reader.getDictionary(lang);
            return Kolab::KolabObjectWriter::writeDictionary(dict, lang);
        }
        case Kolab::InvalidObject:
        default:
            //TODO handle configuration objects
            Error() << "failed to read mime file";
    }
    return KMime::Message::Ptr();
}
        
/**
 * Upgrades the format of a complete mime message containing a kolab object
 */
QString upgradeMime(const QByteArray &input, Kolab::ObjectType overrideObjectType)
{
    KMime::Message::Ptr msg = KMime::Message::Ptr(new KMime::Message);
    msg->setContent( KMime::CRLFtoLF(input) );
    msg->parse();
    msg->content(KMime::ContentIndex());
        
    KMime::Message::Ptr message = upgradeMessage(msg, overrideObjectType);
    if (!message) {
        return QString();
    }

    QString result;
    QTextStream s(&result);
    message->toStream(s);
    return result;
}



QString upgradeEventXML(const QByteArray &xmlData, QStringList &attachments)
{
    const KCalCore::Event::Ptr i = Kolab::readV2EventXML(xmlData, attachments);
    const Kolab::Event &event = Kolab::Conversion::fromKCalCore(*i);
    const std::string &v3String = Kolab::writeEvent(event);
    return QString::fromStdString(v3String);
}


    }
}
