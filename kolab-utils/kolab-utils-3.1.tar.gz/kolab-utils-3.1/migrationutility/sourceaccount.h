/*
 * Copyright (C) 2012  Christian Mollekopf <mollekopf@kolabsys.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef SOURCEACCOUNT_H
#define SOURCEACCOUNT_H

#include <QObject>
#include <QStringList>
#include <formathelpers.h>
#include <kolabobject.h>
#include <kimap/loginjob.h>
#include <kimap/listjob.h>
#include <kmime/kmime_message.h>
#include "object.h"
#include "jobs/fetchmessagesjob.h"
#include "statefile.h"

/**
 * Job interface to retrieve objects from a folder.
 */
class FetchObjectsJob: public KJob
{
    Q_OBJECT
public:
    explicit FetchObjectsJob(QObject* parent = 0);
Q_SIGNALS:
    /**
     * Emitted when objects are received from a folder.
     * First arument is the sourcefolder that the objects where fetched from.
     */
    void objectsReceived(QString, QList<Object>);
};

/**
 * Job interface to retrieve folder of an account.
 */
class FetchFoldersJob: public KJob
{
    Q_OBJECT
public:
    explicit FetchFoldersJob(QObject* parent = 0);
Q_SIGNALS:
    /**
     * Emitted when objects are received from a folder.
     * First arument is the sourcefolder that the objects where fetched from.
     */
    void foldersReceived(QStringList);
};

/**
 * Represents a single users account on a server.
 *
 * This class is used as factory for the jobs to extract the necessary data that needs to be migrated.
 *
 * One account typically represents access via a single protocol (i.e. an imap account).
 */
class SourceAccount: public QObject
{
    Q_OBJECT
public:
    explicit SourceAccount(QObject* parent = 0);

    /**
     * Login to the source account.
     *
     * If the job is sucessful, a session has been established and the source account can be used.
     */
    virtual KJob *login();

    /*
     * Synchronous lookup of folder list
     */
    virtual QStringList lookupFolderList();

    /**
     * Asynchronous lookup of folders
     */
    virtual FetchFoldersJob *fetchFolderList();

    /**
     * Synchronous wrapper around fetch objects + convertObject
     *
     * Use only for testing.
     *
     * Returns all objects of the source folder already converted using convertObject.
     */
    QList<Object> getObjects(const QString &sourceFolder);

    /**
     * Async method to retrieve objects
     *
     * used in combination with convertObject to stream objects.
     *
     * @param sourceFolder Folder on the source server to fetch objects from.
     */
    virtual FetchObjectsJob *fetchObjects(const QString &sourceFolder);

    /**
     * convert source object to target object.
     * Used when streaming objects.
     */
    virtual Object convertObject(const Object &object, const QString& sourceFolder) const;

    /**
     * Close connection to source account;
     */
    virtual KJob *logout();

    /**
     * Translate source folder to target folder
     */
    virtual QPair<Kolab::FolderType, QString> translateFolder(const QString& sourceFolder);

    /**
     * Set a statefile to record migration progress.
     * This allows to resume the migration.
     */
    void setStatefile(const StateFile &);

    /**
     * Convenience method to record the migration of a single object.
     */
    void recordSuccessfulMigration(const Object &obj, const QString &folder);

    /**
     * Record the sucessful migration of an object.
     */
    virtual void recordSuccessfulMigration(const QList<Object> &obj, const QString &sourceFolder);

    /**
     * Specify a list of regex to ignore source folders.
     */
    void setIgnoredFolders(const QStringList &);
    virtual QStringList ignoredFolders() const;

protected:
    StateFile mStatefile;
private slots:
    void onObjectsReceived(const QString &, const QList<Object> &);

private:
    QList<Object> mObjectList;
    QStringList mIgnoredFolders;
};

class TestAccount: public SourceAccount
{
    Q_OBJECT
public:
    explicit TestAccount(QObject* parent = 0);
    virtual QStringList lookupFolderList();
    virtual FetchObjectsJob *fetchObjects(const QString &sourceFolder);
    virtual KJob *login();
    QStringList mFolderList;
private:
    class DummyJob : public KJob {
        virtual void start() {emitResult();}
    };
};


#endif // SOURCEACCOUNT_H
