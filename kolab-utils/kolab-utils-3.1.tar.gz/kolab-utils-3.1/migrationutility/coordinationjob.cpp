/*
 * Copyright (C) 2012  Christian Mollekopf <mollekopf@kolabsys.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "coordinationjob.h"
#include "sourceserver.h"
#include "kolabserver.h"
#include "migrateuserjob.h"
#include <errorhandler.h>
#include <QDebug>

CoordinationJob::CoordinationJob(SourceServer *sourceServer, KolabServer *kolabServer, QObject* parent)
:   KJob(parent),
    mSourceServer(sourceServer),
    mKolabServer(kolabServer)
{

}

void CoordinationJob::start()
{
    UserListJob *listJob = mSourceServer->listUsers();
    Q_ASSERT(listJob);
    connect(listJob, SIGNAL(result(KJob*)), this, SLOT(onUserListJobDone(KJob*)));
    listJob->start();
}

void CoordinationJob::onUserListJobDone(KJob* job)
{
    if (job->error()) {
        setError(UserDefinedError);
        setErrorText("Failed to get user list: " + job->errorString());
        emitResult();
        return;
    }
    UserListJob *listJob = static_cast<UserListJob*>(job);
    mUserList = listJob->getUserList();
    if (mUserList.isEmpty()) {
        Debug() << "no users found";
    } else {
        Debug() << "migrating the following users: ";
        qDebug() << mUserList;
    }
    processUser();
}

void CoordinationJob::processUser()
{
    if (mUserList.isEmpty()) {
        Debug() << "done";
        emitResult();
        return;
    }
    const QString user = mUserList.takeFirst();
    MigrateUserJob *job = new MigrateUserJob(mSourceServer->getSourceAccounts(user), mKolabServer->getAccount(user), this);
    connect(job, SIGNAL(result(KJob*)), this, SLOT(userMigrated(KJob*)));
    job->start();
}

void CoordinationJob::userMigrated(KJob *job)
{
    if (job->error()) {
        Error() << job->errorString();
    }
    processUser();
}

