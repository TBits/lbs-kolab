/*
 * Copyright (C) 2012  Christian Mollekopf <mollekopf@kolabsys.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef IMAPSOURCEACCOUNT_H
#define IMAPSOURCEACCOUNT_H

#include "sourceaccount.h"

class IMAPSourceAccount: public SourceAccount
{
    Q_OBJECT
public:
    explicit IMAPSourceAccount(QObject* parent = 0);
    virtual ~IMAPSourceAccount();
    virtual QStringList lookupFolderList();
    virtual FetchObjectsJob *fetchObjects(const QString &folder);
    virtual Object convertObject(const Object &object, const QString& folder) const;
    virtual QPair<Kolab::FolderType, QString> translateFolder(const QString& folder);

    /**
     * Prepare the connection for a login attempt.
     */
    void prepareConnection(QString host, qint16 port, const QString &authorizationName, const QString &userName, const QString &password, KIMAP::LoginJob::EncryptionMode encryptionMode, KIMAP::LoginJob::AuthenticationMode authenticationMode);

    KJob *login();
    KJob *logout();
    virtual void recordSuccessfulMigration(const QList<Object> &obj, const QString &folder);

private slots:
    void mailBoxesReceived(const QList<KIMAP::MailBoxDescriptor> &descriptors, const QList< QList< QByteArray > > &flags);
    void onSessionStateChanged(KIMAP::Session::State,KIMAP::Session::State);

protected:
    //get namespace
    virtual void init();
    Kolab::FolderType getFolderType(const QString &folder);
    KIMAP::Session *getSession();
    QList<KIMAP::MailBoxDescriptor> mPersonalNamespaces;

private:
    /**
     * Get UIDS of all messages in the folder on the source account
     *
     * This is used to find out which objects to migrate by subtracting already migrated uids from the list.
     */
    QList<qint64> getImapUids(const QString &folder);

    QList<KIMAP::MailBoxDescriptor> mMailboxes;
    KIMAP::Session *mSession;
    QString mHost;
    int mPort;
    QString mUsername;
    QString mAuthorizationName;
    QString mPw;
    KIMAP::LoginJob::EncryptionMode mEncryptionMode;
    KIMAP::LoginJob::AuthenticationMode mAuthenticationMode;
};

class FetchIMAPObjectsJob : public FetchObjectsJob
{
    Q_OBJECT
public:
    FetchIMAPObjectsJob(FetchMessagesJob *fetchJob, QObject *parent);
    virtual void start();
    FetchMessagesJob * const mFetchMessagesJob;
private slots:
    void onJobDone(KJob *job);
};


#endif
