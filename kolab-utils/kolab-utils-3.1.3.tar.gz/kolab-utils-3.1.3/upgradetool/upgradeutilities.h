/*
 * Copyright (C) 2012  Christian Mollekopf <mollekopf@kolabsys.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef UPGRADEUTILITIES_H
#define UPGRADEUTILITIES_H
#include <QString>
#include <kolabobject.h>
#include <kmime/kmime_message.h>
#include <ktimezone.h>

namespace Kolab {
    namespace Upgrade {
/**
 * Takes a v2 xml document and returns a v3 version
 */
// QString upgradeEventXML(const QByteArray &xmlData);

struct UpgradeOptions {
    UpgradeOptions()
        :overrideObjectType(Kolab::InvalidObject),
        fixUtcIncidences(false),
        fixUtcIncidencesWithOffset(false),
        fixUtcIncidencesOffset(0),
        validateMode(false),
        noDelete(false)
    {

    }

    Kolab::ObjectType overrideObjectType;
    bool fixUtcIncidences;
    bool fixUtcIncidencesWithOffset;
    int fixUtcIncidencesOffset;
    KTimeZone fixUtcIncidencesTimezone;

    bool validateMode;
    bool noDelete;
    QString saveTo;
};

/**
 * Takes a v2 mime message and returns a v3 version
 */
KMime::Message::Ptr upgradeMessage(KMime::Message::Ptr msg, UpgradeOptions upgradeOptions = UpgradeOptions());
bool validateMessage(KMime::Message::Ptr msg, const QList<Kolab::ObjectType> &expectedType);
QString upgradeMime(const QByteArray &, UpgradeOptions upgradeOptions = UpgradeOptions());



    }
}

#endif
