/*
    <one line to give the library's name and an idea of what it does.>
    Copyright (C) 2012  Christian Mollekopf <chrigi_1@fastmail.fm>

    This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU Affero General Public
    License as published by the Free Software Foundation; either
    version 2.1 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    Affero General Public License for more details.

    You should have received a copy of the GNU Affero General Public
    License along with this library; if not, write to the Free Software
    Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
*/

#include "imapupgradejob.h"
#include "kolabformatupgradejob.h"
#include "jobs/probekolabserverjob.h"
#include "jobs/sequentialcompositejob.h"

#include <kimap/loginjob.h>
#include <kimap/logoutjob.h>
#include <kimap/session.h>
#include <kimap/listjob.h>
#include <kimap/getmetadatajob.h>
#include <kimap/sessionuiproxy.h>
#include <kimap/namespacejob.h>
#include <kimap/capabilitiesjob.h>

#include <kmime/kmime_message.h>
#include <errorhandler.h>
#include <kolabdefinitions.h>

class UiProxy: public KIMAP::SessionUiProxy {
  public:
    bool ignoreSslError(const KSslErrorUiData& /*errorData*/) {
        return true; //Necessary due to the untrusted certificate 
    }
};


ImapUpgradeJob::ImapUpgradeJob(QObject* parent): KJob(parent),
m_session(0)
{

}

ImapUpgradeJob::~ImapUpgradeJob()
{

}

void ImapUpgradeJob::setUpgradeOptions(const Kolab::Upgrade::UpgradeOptions &options)
{
    m_upgradeOptions = options;
}

void ImapUpgradeJob::setFolderToUpgrade(const QString &folder)
{
    m_folderToUpgrade = folder;
}


void ImapUpgradeJob::connectToAccount(const QString &hostName, qint16 port, const QString &username, const QString &proxyauth, const QString &pw, KIMAP::LoginJob::EncryptionMode encryptionMode, KIMAP::LoginJob::AuthenticationMode authenticationMode)
{
    Debug() << "connecting to: " << hostName << port << username << pw;
    
    m_session = new KIMAP::Session( hostName, port, this );
    m_session->setUiProxy( KIMAP::SessionUiProxy::Ptr(new UiProxy()) );
    
    QObject::connect( m_session, SIGNAL(stateChanged(KIMAP::Session::State,KIMAP::Session::State)),
                      this, SLOT(onSessionStateChanged(KIMAP::Session::State,KIMAP::Session::State)) );
    
    KIMAP::LoginJob *loginJob = new KIMAP::LoginJob( m_session );
    if (!proxyauth.isEmpty()) {
        loginJob->setAuthorizationName(proxyauth);
    }
    loginJob->setUserName( username );
    loginJob->setPassword( pw );
    loginJob->setEncryptionMode( encryptionMode );
    if (encryptionMode != KIMAP::LoginJob::Unencrypted) {
        m_requireEncryption = true;
    } else {
        m_requireEncryption = false;
    }
    loginJob->setAuthenticationMode( authenticationMode );
    
    QObject::connect( loginJob, SIGNAL(result(KJob*)),
                      this, SLOT(onLoginDone(KJob*)) );
    loginJob->start();
}

void ImapUpgradeJob::onSessionStateChanged(KIMAP::Session::State newState, KIMAP::Session::State oldState)
{
    Debug() << newState;
    if (newState == KIMAP::Session::Disconnected && oldState != KIMAP::Session::Disconnected) {
        Warning() << "lost connection";
    }
}

void ImapUpgradeJob::onLoginDone( KJob *job )
{
    KIMAP::LoginJob *login = static_cast<KIMAP::LoginJob*>( job );
    
    if ( job->error() ) {
        Error() << job->errorString();
        Error() << "Login failed, job aborted";
        emitResult();
        return;
    }

    if (m_requireEncryption && login->encryptionMode() == KIMAP::LoginJob::Unencrypted) {
        setError(KJob::UserDefinedError);
        setErrorText("failed to encrypt communication");
        Error() << errorString();
        emitResult();
        return;
    }

    ProbeKolabServerJob *probeJob = new ProbeKolabServerJob(m_session, this);
    connect(probeJob, SIGNAL(result(KJob*)), this, SLOT(onProbeDone(KJob*)));
    probeJob->start();
}

void ImapUpgradeJob::onProbeDone(KJob* job)
{
    if ( job->error() ) {
        Error() << job->errorString();
        emitResult();
        return;
    }
    ProbeKolabServerJob *capabilitiesJob = qobject_cast<ProbeKolabServerJob*>( job );
    Q_ASSERT(capabilitiesJob);
    
    SequentialCompositeJob *seqJob = new SequentialCompositeJob(this);

    QMultiHash<QString,QString> folders;
    if (!m_upgradeOptions.validateMode) {
         folders = capabilitiesJob->kolabFolders();
    } else {
        folders = capabilitiesJob->allFolders();
    }
    QMultiHash<QString, QString>::const_iterator it;
    QMultiHash<QString, QString>::const_iterator end = folders.constEnd();
    for (it = folders.constBegin(); it != end; ++it) {
        if (!m_upgradeOptions.validateMode && it.key() == QLatin1String(KOLAB_FOLDER_TYPE_FREEBUSY)) {
            continue;
        }
        if (!m_folderToUpgrade.isEmpty() && it.value() != m_folderToUpgrade) {
            continue;
        }
        KolabFormatUpgradeJob *upgradeJob = new KolabFormatUpgradeJob(it.value(), m_session, this);
        upgradeJob->setUpgradeOptions(m_upgradeOptions);
        upgradeJob->setFolderType(it.key());
        seqJob->addSubjob(upgradeJob);
    }
    
    connect(seqJob, SIGNAL(result(KJob*)), this, SLOT(modifyDone(KJob*)));
    seqJob->start();
}

void ImapUpgradeJob::modifyDone( KJob *job )
{
    Debug() << "all done, logging out";
    if ( job->error() ) {
        Error() << job->errorString();
    }
    //Logout after we're done
    if (m_session->state() != KIMAP::Session::Disconnected) {
        KIMAP::LogoutJob *logoutJob = new KIMAP::LogoutJob(m_session);
        connect(logoutJob, SIGNAL(result(KJob*)), this, SLOT(logoutDone(KJob*)));
        logoutJob->start();
    } else {
        Debug() << "session is down, not logging out.";
        emitResult();
    }
}

void ImapUpgradeJob::logoutDone( KJob *job )
{
    emitResult();
}
