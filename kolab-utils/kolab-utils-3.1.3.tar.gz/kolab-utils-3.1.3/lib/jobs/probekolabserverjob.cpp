/*
 * Copyright (C) 2012  Christian Mollekopf <mollekopf@kolabsys.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "probekolabserverjob.h"
#include "findkolabfoldersjob.h"
#include "setupkolabfoldersjob.h"
#include "probeimapserverjob.h"
#include <errorhandler.h>

ProbeKolabServerJob::ProbeKolabServerJob(KIMAP::Session *session, QObject* parent)
:   KJob(parent),
    mSession(session)
{

}

ProbeKolabServerJob::~ProbeKolabServerJob()
{

}

void ProbeKolabServerJob::start()
{
    ProbeIMAPServerJob *probeJob = new ProbeIMAPServerJob(mSession, this);
    connect(probeJob, SIGNAL(result(KJob*)), this, SLOT(onProbeJobDone(KJob*)));
    probeJob->start();
}

void ProbeKolabServerJob::onProbeJobDone(KJob* job)
{
    if (job->error()) {
        Warning() << job->errorString();
        setError(KJob::UserDefinedError);
        emitResult();
        return;
    }
    ProbeIMAPServerJob *probeJob = static_cast<ProbeIMAPServerJob*>(job);
    mCapabilities =  probeJob->capabilities();
    mPersonalNamespace = probeJob->personalNamespace();
    mExcludedNamespace = probeJob->excludedNamespaces();
    FindKolabFoldersJob *findJob = new FindKolabFoldersJob(mCapabilities, mPersonalNamespace, mExcludedNamespace, mSession, this);
    connect(findJob, SIGNAL(result(KJob*)), this, SLOT(findKolabFoldersDone(KJob*)));
    findJob->start();
}

void ProbeKolabServerJob::findKolabFoldersDone(KJob *job)
{
    if (job->error()) {
        Warning() << job->errorString();
        setError(KJob::UserDefinedError);
        emitResult();
        return;
    }
    FindKolabFoldersJob *findJob = static_cast<FindKolabFoldersJob*>(job);
//    qDebug() << "Found kolab folders: " << findJob->getKolabFolders();
    mKolabFolders = findJob->getKolabFolders();
    mAllFolders = findJob->getAllFolders();
    emitResult();
}

QMultiHash<QString, QString> ProbeKolabServerJob::kolabFolders() const
{
    return mKolabFolders;
}

QMultiHash<QString, QString> ProbeKolabServerJob::allFolders() const
{
    return mAllFolders;
}

QStringList ProbeKolabServerJob::capabilities() const
{
    return mCapabilities;
}

QList< KIMAP::MailBoxDescriptor > ProbeKolabServerJob::personalNamespace() const
{
    return mPersonalNamespace;
}

QList< KIMAP::MailBoxDescriptor > ProbeKolabServerJob::excludedNamespaces() const
{
    return mExcludedNamespace;
}
