/*
 * Copyright (C) 2012  Christian Mollekopf <mollekopf@kolabsys.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "getuserlistjob.h"
#include <kimap/listjob.h>
#include <kimap/selectjob.h>
#include <kimap/namespacejob.h>
#include <errorhandler.h>


GetUserListJob::GetUserListJob(KIMAP::Session *session, QObject* parent)
:   KJob(parent),
    mSession(session)
{
}

void GetUserListJob::setFilterDomain(const QString &domain)
{
    mFilterDomain = domain;
}

void GetUserListJob::start()
{
//     KIMAP::NamespaceJob *nsJob = new KIMAP::NamespaceJob( mSession );
//     QObject::connect( nsJob, SIGNAL(result(KJob*)), SLOT(onNamespacesTestDone(KJob*)));
//     nsJob->start();

    KIMAP::ListJob *listJob = new KIMAP::ListJob(mSession);
    listJob->setOption(KIMAP::ListJob::IncludeUnsubscribed);
//     KIMAP::MailBoxDescriptor desc;
//     desc.name = QLatin1String("user/");
//     desc.separator = QLatin1Char('/');
//     QList<KIMAP::MailBoxDescriptor> namespaces;
//     namespaces.append(desc);
//     listJob->setQueriedNamespaces(namespaces);
    QObject::connect( listJob, SIGNAL(mailBoxesReceived(QList<KIMAP::MailBoxDescriptor>,QList<QList<QByteArray> >)),
                      this, SLOT(mailBoxesReceived(QList<KIMAP::MailBoxDescriptor>,QList<QList<QByteArray> >)));
    QObject::connect( listJob, SIGNAL(result(KJob*)),
                      this, SLOT(onListDone(KJob*)) );
    listJob->start();
}

// void GetUserListJob::onNamespacesTestDone(KJob *job)
// {
//     KIMAP::NamespaceJob *nsJob = qobject_cast<KIMAP::NamespaceJob*>( job );
//     Q_ASSERT(nsJob);
//     foreach (const KIMAP::MailBoxDescriptor &desc, nsJob->personalNamespaces()) {
//         Debug() << "personal " << desc.name;
//     }
//     foreach (const KIMAP::MailBoxDescriptor &desc, nsJob->userNamespaces()) {
//         Debug() << "user " << desc.name << desc.separator;
//     }
//     foreach (const KIMAP::MailBoxDescriptor &desc, nsJob->sharedNamespaces()) {
//         Debug() << "shared " << desc.name;
//     }
// }


void GetUserListJob::mailBoxesReceived(const QList<KIMAP::MailBoxDescriptor> &descriptors, const QList< QList< QByteArray > > &/* flags */)
{
    // Example listing:
    // user/jack@example.org
    // user/jack/Calendar@example.org
    // user/john.doe@other.org
    // user/john.doe/Calendar@other.org
    // user/jack.doe@company.com
    // user/jack@subsidiary.company.com
    // user/john
    // user/john/Calendar

    foreach (const KIMAP::MailBoxDescriptor &descriptor, descriptors) {
        if (!mFilterDomain.isEmpty() && !descriptor.name.contains(mFilterDomain)) {
            continue;
        }
        const QChar separator(descriptor.separator);
        //FIXME get from namespace result
        const QLatin1String userNamespace("user");
        QString path(descriptor.name);

        //In case there can be leading separators
        if (path.startsWith(separator)) {
            path.remove(0, 1);
        }

        //Otherwise we would get duplicates with multiple domains
        const bool containsNoFolders = descriptor.name.count(separator) < 2;

        if (descriptor.name.startsWith(userNamespace) && containsNoFolders) {
            const QString name = descriptor.name.section(separator, 1, 1);
            Debug() << name << descriptor.name;
            mNames.insert(name);
        }
    }
}

void GetUserListJob::onListDone(KJob *job)
{
    if ( job->error() ) {
        Warning() << job->errorString();
        setError(KJob::UserDefinedError);
        emitResult();
        return;
    }
    Debug() << "list successful";
    emitResult();
}

QStringList GetUserListJob::getUserList() const
{
    return mNames.toList();
}
