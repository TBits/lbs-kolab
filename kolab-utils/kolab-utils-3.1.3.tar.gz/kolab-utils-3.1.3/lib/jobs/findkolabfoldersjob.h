/*
    <one line to give the library's name and an idea of what it does.>
    Copyright (C) 2012  Christian Mollekopf <chrigi_1@fastmail.fm>

    This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU Affero General Public
    License as published by the Free Software Foundation; either
    version 2.1 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    Affero General Public License for more details.

    You should have received a copy of the GNU Affero General Public
    License along with this library; if not, write to the Free Software
    Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
*/


#ifndef FINDKOLABFOLDERSJOB_H
#define FINDKOLABFOLDERSJOB_H

#include <kjob.h>
#include <QStringList>
#include <QMap>
#include <QHash>
#include <kimap/listjob.h>

namespace KIMAP {
    class Session;
}

class FindKolabFoldersJob : public KJob
{
    Q_OBJECT
public:
    explicit FindKolabFoldersJob(const QStringList &serverCapabilities, const QList<KIMAP::MailBoxDescriptor> &personalNamespaces,  const QList<KIMAP::MailBoxDescriptor> &excluded, KIMAP::Session *session, QObject* parent = 0);
    virtual void start();
    QMultiHash<QString, QString> getKolabFolders();
    QMultiHash<QString, QString> getAllFolders();
private slots:
    void onMailBoxesReceived( const QList< KIMAP::MailBoxDescriptor > &descriptors,
                              const QList< QList<QByteArray> > &flags );
    void onMailBoxesReceiveDone( KJob* job );
    void onGetMetaDataDone( KJob *job );
private:    
    KIMAP::Session *m_session;
    
    QList<KIMAP::MailBoxDescriptor> m_mailboxes;
    QHash<QString, QString> m_kolabFolders;
    QHash<QString, QString> m_allFolders;
    int m_metadataRetrieveJobs;
    bool m_mailBoxReceiveDone;
    QList<KIMAP::MailBoxDescriptor> m_personalNamespaces;
    QStringList m_excludedNamespaces;
    QStringList m_serverCapabilities;
    
};

#endif // FINDKOLABFOLDERSJOB_H
