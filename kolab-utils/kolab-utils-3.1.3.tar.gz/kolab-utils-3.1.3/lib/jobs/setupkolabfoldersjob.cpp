/*
 * Copyright (C) 2012  Christian Mollekopf <mollekopf@kolabsys.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "setupkolabfoldersjob.h"

#include <kimap/session.h>
#include <kimap/selectjob.h>

#include <errorhandler.h>
#include <kolabdefinitions.h>
#include <formathelpers.h>

#include "createkolabfolderjob.h"

SetupKolabFoldersJob::SetupKolabFoldersJob(const QStringList &serverCapabilities, QString rootFolder, KIMAP::Session* session, QObject* parent)
:   KJob(parent),
    m_session(session),
    m_rootFolder(rootFolder),
    m_serverCapabilities(serverCapabilities)
{

}

void SetupKolabFoldersJob::setKolabFolders(const QStringList &mailboxes)
{
    m_folderTypes.clear();
    foreach (const QString &folder, mailboxes) {
        if (!m_folderTypes.contains(folder)) {
            m_folderTypes.append(folder);
        }
    }
}

void SetupKolabFoldersJob::start()
{
    if (!m_rootFolder.isEmpty()) {
        KIMAP::SelectJob *selectJob = new KIMAP::SelectJob(m_session);
        selectJob->setMailBox(m_rootFolder);
        connect(selectJob, SIGNAL(result(KJob*)), this, SLOT(onSelectDone(KJob*)));
        selectJob->start();
    } else {
        createNext();
    }
}

void SetupKolabFoldersJob::onSelectDone(KJob *job)
{
    if ( job->error() ) {
        Warning() << job->errorString();
        setError(KJob::UserDefinedError);
        emitResult();
        return;
    }
    createNext();
}

static QString getFolderName(Kolab::FolderType type)
{
    return QString::fromStdString(Kolab::nameForFolderType(type));
}

static Kolab::FolderType getFolderType(const QString &typeString)
{
    return Kolab::folderTypeFromString(typeString.toStdString());
}

void SetupKolabFoldersJob::createNext()
{
    if (m_folderTypes.isEmpty()) {
        emitResult();
        return;
    }
    createMailbox(m_folderTypes.takeFirst());
}

void SetupKolabFoldersJob::createMailbox(const QString &currentFolderType)
{
    const Kolab::FolderType folderType = getFolderType(currentFolderType);
    if (folderType == Kolab::MailType) {
        Warning() << "unknown kolab type: " << currentFolderType;
        setError(KJob::UserDefinedError);
        emitResult();
        return;
    }
    const QString name = getFolderName(folderType);
    const QByteArray privateAnnotation = QString::fromStdString(Kolab::folderAnnotation(folderType, true)).toLatin1();
    const QByteArray sharedAnnotation = QString::fromStdString(Kolab::folderAnnotation(folderType, false)).toLatin1();

    m_createdFolders.insert(currentFolderType, name);

    CreateKolabFolderJob *createJob = new CreateKolabFolderJob(name,
                                                           sharedAnnotation,
                                                           privateAnnotation,
                                                           CreateKolabFolderJob::capablitiesFromString(m_serverCapabilities),
                                                           m_session,
                                                           this
                                                          );
    connect(createJob, SIGNAL(result(KJob*)), this, SLOT(onCreateDone(KJob*)));
    createJob->start();
}

void SetupKolabFoldersJob::onCreateDone(KJob *job)
{
    if (job->error()) {
        Warning() << job->errorString() << "Failed to create folder";
    } else {
        CreateKolabFolderJob *createJob = static_cast<CreateKolabFolderJob*>(job);
        Debug() << "Created folder " << m_rootFolder << createJob->folder();
    } 
    createNext();
}

QMap< QString, QString > SetupKolabFoldersJob::createdFolders() const
{
    return m_createdFolders;
}
