/*
 * Copyright (C) 2012  Christian Mollekopf <mollekopf@kolabsys.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef FBAGGREGATORJOB_H
#define FBAGGREGATORJOB_H
#include <kjob.h>
#include <kolabfreebusy.h>
#include "kolabjob.h"

namespace KIMAP {
class Session;
}

class FBAggregatorJob: public KolabJob
{
    Q_OBJECT
public:
    explicit FBAggregatorJob(const SessionSettings &settings, QObject* parent = 0);
    QString generatedFile() const;
    
protected:
    virtual QStringList requiredFolders();
    
private Q_SLOTS:
    void onFetchFBDone(KJob *job);
//     void onGenerateFBDone(KJob*);
//     void onModDone(KJob*);
private:
    virtual void startWork();

    QString mFreebusyFolder;
    QString mGeneratedFile;

    Kolab::Freebusy mSimpleFreebusy;
};

#endif // FBAGGREGATORJOB_H
