/*
 * Copyright (C) 2014 Sandro Knauß <knauss@kolabsys.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "fbdaemonthread.h"

#include <QtNetwork>

FbDaemonThread::FbDaemonThread(int socketDescriptor, QObject* parent)
    : QObject(parent)
    , socketDescriptor(socketDescriptor)
    , tcpSocket(0)
    , connection(0)
{
    //This is the only part running in the parent thread, don't do anything here.
}

FbDaemonThread::~FbDaemonThread()
{
    //Ensure this is executed in the worker thread
    Q_ASSERT(QThread::currentThread() == thread());
    delete tcpSocket;
    delete connection;
}

void FbDaemonThread::start()
{
    Q_ASSERT(QThread::currentThread() == thread());
    tcpSocket = new QTcpSocket(this);
    connection = new FbDaemonConnection(this);

    if (!tcpSocket->setSocketDescriptor(socketDescriptor)) {
        emit error(tcpSocket->error());
        emit finished(thread());
        return;
    }

    connect(tcpSocket, SIGNAL(readyRead()), SLOT(onData()));
    connect(tcpSocket, SIGNAL(disconnected()), SLOT(onDisconnected()));
    connect(tcpSocket, SIGNAL(error(QAbstractSocket::SocketError)), SLOT(onSocketError(QAbstractSocket::SocketError)));

    connect(connection, SIGNAL(sendData(const QByteArray&)), SLOT(onSendData(const QByteArray&)));
    connect(connection, SIGNAL(close()), SLOT(onClose()));

    qDebug() << "New client from " <<  tcpSocket->peerAddress() << tcpSocket->peerPort();
}

void FbDaemonThread::onDisconnected()
{
    Q_ASSERT(QThread::currentThread() == thread());
    qDebug() << "disconnected";
    emit finished(thread());
}

void FbDaemonThread::onSocketError(QAbstractSocket::SocketError error)
{
    Q_ASSERT(QThread::currentThread() == thread());
    qWarning() << "Socket error: " << error;
    emit this->error(error);
    //Never call disconnectFromHost in error state. It will result in an endless loop because it tries to write data.
    onClose();
}

void FbDaemonThread::onData()
{
    Q_ASSERT(QThread::currentThread() == thread());
    data += tcpSocket->readAll();
    if (data.contains('\n')) {
        int bytes = data.indexOf('\n') + 1;
        QByteArray message = data.left(bytes);
        data = data.mid(bytes);
        emit newLine(message);
    }
}

void FbDaemonThread::onSendData(const QByteArray& block)
{
    Q_ASSERT(QThread::currentThread() == thread());
    tcpSocket->write(block);
}

void FbDaemonThread::onClose()
{
    Q_ASSERT(QThread::currentThread() == thread());
    tcpSocket->close();
}

