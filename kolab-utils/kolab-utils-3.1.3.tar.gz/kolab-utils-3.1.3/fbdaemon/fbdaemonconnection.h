/*
 * Copyright (C) 2014 Sandro Knauß <knauss@kolabsys.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef FBDAEMONCONNECTION_H
#define FBDAEMONCONNECTION_H

#include <QObject>
#include <QFile>
#include <QStringList>
#include <kdatetime.h>
#include <kjob.h>
#include <kolabfreebusy.h>
class FbDaemonThread;
class ConnectionTest;

struct Timeslot {
    KDateTime start;
    KDateTime end;
};

class FbDaemonConnection : public QObject
{
    Q_OBJECT
    friend class ConnectionTest;
public:
    FbDaemonConnection(FbDaemonThread* parent);
    virtual ~FbDaemonConnection();

signals:
    void sendData(const QByteArray&);
    void close();

protected:
    void setJob(KJob*);

private:
    const QByteArray createStatusLine(const QByteArray &status, const QByteArray &additional);
    void generateForUser(const QStringList);
    void generateForFolder(const QStringList);

    void sendError(const QByteArray&);

    bool validateMethod(const QByteArray&);
    bool validateGenerateForUser(const QString&);
    bool validateGenerateForFolder(const QString&);
    bool validateTimeslot(const QString&);
    Timeslot parseTimeslot(const QString&);

    QByteArray method;
    KJob *job;
    int defaultTimeslot;
private slots:
    void onNewLine(const QByteArray&);
    void onGenerateUserDone(KJob*);
    void onGenerateFolderDone(KJob*);
    void onSendFbObject(const Kolab::Freebusy&);


};

#endif // FBDAEMONCONNECTION_H
