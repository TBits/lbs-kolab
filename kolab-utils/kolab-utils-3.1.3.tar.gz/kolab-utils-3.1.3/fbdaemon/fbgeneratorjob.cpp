/*
    <one line to give the library's name and an idea of what it does.>
    Copyright (C) 2012  Christian Mollekopf <chrigi_1@fastmail.fm>

    This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU Affero General Public
    License as published by the Free Software Foundation; either
    version 2.1 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    Affero General Public License for more details.

    You should have received a copy of the GNU Affero General Public
    License along with this library; if not, write to the Free Software
    Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
*/


#include "fbgeneratorjob.h"
#include "authenticationjob.h"
#include "generatefbjob.h"
#include "settings.h"
#include "jobs/probekolabserverjob.h"
#include "jobs/messagemodifyjob.h"
#include "jobs/fetchmessagesjob.h"
#include "jobs/sequentialcompositejob.h"

#include <kolabdefinitions.h>
#include <kolabobject.h>
#include <commonconversion.h>
#include <errorhandler.h>
#include <kdebug.h>
#include <kimap/logoutjob.h>
#include <kimap/expungejob.h>

FBGeneratorJob::FBGeneratorJob(const SessionSettings &settings, bool store, QObject* parent)
    : KolabJob(settings, parent),
      mOldImapUid(-1),
      mStore(store)
{
    mStartOfTimeFrame = KDateTime::currentUtcDateTime();
    mEndOfTimeFrame = mStartOfTimeFrame.addDays(Settings::instance().getTimeframe());
}

QStringList FBGeneratorJob::requiredFolders()
{
    return QStringList() << KOLAB_FOLDER_TYPE_FREEBUSY;
}

void FBGeneratorJob::startGenerateFBJob()
{
    GenerateFBJob *fbJob = new GenerateFBJob(mEventFolders, mStartOfTimeFrame, mEndOfTimeFrame, mSession, this);
    QObject::connect(fbJob, SIGNAL(result(KJob*)), this, SLOT(onGenerateFBDone(KJob*)));
    fbJob->start();
}

void FBGeneratorJob::startWork()
{
    if (mKolabFolders.values(KOLAB_FOLDER_TYPE_FREEBUSY).isEmpty()) {
        kWarning() << "no freebusy folder found";
        setError(KJob::UserDefinedError);
        logout();
        return;
    }
    mFreebusyFolder = mKolabFolders.values(KOLAB_FOLDER_TYPE_FREEBUSY).first();
    mEventFolders = mKolabFolders.values(KOLAB_FOLDER_TYPE_EVENT);
    if (mEventFolders.isEmpty()) {
        kWarning() << "no event folders available";
        logout();
        return;
    }

    if (mStore) {
        FetchMessagesJob *fetchJob = new FetchMessagesJob(mFreebusyFolder, mSession, this);
        connect(fetchJob, SIGNAL(result(KJob*)), this, SLOT(onFetchFBDone(KJob*)));
        fetchJob->start();
    } else {
        startGenerateFBJob();
    }
}


void FBGeneratorJob::onFetchFBDone(KJob *job)
{
    if ( job->error() ) {
        kWarning() << job->errorString();
        setError(KJob::UserDefinedError);
        logout();
        return;
    }
    FetchMessagesJob *fetchJob = qobject_cast<FetchMessagesJob*>( job );
    Q_ASSERT(fetchJob);

    kDebug() << fetchJob->getMessages().size();
    foreach (const KMime::Message::Ptr &msg, fetchJob->getMessages()) {
        kDebug() << "existing fb object " << msg->subject()->asUnicodeString();
    }

    int threshold = Settings::instance().getThreshold();

    /*
     * The f/b object to update is identified based on a Mime-Header
     *
     * For the local server we're going to use the Settings::getServerUri()
     */
    qint16 port;
    const QString localUri = Settings::instance().getServerUri(port).toUtf8();
    int count = 0;
    // bool upToDate = false;
    foreach (const KMime::Message::Ptr &msg, fetchJob->getMessages()) {
        KMime::Headers::Base *xOriginHeader = msg->getHeaderByType(X_ORIGIN_HEADER);
        if (xOriginHeader) qDebug() << "existing fb object " << xOriginHeader->asUnicodeString() << localUri;
        if (xOriginHeader && (xOriginHeader->asUnicodeString() == localUri)) {

            const Kolab::Freebusy &oldFB = Kolab::KolabObjectReader(msg).getFreebusy();
            const KDateTime dtstamp = Kolab::Conversion::toDate(oldFB.timestamp());
            const KDateTime start = Kolab::Conversion::toDate(oldFB.start());
            const KDateTime end = Kolab::Conversion::toDate(oldFB.end());

            qDebug() << mStartOfTimeFrame << start << mEndOfTimeFrame << end << threshold;
            if (!(mStartOfTimeFrame < start || mEndOfTimeFrame > end.addDays(threshold))) {
                qDebug() << "within threshold, skipping";
                // upToDate = true;
                continue;
            }

            if (mOldImapUid < 0) {
                mOldImapUid = fetchJob->getImapUid(msg);
                mOldFlags = fetchJob->getFlags(msg);
            }
            count++;
        }
    }
    if (count > 1) {
        Warning() << "multiple old fb objects detected this shouldn't ever happen";
        //FIXME this can actually happen if the fb generator is run from several places (resulting in differen origin hostnames, e.g. localhost 127.0.0.1 demo.kolab.org)
        //TODO cleanup
    }
    //FIXME we also need to check that no new events are existing, otherwise this check prevents us from generating up-to date information
/*    if (upToDate) {
        Debug() << "fb objects are up-to-date, nothing to do";
        logout();
        return;
    }
*/

//     kDebug() << mEventFolder;
    startGenerateFBJob();
}

void FBGeneratorJob::onGenerateFBDone(KJob *job)
{
    if ( job->error() ) {
        Warning() << "Error " << job->errorString();
        logout();
        return;
    }
    GenerateFBJob *fbJob = qobject_cast<GenerateFBJob*>( job );
    Q_ASSERT(fbJob);

    mFreebusy = fbJob->getFreebusy();

    const Kolab::ContactReference org(Kolab::ContactReference::EmailReference, Kolab::Conversion::toStdString(mSessionSettings.userName));
    mFreebusy.setOrganizer(org);

    if (!mFreebusy.organizer().isValid()) {
//        mFreebusy.setOrganizer(/*mUserName, mUserName+QLatin1Char('@')+mHostName.remove("imap.")*/);
        Warning() << "no valid organizer";
        setError(KJob::UserDefinedError);
        logout();
        return;
    }

    // We want only create the freebusy object and do not want to store it at the IMAP server
    if (mStore) {
        storeFBObject();
    } else {
        logout();
    }
}

void FBGeneratorJob::storeFBObject()
{
    if (!mFreebusy.isValid()) {
        Debug() << "did not generate a fb object";
        //TODO generate empty fb object to mark time as free
        logout();
        return;
    }

    KMime::Message::Ptr message = Kolab::KolabObjectWriter::writeFreebusy(mFreebusy);
    if (Kolab::ErrorHandler::instance().error() > Kolab::ErrorHandler::Debug) {
        Warning() << "Error: " << Kolab::ErrorHandler::instance().errorMessage();
        setError(KJob::UserDefinedError);
        logout();
        return;
    }

    qint16 port;
    message->appendHeader( new KMime::Headers::Generic( X_ORIGIN_HEADER, message.get(), Settings::instance().getServerUri(port).toUtf8(), "utf-8" ) );
    message->assemble();

//     kDebug() << message->encodedContent();
    SequentialCompositeJob *seqJob = new SequentialCompositeJob(this);
    seqJob->addSubjob(new MessageModifyJob(message, mFreebusyFolder, mOldFlags, mOldImapUid, mSession, this));
    seqJob->addSubjob(new KIMAP::ExpungeJob(mSession));
    QObject::connect(seqJob, SIGNAL(result(KJob*)), this, SLOT(onModDone(KJob*)));
    seqJob->start();
}

void FBGeneratorJob::onModDone(KJob *job)
{
    if ( job->error() ) {
        kWarning() << job->errorString();
    }
    logout();
}

void FBGeneratorJob::setTimeFrame(const KDateTime &start, const KDateTime &end)
{
    mStartOfTimeFrame = start;
    mEndOfTimeFrame = end;
}

Kolab::Freebusy FBGeneratorJob::getFreebusy()
{
    return mFreebusy;
}
