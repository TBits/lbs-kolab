/*
 * Copyright (C) 2012  Christian Mollekopf <mollekopf@kolabsys.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef STATEFILE_H
#define STATEFILE_H

#include <QList>
#include <QString>

/**
 * Migration state
 * TODO store UIDVALIDITY with file to ensure imap uids are still valid
 */
class StateFile
{
public:
    StateFile();
    StateFile(const QString &filename, const QString &user);
    QList<qint64> getMigratedUids(const QString &folder);
//     void addMigratedUid(const QString &folder, qint64 uid);
    void setMigratedUids(const QString& folder, const QList<qint64> &uids);
    void appendMigratedUids(const QString& folder, const QList<qint64> &uids);
    bool isValid();
private:
    QString mFilename;
    QString mUser;
};

#endif // STATEFILE_H
