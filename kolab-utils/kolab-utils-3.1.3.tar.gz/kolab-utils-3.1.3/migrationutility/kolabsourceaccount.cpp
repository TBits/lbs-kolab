/*
 * Copyright (C) 2013  Christian Mollekopf <mollekopf@kolabsys.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "kolabsourceaccount.h"

#include <jobs/probekolabserverjob.h>
#include <errorhandler.h>
#include <kolabobject.h>

KolabSourceAccount::KolabSourceAccount(QObject* parent)
:   IMAPSourceAccount(parent)
{

}

Kolab::FolderType KolabSourceAccount::getFolderType(const QString &folder) const
{
    if (mKolabFolders.values().contains(folder)) {
        return Kolab::folderTypeFromString(mKolabFolders.key(folder).toStdString());
    }
    return Kolab::MailType;
}

QPair<Kolab::FolderType, QString> KolabSourceAccount::translateFolder(const QString& folder)
{
    return QPair<Kolab::FolderType, QString>(getFolderType(folder), folder);
}

void KolabSourceAccount::init()
{
    ProbeKolabServerJob *probeJob = new ProbeKolabServerJob(getSession(), this);
    probeJob->exec();
    mKolabFolders = probeJob->kolabFolders();
    mPersonalNamespaces = probeJob->personalNamespace();
}

// void KolabSourceAccount::mailBoxesReceived(const QList<KIMAP::MailBoxDescriptor> &descriptors, const QList< QList< QByteArray > > &/* flags */)
// {
//     mMailboxes.append(descriptors);
//     //TODO store folder type from metadata
// //     for (int i = 0; i < descriptors.size(); i++) {
// //         Debug() << descriptors.at(i).name;
// //         foreach (const QByteArray &arr, flags.at(i)) {
// //             Debug() << arr;
// //         }
// //     }
// }

QVariant upgradeMessage(const KMime::Message::Ptr &msg)
{
    //TODO deduplicate with upgradetool, check for errors during reading.
    Kolab::KolabObjectReader reader;
    switch (reader.parseMimeMessage(msg)) {
        case Kolab::EventObject:
        case Kolab::TodoObject:
        case Kolab::JournalObject:
            return QVariant::fromValue(reader.getIncidence());
        case Kolab::ContactObject:
            return QVariant::fromValue(reader.getContact());
        case Kolab::DistlistObject:
            return QVariant::fromValue(reader.getDistlist());
        case Kolab::NoteObject: {
            Note note;
            note.msg = reader.getNote();
            return QVariant::fromValue(note);
        }
        case Kolab::DictionaryConfigurationObject: {
            Dictionary dictionary;
            dictionary.dict = reader.getDictionary(dictionary.lang);
            return QVariant::fromValue(dictionary);
        }
        case Kolab::InvalidObject:
        default:
            //TODO handle configuration objects
            Error() << "failed to read mime file";
    }
    return QVariant();
}

Object KolabSourceAccount::convertObject(const Object& object, const QString& folder) const
{
    const bool isKolabType = mKolabFolders.values().contains(folder);
    if (isKolabType) {
        Object obj(object);
        obj.object = upgradeMessage(object.object.value<KMime::Message::Ptr>());
        return obj;
    }
    return object;
}
