/*
 * Copyright (C) 2012  Christian Mollekopf <mollekopf@kolabsys.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef MIGRATEUSERJOB_H
#define MIGRATEUSERJOB_H

#include <kjob.h>
#include <QStringList>

class SourceAccount;
class KolabAccount;

/**
 * Migrates a user to his new target account (currently limited to a kolab account as target).
 *
 * A user may have multiple source accounts on the source server (i.e. one imap account, one cardav account, ...)
 */
class MigrateUserJob: public KJob
{
    Q_OBJECT
public:
    explicit MigrateUserJob(const QList<SourceAccount*> &sourceAccounts, KolabAccount *kolabAccount, QObject* parent = 0);
    virtual void start();
private slots:
    void onLoginDone(KJob*);
    void onFolderMigrated(KJob*);
    void onFoldersFetched(KJob*);
    void onFoldersReceived(const QStringList &);
    void onLogoutDone(KJob *);
    void fetchFolders();
    void migrateNextFolder();
    void migrateNextAccount();
private:
    bool isIgnored(const QString &) const;
    QStringList mFolderQueue;
    QList<SourceAccount*> mSourceAccounts;
    SourceAccount *mCurrentSourceAccount;
    KolabAccount *mKolabAccount;
    QString mCurrentFolder;
};

#endif // MIGRATEUSERJOB_H
