/*
 * Copyright (C) 2012  Christian Mollekopf <mollekopf@kolabsys.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef MIGRATEFOLDERJOB_H
#define MIGRATEFOLDERJOB_H

#include <kjob.h>

struct Object;
class SourceAccount;
class KolabAccount;
class MigrateFolderJob: public KJob
{
    Q_OBJECT
public:
    explicit MigrateFolderJob(const QString &folder, SourceAccount *sourceAccount, KolabAccount *kolabAccount, QObject* parent = 0);
    virtual void start();
private Q_SLOTS:
    void doStart();
    void fetchJobFinished(KJob*);
    void appendJobFinished(KJob*);
    void processMessages(const QString &,const QList<Object>&);
private:
    void checkDone();
    SourceAccount *mSourceAccount;
    KolabAccount *mKolabAccount;
    QString mFolder;
    QString mTargetFolder;
    int mRunningAppendJobs;
    bool mFetchDone;
};

#endif // MIGRATEFOLDERJOB_H
