/*
 * Copyright (C) 2012  Christian Mollekopf <mollekopf@kolabsys.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "kolabserver.h"
#include "kolabaccount.h"
#include <errorhandler.h>

KolabServer::KolabServer(QObject* parent)
:   QObject(parent),
    mEncryptionMode(KIMAP::LoginJob::TlsV1),
    mAuthenticationMode(KIMAP::LoginJob::Plain),
    mDryRun(false),
    mWipeTargetFolders(false),
    mVersion(Kolab::KolabV3)
{

}

void KolabServer::setVersion(Kolab::Version version)
{
    mVersion = version;
}

void KolabServer::setHost(const QString& host, qint16 port)
{
    mHost = host;
    mPort = port;
}

void KolabServer::setAdminCredentials(const QString& username, const QString& pw)
{
    mUsername = username;
    mPw = pw;
}

void KolabServer::setEncryption(KIMAP::LoginJob::EncryptionMode enc)
{
    mEncryptionMode = enc;
}

void KolabServer::setAuthentication(KIMAP::LoginJob::AuthenticationMode auth)
{
    mAuthenticationMode = auth;
}

void KolabServer::addTargetUserForSource(const QString &sourceUser, const QString &targetUser)
{
    mTargetForSourceUser.insert(sourceUser, targetUser);
}

void KolabServer::setDryRun(bool enable)
{
    mDryRun = enable;
}

void KolabServer::setWipeTargetFolders(bool enable)
{
    mWipeTargetFolders = enable;
}

void KolabServer::setRegextrans(const QStringList &regextrans)
{
    Debug() << "Regextrans: " << regextrans;
    mRegextrans = regextrans;
}

KolabAccount* KolabServer::getAccount(const QString& user)
{
    KolabAccount *account = new KolabAccount(this);
    account->setHost(mHost, mPort);
    QString targetUser(user);
    if (mTargetForSourceUser.contains(user)) {
        targetUser = mTargetForSourceUser.value(user);
        Debug() << "Using " << targetUser << " for " << user << "as target user";
    }
    account->setCredentials(targetUser, mPw, mUsername);
    account->setDryRun(mDryRun);
    account->setWipeTargetFolders(mWipeTargetFolders);
    account->setVersion(mVersion);
    account->setRegextrans(mRegextrans);
    if (!account->init()) {
        account->deleteLater();
        return 0;
    }
    return account;
}

