/*
 * Copyright (C) 2013  Christian Mollekopf <mollekopf@kolabsys.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef GOOGLESOURCESERVER_H
#define GOOGLESOURCESERVER_H

#include <kimap/loginjob.h>
#include <QStringList>

#include "sourceserver.h"

class GoogleSourceServer: public SourceServer
{
    Q_OBJECT
public:
    explicit GoogleSourceServer(QObject* parent = 0);

    void setHost(const QString &host, qint16 port);
    void setAdminCredentials(const QString &username, const QString &pw);
    void setEncryption(KIMAP::LoginJob::EncryptionMode);
    void setAuthentication(KIMAP::LoginJob::AuthenticationMode);
protected:
    virtual QList<SourceAccount*> getSourceAccountsImpl(const QString& user);
    void logout();
    QString mHost;
    int mPort;
    QString mUsername;
    QString mPw;
    KIMAP::LoginJob::EncryptionMode mEncryptionMode;
    KIMAP::LoginJob::AuthenticationMode mAuthenticationMode;
};

#endif