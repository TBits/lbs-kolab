/*
    <one line to give the library's name and an idea of what it does.>
    Copyright (C) 2012  Christian Mollekopf <chrigi_1@fastmail.fm>

    This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU Affero General Public
    License as published by the Free Software Foundation; either
    version 2.1 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    Affero General Public License for more details.

    You should have received a copy of the GNU Affero General Public
    License along with this library; if not, write to the Free Software
    Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
*/


#include "findkolabfoldersjob.h"
#include <kimap/session.h>
#include <kimap/metadatajobbase.h>
#include <kimap/getmetadatajob.h>
#include <boost/concept_check.hpp>
#include <kolabdefinitions.h>
#include <errorhandler.h>

FindKolabFoldersJob::FindKolabFoldersJob(const QStringList &serverCapabilities, const QList<KIMAP::MailBoxDescriptor> &pN, const QList<KIMAP::MailBoxDescriptor> &excluded, KIMAP::Session* session, QObject* parent)
: KJob(parent),
m_session(session),
m_metadataRetrieveJobs(0),
m_mailBoxReceiveDone(false),
m_personalNamespaces(pN),
m_serverCapabilities(serverCapabilities)
{
    foreach (const KIMAP::MailBoxDescriptor &desc, excluded) {
        m_excludedNamespaces.append(desc.name);
    }
}


void FindKolabFoldersJob::start()
{
//     foreach (const KIMAP::MailBoxDescriptor &desc, m_personalNamespaces) {
//         Debug() << desc.name;
//     }
    KIMAP::ListJob *fullListJob = new KIMAP::ListJob( m_session );
    fullListJob->setOption( KIMAP::ListJob::IncludeUnsubscribed );
    fullListJob->setQueriedNamespaces( m_personalNamespaces );
    connect( fullListJob, SIGNAL(mailBoxesReceived(QList<KIMAP::MailBoxDescriptor>,QList<QList<QByteArray> >)),
             this, SLOT(onMailBoxesReceived(QList<KIMAP::MailBoxDescriptor>,QList<QList<QByteArray> >)) );
    connect( fullListJob, SIGNAL(result(KJob*)), SLOT(onMailBoxesReceiveDone(KJob*)) );
    fullListJob->start();
}

QMultiHash<QString, QString> FindKolabFoldersJob::getKolabFolders()
{
    return m_kolabFolders;
}

void FindKolabFoldersJob::onMailBoxesReceived( const QList< KIMAP::MailBoxDescriptor > &descriptors,
                                        const QList< QList<QByteArray> > &/* flags */ )
{   
    for ( int i=0; i<descriptors.size(); ++i ) {
        KIMAP::MailBoxDescriptor descriptor = descriptors[i];
//         Debug() << "Box listed: " << descriptor.name;
        bool skip = false;
        foreach(const QString &excluded, m_excludedNamespaces) {
            if (descriptor.name.contains(excluded)) {
                skip = true;
                break;
            }
        }
        if (skip) {
//             Debug() << "skipping other users folder: " << descriptor.name;
            continue;
        }
//         Debug() << flags[i];
                
        KIMAP::GetMetaDataJob *meta = new KIMAP::GetMetaDataJob( m_session );
        meta->setMailBox( descriptor.name );
        if ( m_serverCapabilities.contains( "METADATA" ) ) {
            meta->setServerCapability( KIMAP::MetaDataJobBase::Metadata );
            //TODO support shared/private
            meta->addEntry( "/shared" KOLAB_FOLDER_TYPE_ANNOTATION );
        } else if ( m_serverCapabilities.contains( "ANNOTATEMORE" ) ) {
            meta->setServerCapability( KIMAP::MetaDataJobBase::Annotatemore );
            meta->addEntry( KOLAB_FOLDER_TYPE_ANNOTATION, "value.shared" );
        } else {
            Warning() << "Server does not support annotations";
            emitResult();
            return;
        }
        connect( meta, SIGNAL(result(KJob*)), SLOT(onGetMetaDataDone(KJob*)) );
        m_metadataRetrieveJobs++;
        meta->start();
    }
}

void FindKolabFoldersJob::onMailBoxesReceiveDone( KJob* job )
{
    if ( job->error() ) {
        Warning() << job->errorString();
    }
    m_mailBoxReceiveDone = true;
    if (m_metadataRetrieveJobs == 0) {
        emitResult();
    }
}

void FindKolabFoldersJob::onGetMetaDataDone( KJob *job )
{
    m_metadataRetrieveJobs--;
    if ( job->error() ) {
        Warning() << job->errorString();
        setError(KJob::UserDefinedError);
        if (m_mailBoxReceiveDone && (m_metadataRetrieveJobs <= 0)) {
            emitResult();
        }
        return; // Well, no metadata for us then...
    }
    
    KIMAP::GetMetaDataJob *meta = qobject_cast<KIMAP::GetMetaDataJob*>( job );
    QMap<QByteArray, QMap<QByteArray, QByteArray> > rawAnnotations = meta->allMetaData( meta->mailBox() );
    
    QByteArray attribute = "";
    QByteArray annotation = KOLAB_FOLDER_TYPE_ANNOTATION;
    if ( meta->serverCapability()==KIMAP::MetaDataJobBase::Annotatemore ) {
        attribute = "value.shared";
    }
    if ( meta->serverCapability()==KIMAP::MetaDataJobBase::Metadata ) {
        annotation = "/shared" KOLAB_FOLDER_TYPE_ANNOTATION;
    }

    //TODO default flag?
    const QByteArray &kolabType = rawAnnotations[annotation][attribute];
//     Debug() << meta->mailBox() << kolabType;
    if (!kolabType.isEmpty()) {
        if (kolabType.contains(KOLAB_FOLDER_TYPE_CONTACT)) {
            m_kolabFolders.insertMulti(KOLAB_FOLDER_TYPE_CONTACT, meta->mailBox());
        } else if (kolabType.contains(KOLAB_FOLDER_TYPE_EVENT)) {
            m_kolabFolders.insertMulti(KOLAB_FOLDER_TYPE_EVENT, meta->mailBox());
        } else if (kolabType.contains(KOLAB_FOLDER_TYPE_TASK)) {
            m_kolabFolders.insertMulti(KOLAB_FOLDER_TYPE_TASK, meta->mailBox());
        } else if (kolabType.contains(KOLAB_FOLDER_TYPE_JOURNAL)) {
            m_kolabFolders.insertMulti(KOLAB_FOLDER_TYPE_JOURNAL, meta->mailBox());
        } else if (kolabType.contains(KOLAB_FOLDER_TYPE_NOTE)) {
            m_kolabFolders.insertMulti(KOLAB_FOLDER_TYPE_NOTE, meta->mailBox());
        } else if (kolabType.contains(KOLAB_FOLDER_TYPE_FREEBUSY)) {
            m_kolabFolders.insertMulti(KOLAB_FOLDER_TYPE_FREEBUSY, meta->mailBox());
        } else if (kolabType.contains("mail") || kolabType.contains("configuration") || kolabType.contains("file") || kolabType == "NIL") {
            //ignore silently
        } else {
            Warning() << "invalid/unhandled folder-type " << kolabType;
        }
    }
    if (m_mailBoxReceiveDone && (m_metadataRetrieveJobs <= 0)) {
        emitResult();
    }
}
