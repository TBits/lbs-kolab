providers
=====

An Erlang providers library.

Build
-----

    $ rebar compile
