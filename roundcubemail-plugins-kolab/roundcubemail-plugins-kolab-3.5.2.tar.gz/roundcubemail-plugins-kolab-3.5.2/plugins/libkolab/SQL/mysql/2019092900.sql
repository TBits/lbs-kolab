ALTER TABLE `kolab_folders` CHANGE `resource` `resource` varchar(255) BINARY NOT NULL;
