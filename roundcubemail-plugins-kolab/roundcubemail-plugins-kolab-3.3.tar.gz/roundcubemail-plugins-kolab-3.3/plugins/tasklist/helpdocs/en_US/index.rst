.. index:: Tasks
.. _tasklist:

********
Tasks
********

The *Tasks* module helps you organize your daily jobs and ToDo's and will alert you about upcoming deadlines.

.. toctree::
   :maxdepth: 2

   overview
   manage
