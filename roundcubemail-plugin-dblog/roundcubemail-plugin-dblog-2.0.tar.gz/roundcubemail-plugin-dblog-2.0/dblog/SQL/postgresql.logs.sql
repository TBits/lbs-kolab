- -------------------------------------------
postgresql.logs.sql
- -------------------------------------------

BEGIN;

CREATE TABLE logs (

  id BIGSERIAL NOT NULL,
  timestamp TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL,
  log TEXT,
  user_id INTEGER NOT NULL,
  userip INET DEFAULT NULL,
  hostip INET DEFAULT NULL,
  username CHARACTER VARYING(128) NOT NULL,
  line TEXT NOT NULL

);

ALTER TABLE ONLY logs
    ADD CONSTRAINT logs_pkey PRIMARY KEY (id);

CREATE INDEX logs_timestamp_idx ON logs(timestamp);
CREATE INDEX logs_user_id_idx ON logs(user_id);

CREATE OR REPLACE FUNCTION set_timestamp() RETURNS TRIGGER AS
$update_timestamp$
    BEGIN
      NEW.timestamp = now();
      RETURN NEW;
    END;
$update_timestamp$ LANGUAGE plpgsql;

CREATE TRIGGER update_timestamp
BEFORE UPDATE ON logs
    FOR EACH ROW EXECUTE PROCEDURE set_timestamp();

COMMIT;
