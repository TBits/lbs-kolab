<?php
/*
 +--------------------------------------------------------------------------+
 | This file is part of the Kolab File API                                  |
 |                                                                          |
 | Copyright (C) 2012-2018, Kolab Systems AG                                |
 |                                                                          |
 | This program is free software: you can redistribute it and/or modify     |
 | it under the terms of the GNU Affero General Public License as published |
 | by the Free Software Foundation, either version 3 of the License, or     |
 | (at your option) any later version.                                      |
 |                                                                          |
 | This program is distributed in the hope that it will be useful,          |
 | but WITHOUT ANY WARRANTY; without even the implied warranty of           |
 | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the             |
 | GNU Affero General Public License for more details.                      |
 |                                                                          |
 | You should have received a copy of the GNU Affero General Public License |
 | along with this program. If not, see <http://www.gnu.org/licenses/>      |
 +--------------------------------------------------------------------------+
 | Author: Aleksander Machniak <machniak@kolabsys.com>                      |
 +--------------------------------------------------------------------------+
*/

class file_api_wopi extends file_api
{
    public $output_type = file_api_core::OUTPUT_JSON;
    public $path        = array();
    public $args        = array();
    public $method      = 'GET';


    /**
     * Session validation check and session start
     */
    protected function session_validate($new_session = false, $token = null)
    {
        if (empty($_GET['access_token'])) {
            throw new Exception("Token missing", file_api_core::ERROR_UNAUTHORIZED);
        }

        return parent::session_validate($new_session = false, $_GET['access_token']);
    }

    /**
     * Storage/System method handler
     */
    protected function request_handler($request)
    {
        // header("X-WOPI-HostEndpoint: " . $endpoint_desc);
        // header("X-WOPI-MachineName: " .  $machine_name);
        header("X-WOPI-ServerVersion: " . file_api_core::API_VERSION);

        $request = $_GET['method']; // file_api uses strtolower(), we don't want that

        // handle request
        if ($request && preg_match('/^[a-z]+\/*[a-zA-Z0-9_\/-]*$/', $request)) {
            $path    = explode('/', $request);
            $request = array_shift($path);
            $method  = $_SERVER['REQUEST_METHOD'];

            if ($_method = rcube_utils::request_header('X-WOPI-Override')) {
                $method = $_method;
            }
            else if ($method == 'POST' && !empty($_SERVER['HTTP_X_HTTP_METHOD'])) {
                $method = $_SERVER['HTTP_X_HTTP_METHOD'];
            }

            $this->path   = $path;
            $this->args   = $_GET;
            $this->method = $method;

            include_once __DIR__ . "/wopi/$request.php";

            $class_name = "file_wopi_$request";
            if (class_exists($class_name, false)) {
                $handler = new $class_name($this);
                return $handler->handle();
            }
        }

        throw new Exception("Unknown method", file_api_core::ERROR_NOT_FOUND);
    }

    /**
     * Send success response
     *
     * @param mixed $data Data
     */
    public function output_success($data)
    {
        $this->output_send($data);
    }

    /**
     * Send error response
     *
     * @param mixed $response Response data
     * @param int   $code     Error code
     */
    public function output_error($response, $code = null)
    {
        header(sprintf("HTTP/1.0 %d %s", $code ?: file_api_core::ERROR_CODE, $response));

        $this->output_send();
    }

    /**
     * Send response
     *
     * @param mixed $data Data
     */
    public function output_send($data = null)
    {
        // Remove NULL data according to WOPI spec.
        if (is_array($data)) {
            $data = array_filter($data, function($v) { return $v !== null; });
        }

        parent::output_send($data);
    }
}
