ALTER TABLE "chwala_sessions" ADD COLUMN "readonly" smallint DEFAULT 0 NOT NULL;
