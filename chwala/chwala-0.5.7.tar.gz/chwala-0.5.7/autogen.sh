#!/bin/bash

package="chwala"

if [ $# -ne 1 ]; then
    echo "Usage: $0 <version>"
    exit 1
fi

version=$1

if [ ! -z "$(git tag -l | grep -E '${package}-${version}$')" ]; then
    echo "Version ${version} already exists"
    exit 1
fi

if [ -f "./composer.phar" ]; then
    git clean -d -f -x
    rm -rf vendor/
fi

curl -sS https://getcomposer.org/installer | php

if [ $? -ne 0 ]; then
    echo "Getting composer failed... Bye!"
    exit 1
fi

cp composer.json composer-dev.json
cp composer.json-dist composer.json

./composer.phar install --no-dev

if [ $? -ne 0 ]; then
    echo "Running ./composer.phar install failed... Bye!"
    exit 1
fi

if [ -d "../${package}-${version}/" ]; then
    rm -rf ../${package}-${version}/
fi

mkdir -p ../${package}-${version}/
cp -a * ../${package}-${version}/.
find ../${package}-${version}/ -type d -name ".git" -exec rm -rf {} \; 2>/dev/null
find ../${package}-${version}/ -mindepth 1 -maxdepth 1 -type f -name "composer.phar" -delete 2>/dev/null

pwd=$(pwd)
pushd ..
tar czvf ${pwd}/${package}-${version}.tar.gz ${package}-${version}/
popd
