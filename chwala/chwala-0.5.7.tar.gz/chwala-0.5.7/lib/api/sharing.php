<?php
/*
 +--------------------------------------------------------------------------+
 | This file is part of the Kolab File API                                  |
 |                                                                          |
 | Copyright (C) 2012-2018, Kolab Systems AG                                |
 |                                                                          |
 | This program is free software: you can redistribute it and/or modify     |
 | it under the terms of the GNU Affero General Public License as published |
 | by the Free Software Foundation, either version 3 of the License, or     |
 | (at your option) any later version.                                      |
 |                                                                          |
 | This program is distributed in the hope that it will be useful,          |
 | but WITHOUT ANY WARRANTY; without even the implied warranty of           |
 | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the             |
 | GNU Affero General Public License for more details.                      |
 |                                                                          |
 | You should have received a copy of the GNU Affero General Public License |
 | along with this program. If not, see <http://www.gnu.org/licenses/>      |
 +--------------------------------------------------------------------------+
 | Author: Aleksander Machniak <machniak@kolabsys.com>                      |
 +--------------------------------------------------------------------------+
*/

class file_api_sharing extends file_api_common
{
    /**
     * Request handler
     */
    public function handle()
    {
        parent::handle();

        if (!isset($this->args['folder']) || $this->args['folder'] === '') {
            throw new Exception("Missing folder name", file_api_core::ERROR_CODE);
        }

        list($driver, $path) = $this->api->get_driver($this->args['folder']);

        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            // Required arguments:
            // - action: 'submit', 'update', 'delete'
            // - mode: depends on the storage driver
            return $driver->sharing($path, file_storage::SHARING_MODE_UPDATE, $this->args);
        }

        $form = $driver->sharing($path, file_storage::SHARING_MODE_FORM);

        if (empty($form)) {
            throw new Exception("Sharing not supported", file_api_core::ERROR_UNSUPPORTED);
        }

        $rights = $driver->sharing($path, file_storage::SHARING_MODE_RIGHTS);

        $this->localize_form_data($form);

        $result = array(
            'form'   => $form,
            'rights' => (array) $rights,
        );

        return $result;
    }

    /**
     * Recurrent function to localize form data entries
     */
    protected function localize_form_data(&$data, $key = null, $self = null)
    {
        if (!$self) {
            $self = $this;
        }

        if (in_array($key, array('title', 'placeholder', 'label', 'list_column_label'))) {
            $data = $self->api->translate($data);
        }
        else if ($key == 'options') {
            $data = array_map(array($self->api, 'translate'), $data);
        }
        else if (is_array($data)) {
            array_walk($data, array($self, 'localize_form_data'), $self);
        }
    }
}
