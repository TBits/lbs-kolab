<?php
/*
 +--------------------------------------------------------------------------+
 | This file is part of the Kolab File API                                  |
 |                                                                          |
 | Copyright (C) 2012-2018, Kolab Systems AG                                |
 |                                                                          |
 | This program is free software: you can redistribute it and/or modify     |
 | it under the terms of the GNU Affero General Public License as published |
 | by the Free Software Foundation, either version 3 of the License, or     |
 | (at your option) any later version.                                      |
 |                                                                          |
 | This program is distributed in the hope that it will be useful,          |
 | but WITHOUT ANY WARRANTY; without even the implied warranty of           |
 | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the             |
 | GNU Affero General Public License for more details.                      |
 |                                                                          |
 | You should have received a copy of the GNU Affero General Public License |
 | along with this program. If not, see <http://www.gnu.org/licenses/>      |
 +--------------------------------------------------------------------------+
 | Author: Aleksander Machniak <machniak@kolabsys.com>                      |
 +--------------------------------------------------------------------------+
*/

class file_api_autocomplete extends file_api_common
{
    /**
     * Request handler
     */
    public function handle()
    {
        parent::handle();

        if (!isset($this->args['search']) || $this->args['search'] === '') {
            throw new Exception("Missing search keyword", file_api_core::ERROR_CODE);
        }

        if (isset($this->args['folder']) && $this->args['folder'] !== '') {
            list($driver, $path) = $this->api->get_driver($this->args['folder']);
        }
        else {
            $driver = $this->api->get_backend();
        }

        if (!empty($this->args['mode'])) {
            $mode = 0;
            $mode += stripos($this->args['mode'], 'user') !== false ? file_storage::SEARCH_USER : 0;
            $mode += stripos($this->args['mode'], 'group') !== false ? file_storage::SEARCH_GROUP : 0;
        }

        if (empty($mode)) {
            $mode = file_storage::SEARCH_USER;
        }

        return $driver->autocomplete($this->args['search'], $mode);
    }
}
