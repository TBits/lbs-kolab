ALTER TABLE `chwala_sessions` ADD COLUMN `readonly` tinyint(1) NOT NULL DEFAULT 0;
