<?php
/*
 +--------------------------------------------------------------------------+
 | This file is part of the Kolab File API                                  |
 |                                                                          |
 | Copyright (C) 2012-2014, Kolab Systems AG                                |
 |                                                                          |
 | This program is free software: you can redistribute it and/or modify     |
 | it under the terms of the GNU Affero General Public License as published |
 | by the Free Software Foundation, either version 3 of the License, or     |
 | (at your option) any later version.                                      |
 |                                                                          |
 | This program is distributed in the hope that it will be useful,          |
 | but WITHOUT ANY WARRANTY; without even the implied warranty of           |
 | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the             |
 | GNU Affero General Public License for more details.                      |
 |                                                                          |
 | You should have received a copy of the GNU Affero General Public License |
 | along with this program. If not, see <http://www.gnu.org/licenses/>      |
 +--------------------------------------------------------------------------+
 | Author: Aleksander Machniak <machniak@kolabsys.com>                      |
 +--------------------------------------------------------------------------+
*/

class file_api_folder_list extends file_api_common
{
    /**
     * Request handler
     */
    public function handle()
    {
        parent::handle();

        $params   = $this->folder_list_params();
        $search   = isset($params['search']) ? mb_strtoupper($params['search']) : null;
        $drivers  = $this->api->get_drivers(true, $admin_drivers);
        $errors   = array();
        $has_more = false;

        if (isset($this->args['folder']) && strlen($this->args['folder'])) {
            list($driver, $path) = $this->api->get_driver($this->args['folder']);

            $title          = $driver->title();
            $params['path'] = $path;

            try {
                $folders = $this->folder_list($driver, $params, true);
            }
            catch (Exception $e) {
                $folders = array();
                if ($e->getCode() == file_storage::ERROR_NOAUTH) {
                    if (!in_array($title, $admin_drivers)) {
                        // inform UI about to ask user for credentials
                        $errors[$title] = $this->parse_metadata($driver->driver_metadata());
                    }
                    else {
                        $errors[$title] = array('error' => file_storage::ERROR_NOAUTH);
                    }
                }
            }

            $drivers = array();
        }
        else {
            $backend = $this->api->get_backend();

            // get folders from default driver
            if (!$this->rc->config->get('fileapi_backend_storage_disabled')) {
                $folders = $this->folder_list($backend, $params);
            }
        }

        // old result format
        if ($this->api->client_version() < 2) {
            return $folders;
        }

        // get folders from external sources
        foreach ($drivers as $driver) {
            $title  = $driver->title();
            $prefix = $title . file_storage::SEPARATOR;

            // folder exists in main source, replace it with external one
            foreach ($folders as $idx => $folder) {
                if (is_array($folder)) {
                    $folder = $folder['folder'];
                }
                if ($folder == $title || strpos($folder, $prefix) === 0) {
                    unset($folders[$idx]);
                }
            }

            if ($search === null || strpos(mb_strtoupper($title), $search) !== false) {
                if ($folder = $this->driver_root_folder($driver, $params)) {
                    $has_more  = $has_more || count($folders) > 0;
                    $folders[] = $folder;
                }
            }

            if ($driver != $backend && $params['level'] != 1) {
                try {
                    $_folders = $this->folder_list($driver, $params);
                    if (!empty($_folders)) {
                        $folders  = array_merge($folders, $_folders);
                        $has_more = true;
                        unset($_folders);
                    }
                }
                catch (Exception $e) {
                    if ($e->getCode() == file_storage::ERROR_NOAUTH) {
                        if (!in_array($title, $admin_drivers)) {
                            // inform UI about to ask user for credentials
                            $errors[$title] = $this->parse_metadata($driver->driver_metadata());
                        }
                        else {
                            $errors[$title] = array('error' => file_storage::ERROR_NOAUTH);
                        }
                    }
                }
            }
        }

        // re-sort the list
        if ($has_more) {
            usort($folders, array('file_utils', 'sort_folder_comparator'));
        }

        return array(
            'list'        => array_values($folders),
            'auth_errors' => $errors,
        );
    }

    protected function driver_root_folder($driver, $params)
    {
        $title  = $driver->title();
        $folder = $params['extended'] ? array('folder' => $title) : $title;

        if ($params['permissions'] || ($params['type'] & file_storage::FILTER_WRITABLE)) {
            if ($readonly = !($driver->folder_rights('') & file_storage::ACL_WRITE)) {
                if ($params['permissions']) {
                    $folder['readonly'] = true;
                }
            }
        }
        else {
            $readonly = false;
        }

        if (!$readonly || !($params['type'] & file_storage::FILTER_WRITABLE)) {
            return $folder;
        }
    }
}
