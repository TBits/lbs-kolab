#!/bin/sh

# replace community colors with enterprise
do_replace()
{
    perl -pi -e "s/#e63023/#f8ce0c/i" $1      #main-color
    perl -pi -e "s/230,48,35/248,206,12/" $1  #main-color (rgb)
    perl -pi -e "s/#eb594f/#f8d83d/i" $1      #link-color
    perl -pi -e "s/#fad6d3/#fceb9e/i" $1      #light
}

do_replace ./styles.css
