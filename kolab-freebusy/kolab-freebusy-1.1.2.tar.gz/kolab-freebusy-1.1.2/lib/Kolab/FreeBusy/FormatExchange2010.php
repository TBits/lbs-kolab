<?php

/**
 * This file is part of the Kolab Server Free/Busy Service
 *
 * @author Thomas Bruederli <bruederli@kolabsys.com>
 *
 * Copyright (C) 2013, Kolab Systems AG <contact@kolabsys.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as
 * published by the Free Software Foundation, either version 3 of the
 * License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 */

namespace Kolab\FreeBusy;

use Sabre\VObject\Reader as VCalReader;
use Sabre\VObject\FreeBusyGenerator;
use Sabre\VObject\ParseException;
use Desarrolla2\Cache\Cache;
use Desarrolla2\Cache\Adapter\File as FileCache;
use \SimpleXMLElement;


/**
 * Implementation of a data converter reading Exchange 2010 Internet Calendar Publishing files
 */
class FormatExchange2010 extends Format
{
	private $tzmap;

	/**
	 * @see Format::toVCalendar()
	 */
	public function toVCalendar($input)
	{
		// convert Microsoft timezone identifiers to Olson standard
		// do this before parsing to create correct DateTime values
		$input = preg_replace_callback('/(TZID[=:])([-\w ]+)\b/i', array($this, 'convertTZID'), $input);

		try {
			// parse vcalendar data
			$calendar = VCalReader::read($input);

			// map X-MICROSOFT-CDO-* attributes into iCal equivalents
			foreach ($calendar->VEVENT as $vevent) {
				if ($busystatus = reset($vevent->select('X-MICROSOFT-CDO-BUSYSTATUS'))) {
					$vevent->STATUS->value = $busystatus->value;
				}
			}

			// feed the calendar object into the free/busy generator
			// we must specify a start and end date, because recurring events are expanded. nice!
			$utc = new \DateTimezone('UTC');
			$fbgen = new FreeBusyGenerator(
				new \DateTime('now - 8 weeks 00:00:00', $utc),
				new \DateTime('now + 16 weeks 00:00:00', $utc),
				$calendar
			);

			// get the freebusy report
			$freebusy = $fbgen->getResult();
			$freebusy->PRODID = Utils::PRODID;
			$freebusy->METHOD = 'PUBLISH';

			// serialize to VCALENDAR format
			return $freebusy->serialize();
		}
		catch (ParseException $e) {
			Logger::get('format.Exchange2010')->addError("iCal parse error: " . $e->getMessage());
		}

		return false;
	}

	/**
	 * preg_replace callback function to map Timezone identifiers
	 */
	private function convertTZID($m)
	{
		if (!isset($this->tzmap)) {
			$this->getTZMAP();
		}

		$key = strtolower($m[2]);
		if ($this->tzmap[$key]) {
			$m[2] = $this->tzmap[$key];
		}

		return $m[1] . $m[2] . $m[3];
	}

	/**
	 * Generate a Microsoft => Olson Timezone mapping table from an official source
	 */
	private function getTZMAP()
	{
		if (!isset($this->tzmap)) {
			$log = Logger::get('format.Exchange2010');
			$cache = new Cache(new FileCache(sys_get_temp_dir()));

			// read from cache
			$this->tzmap = $cache->get('windows-timezones');

			// fetch timezones map from source
			if (empty($this->tzmap)) {
				$this->tzmap = array();
				$zones_url = 'http://unicode.org/repos/cldr/trunk/common/supplemental/windowsZones.xml';
				if ($xml = @file_get_contents($zones_url)) {
					try {
						$zonedata = new SimpleXMLElement($xml, LIBXML_NOWARNING | LIBXML_NOERROR);
						foreach ($zonedata->windowsZones[0]->mapTimezones[0]->mapZone as $map) {
							$other = strtolower(strval($map['other']));
							$region = strval($map['territory']);
							$words = explode(' ', $other);
							$olson = explode(' ', strval($map['type']));

							// skip invalid entries
							if (empty($other) || empty($olson))
								continue;

							// create an entry for all substrings
							for ($i = 1; $i <= count($words); $i++) {
								$last = $i == count($words);
								$key = join(' ', array_slice($words, 0, $i));
								if ($region == '001' || ($last && empty($this->tzmap[$key]))) {
									$this->tzmap[$key] = $olson[0];
								}
							}
						}

						// cache the mapping for one week
						$cache->set('windows-timezones', $this->tzmap, 7 * 86400);

						$log->addInfo("Updated Windows Timezones Map from source", array($zones_url));
					}
					catch (\Exception $e) {
						$log->addError("Failed parse Windows Timezones Map: " . $e->getMessage());
					}
				}
				else {
					$log->addError("Failed to load Windows Timezones Map from source", array($zones_url));
				}
			}
		}

		return $this->tzmap;
	}
}
