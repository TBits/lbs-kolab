<?php

/**
 * This file is part of the Kolab Server Free/Busy Service
 *
 * @author Thomas Bruederli <bruederli@kolabsys.com>
 *
 * Copyright (C) 2013, Kolab Systems AG <contact@kolabsys.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as
 * published by the Free Software Foundation, either version 3 of the
 * License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 */

namespace Kolab\FreeBusy;

/**
 * Abstract class to fetch free/busy data from a specific source
 */
abstract class Source
{
	protected $config = array();
	protected $cached = false;

	/**
	 * Factory method creating an instace of Source according to config
	 *
	 * @param string Source URI
	 * @param array Hash array with config
	 */
	public static function factory($url, $conf)
	{
		$config = parse_url($url);
		$config['url'] = $url;
		switch ($config['scheme']) {
			case 'file':	return new SourceFile($config + $conf);
			case 'tls':
			case 'imap':
			case 'imaps':	return new SourceIMAP($config + $conf);
			case 'http':
			case 'https':	return new SourceURL($config + $conf);
			case 'fbd':
			case 'fbdaemon': return new SourceFBDaemon($config + $conf);
			case 'aggregate': return new SourceAggregator($config + $conf);
		}

		Logger::get('source')->addError("Invalid source configuration: " . $url);
		return null;
	}

	/**
	 * Default constructor
	 */
	public function __construct($config)
	{
		$this->config = $config;
	}

	/**
	 * Retrieve free/busy data for the given user
	 *
	 * @param array Hash array with user attributes
	 */
	abstract public function getFreeBusyData($user, $extended);

	/**
	 * Replace all %varname strings in config with values from $user
	 */
	protected function getUserConfig($user)
	{
		$config = array();
		foreach ($this->config as $k => $val) {
			if (is_string($val) && strpos($val, '%') !== false) {
				$val = preg_replace_callback(
					'/%\{?([a-z0-9]+)\}?/',
					function($m) use ($k, $user) {
						$enc = $k == 'url' || $k == 'query' || $k == 'fbsource';
						return $enc ? urlencode($user[$m[1]]) : $user[$m[1]];
					},
					$val);
			}

			$config[$k] = $val;
		}

		return $config;
	}

	/**
	 * Helper method to check if a cached file exists and is still valid
	 *
	 * @param array Hash array with (replaced) config properties
	 * @return string Cached free-busy data or false if cache file doesn't exist or is expired
	 */
	protected function getCached($config)
	{
		if ($config['cacheto'] && file_exists($config['cacheto'])) {
			if (empty($config['expires']) || filemtime($config['cacheto']) + Utils::getOffsetSec($config['expires']) >= time()) {
				$this->cached = true;
				return file_get_contents($config['cacheto']);
			}
		}

		return false;
	}

	/**
	 * Return the value of the 'cached' flag
	 */
	public function isCached()
	{
		return $this->cached;
	}
}
