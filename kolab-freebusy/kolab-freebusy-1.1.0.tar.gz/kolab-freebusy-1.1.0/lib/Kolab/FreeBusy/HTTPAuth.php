<?php

/**
 * This file is part of the Kolab Server Free/Busy Service
 *
 * @author Thomas Bruederli <bruederli@kolabsys.com>
 *
 * Copyright (C) 2013, Kolab Systems AG <contact@kolabsys.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as
 * published by the Free Software Foundation, either version 3 of the
 * License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 */

namespace Kolab\FreeBusy;

use \Net_LDAP3;
use \Monolog\Logger as Monolog;

/**
 * Static class to process HTTP authentication to this service
 */
class HTTPAuth
{
	private static $logger;

	/**
	 * Validate HTTP basic auth against the configured backend
	 */
	public static function check($config)
	{
		$logger = Logger::get('httpauth');

		// no http auth submitted, abort!
		if (empty($_SERVER['PHP_AUTH_USER']) || !isset($_SERVER['PHP_AUTH_PW'])) {
			$logger->addDebug('No HTTP auth submitted');
			return false;
		}

		switch ($config['type']) {
			case 'static':
				return self::checkStatic($config, $_SERVER['PHP_AUTH_USER'], $_SERVER['PHP_AUTH_PW']);

			case 'ldap':
				return self::checkLDAP($config, $_SERVER['PHP_AUTH_USER'], $_SERVER['PHP_AUTH_PW']);

			default:
				$logger->addWarning('Unsupported auth type ' . $config['type']);
				break;
		}

		return false;
	}

	/**
	 * Validate static user credentials from config
	 */
	private static function checkStatic($config, $user, $pass)
	{
		$valid = $user == $config['username'] && $pass == $config['password'];
		Logger::get('httpauth')->addInfo("Static: authenticating user '$user': " . ($valid ? 'SUCCESS' : 'FAILURE'));
		return $valid;
	}

	/**
	 * Validate user credentials against the configured LDAP backend
	 */
	private static function checkLDAP($config, $user, $pass)
	{
		self::$logger = Logger::get('httpauth', intval($config['loglevel']));

		list($u, $d) = explode('@', $user);
		$replaces = array('%dc' => 'dc=' . str_replace('.', ',dc=', $d), '%u' => $u);
		$config['base_dn'] = strtr($config['base_dn'], $replaces);
		$config['filter'] = strtr($config['filter'], $replaces);

		$host = parse_url($config['host']);
		$ldap_config = array(
			'hosts'   => array($config['host']),
			'port'    => $host['port'] ?: 389,
			'use_tls' => $host['scheme'] == 'tls',
			'root_dn' => $config['base_dn'],
			'filter'  => $config['filter'],
			'service_bind_dn' => $config['bind_dn'],
			'service_bind_pw' => $config['bind_pw'],
			'log_hook' => 'Kolab\FreeBusy\HTTPAuth::ldapLog',
		);

		// instantiate Net_LDAP3 and connect with logger
		$ldap = new Net_LDAP3($ldap_config);

		// connect + bind to LDAP server
		if ($ldap->connect()) {
			self::$logger->addDebug("LDAP: connected to $config[host] with '$config[bind_dn]'");

			// extract domain part from base_dn
			$dn_domain = ldap_explode_dn($config['base_dn'], 1);
			unset($dn_domain['count']);
			$domain = join('.', $dn_domain);

			$valid = (bool)$ldap->login($user, $pass, $domain);
		}
		else {
			self::$logger->addWarning("LDAP: connectiion to $config[host] with '$config[bind_dn]' failed!");
		}

		self::$logger->addInfo("LDAP: authenticating user '$user': " . ($valid ? 'SUCCESS' : 'FAILURE'));
		return $valid;
	}

	/**
	 * Callback for Net_LDAP3 logging
	 */
	public static function ldapLog($level, $msg)
	{
		// map PHP log levels to Monolog levels
		static $loglevels = array(
			LOG_DEBUG   => Monolog::DEBUG,
			LOG_NOTICE  => Monolog::NOTICE,
			LOG_INFO    => Monolog::INFO,
			LOG_WARNING => Monolog::WARNING,
			LOG_ERR     => Monolog::ERROR,
			LOG_CRIT    => Monolog::CRITICAL,
			LOG_ALERT   => Monolog::ALERT,
			LOG_EMERG   => Monolog::EMERGENCY,
		);

		$msg = is_array($msg) ? join('; ', $msg) : strval($msg);
		self::$logger->addRecord($loglevels[$level], $msg);
	}

}