<?php

/**
 * This file is part of the Kolab Server Free/Busy Service
 *
 * @author Thomas Bruederli <bruederli@kolabsys.com>
 *
 * Copyright (C) 2013, Kolab Systems AG <contact@kolabsys.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as
 * published by the Free Software Foundation, either version 3 of the
 * License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 */

namespace Kolab\FreeBusy;

/**
 * Implementation of a static address directory for Free/Busy user lookups.
 *
 * This directory basically pipes the username through with an optional check
 * whether it matches the configured filter rule
 */
class DirectoryStatic extends Directory
{
	/**
	 * Default constructor loading directory configuration
	 */
	public function __construct($config)
	{
		$this->config = $config;
	}

	/**
	 * @see Directory::resolve()
	 */
	public function resolve($user)
	{
		$result = array('s' => $user);

		// check if user matches the filter property (if configured)
		if (!empty($this->config['filter'])) {
			if (!preg_match('!'.$this->config['filter'].'!i', $user))
			 	$result = false;
		}

		return $result;
	}

}

