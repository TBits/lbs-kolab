<?php

/**
 * This file is part of the Kolab Server Free/Busy Service
 *
 * @author Thomas Bruederli <bruederli@kolabsys.com>
 *
 * Copyright (C) 2013, Kolab Systems AG <contact@kolabsys.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as
 * published by the Free Software Foundation, either version 3 of the
 * License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 */

namespace Kolab\FreeBusy;

/**
 * Base class to handle free/busy data format conversion
 */
class Format
{
	protected $config;

	/**
	 * Factory method creating an instace of Format according to the given type
	 *
	 * @param string Format identifier
	 */
	public static function factory($type)
	{
		switch (strtolower($type)) {
			case 'exchange2010':
				return new FormatExchange2010;

			default:
				if (!empty($type)) {
					Logger::get('format')->addError("Unknown format type '$type'!");
				}
				return new Format;
		}

		return null;
	}

	/**
	 * Convert the given free/busy data stream to iCal format
	 *
	 * @param string Input data stream
	 * @return string iCal formatted free/busy list
	 */
	public function toVCalendar($input)
	{
		// default: no format changes
		return $input;
	}


}