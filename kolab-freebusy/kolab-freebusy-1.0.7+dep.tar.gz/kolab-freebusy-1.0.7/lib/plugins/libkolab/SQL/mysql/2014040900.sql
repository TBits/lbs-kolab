ALTER TABLE `kolab_cache_contact` CHANGE `data` `data` LONGTEXT NOT NULL;
ALTER TABLE `kolab_cache_event` CHANGE `data` `data` LONGTEXT NOT NULL;
ALTER TABLE `kolab_cache_task` CHANGE `data` `data` LONGTEXT NOT NULL;
ALTER TABLE `kolab_cache_journal` CHANGE `data` `data` LONGTEXT NOT NULL;
ALTER TABLE `kolab_cache_note` CHANGE `data` `data` LONGTEXT NOT NULL;
ALTER TABLE `kolab_cache_file` CHANGE `data` `data` LONGTEXT NOT NULL;
ALTER TABLE `kolab_cache_configuration` CHANGE `data` `data` LONGTEXT NOT NULL;
ALTER TABLE `kolab_cache_freebusy` CHANGE `data` `data` LONGTEXT NOT NULL;
