INTALLATION PROCEDURE
=====================

This package uses [Composer](http://getcomposer.org) to install and maintain required PHP libraries.

1. Install Composer

Execute this in the project root directory:

`$ curl -s http://getcomposer.org/installer | php`

This will create a file named composer.phar in the project directory.

2. Install Dependencies

`$ php composer.phar install`

2a. Link Roundcube framework and plugins

If free-busy data is to be pulled from IMAP directly, the Roundcube framework, config
and Kolab-specific plugins are required. Symlink them into the project directory:

```
$ ln -s /usr/share/roundcubemail/program/lib/Roundcube lib/Roundcube
$ ln -s /usr/share/roundcubemail/plugins lib/plugins
$ ln -s /etc/roundcubemail/defaults.inc.php config/defaults.inc.php
$ ln -s /etc/roundcubemail/config.inc.php config/config.inc.php
```

3. Create local config

Copy the config template file to config/config.ini:

`$ cp config/config.ini.sample config/config.ini`

Edit the local config/config.ini file according to your setup and taste.

4. Give write access for the webserver user to the 'log' folder:

`$ chown <www-user> log`

5. Configure your webserver to point to the 'web' directory of this package as document root.

