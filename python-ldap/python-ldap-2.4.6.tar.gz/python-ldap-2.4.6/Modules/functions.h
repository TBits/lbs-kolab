/* See http://www.python-ldap.org/ for details.
 * $Id: functions.h,v 1.4 2009/04/17 12:19:09 stroeder Exp $ */

#ifndef __h_functions_
#define __h_functions_

/* $Id: functions.h,v 1.4 2009/04/17 12:19:09 stroeder Exp $ */

#include "common.h"
extern void LDAPinit_functions( PyObject* );

#endif /* __h_functions_ */
