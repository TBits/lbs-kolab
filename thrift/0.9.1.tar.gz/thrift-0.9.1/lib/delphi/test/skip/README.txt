These two projects belong together. Both programs 
simulate server and client for different versions 
of the same protocol.

The intention of this test is to ensure fully
working compatibilty features of the Delphi Thrift 
implementation.

The expected test result is, that no errors occur 
with both programs, regardless in which order they 
might be started.
