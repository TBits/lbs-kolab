#ifndef EBLOOM_NIFS
#define EBLOOM_NIFS

extern "C"
{
#include "erl_nif.h"
}

#endif
