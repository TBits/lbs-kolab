
.. include:: ../README.rst

Contents
========

.. toctree::
    :maxdepth: 2

    about
    install
    usage
    RFC 5545 <rfc5545/index>
    credits
    license
