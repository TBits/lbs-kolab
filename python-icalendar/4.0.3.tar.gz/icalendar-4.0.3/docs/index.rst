.. include:: ../README.rst

Contents
========

.. toctree::
    :maxdepth: 2

    about
    install
    usage
    api
    cli
    credits
    license
