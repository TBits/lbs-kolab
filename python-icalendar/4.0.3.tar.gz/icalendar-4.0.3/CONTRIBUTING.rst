You want to help and contribute? Perfect!
=========================================

These are some contribution examples
------------------------------------

- Reporting issues to the bugtracker.

- Submitting pull requests from a forked icalendar repo.

- Extending the documentation.

- Sponsor a Sprint (http://plone.org/events/sprints/whatis).


For pull requests, keep this in mind
------------------------------------

- Add a test which proves your fix and make it pass.

- Describe your change in CHANGES.rst

- Add yourself to the docs/credits.rst
