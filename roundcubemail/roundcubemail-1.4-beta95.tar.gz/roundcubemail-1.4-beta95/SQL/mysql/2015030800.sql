ALTER TABLE `identities` CHANGE `signature` `signature` longtext;
