[![Build Status](https://travis-ci.org/massemanet/eper.svg?branch=master)](https://travis-ci.org/massemanet/eper)

eper is a loose collection of Erlang Performance related tools.

* dtop   - similar to unix top
* ntop   - visualizes network traffic
* atop   - shows various aspects of the VM allocators
* redbug - similar to the OTP dbg application, but safer, better etc.