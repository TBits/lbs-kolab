<?php

/**
 +--------------------------------------------------------------------------+
 | Kolab Autodiscover Service                                               |
 |                                                                          |
 | Copyright (C) 2011-2014, Kolab Systems AG <contact@kolabsys.com>         |
 |                                                                          |
 | This program is free software: you can redistribute it and/or modify     |
 | it under the terms of the GNU General Public License as published by     |
 | the Free Software Foundation, either version 3 of the License, or        |
 | (at your option) any later version.                                      |
 |                                                                          |
 | This program is distributed in the hope that it will be useful,          |
 | but WITHOUT ANY WARRANTY; without even the implied warranty of           |
 | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the             |
 | GNU General Public License for more details.                             |
 |                                                                          |
 | You should have received a copy of the GNU General Public License        |
 | along with this program. If not, see http://www.gnu.org/licenses/.       |
 +--------------------------------------------------------------------------+
 | Author: Daniel Hoffend <dh@dotlan.net>                                   |
 +--------------------------------------------------------------------------+
*/

/**
 * Autodiscover Service class for Microsoft Autodiscover V2
 */
class AutodiscoverJson extends Autodiscover
{

    public function handle_request()
    {
        if (preg_match('|autodiscover.json/v1.0/([^\?]+)|', $_SERVER['REQUEST_URI'], $regs)) {
            $this->email = $regs[1];
        }

        Log::debug('Request [json]: ' . $_SERVER['REQUEST_URI']);
    }

    /**
     * Generates JSON response
     */
    protected function handle_response()
    {
        if (strtolower($_GET['Protocol']) == 'activesync'
            && !empty($this->config['activesync'])
        ) {
            if (!preg_match('/^https?:/i', $this->config['activesync'])) {
                $this->config['activesync'] = 'https://' . $this->config['activesync'] . '/Microsoft-Server-ActiveSync';
            }
            $json = array(
                'Protocol' => 'ActiveSync',
                'Url' => $this->config['activesync']
            );
        }
        elseif (strtolower($_GET['Protocol']) == 'autodiscoverv1') {
            $json = array(
                'Protocol' => 'ActiveSync',
                'Url' => 'https://' . $_SERVER['HTTP_HOST'] . '/Autodiscover/Autodiscover.xml'
            );
        }
        else {
            http_response_code(400);
            $json = array(
                'ErrorCore' => 'InvalidProtocol',
                'ErrorMessage' => 'The given protocol value \u0027'
                    . $_GET['Protocol']
                    . '\u0027 is invalid. Supported values are \u0027'
                    . (!empty($this->config['activesync']) ? 'ActiveSync,' : '')
                    . 'AutodiscoverV1\u0027'
            );
        }

        $response = json_encode($json, JSON_PRETTY_PRINT);
        Log::debug('Response [json]: ' . $response);

        header('Content-Type: application/json; charset=' . Autodiscover::CHARSET);
        echo $response;
        exit;
    }
}
