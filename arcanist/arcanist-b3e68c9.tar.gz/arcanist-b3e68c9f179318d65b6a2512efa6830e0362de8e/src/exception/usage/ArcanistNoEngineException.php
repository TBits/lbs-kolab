<?php

/**
 * Thrown when no engine is configured for linting or running unit tests.
 */
final class ArcanistNoEngineException extends ArcanistUsageException {}
