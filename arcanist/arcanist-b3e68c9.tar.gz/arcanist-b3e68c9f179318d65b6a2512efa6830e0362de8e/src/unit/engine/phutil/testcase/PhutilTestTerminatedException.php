<?php

/**
 * Thrown to prematurely end test execution.
 */
final class PhutilTestTerminatedException extends Exception {}
