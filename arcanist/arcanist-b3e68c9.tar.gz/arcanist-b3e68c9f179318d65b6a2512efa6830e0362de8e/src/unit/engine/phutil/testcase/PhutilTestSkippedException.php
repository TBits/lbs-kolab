<?php

/**
 * Thrown to skip test execution.
 */
final class PhutilTestSkippedException extends Exception {}
