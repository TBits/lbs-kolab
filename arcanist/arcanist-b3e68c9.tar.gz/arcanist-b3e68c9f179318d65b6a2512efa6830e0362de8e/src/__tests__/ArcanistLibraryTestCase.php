<?php

final class ArcanistLibraryTestCase extends PhutilLibraryTestCase {}
