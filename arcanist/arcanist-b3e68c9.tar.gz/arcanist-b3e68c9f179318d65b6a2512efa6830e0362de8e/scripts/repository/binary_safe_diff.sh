#!/bin/sh

diff "$@" || exit 1
