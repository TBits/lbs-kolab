<?php

namespace Sabre\DAV;

use Sabre\HTTP;

/**
 * URLUtil
 *
 * This file moved to the HTTP package and is now deprecated. Use
 * Sabre\HTTP\URLUtil instead.
 *
 * This file will be removed in a future version.
 *
 * @copyright Copyright (C) fruux GmbH (https://fruux.com/)
 * @copyright Copyright (C) fruux GmbH (https://fruux.com/)
 * @deprecated Use Sabre\HTTP\URLUtil instead!
 * @license http://sabre.io/license/ Modified BSD License
 */
class URLUtil extends HTTP\URLUtil {

}
