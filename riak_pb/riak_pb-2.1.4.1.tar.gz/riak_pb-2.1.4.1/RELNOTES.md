Release Notes
=============

* [`2.1.4.1`](https://github.com/basho/riak_pb/issues?q=milestone%3Ariak_pb-2.1.4.1)
 * OTP 19 support in `riak_pb` and dependencies.
