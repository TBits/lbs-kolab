# Riak Control

Riak Control is a OTP application included in the Riak database which
provides a user interface for cluster planning and visibility.  As Riak
Control comes bundled with Riak, you do not need to install this
application separately.  

## Enabling Riak Control

For more information on enabling Riak Control, see the
[docs](http://docs.basho.com/riak/latest/ops/advanced/riak-control/).
