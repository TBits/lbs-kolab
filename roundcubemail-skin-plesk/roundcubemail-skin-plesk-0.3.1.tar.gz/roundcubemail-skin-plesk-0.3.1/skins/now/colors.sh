#!/bin/sh

# replace community colors with "now" colors
do_replace()
{
    perl -pi -e "s/#e63023/#f4a628/i" $1      #main-color
    perl -pi -e "s/230,48,35/244,166,40/" $1  #main-color (rgb)
    perl -pi -e "s/#eb594f/#f1a629/i" $1      #link-color
    perl -pi -e "s/#fad6d3/#ffcf86/i" $1      #light
}

do_replace ./styles.css
