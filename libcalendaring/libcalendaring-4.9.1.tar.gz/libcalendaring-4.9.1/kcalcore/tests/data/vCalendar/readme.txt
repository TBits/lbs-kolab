Test files to check vCalendar export and import for correctness. They cover 
all cases of recurrence rules that were possible in KOrganizer from KDE 3.4. 
Each event (=file) exists as iCalendar and vCalendar file. The reference 
data is the corresponding event in the other format. 

