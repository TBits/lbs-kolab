These files belong to LibKCal's test suite. Their main goal is to check 
various aspects of recurrence rules. See the readme.txt files in each 
subdirectory for more information about the purposes of them.
