<?php

@%@UCRWARNING=// @%@

// if you want to load localization strings for specific sub-libraries of jquery-ui, configure them here 
$config['jquery_ui_i18n'] = array('datepicker');

// map Roundcube skins with jquery-ui skins here
$config['jquery_ui_skin_map'] = array(
  'larry' => 'larry',
  'default' => 'enterprise',
  'enterprise' => 'enterprise',
  'groupvice4' => 'redmond',
);

?>
