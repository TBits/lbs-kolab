#!/bin/bash
#
# Kolab Webclient join script
#
# Copyright (C) 2012 Kolab Systems AG <contact@kolabsystems.com>
#
# http://kolabsystems.com/
#
# All rights reserved.
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License version 3 as
# published by the Free Software Foundation
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along
# with this program; if not, write to the Free Software Foundation, Inc.,
# 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA

VERSION=2

. /usr/share/univention-lib/all.sh
. /usr/share/univention-join/joinscripthelper.lib

joinscript_init

eval "$(univention-config-registry shell)"

# start mysql if not running
if [ ! -e /var/run/mysqld/mysqld.sock ]; then
    test -x /etc/init.d/mysql && /etc/init.d/mysql start
fi

# set up mysql roundcube password if none is set
if [ ! -e /etc/roundcube.secret ]; then
    touch /etc/roundcube.secret
    chmod 600 /etc/roundcube.secret
    chown root /etc/roundcube.secret
    makepasswd --nocrypt > /etc/roundcube.secret
fi

# Create and initialize the Roundcube database if it doesn't exist
passwd=$(cat /etc/mysql.secret)

# $HOME may not be set -- however, honor it if it is.
if [ -z "$HOME" ]; then
    export HOME=/root
fi

if [ -z "$USER" ]; then
    export USER=root
fi

if [ ! -e "$HOME/.my.cnf" ]; then
    cnf_created=1
    touch $HOME/.my.cnf
    chmod 600 $HOME/.my.cnf
    chown root:root $HOME/.my.cnf
    echo "[mysql]" > $HOME/.my.cnf
    echo "password=$passwd" >> $HOME/.my.cnf
else
    cnf_created=0
fi

if ! mysql -e "use roundcubemail" > /dev/null 2>&1 ; then
    rcpasswd=$(cat /etc/roundcube.secret)
    mysql -e "CREATE DATABASE roundcubemail;" || :
    mysql -e "GRANT ALL PRIVILEGES ON roundcubemail.* TO roundcube@localhost IDENTIFIED BY '$rcpasswd';" || :
    mysql roundcubemail < /usr/share/doc/roundcubemail/SQL/mysql.initial.sql
    mysql roundcubemail < /usr/share/roundcubemail/plugins/calendar/drivers/kolab/SQL/mysql.initial.sql
    mysql roundcubemail < /usr/share/roundcubemail/plugins/libkolab/SQL/mysql.initial.sql
    mysql roundcubemail < /usr/share/doc/kolab-syncroton/SQL/mysql.initial.sql
    unset rcpasswd
fi

unset passwd

if [ ${cnf_created} -eq 1 ]; then
    rm -rf $HOME/.my.cnf
fi

# create random 24bit DES key if none is set
if [ ! -e /etc/roundcube.des_key ]; then
    touch /etc/roundcube.des_key
    chmod 600 /etc/roundcube.des_key
    chown root /etc/roundcube.des_key
    makepasswd --chars=24 > /etc/roundcube.des_key
fi

# Include new DES key in the roundcubemail configuration
univention-config-registry commit /etc/roundcubemail/config.inc.php

if [ -d "/etc/iRony/" ]; then
    univention-config-registry commit /etc/iRony/dav.inc.php
fi

if [ -d "/etc/kolab-freebusy/" ]; then
    univention-config-registry commit /etc/kolab-freebusy/config.ini
fi

apache_reload=0

# Disable legacy Kolab Free/Busy site
if [ -e "/etc/apache2/sites-enabled/kolab2-freebusy" ]; then
    echo "Disabling kolab2-freebusy"
    a2dissite kolab2-freebusy >/dev/null 2>&1
    apache_reload=1
fi

# Enable Kolab Free/Busy site
if [ -e "/etc/apache2/sites-available/kolab-freebusy" -a ! -e "/etc/apache2/sites-enabled/kolab-freebusy" ]; then
    echo "Enabling kolab-freebusy"
    a2ensite kolab-freebusy >/dev/null 2>&1
    apache_reload=1
fi

# Enable chwala site
if [ -e "/etc/apache2/sites-available/chwala" -a ! -e "/etc/apache2/sites-enabled/chwala" ]; then
    echo "Enabling chwala"
    a2ensite chwala >/dev/null 2>&1
    apache_reload=1
fi

# Enable iRony site
if [ -e "/etc/apache2/sites-available/iRony" -a ! -e "/etc/apache2/sites-enabled/iRony" ]; then
    echo "Enabling iRony"
    a2ensite iRony >/dev/null 2>&1
    apache_reload=1
fi

if [ ${apache_reload} -eq 1 ]; then
    invoke-rc.d apache2 reload
fi

# Register the webclient on UCS landing page
ucr set \
    ucs/web/overview/entries/service/kolab-webclient/icon?"/webmail/skins/enterprise/images/kolab-ucs-logo.svg" \
    ucs/web/overview/entries/service/kolab-webclient/link?"/webmail" \
    ucs/web/overview/entries/service/kolab-webclient/label?"Kolab Enterprise Web Application" \
    ucs/web/overview/entries/service/kolab-webclient/label/de?"Kolab Enterprise Webanwendung" \
    ucs/web/overview/entries/service/kolab-webclient/description?"Manage mail, contacts, appointments, tasks, and notes" \
    ucs/web/overview/entries/service/kolab-webclient/description/de?"Nachrichten, Kontakte, Termine, Aufgaben und Notizen verwalten"

# add service to my host object
ucs_addServiceToLocalhost "Kolab-Webclient" "$@"

joinscript_save_current_version

exit 0

