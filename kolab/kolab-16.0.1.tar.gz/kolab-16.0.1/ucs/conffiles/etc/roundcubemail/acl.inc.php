<?php

@%@UCRWARNING=// @%@

// Default look of access rights table
// In advanced mode all access rights are displayed separately
// In simple mode access rights are grouped into four groups: read, write, delete, full 
    $config['acl_advanced_mode'] = false;

// LDAP addressbook that would be searched for user names autocomplete.
// That should be an array refering to the $config['ldap_public'] array key
// or complete addressbook configuration array.
    $config['acl_users_source'] = 'kolab_addressbook';

// The LDAP attribute which will be used as ACL user identifier
$config['acl_users_field'] = 'mailPrimaryAddress';

// The LDAP search filter will be &'d with search queries
    $config['acl_users_filter'] = 'objectClass=kolabInetOrgPerson';

    $config['acl_groups'] = true;
    $config['acl_group_prefix'] = 'group:';

    if (file_exists(RCUBE_CONFIG_DIR . '/' . $_SERVER["HTTP_HOST"] . '/' . basename(__FILE__))) {
        include_once(RCUBE_CONFIG_DIR . '/' . $_SERVER["HTTP_HOST"] . '/' . basename(__FILE__));
    }

?>
