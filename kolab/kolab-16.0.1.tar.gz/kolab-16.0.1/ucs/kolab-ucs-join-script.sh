#!/bin/bash

VERSION=6

# We should probably just use base.sh and ldap.sh, for now we just use all.sh
. /usr/share/univention-lib/all.sh
. /usr/share/univention-join/joinscripthelper.lib
joinscript_init

function addUserAttribute {
	name="$1"
	shift
	udm settings/extended_attribute create \
		--ignore_exists \
		--position "cn=kolab,cn=custom attributes,cn=univention,$ldap_base" \
		--set tabName="Mail" \
		--append translationTabName='"de_CH" "Mail"' \
		--append translationTabName='"de_DE" "Mail"' \
		--set name="$name" \
		--set CLIName="$name" \
		--set mayChange=1 \
		"$@"
}

eval "$(univention-config-registry shell)"

# Delete old service references
echo -n "Removing legacy Kolab 2 service reference from LDAP ... "
ucs_removeServiceFromLocalhost "kolab2" "$@"

# Delete old custom attributes (we use our own container now, see below)
for ATTRIBUTE in \
	KolabEnabled \
	KolabForwardAddress \
	KolabForwardActive \
	KolabForwardKeepCopy \
	KolabForwardUCE \
	KolabVacationText \
	KolabVacationActive \
	KolabVacationAddress \
	KolabVacationNoReactDomain \
	KolabDeliveryToFolderName \
	KolabDeliveryToFolderActive ; \
do udm settings/extended_attribute remove \
	--dn "cn=$ATTRIBUTE,cn=custom attributes,cn=univention,$ldap_base" ; done

# Create a container for all Kolab-related custom attributes
univention-directory-manager container/cn create "$@" --ignore_exists \
	--position "cn=custom attributes,cn=univention,$ldap_base" \
	--set name=kolab

# Register Kolab service
echo -n "Creating Kolab service in LDAP ... "
ucs_addServiceToLocalhost "kolab" "$@"

# Register LDAP schema extensions
ucs_registerLDAPExtension "$@" \
	--schema /usr/share/doc/kolab-schema/kolab3.schema \
	--schema /usr/share/doc/kolab-schema/univention-kolab3-wrapper.schema \
	--acl /usr/share/doc/kolab-schema/univention-kolab3.acl \
	--udm_hook /usr/share/kolab-ucs/hookKolabEnabled.py \
	--udm_syntax /usr/share/kolab-ucs/kolab-syntax-classes.py

# Create Groupware account template
echo -n "Creating Groupware Account template ... "
udm settings/usertemplate create "$@" --ignore_exists \
	--position cn=templates,cn=univention,${ldap_base} \
	--set name="${domainname} Groupware Account" \
	--set mailPrimaryAddress="<username>@${domainname}" \
	--set e-mail="<username>@${domainname}" \
	--set unixhome="/home/<username>"

mail=$(udm settings/usertemplate list "$@" --filter="cn=$domainname Groupware Account" | grep ' e-mail:' | sed 's/[^:]*: //;s/^None$//')
shell=$(udm settings/usertemplate list "$@" --filter="cn=$domainname Groupware Account" | grep ' shell:' | sed 's/[^:]*: //;s/^None$//')
unixhome=$(udm settings/usertemplate list "$@" --filter="cn=$domainname Groupware Account" | grep ' unixhome:' | sed 's/[^:]*: //;s/^\/home\/$//')
if [ -z "$mail" -o -z "$shell" -o -z "$unixhome" ]; then
	udm settings/usertemplate modify --dn "cn=$domainname Groupware Account,cn=templates,cn=univention,$ldap_base" --set mailPrimaryAddress="<username>@$domainname" --set e-mail="<username>@$domainname" --set shell="/bin/bash" --set unixhome="/home/<username>"
fi

# remove old '$hostname.$domainname Groupware Account' template (#1606)
udm settings/usertemplate remove --dn "$hostname.$domainname Groupware Account,cn=templates,cn=univention,${ldap_base}" || true

# Create mail domain
echo -n "Creating mail domain ${domainname} ... "
udm mail/domain create \
    $@ --ignore_exists \
    --set name=${domainname} \
    --position cn=domain,cn=mail,${ldap_base} \
    >/dev/null 2>&1 && echo "OK" || echo "FAIL"

# Create cyrus-admin user
echo -n "Creating Cyrus Admin user ... "
udm users/user create "$@" --ignore_exists \
	--set password=$(cat /etc/cyrus.secret) \
	--set "username=cyrus-admin" \
	--set "firstname=Cyrus" \
	--set "lastname=Administrator" \
	--position "cn=users,${ldap_base}"

### UMC Settings

udm settings/extended_attribute create "$@" --ignore_exists \
	--set objectClass=univentionObject \
	--set name=KolabEnabled \
	--set CLIName=KolabEnabled \
	--append module=users/user \
	--set tabName="Account" \
	--set tabAdvanced=0 \
	--set overwriteTab=0 \
	--append translationTabName='"de_CH" "Konto"' \
	--append translationTabName='"de_DE" "Konto"' \
	--set groupName="Kolab Groupware" \
	--set shortDescription="Kolab Groupware Account" \
	--set longDescription="Defines if the user can use Kolab Groupware features" \
	--append translationShortDescription='"de_DE" "Kolab Groupware Konto"' \
	--append translationLongDescription='"de_DE" "Legt fest, ob der Nutzer Kolab Groupware Funktionen nutzen kann"' \
	--set hook=hookKolabEnabled \
	--set ldapMapping=kolabDummyAttribute \
	--set deleteObjectClass=0 \
	--set version=2 \
	--set valueRequired=0 \
	--set fullWidth=0 \
	--set doNotSearch=0 \
	--set syntax=boolean \
	--set default=1 \
	--set mayChange=1 \
	--set multivalue=0 \
	--set notEditable=0 \
	--set disableUDMWeb=0 \
	--position "cn=kolab,cn=custom attributes,cn=univention,${ldap_base}"

# Shared folder type
udm settings/extended_attribute create "$@" --ignore_exists \
	--set objectClass=kolabSharedFolder \
	--set name=KolabFolderType \
	--set CLIName=KolabFolderType \
	--append module=mail/folder \
	--set tabName="General" \
	--append translationTabName='"de_AT" "Allgemein"' \
	--append translationTabName='"de_CH" "Allgemein"' \
	--append translationTabName='"de_DE" "Allgemein"' \
	--set tabAdvanced=0 \
	--set overwriteTab=0 \
	--set tabPosition=99 \
	--set shortDescription="Folder Type" \
	--set longDescription="Folders can not only be used to share mail but also contacts, calendars, task lists, notes, or journals." \
	--append translationShortDescription='"de_AT" "Ordnertyp"' \
	--append translationShortDescription='"de_CH" "Ordnertyp"' \
	--append translationShortDescription='"de_DE" "Ordnertyp"' \
	--append translationLongDescription='"de_AT" "Ordner können nicht nur für E-Mails gemeinsam genutzt werden, sondern auch für Adressbücher, Kalender, Aufgaben, Notizen und Journal."' \
	--append translationLongDescription='"de_CH" "Ordner können nicht nur für E-Mails gemeinsam genutzt werden, sondern auch für Adressbücher, Kalender, Aufgaben, Notizen und Journal."' \
	--append translationLongDescription='"de_DE" "Ordner können nicht nur für E-Mails gemeinsam genutzt werden, sondern auch für Adressbücher, Kalender, Aufgaben, Notizen und Journal."' \
	--set ldapMapping=kolabFolderType \
	--set deleteObjectClass=1 \
	--set valueRequired=0 \
	--set doNotSearch=0 \
	--set syntax=mail_folder_type \
	--set default=None \
	--set mayChange=1 \
	--set multivalue=0 \
	--set notEditable=0 \
	--set disableUDMWeb=0 \
	--position "cn=kolab,cn=custom attributes,cn=univention,${ldap_base}"

# Invitation policies
udm settings/extended_attribute create "$@" --ignore_exists \
	--set objectClass="kolabInetOrgPerson" \
	--set name="KolabInvitationPolicy" \
	--set CLIName="KolabInvitationPolicy" \
	--append module="users/user" \
	--append module="users/self" \
	--set groupPosition=1 \
	--set tabName="Kolab Groupware" \
	--append translationTabName='"de_CH" "Kolab Groupware"' \
	--append translationTabName='"de_DE" "Kolab Groupware"' \
	--set tabAdvanced=0 \
	--set overwriteTab=0 \
	--set tabPosition=1 \
	--set groupName="Invitations" \
	--append translationGroupName='"de_CH" "Einladungen"' \
	--append translationGroupName='"de_DE" "Einladungen"' \
	--set shortDescription="Invitation Policy" \
	--append translationShortDescription='"de_CH" "Einladungsrichtlinie"' \
	--append translationShortDescription='"de_DE" "Einladungsrichtlinie"' \
	--set longDescription="Policy for handling invitations. Multiple policies can be combined, most accurate is applied." \
	--append translationLongDescription='"de_CH" "Richtlinie zur Handhabung von Einladungen. Verschiedene Richtlinien können kombiniert werden, die zutreffendste wird angewandt."' \
	--append translationLongDescription='"de_DE" "Richtlinie zur Handhabung von Einladungen. Verschiedene Richtlinien können kombiniert werden, die zutreffendste wird angewandt."' \
	--set ldapMapping=kolabInvitationPolicy \
	--set deleteObjectClass=0 \
	--set valueRequired=0 \
	--set fullWidth=0 \
	--set doNotSearch=0 \
	--set syntax=KolabInvitationPolicies \
	--set mayChange=1 \
	--set multivalue=1 \
	--set notEditable=0 \
	--set disableUDMWeb=0 \
	--position "cn=kolab,cn=custom attributes,cn=univention,${ldap_base}"

# Delegation
udm settings/extended_attribute create "$@" --ignore_exists \
	--set objectClass="kolabInetOrgPerson" \
	--set name="KolabDelegate" \
	--set CLIName="KolabDelegate" \
	--append module="users/user" \
	--append module="users/self" \
	--set groupPosition=2 \
	--set tabName="Kolab Groupware" \
	--append translationTabName='"de_CH" "Kolab Groupware"' \
	--append translationTabName='"de_DE" "Kolab Groupware"' \
	--set tabAdvanced=0 \
	--set overwriteTab=0 \
	--set tabPosition=1 \
	--set groupName="Delegation" \
	--append translationGroupName='"de_CH" "Vertretung"' \
	--append translationGroupName='"de_DE" "Vertretung"' \
	--set shortDescription="Delegates" \
	--append translationShortDescription='"de_CH" "Vertreter"' \
	--set longDescription="Delegates can answer mail and invitations on behalf of a user." \
	--append translationLongDescription='"de_CH" "Vertreter können Mails und Einladungen im Namen des Nutzers beantworten."' \
	--append translationLongDescription='"de_DE" "Vertreter können Mails und Einladungen im Namen des Nutzers beantworten."' \
	--set ldapMapping=kolabDelegate \
	--set deleteObjectClass=0 \
	--set valueRequired=0 \
	--set fullWidth=0 \
	--set doNotSearch=0 \
	--set syntax=UserDN \
	--set mayChange=1 \
	--set multivalue=1 \
	--set notEditable=0 \
	--set disableUDMWeb=0 \
	--position "cn=kolab,cn=custom attributes,cn=univention,${ldap_base}"

# Forwards
addUserAttribute KolabForwardAddress \
	"$@" \
	--set objectClass="kolabInetOrgPerson" \
	--append module="users/user" \
	--append module="users/self" \
	--set groupPosition=1 \
	--set groupName="Forwards" \
	--append translationGroupName='"de_CH" "Weiterleitung"' \
	--append translationGroupName='"de_DE" "Weiterleitung"' \
	--set tabPosition=1 \
	--set shortDescription="Forwarding address" \
	--append translationShortDescription='"de_CH" "E-Mail-Adresse für Mailweiterleitung"' \
	--append translationShortDescription='"de_DE" "E-Mail-Adresse für Mailweiterleitung"' \
	--set syntax=emailAddress \
	--set multivalue=1 \
	--set ldapMapping=kolabForwardAddress

addUserAttribute KolabForwardActive \
	"$@" \
	--set objectClass="univentionKolabInetOrgPerson" \
	--append module="users/user" \
	--append module="users/self" \
	--set groupPosition=1 \
	--set groupName="Forwards" \
	--append translationGroupName='"de_CH" "Weiterleitung"' \
	--append translationGroupName='"de_DE" "Weiterleitung"' \
	--set tabPosition=3 \
	--set shortDescription="Forward mail" \
	--append translationShortDescription='"de_CH" "Mails weiterleiten"' \
	--append translationShortDescription='"de_DE" "Mails weiterleiten"' \
	--set syntax=TrueFalseUp \
	--set multivalue=0 \
	--set ldapMapping=univentionKolabForwardActive

addUserAttribute KolabForwardKeepCopy \
	"$@" \
	--set objectClass="kolabInetOrgPerson" \
	--append module="users/user" \
	--append module="users/self" \
	--set groupPosition=1 \
	--set groupName="Forwards" \
	--append translationGroupName='"de_CH" "Weiterleitung"' \
	--append translationGroupName='"de_DE" "Weiterleitung"' \
	--set tabPosition=5 \
	--set shortDescription="Keep a copy of forwarded mail" \
	--append translationShortDescription='"de_CH" "Kopie erstellen bei Mailweiterleitung"' \
	--append translationShortDescription='"de_DE" "Kopie erstellen bei Mailweiterleitung"' \
	--set syntax=TrueFalseUp \
	--set multivalue=0 \
	--set ldapMapping=kolabForwardKeepCopy

addUserAttribute KolabForwardUCE \
	"$@" \
	--set objectClass="kolabInetOrgPerson" \
	--append module="users/user" \
	--append module="users/self" \
	--set groupPosition=1 \
	--set groupName="Forwards" \
	--append translationGroupName='"de_CH" "Weiterleitung"' \
	--append translationGroupName='"de_DE" "Weiterleitung"' \
	--set tabPosition=6 \
	--set shortDescription="Forward Spam" \
	--append translationShortDescription='"de_CH" "Spam weiterleiten"' \
	--append translationShortDescription='"de_DE" "Spam weiterleiten"' \
	--set syntax=TrueFalseUp \
	--set multivalue=0 \
	--set ldapMapping=kolabForwardUCE

# Vacation
addUserAttribute KolabVacationText \
	"$@" \
	--set objectClass="univentionKolabInetOrgPerson" \
	--append module="users/user" \
	--append module="users/self" \
	--set groupPosition=2 \
	--set groupName="Vacation" \
	--append translationGroupName='"de_CH" "Abwesenheit"' \
	--append translationGroupName='"de_DE" "Abwesenheit"' \
	--set tabPosition=11 \
	--set shortDescription="Text of out of office notice" \
	--append translationShortDescription='"de_CH" "Text der Abwesenheitsnotiz"' \
	--append translationShortDescription='"de_DE" "Text der Abwesenheitsnotiz"' \
	--set syntax=TextArea \
	--set multivalue=0 \
	--set ldapMapping=univentionKolabVacationText

addUserAttribute KolabVacationActive \
	"$@" \
	--set objectClass="univentionKolabInetOrgPerson" \
	--append module="users/user" \
	--append module="users/self" \
	--set groupPosition=2 \
	--set groupName="Vacation" \
	--append translationGroupName='"de_CH" "Abwesenheit"' \
	--append translationGroupName='"de_DE" "Abwesenheit"' \
	--set tabPosition=12 \
	--set shortDescription="Activate out of office notice" \
	--append translationShortDescription='"de_CH" "Abwesenheitsnotiz aktivieren"' \
	--append translationShortDescription='"de_DE" "Abwesenheitsnotiz aktivieren"' \
	--set syntax=TrueFalseUp \
	--set multivalue=0 \
	--set ldapMapping=univentionKolabVacationActive

addUserAttribute KolabVacationAddress \
	"$@" \
	--set objectClass="kolabInetOrgPerson" \
	--append module="users/user" \
	--append module="users/self" \
	--set groupPosition=2 \
	--set groupName="Vacation" \
	--append translationGroupName='"de_CH" "Abwesenheit"' \
	--append translationGroupName='"de_DE" "Abwesenheit"' \
	--set tabPosition=13 \
	--set shortDescription=" E-mail adresses for vacation notice" \
	--append translationShortDescription='"de_CH" "E-Mail-Adressen für Abwesenheitsnotiz"' \
	--append translationShortDescription='"de_DE" "E-Mail-Adressen für Abwesenheitsnotiz"' \
	--set multivalue=0 \
	--set syntax=emailAddress \
	--set ldapMapping=kolabVacationAddress

addUserAttribute KolabVacationNoReactDomain \
	"$@" \
	--set objectClass="univentionKolabInetOrgPerson" \
	--append module="users/user" \
	--append module="users/self" \
	--set groupPosition=2 \
	--set groupName="Vacation" \
	--append translationGroupName='"de_CH" "Abwesenheit"' \
	--append translationGroupName='"de_DE" "Abwesenheit"' \
	--set tabPosition=14 \
	--set syntax=string \
	--set multivalue=1 \
	--set shortDescription="Exclude mail domains from out of office notices" \
	--append translationShortDescription='"de_CH" "Domains von Abwesenheitsnotiz ausnehmen"' \
	--append translationShortDescription='"de_DE" "Domains von Abwesenheitsnotiz ausnehmen"' \
	--set ldapMapping=univentionKolabVacationNoReactDomain

# SMTP Access Policy
addUserAttribute KolabAllowSMTPSender \
	"$@" \
	--set objectClass="kolabInetOrgPerson" \
	--append module="users/user" \
	--append module="users/self" \
	--set groupPosition=21 \
	--set groupName="SMTP Access Policy" \
	--append translationGroupName='"de_CH" "SMTP-Zugriffsrichtlinien"' \
	--append translationGroupName='"de_DE" "SMTP-Zugriffsrichtlinien"' \
	--set tabPosition=1 \
	--set shortDescription="Sender Access List" \
	--append translationShortDescription='"de_CH" "Liste von Absendern"' \
	--append translationShortDescription='"de_DE" "Liste von Absendern"' \
	--set longDescription="Wildcards or regular expressions allowed. To reject an address or domain, prefix the entry with -, e.g. -john.doe@example.org. Most accurate policy is applied."\
	--append translationLongDescription='"de_CH" "Platzhalter oder reguäre Ausdücke erlaubt. Um eine Adresse oder Domäne zu abzuweisen, den Eintrag mit - beginnen, z. B. -max.mustermann@example.org. Die zutreffendste Richtinige wird angewandt."'\
	--append translationLongDescription='"de_DE" "Platzhalter oder reguäre Ausdücke erlaubt. Um eine Adresse oder Domäne zu abzuweisen, den Eintrag mit - beginnen, z. B. -max.mustermann@example.org. Die zutreffendste Richtinige wird angewandt."'\
	--set syntax=string \
	--set multivalue=1 \
	--set ldapMapping=kolabAllowSMTPSender

addUserAttribute KolabAllowSMTPRecipient \
	"$@" \
	--set objectClass="kolabInetOrgPerson" \
	--append module="users/user" \
	--append module="users/self" \
	--set groupPosition=22 \
	--set groupName="SMTP Access Policy" \
	--append translationGroupName='"de_CH" "SMTP-Zugriffsrichtlinien"' \
	--append translationGroupName='"de_DE" "SMTP-Zugriffsrichtlinien"' \
	--set tabPosition=1 \
	--set shortDescription="Recipient(s) Access List" \
	--append translationShortDescription='"de_CH" "Liste von Adressaten"' \
	--append translationShortDescription='"de_DE" "Liste von Adressaten"' \
	--set longDescription="Wildcards or regular expressions allowed. To reject an address or domain, prefix the entry with -, e.g. -john.doe@example.org. Most accurate policy is applied."\
	--append translationLongDescription='"de_CH" "Platzhalter oder reguäre Ausdücke erlaubt. Um eine Adresse oder Domäne zu abzuweisen, den Eintrag mit - beginnen, z. B. -max.mustermann@example.org. Die zutreffendste Richtinige wird angewandt."'\
	--append translationLongDescription='"de_DE" "Platzhalter oder reguäre Ausdücke erlaubt. Um eine Adresse oder Domäne zu abzuweisen, den Eintrag mit - beginnen, z. B. -max.mustermann@example.org. Die zutreffendste Richtinige wird angewandt."'\
	--set syntax=string \
	--set multivalue=1 \
	--set ldapMapping=kolabAllowSMTPRecipient

# Delivery
addUserAttribute KolabDeliveryToFolderName \
	"$@" \
	--set objectClass="univentionKolabInetOrgPerson" \
	--append module="users/user" \
	--append module="users/self" \
	--set groupPosition=4 \
	--set groupName="Delivery" \
	--append translationGroupName='"de_CH" "Zustellung"' \
	--append translationGroupName='"de_DE" "Zustellung"' \
	--set tabPosition=31 \
	--set syntax=string \
	--set multivalue=0 \
	--set shortDescription="Folder for incoming mail" \
	--append translationShortDescription='"de_CH" "Ordner für eingehende Mails"' \
	--append translationShortDescription='"de_DE" "Ordner für eingehende Mails"' \
	--set ldapMapping=univentionKolabDeliveryToFolderName

addUserAttribute KolabDeliveryToFolderActive \
	"$@" \
	--set objectClass="univentionKolabInetOrgPerson" \
	--append module="users/user" \
	--append module="users/self" \
	--set groupPosition=4 \
	--set groupName="Delivery" \
	--append translationGroupName='"de_CH" "Zustellung"' \
	--append translationGroupName='"de_DE" "Zustellung"' \
	--set tabPosition=32 \
	--set syntax=TrueFalseUp \
	--set multivalue=0 \
	--set shortDescription="Move incoming mails into chosen folder" \
	--append translationShortDescription='"de_CH" "Eingehende Mails in einen ausgewählten Ordner verschieben"' \
	--append translationShortDescription='"de_DE" "Eingehende Mails in einen ausgewählten Ordner verschieben"' \
	--set ldapMapping=univentionKolabDeliveryToFolderActive

# Allow Domain Users to modify self
udm groups/group modify \
    --dn "cn=Domain Users,cn=groups,$ldap_base" \
    --policy-reference "cn=default-udm-self,cn=UMC,cn=policies,$ldap_base"

stop_udm_cli_server

joinscript_save_current_version

exit 0
