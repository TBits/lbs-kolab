#!/bin/sh
#
# Kolab Systems UCS Groupware Server
#  unjoin script
#
# Copyright 2015 Kolab Systems AG
#
# http://www.kolabsystems.com/
#
# All rights reserved.
#
# The source code of this program is made available
# under the terms of the GNU Affero General Public License version 3
# (GNU AGPL V3) as published by the Free Software Foundation.
#
# Binary versions of this program provided by Univention to you as
# well as other copyrighted, protected or trademarked materials like
# Logos, graphics, fonts, specific documentations and configurations,
# cryptographic keys etc. are subject to a license agreement between
# you and Univention and not subject to the GNU AGPL V3.
#
# In the case you use this program under the terms of the GNU AGPL V3,
# the program is provided in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU Affero General Public License for more details.
#
# You should have received a copy of the GNU Affero General Public
# License with the Debian GNU/Linux or Univention distribution in file
# /usr/share/common-licenses/AGPL-3; if not, see
# <http://www.gnu.org/licenses/>.

VERSION=3

. /usr/share/univention-join/joinscripthelper.lib
. /usr/share/univention-lib/all.sh
joinscript_init

SERVICE="kolab"

eval "$(ucr shell)"

# remove extented attributes
for ATTRIBUTE in \
	KolabEnabled \
	KolabFolderType \
	KolabInvitationPolicy \
	KolabDelegate \
	KolabForwardAddress \
	KolabForwardActive \
	KolabForwardKeepCopy \
	KolabForwardUCE \
	KolabVacationText \
	KolabVacationActive \
	KolabVacationAddress \
	KolabVacationNoReactDomain \
	KolabAllowSMTPSender \
	KolabAllowSMTPRecipient \
	KolabDeliveryToFolderName \
	KolabDeliveryToFolderActive ; \
do udm settings/extended_attribute remove \
	--dn "cn=$ATTRIBUTE,cn=kolab,cn=custom attributes,cn=univention,$ldap_base" ; done

# Remove our container
udm container/cn delete --dn "cn=kolab2,cn=custom attributes,cn=univention,$ldap_base"

# Remove user template
udm settings/usertemplate remove \
	--dn "cn=$domainname Groupware Account,cn=templates,cn=univention,${ldap_base}"

# remove service from my host object
ucs_removeServiceFromLocalhost "kolab" "$@" || die

# do NOT call "joinscript_save_current_version"
# otherwise an entry will be appended to /var/univenion-join/status
# instead the join script needs to be removed from the status file
joinscript_remove_script_from_status_file kolab-ucs

exit 0
