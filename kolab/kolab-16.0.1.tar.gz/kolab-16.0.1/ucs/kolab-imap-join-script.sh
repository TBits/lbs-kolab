#!/bin/sh
#
# Kolab Systems Cyrus Mail Server
#  join script
#
# Copyright 2012-2015 Kolab Systems AG
#
# http://www.kolabsystems.com/
#
# All rights reserved.
#
# The source code of this program is made available
# under the terms of the GNU Affero General Public License version 3
# (GNU AGPL V3) as published by the Free Software Foundation.
#
# Binary versions of this program provided by Univention to you as
# well as other copyrighted, protected or trademarked materials like
# Logos, graphics, fonts, specific documentations and configurations,
# cryptographic keys etc. are subject to a license agreement between
# you and Univention and not subject to the GNU AGPL V3.
#
# In the case you use this program under the terms of the GNU AGPL V3,
# the program is provided in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU Affero General Public License for more details.
#
# You should have received a copy of the GNU Affero General Public
# License with the Debian GNU/Linux or Univention distribution in file
# /usr/share/common-licenses/AGPL-3; if not, see
# <http://www.gnu.org/licenses/>.

VERSION=3

. /usr/share/univention-join/joinscripthelper.lib
. /usr/share/univention-lib/all.sh
joinscript_init

eval "$(univention-config-registry shell)"

# Unset univention-config-registry settings we no longer use.
univention-config-registry unset \
    mail/cyrus/imap/lookup_groups \
    mail/cyrus/ldap/pwfile \
    mail/cyrus/imap/quotainterval \
    mail/cyrus/version \
    mail/saslauthd/threads

# Add our settings
univention-config-registry set \
    mail/cyrus?yes \
    mail/cyrus/autostart?yes \
    mail/cyrus/imap?yes \
    mail/cyrus/pop?yes \
    mail/cyrus/sieve/listen_host?all \
    mail/cyrus/idlemethod?idled \
    mail/cyrus/mailbox/rename?yes \
    mail/cyrus/mailbox/delete?no \
    mail/antispam/globalfolder?"spam@$domainname" \
    mail/cyrus/backup-metadata/cron?"15 3 * * *" \
    mail/cyrus/squatter/time?"at=0530"

# Copy SSL certificates to a place Cyrus IMAP can read them from
cp /etc/univention/ssl/$hostname.$domainname/cert.pem /var/lib/imap/
cp /etc/univention/ssl/$hostname.$domainname/private.key /var/lib/imap/
chmod 600 /var/lib/imap/cert.pem /var/lib/imap/private.key
chown cyrus /var/lib/imap/cert.pem /var/lib/imap/private.key

# Add the IMAP service to our host object
ucs_addServiceToLocalhost "IMAP" "$@"

ucr commit /etc/cyrus.conf
ucr commit /etc/imapd.conf

if [ "${server_role}" = "domaincontroller_master" ]; then
    echo -n "Creating Cyrus Administrator user ... "
    univention-directory-manager users/user create \
        --set password=$(cat /etc/cyrus.secret) \
        --set "username=cyrus-admin" \
        --set "firstname=Cyrus" \
        --set "lastname=Administrator" \
        --set "objectFlag=functional" \
        --position "cn=users,${ldap_base}" \
        >/dev/null 2>&1 && echo "OK" || echo "FAIL"
fi

# restart cyrus
if [ -x /etc/init.d/cyrus-imapd ]; then
	invoke-rc.d cyrus-imapd restart
fi

joinscript_save_current_version

exit 0
