#!/bin/bash
#
# Kolab Webclient unjoin script
#
# Copyright (C) 2015 Kolab Systems AG <contact@kolabsystems.com>
#
# http://kolabsystems.com/
#
# All rights reserved.
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License version 3 as
# published by the Free Software Foundation
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along
# with this program; if not, write to the Free Software Foundation, Inc.,
# 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA

VERSION=1

. /usr/share/univention-lib/all.sh
. /usr/share/univention-join/joinscripthelper.lib

joinscript_init

eval "$(univention-config-registry shell)"

apache_reload=0

# De-register the webclient on UCS landing page
ucr unset \
    ucs/web/overview/entries/service/kolab-webclient/icon \
    ucs/web/overview/entries/service/kolab-webclient/link \
    ucs/web/overview/entries/service/kolab-webclient/label \
    ucs/web/overview/entries/service/kolab-webclient/label/de \
    ucs/web/overview/entries/service/kolab-webclient/description \
    ucs/web/overview/entries/service/kolab-webclient/description/de

# remove service from my host object
ucs_removeServiceFromLocalhost "Kolab-Webclient" "$@"

joinscript_remove_script_from_status_file kolab-webclient

exit 0

