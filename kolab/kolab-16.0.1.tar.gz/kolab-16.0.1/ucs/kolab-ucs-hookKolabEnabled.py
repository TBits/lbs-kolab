#!/usr/bin/python2.7
#
# Copyright (C) 2015 Kolab Systems AG
#
# http://kolabsystems.com/
#
# All rights reserved.
#
# source code of this program is made available
# under the terms of the GNU Affero General Public License version 3
# (GNU AGPL V3) as published by the Free Software Foundation.
#
# Binary versions of this program provided by Univention to you as
# well as other copyrighted, protected or trademarked materials like
# Logos, graphics, fonts, specific documentations and configurations,
# cryptographic keys etc. are subject to a license agreement between
# you and Univention and not subject to the GNU AGPL V3.
#
# In the case you use this program under the terms of the GNU AGPL V3,
# the program is provided in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU Affero General Public License for more details.
#
# You should have received a copy of the GNU Affero General Public
# License with the Debian GNU/Linux or Univention distribution in file
# /usr/share/common-licenses/AGPL-3. If not, see <http://www.gnu.org/licenses/>.

from univention.admin.hook import simpleHook
import univention.debug as ud

VALUE_ENABLED = '1'
NAME_OBJECTCLASS = 'kolabInetOrgPerson'
NAME_ATTRIBUTE = 'kolabDummyAttribute'
NAME_PROPERTY = 'KolabEnabled'
REMOVE_ATTRIBUTES = [
	'KolabForwardAddress',
	'KolabForwardActive',
	'KolabForwardKeepCopy',
	'KolabForwardUCE',
	'KolabVacationText',
	'KolabVacationActive',
	'KolabVacationAddress',
	'KolabVacationNoReactDomain',
	'KolabDeliveryToFolderName',
	'KolabDeliveryToFolderActive',
]

import pprint

class hookKolabEnabled(simpleHook):

	def hook_open(self, module):
		ud.debug(ud.ADMIN, ud.ALL, 'admin.hook.hookKolabEnabled: _open called')

		if NAME_OBJECTCLASS in module.oldattr.get('objectClass', []):
			module[NAME_PROPERTY] = VALUE_ENABLED
		ud.debug(ud.ADMIN, ud.ALL, 'admin.hook.hookKolabEnabled: _open (value=%r)' % module[NAME_PROPERTY])

	def hook_ldap_addlist(self, module, al=[]):
		ud.debug(ud.ADMIN, ud.ALL, 'admin.hook.hookKolabEnabled.addlist (value=%r)' % module[NAME_PROPERTY])
		if module[NAME_PROPERTY] == VALUE_ENABLED:
			al.append(('objectClass', '', NAME_OBJECTCLASS))
		for item in al[:]:
			if item[0] == NAME_ATTRIBUTE:
				al.remove(item)
		ud.debug(ud.ADMIN, ud.ALL, 'admin.hook.hookKolabEnabled.addlist\n al = %s' % pprint.PrettyPrinter(indent=4).pformat(al))
		return al

	def hook_ldap_modlist(self, module, ml=[]):
		"""Add or remove objectClass when UDM checkbox is enabled or disabled."""
		ud.debug(ud.ADMIN, ud.ALL, 'admin.hook.hookKolabEnabled.modlist (value=%r)' % module[NAME_PROPERTY])

		# compute new accumulated objectClass
		old_ocs = module.oldattr.get('objectClass', [])
		ocs = set(old_ocs)

		is_enabled = module[NAME_PROPERTY] == VALUE_ENABLED

		for modification in ml[:]:
			attr, remove_val, add_val = modification

			if attr == 'objectClass':
				if not isinstance(remove_val, list):
					remove_val = set([remove_val])
				ocs -= set(remove_val)

				if not isinstance(add_val, list):
					add_val = set([add_val])
					add_val.discard('')
				ocs |= set(add_val)

				ml.remove(modification)

			elif not is_enabled and attr in REMOVE_ATTRIBUTES:
				ml.remove(modification)
			elif attr == NAME_ATTRIBUTE:
				ml.remove(modification)

		if is_enabled:
			ocs.add(NAME_OBJECTCLASS)
		else:
			ocs.discard(NAME_OBJECTCLASS)
			for attr in REMOVE_ATTRIBUTES:
				ml.append((attr, module.oldattr.get(attr, ''), ''))

		ml.append(('objectClass', old_ocs, list(ocs)))

		ud.debug(ud.ADMIN, ud.ALL, 'admin.hook.hookKolabEnabled.modlist\n ml = %s' % pprint.PrettyPrinter(indent=4).pformat(ml))
		return ml
