#!/bin/bash

VERSION=2

. /usr/share/univention-join/joinscripthelper.lib
. /usr/share/univention-lib/all.sh
joinscript_init

function addUserAttribute {
	name="$1"
	shift
	udm settings/extended_attribute create \
		--ignore_exists \
		--position "cn=custom attributes,cn=univention,$ldap_base" \
		--set tabName="Mail" \
		--append translationTabName='"de_CH" "Mail"' \
		--append translationTabName='"de_DE" "Mail"' \
		--set name="$name" \
		--set CLIName="$name" \
		--set mayChange=1 \
		"$@"
}

eval "$(univention-config-registry shell)"

if [ "${server_role}" == "domaincontroller_master" -o \
        "${server_role}" == "domaincontroller_backup" -o \
        "${server_role}" == "domaincontroller_slave" -o \
        "${server_role}" == "memberserver" ]; then

    # Delete old service references
    echo -n "Removing legacy kolab2 service reference from LDAP ... "
	univention-admin settings/service remove \
        --dn cn=kolab2,cn=services,cn=univention,${ldap_base} \
        >/dev/null 2>&1 && echo "OK" || echo "FAIL"

    echo -n "Creating kolab service in LDAP ... "
	univention-admin container/cn create \
        --ignore_exists $@ \
        --position cn=univention,${ldap_base} \
        --set name=services >/dev/null 2>&1

	univention-admin settings/service create \
        --ignore_exists $@ \
        --position cn=services,cn=univention,${ldap_base} \
        --set name=kolab \
        >/dev/null 2>&1 && echo "OK" || echo "FAIL"

    echo -n "Appending service kolab ..."
	univention-admin computers/${server_role} modify \
        $@ --dn ${ldap_hostdn} \
        --remove service="kolab2" \
        >/dev/null 2>&1

	univention-admin computers/${server_role} modify \
        $@ --dn ${ldap_hostdn} \
        --append service="kolab" \
        >/dev/null 2>&1 && echo "OK" || echo "FAIL"

	# if there is no default kolab home server ...
	kolab_home=`univention-admin settings/default list \
        $@ --filter='cn=default' 2>/dev/null \
        | grep -i defaultUniventionMailHomeServer \
        | sed -r 's/\s*defaultUniventionMailHomeServer: //'`

	if [ "${kolab_home}" = "None" -o -z "${kolab_home}" ]; then
        echo -n "Setting default groupware server ... "
		univention-admin settings/default modify \
            $@ --dn cn=default,cn=univention,${ldap_base} \
            --set defaultUniventionMailHomeServer="${hostname}.${domainname}" \
            >/dev/null 2>&1 && echo "OK" || echo "FAIL"
	fi

    echo -n "Creating Groupware Account template ... "
	univention-admin settings/usertemplate create \
        $@ --ignore_exists \
        --position cn=templates,cn=univention,${ldap_base} \
        --set name="${domainname} Groupware Account" \
        --set univentionMailHomeServer="${hostname}.${domainname}" \
        --set mailPrimaryAddress="<username>@${domainname}" \
        --set e-mail="<username>@${domainname}" \
        --set unixhome="/home/<username>" \
        >/dev/null 2>&1 && echo "OK" || echo "FAIL"
fi

echo -n "Creating mail domain ${domainname} ... "
univention-admin mail/domain create \
    $@ --ignore_exists \
    --set name=${domainname} \
    --position cn=domain,cn=mail,${ldap_base} \
    >/dev/null 2>&1 && echo "OK" || echo "FAIL"

# The rest of this script only needs to be executed if we're on a system that has the UDM
# installed.

if [ -z "$(which udm 2>/dev/null)" ]; then
    joinscript_save_current_version
    exit 0
fi

### Admin Settings
# Forwards
addUserAttribute KolabForwardAddress \
	--set objectClass="kolabInetOrgPerson" \
	--append module="users/user" \
	--append module="users/self" \
	--set groupPosition=1 \
	--set groupName="Forwards" \
	--append translationGroupName='"de_CH" "Weiterleitung"' \
	--append translationGroupName='"de_DE" "Weiterleitung"' \
	--set tabPosition=1 \
	--set shortDescription="Forwarding address" \
	--append translationShortDescription='"de_CH" "E-Mail-Adresse für Mailweiterleitung"' \
	--append translationShortDescription='"de_DE" "E-Mail-Adresse für Mailweiterleitung"' \
	--set syntax=emailAddress \
	--set multivalue=1 \
	--set ldapMapping=kolabForwardAddress

addUserAttribute KolabForwardActive \
	--set objectClass="univentionKolabInetOrgPerson" \
	--append module="users/user" \
	--append module="users/self" \
	--set groupPosition=1 \
	--set groupName="Forwards" \
	--append translationGroupName='"de_CH" "Weiterleitung"' \
	--append translationGroupName='"de_DE" "Weiterleitung"' \
	--set tabPosition=3 \
	--set shortDescription="Forward mail" \
	--append translationShortDescription='"de_CH" "Mails weiterleiten"' \
	--append translationShortDescription='"de_DE" "Mails weiterleiten"' \
	--set syntax=TrueFalseUp \
	--set multivalue=0 \
	--set ldapMapping=univentionKolabForwardActive

addUserAttribute KolabForwardKeepCopy \
	--set objectClass="kolabInetOrgPerson" \
	--append module="users/user" \
	--append module="users/self" \
	--set groupPosition=1 \
	--set groupName="Forwards" \
	--append translationGroupName='"de_CH" "Weiterleitung"' \
	--append translationGroupName='"de_DE" "Weiterleitung"' \
	--set tabPosition=5 \
	--set shortDescription="Keep a copy of forwarded mail" \
	--append translationShortDescription='"de_CH" "Kopie erstellen bei Mailweiterleitung"' \
	--append translationShortDescription='"de_DE" "Kopie erstellen bei Mailweiterleitung"' \
	--set syntax=TrueFalseUp \
	--set multivalue=0 \
	--set ldapMapping=kolabForwardKeepCopy

addUserAttribute KolabForwardUCE \
	--set objectClass="kolabInetOrgPerson" \
	--append module="users/user" \
	--append module="users/self" \
	--set groupPosition=1 \
	--set groupName="Forwards" \
	--append translationGroupName='"de_CH" "Weiterleitung"' \
	--append translationGroupName='"de_DE" "Weiterleitung"' \
	--set tabPosition=6 \
	--set shortDescription="Forward Spam" \
	--append translationShortDescription='"de_CH" "Spam weiterleiten"' \
	--append translationShortDescription='"de_DE" "Spam weiterleiten"' \
	--set syntax=TrueFalseUp \
	--set multivalue=0 \
	--set ldapMapping=kolabForwardUCE

# Vacation
addUserAttribute KolabVacationText \
	--set objectClass="univentionKolabInetOrgPerson" \
	--append module="users/user" \
	--append module="users/self" \
	--set groupPosition=2 \
	--set groupName="Vacation" \
	--append translationGroupName='"de_CH" "Abwesenheit"' \
	--append translationGroupName='"de_DE" "Abwesenheit"' \
	--set tabPosition=11 \
	--set shortDescription="Text of out of office notice" \
	--append translationShortDescription='"de_CH" "Text der Abwesenheitsnotiz"' \
	--append translationShortDescription='"de_DE" "Text der Abwesenheitsnotiz"' \
	--set syntax=TextArea \
	--set multivalue=0 \
	--set ldapMapping=univentionKolabVacationText

addUserAttribute KolabVacationActive \
	--set objectClass="univentionKolabInetOrgPerson" \
	--append module="users/user" \
	--append module="users/self" \
	--set groupPosition=2 \
	--set groupName="Vacation" \
	--append translationGroupName='"de_CH" "Abwesenheit"' \
	--append translationGroupName='"de_DE" "Abwesenheit"' \
	--set tabPosition=12 \
	--set shortDescription="Activate out of office notice" \
	--append translationShortDescription='"de_CH" "Abwesenheitsnotiz aktivieren"' \
	--append translationShortDescription='"de_DE" "Abwesenheitsnotiz aktivieren"' \
	--set syntax=TrueFalseUp \
	--set multivalue=0 \
	--set ldapMapping=univentionKolabVacationActive

addUserAttribute KolabVacationAddress \
	--set objectClass="kolabInetOrgPerson" \
	--append module="users/user" \
	--append module="users/self" \
	--set groupPosition=2 \
	--set groupName="Vacation" \
	--append translationGroupName='"de_CH" "Abwesenheit"' \
	--append translationGroupName='"de_DE" "Abwesenheit"' \
	--set tabPosition=13 \
	--set shortDescription=" E-mail adresses for vacation notice" \
	--append translationShortDescription='"de_CH" "E-Mail-Adressen für Abwesenheitsnotiz"' \
	--append translationShortDescription='"de_DE" "E-Mail-Adressen für Abwesenheitsnotiz"' \
	--set multivalue=0 \
	--set syntax=emailAddress \
	--set ldapMapping=kolabVacationAddress

addUserAttribute KolabVacationNoReactDomain \
	--set objectClass="univentionKolabInetOrgPerson" \
	--append module="users/user" \
	--append module="users/self" \
	--set groupPosition=2 \
	--set groupName="Vacation" \
	--append translationGroupName='"de_CH" "Abwesenheit"' \
	--append translationGroupName='"de_DE" "Abwesenheit"' \
	--set tabPosition=14 \
	--set syntax=string \
	--set multivalue=1 \
	--set shortDescription="Exclude mail domains from out of office notices" \
	--append translationShortDescription='"de_CH" "Domains von Abwesenheitsnotiz ausnehmen"' \
	--append translationShortDescription='"de_DE" "Domains von Abwesenheitsnotiz ausnehmen"' \
	--set ldapMapping=univentionKolabVacationNoReactDomain

# Delivery
addUserAttribute KolabDeliveryToFolderName \
	--set objectClass="univentionKolabInetOrgPerson" \
	--append module="users/user" \
	--append module="users/self" \
	--set groupPosition=3 \
	--set groupName="Delivery" \
	--append translationGroupName='"de_CH" "Zustellung"' \
	--append translationGroupName='"de_DE" "Zustellung"' \
	--set tabPosition=21 \
	--set syntax=string \
	--set multivalue=0 \
	--set shortDescription="Folder for incoming mail" \
	--append translationShortDescription='"de_CH" "Ordner für eingehende Mails"' \
	--append translationShortDescription='"de_DE" "Ordner für eingehende Mails"' \
	--set ldapMapping=univentionKolabDeliveryToFolderName

addUserAttribute KolabDeliveryToFolderActive \
	--set objectClass="univentionKolabInetOrgPerson" \
	--append module="users/user" \
	--append module="users/self" \
	--set groupPosition=3 \
	--set groupName="Delivery" \
	--append translationGroupName='"de_CH" "Zustellung"' \
	--append translationGroupName='"de_DE" "Zustellung"' \
	--set tabPosition=22 \
	--set syntax=TrueFalseUp \
	--set multivalue=0 \
	--set shortDescription="Move incoming mails into chosen folder" \
	--append translationShortDescription='"de_CH" "Eingehende Mails in einen ausgewählten Ordner verschieben"' \
	--append translationShortDescription='"de_DE" "Eingehende Mails in einen ausgewählten Ordner verschieben"' \
	--set ldapMapping=univentionKolabDeliveryToFolderActive

# Allow Domain Users to modify self
udm groups/group modify \
    --dn "cn=Domain Users,cn=groups,$ldap_base" \
    --policy-reference "cn=default-udm-self,cn=UMC,cn=policies,$ldap_base"

# Redirect output for sometimes other dependencies have not been installed successfully
test -x /etc/init.d/slapd && invoke-rc.d slapd restart >/dev/null 2>&1

joinscript_save_current_version

exit 0
