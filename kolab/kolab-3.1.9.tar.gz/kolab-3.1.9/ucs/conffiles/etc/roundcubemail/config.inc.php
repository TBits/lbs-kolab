<?php

/*
@%@UCRWARNING= @%@
*/

    $config = array();

@!@
import os
if os.path.exists('/etc/roundcube.secret'):
	print "    $config['db_dsnw'] = 'mysql://roundcube:%s@localhost/roundcubemail';" % (open('/etc/roundcube.secret','r').read().strip());
else:
	print "    $config['db_dsnw'] = 'ROUNDCUBE.SECRET_IS_MISSING'";
@!@

    $config['session_domain'] = '';
    $config['username_domain'] = '@%@domainname@%@';
    $config['mail_domain'] = '@%@domainname@%@';

    $config['force_https'] = @%@mail/kolab/https@%@;

    $config['use_secure_urls'] = true;
    $config['assets_path'] = '/roundcubemail/assets/';

@!@
import os
if os.path.exists('/etc/roundcube.des_key'):
    print "    $config['des_key'] = '%s';" % (open('/etc/roundcube.des_key','r').read().strip());
else:
    print "    $config['des_key'] = 'rcmail-!24ByteDESkey*Str';";
@!@

    // IMAP Server Settings
    $config['default_host'] = '@%@mail/roundcube/imap/server@%@';
    $config['default_port'] = @%@mail/roundcube/imap/port@%@;
    $config['imap_auth_type'] = '@%@mail/roundcube/imap/auth@%@';
    $config['imap_delimiter'] = '/';
    $config['imap_force_lsub'] = true;

    // Caching and storage settings
    $config['imap_cache'] = 'db';
    $config['imap_cache_ttl'] = '10d';
    $config['messages_cache'] = 'db';
    $config['messages_cache_ttl'] = '10d';
    $config['session_storage'] = 'db';

    // SMTP Server Settings
    $config['smtp_server'] = '@%@mail/roundcube/smtp/server@%@';
    $config['smtp_port'] = @%@mail/roundcube/smtp/port@%@;
    $config['smtp_user'] = '%u';
    $config['smtp_pass'] = '%p';
    $config['smtp_auth_type'] = '@%@mail/roundcube/smtp/auth@%@';
    $config['smtp_helo_host'] = $_SERVER["HTTP_HOST"];

    // LDAP Settings
    $config['ldap_cache'] = 'db';
    $config['ldap_cache_ttl'] = '1h';

    // Kolab specific defaults
    $config['product_name'] = 'Kolab Groupware';
    $config['skin_logo'] = 'skins/kolab/images/kolab_logo_white.png';
    $config['quota_zero_as_unlimited'] = false;
    $config['login_lc'] = 2;
    $config['auto_create_user'] = true;
    $config['enable_installer'] = false;
    // The SMTP server does not allow empty identities
    $config['mdn_use_from'] = true;

    // Plugins
    $config['plugins'] = array(
            'acl',
            'archive',
            'calendar',
            'jqueryui',
            'kolab_addressbook',
            'kolab_auth',
            'kolab_files',
            'kolab_folders',
            'logon_page',
            'managesieve',
            'markasjunk',
            'newmail_notifier',
            'odfviewer',
            'password',
            'redundant_attachments',
            'tasklist',
            'threading_as_default',
            // contextmenu must be after kolab_addressbook (#444)
            'contextmenu',
        );


    // Do not show deleted messages, mark deleted messages as read,
    // and flag them as deleted instead of moving them to the Trash
    // folder.
    $config['skip_deleted'] = true;
    $config['read_when_deleted'] = true;
    $config['flag_for_deletion'] = true;
    $config['delete_always'] = true;

    $config['session_lifetime'] = 180;
    $config['password_charset'] = 'UTF-8';
    $config['useragent'] = 'Kolab 3.1/Roundcube ' . RCUBE_VERSION;
    $config['dont_override'] = Array('skin');

    $config['message_sort_col'] = 'date';

    $config['spellcheck_engine'] = 'pspell';
    $config['spellcheck_dictionary'] = true;
    $config['spellcheck_ignore_caps'] = true;
    $config['spellcheck_ignore_nums'] = true;
    $config['spellcheck_ignore_syms'] = true;

    $config['undo_timeout'] = 10;
    $config['upload_progress'] = 2;
    $config['address_template'] = '{street}<br/>{locality} {zipcode}<br/>{country} {region}';
    $config['preview_pane'] = true;
    $config['preview_pane_mark_read'] = 0;

    $config['autoexpand_threads'] = 2;

    // Bottom posting for reply mode
    $config['reply_mode'] = 0;
    $config['sig_above'] = false;
    $config['mdn_requests'] = 0;
    $config['mdn_default'] = false;
    $config['dsn_default'] = false;
    $config['reply_same_folder'] = false;

    if (file_exists(RCUBE_CONFIG_DIR . '/' . $_SERVER["HTTP_HOST"] . '/' . basename(__FILE__))) {
        include_once(RCUBE_CONFIG_DIR . '/' . $_SERVER["HTTP_HOST"] . '/' . basename(__FILE__));
    }

    // Re-apply mandatory settings here.

    $config['log_driver'] = 'file';
    $config['log_date_format'] = 'd-M-Y H:i:s,u O';
    $config['syslog_id'] = 'roundcube';
    $config['syslog_facility'] = LOG_USER;
    $config['smtp_log'] = true;
    $config['log_logins'] = true;
    $config['log_session'] = true;
@!@
if not baseConfig.get('mail/kolab/debug', '0') == '0':
    print "    $config['debug_level'] = 1;"
    print "    $config['devel_mode'] = true;"
    print "    $config['sql_debug'] = true;"
    print "    $config['memcache_debug'] = true;"
    print "    $config['imap_debug'] = true;"
    print "    $config['ldap_debug'] = true;"
    print "    $config['smtp_debug'] = true;"
    print "    $config['activesync_debug'] = true;"
    print "    $config['activesync_user_log'] = true;"
else:
    print "    $config['debug_level'] = 0;"
    print "    $config['devel_mode'] = false;"
    print "    $config['sql_debug'] = false;"
    print "    $config['memcache_debug'] = false;"
    print "    $config['imap_debug'] = false;"
    print "    $config['ldap_debug'] = false;"
    print "    $config['smtp_debug'] = false;"
    print "    $config['activesync_debug'] = false;"
    print "    $config['activesync_user_log'] = false;"
@!@
    $config['skin'] = 'larry';
    $config['skin_include_php'] = false;
    $config['mime_magic'] = null;
    $config['im_identify_path'] = '/usr/bin/identify';
    $config['im_convert_path'] = '/usr/bin/convert';
    $config['log_dir'] = 'logs/';
    $config['temp_dir'] = '/var/lib/roundcubemail/';

    $config['archive_mbox'] = 'Archive';
    $config['junk_mbox'] = 'Spam';
    $config['default_folders'] = array('INBOX', 'Drafts', 'Sent', 'Spam', 'Trash', 'Archive');

    $config['address_book_type'] = 'ldap';
    $config['autocomplete_min_length'] = 3;
    $config['autocomplete_threads'] = 0;
    $config['autocomplete_max'] = 15;
    $config['ldap_public'] = array(
            'global' => Array(
                    'name'                      => 'Global Address Book',
                    'hosts'                     => array('@%@ldap/server/name@%@'),
                    'port'                      => @%@ldap/server/port@%@,
                    'use_tls'                   => false,
                    'user_specific'             => true,
                    'base_dn'                   => '@%@ldap/base@%@',
                    'bind_dn'                   => '%dn',
                    'bind_pass'                 => '',
                    'search_base_dn'            => '@%@ldap/base@%@',
                    'search_bind_dn'            => '@%@ldap/hostdn@%@',
@!@
import os
if os.path.exists('/etc/machine.secret'):
    print "                    'search_bind_pw'            => '%s'," % (open('/etc/machine.secret','r').read().strip())
else:
    print "                    'search_bind_pw'            => 'MACHINE.SECRET_IS_MISSING',"
@!@
                    'search_filter'             => '(&(objectClass=kolabInetOrgPerson)(|(uid=%u)(mail=%fu)(mailPrimaryAddress=%fu)))',
                    'writable'                  => false,
                    'LDAP_Object_Classes'       => array("top", "inetOrgPerson"),
                    'required_fields'           => array("cn", "sn", "mailPrimaryAddress"),
                    'LDAP_rdn'                  => 'uid',
                    'ldap_version'              => 3,           // using LDAPv3
                    'search_fields'             => array('mailPrimaryAddress', 'cn'),
                    'sort'                      => array('sn', 'initials', 'displayname', 'givenname', 'uid'),
                    'scope'                     => 'sub',       // search mode: sub|base|list
                    'filter'                    => '(objectClass=kolabInetOrgPerson)',
                    'fuzzy_search'              => true,
                    'sizelimit'                 => '0',
                    'timelimit'                 => '0',
                    'fieldmap'                  => Array(
                            // Roundcube        => LDAP
                            'name'              => 'cn',
                            'firstname'         => 'givenName',
                            'surname'           => 'sn',
                            'email:work'        => 'mailPrimaryAddress',
                            'email:other'       => 'mailAlternativeAddress',
                            'nickname'          => 'displayName',
                            'jobtitle'          => 'title',
                            'organization'      => 'o',
                            'phone:home'        => 'homePhone',
                            'phone:home2'       => 'mobile',
                            'phone:home2'       => 'mobile',
                            'phone:work'        => 'telephoneNumber',
                            'phone:mobile'      => 'mobile',
                            //'phone:main'        => 'telephoneNumber',
                            'phone:pager'       => 'pager',
                            'street:work'       => 'street',
                            'locality:work'     => 'l',
                            'zipcode:work'      => 'postalCode',
                            'country:work'      => 'c',
                            'birthday'          => 'univentionBirthday',
                        ),
                    'groups'                    => Array(
                            'base_dn'           => '@%@ldap/base@%@',
                            'scope'             => 'sub',
                            'filter'            => '(&(objectClass=univentionKolabGroup)(mailPrimaryAddress=*))',
                            'object_classes'    => array("top", "univentionKolabGroup"),
                        ),
                ),

        );

    $config['autocomplete_addressbooks'] = Array(
            'global'
        );

    $config['autocomplete_single'] = true;

    $config['htmleditor'] = 0;

    $config['kolab_http_request'] = Array(
            'ssl_verify_host' => true,
            'ssl_verify_peer' => true,
            'ssl_cafile'     => '/etc/univention/ssl/ucsCA/CAcert.pem'
        );


?>
