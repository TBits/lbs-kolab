<?php
    /* Configuration for libkolab */

    $config['kolab_cache'] = true;

    $config['kolab_freebusy_server'] = 'http://' . $_SERVER['HTTP_HOST'] . '/freebusy';
    $config['kolab_ssl_verify_peer'] = true;

    $config['kolab_format_version'] = '@%@mail/kolab/format-mime-version@%@';

    $config['kolab_use_subscriptions'] = true;
?>
