<?php

/*
@%@UCRWARNING= @%@
*/

// The id of the LDAP address book (which refers to the $config['ldap_public'])
// or complete addressbook definition array.
$config['ldap_authentication_addressbook'] = '';

// This will overwrite defined filter
$config['ldap_authentication_filter'] = '(&(objectClass=kolabInetOrgPerson)(|(uid=%u)(mail=%fu)(alias=%fu)))';

// Use this fields (from fieldmap configuration) to get authentication ID
$config['ldap_authentication_login'] = 'email';

// Use this fields (from fieldmap configuration) for default identity
$config['ldap_authentication_name']  = 'name';
$config['ldap_authentication_alias'] = 'alias';
$config['ldap_authentication_email']  = 'email';

?>
