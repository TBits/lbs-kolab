<?php

/*
@%@UCRWARNING= @%@
*/

// The id of the LDAP address book (which refers to the $config['ldap_public'])
// or complete addressbook definition array.
//$config['kolab_auth_addressbook'] = '';
$config['kolab_auth_addressbook'] = array(
        'name'                  => 'Kolab Auth',
        'hosts'                 => array('@%@ldap/server/name@%@'),
        'port'                  => @%@ldap/server/port@%@,
        'use_tls'               => false,
        'user_specific'         => false,
        'base_dn'               => '@%@ldap/base@%@',
        'bind_dn'               => '@%@ldap/hostdn@%@',
@!@
import os
if os.path.exists('/etc/machine.secret'):
 print "        'bind_pass'             => '%s'," % (open('/etc/machine.secret','r').read().strip())
else:
 print "        'bind_pass'             => 'MACHINE.SECRET_IS_MISSING',"
@!@
        'writable'              => false,
        'ldap_version'          => 3,       // using LDAPv3
        'fieldmap' => array(
                'name'    => 'cn',
                'email'   => 'mailprimaryaddress',
                'alias'   => 'alias',
            ),
        'sort'                  => 'cn',
        'scope'                 => 'sub',
        'filter'                => '(objectClass=*)',
        'fuzzy_search'          => true,
        'sizelimit'             => '0',
        'timelimit'             => '0',
        'groups'                    => array(
                'base_dn'           => '@%@ldap/base@%@',
                'filter'            => '(objectClass=kolabGroupOfNames)',
                'object_classes'    => array('top', 'kolabGroupOfNames'),
                'member_attr'       => 'member',
            ),
    );

// This will overwrite defined filter
$config['kolab_auth_filter'] = '(&(objectClass=kolabInetOrgPerson)(|(uid=%u)(mail=%fu)(mailPrimaryAddress=%fu)))';

// Use this fields (from fieldmap configuration) to get authentication ID
$config['kolab_auth_login'] = 'email';

// Use this fields (from fieldmap configuration) for default identity.
// If the value array contains more than one field, first non-empty will be used
// Note: These aren't LDAP attributes, but field names in config
// Note: If there's more than one email address, as many identities will be created
$config['kolab_auth_name']  = 'name';
$config['kolab_auth_alias'] = 'alias';
$config['kolab_auth_email'] = 'email';

// Login and password of the admin user. Enables "Login As" feature.
$config['kolab_auth_admin_login']    = '';
$config['kolab_auth_admin_password'] = '';

// Enable audit logging for abuse of administrative privileges.
$config['kolab_auth_auditlog'] = false;

// Role field (from fieldmap configuration)
$config['kolab_auth_role'] = '';
// The required value for the role attribute to contain should the user be allowed
// to login as another user.
$config['kolab_auth_role_value'] = '';

// Administrative group name to which user must be assigned to
// which adds privilege to login as another user.
$config['kolab_auth_group'] = '';

// Enable plugins on a role-by-role basis. In this example, the 'acl' plugin
// is enabled for people with a 'cn=professional-user,dc=mykolab,dc=ch' role.
//
// Note that this does NOT mean the 'acl' plugin is disabled for other people.
$config['kolab_auth_role_plugins'] = Array(
        'cn=professional-user,dc=mykolab,dc=ch' => Array(
                'acl',
            ),
    );

// Settings on a role-by-role basis. In this example, the 'htmleditor' setting
// is enabled(1) for people with a 'cn=professional-user,dc=mykolab,dc=ch' role,
// and it cannot be overridden. Sample use-case: disable htmleditor for normal people,
// do not allow the setting to be controlled through the preferences, enable the
// html editor for professional users and allow them to override the setting in
// the preferences.
$config['kolab_auth_role_settings'] = Array(
        'cn=professional-user,dc=mykolab,dc=ch' => Array(
                'htmleditor' => Array(
                        'mode' => 'override',
                        'value' => 1,
                        'allow_override' => true
                    ),
            ),
    );


?>
