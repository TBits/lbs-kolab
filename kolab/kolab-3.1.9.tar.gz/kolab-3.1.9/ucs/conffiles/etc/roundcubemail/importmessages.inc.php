<?php

/*
@%@UCRWARNING= @%@
*/

/**
 * ImportMessages configuration file
 */

// Message processing driver
// Use an external process such as virus or spam checker to test the messages before they are imported. Default: null.
$config['importmessages_process_driver'] = null;

?>
