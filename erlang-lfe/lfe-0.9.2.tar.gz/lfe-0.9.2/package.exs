Expm.Package.new(name: "lfe",
                 description: "Lisp Flavored Erlang",
                 version: "0.10.0-dev",
                 keywords: ["LFE", "Lisp", "Languages", "BEAM", "Erlang VM"],
                 maintainers: [[name: "Robert Virding",
                                email: "rvirding@gmail.com"]],
                 repositories: [[github: "rvirding/lfe"]])
