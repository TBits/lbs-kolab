defmodule Bar do
  defstruct name: "", foo: %Foo{}
end
