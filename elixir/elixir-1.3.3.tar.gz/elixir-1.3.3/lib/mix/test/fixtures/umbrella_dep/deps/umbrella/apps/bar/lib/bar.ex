defmodule Bar do
  def bar do
    "hello world"
  end
end
