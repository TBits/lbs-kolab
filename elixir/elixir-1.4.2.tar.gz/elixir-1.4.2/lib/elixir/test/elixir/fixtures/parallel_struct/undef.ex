defmodule Undef do
  def undef() do
    %__MODULE__{}
  end
end
