defmodule Bar do
end

require Foo
IO.puts Foo.message
