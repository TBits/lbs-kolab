defmodule Sample.Fixture.Mixfile do
  use Mix.Project

  def project do
    [app: :sample,
     version: "0.0.1",
     deps: []]
  end
end
