defmodule ExDoc.Fixture.Mixfile do
  use Mix.Project

  def project do
    [app: :ex_doc,
     version: "0.0.1"]
  end
end
