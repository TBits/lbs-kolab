/* cyrus-imapd 2.5.10-49-g2e214b4 */
#define _CYRUS_VERSION "2.5.10-49-g2e214b4"
#define CYRUS_GITVERSION "2e214b46 2016-11-14"
