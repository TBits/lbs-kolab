/* cyrus-imapd 2.5.11-41-gd53406f3f */
#define _CYRUS_VERSION "2.5.11-41-gd53406f3f"
#define CYRUS_GITVERSION "d53406f3 2017-07-24"
