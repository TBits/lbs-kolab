.. _imap-admin-systemcommands-lmtpproxyd:

==============
**lmtpproxyd**
==============

This is a hard linked copy of :cyrusman:`lmtpd(8)`, retained for backwards compatibility from when a murder frontend used its own lmtpd binaries.
