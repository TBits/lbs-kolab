===============
Online Meetings
===============

Join us online! 

Regular contributors catch up online twice weekly, both as a status checkpoint and to make sure we're all alive!

Meetings are currently held at **Monday 11am GMT** and **Thursday midday GMT** via `Google Hangouts <https://plus.google.com/hangouts/_/g4xnqjjb5zvomzeb4kqvja3fz4a>`_. 

