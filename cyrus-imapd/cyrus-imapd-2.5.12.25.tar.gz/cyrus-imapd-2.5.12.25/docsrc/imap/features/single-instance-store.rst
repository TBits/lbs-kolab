=====================
Single-Instance Store
=====================

It is rather uncommon for last week's holiday photos or last weekend's
embarrasing pub crawl videos to be sent to just one user of Cyrus IMAP.

When a message is received for multiple users, Cyrus IMAP can ensure
only one copy is stored on disk.

Back to :ref:`imap-features`
