How do I view ACLs on a mailbox?
--------------------------------

Use :cyrusman:`cyradm(8)`