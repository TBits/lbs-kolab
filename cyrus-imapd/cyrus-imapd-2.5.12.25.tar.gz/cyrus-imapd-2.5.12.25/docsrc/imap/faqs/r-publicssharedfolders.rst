How can I make CyrusSieve work with public shared folders?
----------------------------------------------------------

:ref:`Cyrus Sieve <cyrus-sieve>`