Can I configure pop3d to log amount and size of messages fetched by user?
-------------------------------------------------------------------------

The short answer is no, there isn't any logging based on the size of 
message retrieved or when a specific message is retrieved. Patches are 
welcome. 

