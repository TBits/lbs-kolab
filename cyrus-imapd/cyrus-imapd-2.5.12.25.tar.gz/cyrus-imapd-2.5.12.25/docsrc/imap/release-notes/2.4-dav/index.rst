.. _imap-release-notes-2.4-dav:

==============================
Cyrus IMAP 2.4-caldav Releases
==============================

.. toctree::
    :maxdepth: 1
    :glob:

    x/?.?.??-caldav-beta?
    x/?.?.??-caldav-beta??
