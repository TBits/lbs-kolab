.. _imap-release-notes-2.3:

=======================
Cyrus IMAP 2.3 Releases
=======================

.. toctree::
    :maxdepth: 1
    :glob:

    x/?.?.?
    x/?.?.??
