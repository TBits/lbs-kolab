.. _imap-configuring-the-mta:

===================
Configuring the MTA
===================

.. toctree::
    :maxdepth: 1
    :glob:

..    configuring/*
