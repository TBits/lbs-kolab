.. _imap-admin-systemcommands-proxyd:

==========
**proxyd**
==========

In Progress

Synopsis
========

.. parsed-literal::

    **proxyd** [ **-C** *config-file* ]  

Description
===========


Options
=======

.. program:: proxyd

.. option:: -C config-file

    |cli-dash-c-text|




/etc/imapd.conf,
/etc/cyrus.conf

See Also
========

:cyrusman:`imapd.conf(5)`,
:cyrusman:`cyrus.conf(5)`
