.. _imap-admin-systemcommands-ptloader:

============
``ptloader``
============

intro

Synopsis
========

.. parsed-literal::

    ptloader [OPTIONS]

Description
===========

The ``ptloader`` program outputs a list of files and/or directories
that it expects to exist, but that in fact do not.

Options
=======

.. program:: ptloader

.. option:: -C config-file

    |cli-dash-c-text|

Examples
========

See Also
========
