Tools & Utilities
-----------------

arbitron
++++++++

arbitronsort.pl
+++++++++++++++

chk_cyrus
+++++++++

convert-sieve.pl
++++++++++++++++

ctl_cyrusdb
+++++++++++

ctl_deliver
+++++++++++

ctl_mboxlist
++++++++++++

cvt_cyrusdb
+++++++++++

cvt_cyrusdb_all
+++++++++++++++

cyr_dbtool
++++++++++

cyr_df
++++++

cyrdump
+++++++

cyr_expire
++++++++++

fetchnews
+++++++++

cyr_sequence
++++++++++++

cyr_synclog
+++++++++++

cyr_userseen
++++++++++++

masssievec
++++++++++

Script to mass compile Sieve scripts 

mbexamine
+++++++++

mbpath
++++++

migrate-metadata
++++++++++++++++

mkimap
++++++

mknewsgroups
++++++++++++

rehash
++++++

translatesieve
++++++++++++++

script to translate sieve scripts to use unixhierarchysep and/or altnamespace 

undohash
++++++++

absolutely ancient (downgrade to prior 1.6.2+), probably should be obsoleted entirely 

upgradesieve
++++++++++++

absolutely ancient (upgrade from 1.6.13), probably should be obsoleted entirely 

