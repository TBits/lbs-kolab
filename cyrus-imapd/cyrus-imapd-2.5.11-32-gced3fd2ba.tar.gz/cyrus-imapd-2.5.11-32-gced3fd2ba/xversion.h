/* cyrus-imapd 2.5.11-32-gced3fd2ba */
#define _CYRUS_VERSION "2.5.11-32-gced3fd2ba"
#define CYRUS_GITVERSION "51c5983d 2017-07-12"
