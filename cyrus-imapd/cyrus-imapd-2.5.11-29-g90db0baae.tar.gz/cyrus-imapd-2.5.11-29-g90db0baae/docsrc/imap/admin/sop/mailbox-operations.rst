Mailbox Operations
==================

Determining the size of a mailbox
---------------------------------

The size of a mailbox can be obtained using the cyradm utility, by issuing the :ref:`cyradmn info <imap-admin-systemcommands-cyradm-info>` command.

When using quota, the size of a mailbox hierarchy under the quota root folder can be obtained using the :ref:`cyradmn listquotaroot <imap-admin-systemcommands-cyradm-listquotaroot>` command. 

.. toctree::
   :hidden:

   mailbox-quota
