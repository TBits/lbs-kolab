==============================
Supported Mail Transfer Agents
==============================

.. toctree::
    :maxdepth: 1
    :glob:

    configuration
