Why does Cyrus reject messages with "bare newlines"?
----------------------------------------------------

Bare newlines is a nono in an :rfc:`822` message. You should first try to fix the software that is causing the problem.