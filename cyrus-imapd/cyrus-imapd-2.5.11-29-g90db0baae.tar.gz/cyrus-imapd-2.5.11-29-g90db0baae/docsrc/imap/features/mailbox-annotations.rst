.. _imap-features-mailbox-annotations:

==============================
Mailbox Annotations (METADATA)
==============================

.. NOTE::

    Cyrus IMAP documentation is a work in progress. The completion of
    this particular part of the documentation is pending the resolution
    of :task:`69`.

.. seealso::

    *   :ref:`imap-features-message-annotations`

Back to :ref:`imap-features`
