.. _imap-features-message-annotations:

==============================
Message Annotations (METADATA)
==============================

.. seealso::

    *   :ref:`imap-features-mailbox-annotations`

Back to :ref:`imap-features`
