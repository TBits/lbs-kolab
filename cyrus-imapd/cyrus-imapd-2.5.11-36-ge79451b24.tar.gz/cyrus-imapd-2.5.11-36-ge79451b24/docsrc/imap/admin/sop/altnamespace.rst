Alternative Namespace
=====================

Switching the Alternative Namespace
-----------------------------------

When switching the alternative namespace configuration variable in /etc/imapd.conf, bear in mind that client applications might conclude folders to have been removed and to have been added, as opposed to having been moved, resulting in a complete download of all folders and messages.

