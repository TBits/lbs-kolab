.. _pop3-admin-commands-pop3proxyd:

==============
**pop3proxyd**
==============


This is a hard linked copy of :cyrusman:`pop3d(8)`, retained for backwards compatibility from when a murder frontend used its own pop3d binaries.
