/* cyrus-imapd 2.5.8.12 */
#define _CYRUS_VERSION "2.5.8.12"
#define CYRUS_GITVERSION "fb7ae876 2016-06-02"
