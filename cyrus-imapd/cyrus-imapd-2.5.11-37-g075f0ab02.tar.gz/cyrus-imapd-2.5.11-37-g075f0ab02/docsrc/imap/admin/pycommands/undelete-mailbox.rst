.. _imap-admin-pycommands-undelete-mailbox:

====================
``undelete-mailbox``
====================
