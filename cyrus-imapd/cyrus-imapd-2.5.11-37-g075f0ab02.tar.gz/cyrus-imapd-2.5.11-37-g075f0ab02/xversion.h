/* cyrus-imapd 2.5.11-37-g075f0ab02 */
#define _CYRUS_VERSION "2.5.11-37-g075f0ab02"
#define CYRUS_GITVERSION "075f0ab0 2017-07-23"
