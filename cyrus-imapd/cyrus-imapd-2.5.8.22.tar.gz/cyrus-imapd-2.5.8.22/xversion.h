/* cyrus-imapd 2.5.8.22 */
#define _CYRUS_VERSION "2.5.8.22"
#define CYRUS_GITVERSION "f1affb9b 2016-07-01"
