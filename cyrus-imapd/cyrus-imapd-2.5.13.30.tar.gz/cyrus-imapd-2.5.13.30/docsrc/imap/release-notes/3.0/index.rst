.. _imap-release-notes-3.0:

=============================
Cyrus IMAP 3.0 Releases
=============================

.. toctree::
    :maxdepth: 1
    :glob:

    x/?.?.*
