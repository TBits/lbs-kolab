.. _imap-admin-systemcommands-ptexpire:

============
``ptexpire``
============

intro

Synopsis
========

.. parsed-literal::

    ptexpire [OPTIONS]

Description
===========

The ``ptexpire`` program outputs a list of files and/or directories
that it expects to exist, but that in fact do not.

Options
=======

.. program:: ptexpire

.. option:: -C config-file

    |cli-dash-c-text|

Examples
========

See Also
========
