:orphan:

.. _imap-admin-systemcommands-CMD:

==========
**CMD**
==========

intro...

Synopsis
========

.. parsed-literal::

    **CMD** [ **-C** *config-file* ] [OPTIONS]

Description
===========

**CMD** description...

**CMD** |default-conf-text|

Options
=======

.. program:: CMD

.. option:: -C config-file

    |cli-dash-c-text|

Examples
========

History
=======

Files
=====

See Also
========
