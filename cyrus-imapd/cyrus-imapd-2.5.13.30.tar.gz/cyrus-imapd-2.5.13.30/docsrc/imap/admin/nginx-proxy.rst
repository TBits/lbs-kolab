.. _imap-howto-nginx-proxy:

================================
HOWTO: Using an NGINX IMAP Proxy
================================
