===================
LDAP Authentication
===================

The completion of this part of the documentation is pending the
resolution of :task:`40`.

Back to :ref:`imap-features`
