============
About Cyrus
============

..  toctree::
	  :maxdepth: 2
	
	  What is Cyrus <what_is_cyrus>
	  who_is_cyrus
	  cyrus_roadmap
	  cyrus_history
	  cyrus_bylaws
	
