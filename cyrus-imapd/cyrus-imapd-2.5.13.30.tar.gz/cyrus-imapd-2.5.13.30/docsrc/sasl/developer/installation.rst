.. _sasldevinstallguide:

===========================
Cyrus SASL Developer Guide
===========================

.. todo:
    This is all available at http://www.cyrusimap.org/docs/cyrus-sasl/2.1.25/install.php

Compile from source
===================

Fetch the source 
-----------------

.. todo:
    Fetch from git
    Or unpack from tarball


Dependencies
------------

.. todo:
    ?? Libraries

Compiling
---------

`sh SMakefile`

Configuration
-------------

`./configure ...`

.. note:
    If you tweak configure.ac or any of the .m4 files, you will have to delete configure and then compile again to create a new configure script.

