.. _feedback:

=======
Support
=======

We value feedback on our software as well as our documentation. Please find ways to contact us in this section.

.. toctree::

   feedback-bugs
   feedback-mailing-lists
   feedback-irc
   feedback-meetings
