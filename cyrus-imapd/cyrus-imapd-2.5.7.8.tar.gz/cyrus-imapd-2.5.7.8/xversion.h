/* cyrus-imapd 2.5.7.8 */
#define _CYRUS_VERSION "2.5.7.8"
#define CYRUS_GITVERSION "416a3d99 2016-03-10"
