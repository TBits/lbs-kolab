========
IRC Chat
========

We found chatting on IRC has just that little more bandwidth available
for a conversation as opposed to mailing lists and/or Phabricator, so we
would like to invite you to join us on IRC if you're interested.

There are often Cyrus developers and experienced administrators hanging
around to talk to in a friendly, helpful environment.

Network: **FreeNode (irc.freenode.net)**

Channel: **#cyrus**

If you have an IRC client installed, you may be able to use this link: irc://irc.freenode.net/cyrus

If you don't have an IRC client, you can use the `FreeNode web client <http://webchat.freenode.net/?channels=cyrus&prompt=1>`__

