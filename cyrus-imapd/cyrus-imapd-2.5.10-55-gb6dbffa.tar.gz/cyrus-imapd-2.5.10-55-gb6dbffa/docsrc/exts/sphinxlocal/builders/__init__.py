# -*- coding: utf-8 -*-
"""
    sphinxlocal.builders
    ~~~~~~~~~~~~~~~

    Custom docutils builders.

    :copyright: Copywrite 2015 by Nic Bernstein <nic@onlight.com>
    :license: BSD, see LICENSE for details.
"""
