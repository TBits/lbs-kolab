SASL Authentication Mechanisms
==============================

EXTERNAL
--------

.. todo::
   Content needed here

ANONYMOUS
---------

.. todo::
   Content needed here

PLAIN
-----

.. todo::
   Content needed here

LOGIN
-----

.. todo::
   Content needed here

CRAM-MD5
--------

.. todo::
   Content needed here

DIGEST-MD5
----------

.. todo::
   Content needed here

SCRAM-SHA-1
-----------

.. todo::
   Content needed here

GSSAPI
------

.. todo::
   Content needed here

GS2-KRB5
--------

.. todo::
   Content needed here

GS2-IAKERB
----------

.. todo::
   Content needed here

NTLM
----

.. todo::
   Content needed here

SRP
---

.. todo::
   Content needed here

PSSDSS
------

.. todo::
   Content needed here

OTP
---

.. todo::
   Content needed here

Non-SASL Authentication
-----------------------

.. todo::
   Content needed here

