.. _imap-release-notes-2.5:

=======================
Cyrus IMAP 2.5 Releases
=======================

.. toctree::
    :maxdepth: 1
    :glob:

    x/?.?.?
    x/?.?.??

