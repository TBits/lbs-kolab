.. _imap-release-notes-2.4:

=======================
Cyrus IMAP 2.4 Releases
=======================

.. toctree::
    :maxdepth: 1
    :glob:

    x/?.?.?
    x/?.?.??
