.. _imap-features-server-side-filtering:

=============================
Server Side Filtering (Sieve)
=============================

.. NOTE::

    Cyrus IMAP documentation is a work in progress. The completion of
    this particular part of the documentation is pending the resolution
    of :task:`73`.

Back to :ref:`imap-features`
