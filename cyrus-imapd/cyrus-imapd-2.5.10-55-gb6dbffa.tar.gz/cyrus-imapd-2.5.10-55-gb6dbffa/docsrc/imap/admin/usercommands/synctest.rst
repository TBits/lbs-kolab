.. _imap-admin-usercommands-synctest:

============
**synctest**
============

Interactive IMAP test program: tests the replication protocol. This is installed as a hard link to :cyrusman:`imtest(1)`.
