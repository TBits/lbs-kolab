Debian
======

The good news is Debian distributions are supported by the Cyrus IMAP
team, the bad news is nobody has written up this part of the
documentation yet.

.. NOTE::

    Cyrus IMAP documentation is a work in progress. The completion of
    this particular part of the documentation is pending a Debian-savvy
    volunteer. If you're interested, please see the instructions for
    :ref:`imap-installation-distributions-centos` for a general idea of
    a write-up next-next finish installation of Cyrus IMAP.
