Help! There must be an easier way to get all this going...
----------------------------------------------------------

Currently, the Cyrus project only distributes Cyrus IMAPd and Cyrus SASL 
as source code. If you prefer not to work directly with the source 
distribution - you don't have the time to learn it, find it too 
difficult, or it's otherwise unsuitable - there are a few other options. 

There are a number of projects outside the main Cyrus project that 
provide easy-to-install packages of the Cyrus software. Additionally, 
there are a fair few commercial software packages that include the Cyrus 
software as a component. Our :ref:`installation guide <installguide>` 
page lists these.

Most people active on the :ref:`info-cyrus mailing list <feedback>` 
appear to use the source distribution, so more people are likely to be 
familiar with that than any vendor-specific custom versions. 

Additionally, it can be easier to upgrade to the latest version if 
you're using the source packages. 

Finally: you learn more! In the end, 
the best way to get Cyrus depends on what your specific needs are. 

