.. _installguide:

=======================
IMAP Installation Guide
=======================

Cyrus IMAP packages are shipped with every major distribution, including
but not limited to Fedora, Red Hat Enterprise Linux, CentOS, Scientific
Linux, Debian, Ubuntu, openSUSE, Gentoo, Mageia and ClearOS.

Installation Using Packages
===========================

.. toctree::
    :maxdepth: 1
    :glob:

    installation/distributions/*
    installation/obs

Build and Install Yourself
==========================

.. toctree::
    :maxdepth: 2

    installation/diy
	
.. toctree::
    :hidden:

    mta/index
    
External Tools
==============

These are projects that are not directly developed or managed 
under the umbrella of the Cyrus Project, but may provide enhancements 
or additional functionality.

Both of these projects are not under active development, but are 
definitely worthwhile and would be Good Things to have available.
If you think you'd be interested in taking them on and bringing them
up to speed, we encourage you to contact the original authors.

There is an effort to develop `Cyrus utilities <http://sourceforge.net/projects/cyrus-utils/>`_.

Additionally, a Cyrus administrative GUI is available from http://korreio.sf.net
    
Licensing
=========

All versions of the Cyrus IMAP server and Cyrus SASL library are now 
covered by the following copyright message. However, please note that 
in older distributions, there may still be files that have the old 
copyright text.

::

    * Copyright (c) 1994-2016 Carnegie Mellon University.  All rights reserved.
    *
    * Redistribution and use in source and binary forms, with or without
    * modification, are permitted provided that the following conditions
    * are met:
    *
    * 1. Redistributions of source code must retain the above copyright
    *    notice, this list of conditions and the following disclaimer. 
    *
    * 2. Redistributions in binary form must reproduce the above copyright
    *    notice, this list of conditions and the following disclaimer in
    *    the documentation and/or other materials provided with the
    *    distribution.
    *
    * 3. The name "Carnegie Mellon University" must not be used to
    *    endorse or promote products derived from this software without
    *    prior written permission. For permission or any legal
    *    details, please contact  
    *      Office of Technology Transfer
    *      Carnegie Mellon University
    *      5000 Forbes Avenue
    *      Pittsburgh, PA  15213-3890
    *      (412) 268-4387, fax: (412) 268-7395
    *      tech-transfer@andrew.cmu.edu
    *
    * 4. Redistributions of any form whatsoever must retain the following
    *    acknowledgment:
    *    "This product includes software developed by Computing Services
    *     at Carnegie Mellon University (http://www.cmu.edu/computing/)."
    *
    * CARNEGIE MELLON UNIVERSITY DISCLAIMS ALL WARRANTIES WITH REGARD TO
    * THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
    * AND FITNESS, IN NO EVENT SHALL CARNEGIE MELLON UNIVERSITY BE LIABLE
    * FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
    * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN
    * AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING
    * OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
