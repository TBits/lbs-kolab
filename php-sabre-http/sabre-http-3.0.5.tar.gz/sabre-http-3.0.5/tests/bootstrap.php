<?php

date_default_timezone_set('UTC');

ini_set('error_reporting', E_ALL | E_STRICT | E_DEPRECATED);

// Composer autoloader
include __DIR__ . '/../vendor/autoload.php';

