============
About Bonnie
============

Bonnie is a transcriptor for events that occur against an IMAP server, and
correlates events occuring in a Kolab environment.

As such, Bonnie is the answer to the questions about :ref:`about-audit-trail`,
:ref:`about-archival`, :ref:`about-backup-and-restore`,
:ref:`about-data-loss-prevention`, :ref:`e-discovery` and
:ref:`about-lawful-interception` for electronic communications.

.. toctree::
    :maxdepth: 1

    getting-started
    architecture-and-design/index
    technical-documentation/index
..
    The following are placeholders for documentation that is not to be
    included in the toctree, for it is otherwise referred to.

.. toctree::
    :hidden:

    about/archival
    about/audit-trail
    about/backup-and-restore
    about/data-loss-prevention
    about/e-discovery
    about/lawful-interception

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

