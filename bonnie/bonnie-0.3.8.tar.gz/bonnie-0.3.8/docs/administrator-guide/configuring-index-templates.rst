=========================================
Configuring Elasticsearch Index Templates
=========================================

``headers.Subject``
===================

Adjust the template for ``logstash-*`` indexex to no longer analyze the
``headers.Subject`` field.

Normally, the field is tokenized:

.. parsed-literal::

    $ :command:`curl -XGET /_analyze?text=1234-5678 | python -mjson.tool`
      % Total    % Received % Xferd  Average Speed   Time    Time     Time  Current
                                     Dload  Upload   Total   Spent    Left  Speed
    100   166  100   166    0     0    646      0 --:--:-- --:--:-- --:--:--   648
    {
        "tokens": [
            {
                "end_offset": 4,
                "position": 1,
                "start_offset": 0,
                "token": "1234",
                "type": "<NUM>"
            },
            {
                "end_offset": 9,
                "position": 2,
                "start_offset": 5,
                "token": "5678",
                "type": "<NUM>"
            }
        ]
    }

Get the original template definition:

.. parsed-literal::

    $ :command:`curl -XGET /_template/logstash | python -mjson.tool`
    {
        "logstash" : {
                "order" : 0,
                "template" : "logstash-\*",
                "settings" : {
                "index.refresh_interval" : "5s"
            },
            "mappings" : {
                "_default_" : {
                    "dynamic_templates" : [ {
                        "string_fields" : {
                            "mapping" : {
                                "index" : "analyzed",
                                "omit_norms" : true,
                                "type" : "string",
                                "fields" : {
                                    "raw" : {
                                        "index" : "not_analyzed",
                                        "ignore_above" : 256,
                                        "type" : "string"
                                    }
                                }
                            },
                            "match_mapping_type" : "string",
                            "match" : "\*"
                        }
                    } ],
                    "properties" : {
                        "geoip" : {
                            "dynamic" : true,
                            "path" : "full",
                            "properties" : {
                                "location" : {
                                    "type" : "geo_point"
                                }
                            },
                            "type" : "object"
                        },
                        "@version" : {
                            "index" : "not_analyzed",
                            "type" : "string"
                        }
                    },
                    "_all" : {
                        "enabled" : true
                    }
                }
            },
            "aliases" : { }
        }
    }

Define the new version:

.. parsed-literal::

    $ :command:`curl -XPUT http://es.lhm.klab.cc:9200/_template/logstash -d '`
    {
        "logstash" : {
                "order" : 0,
                "template" : "logstash-\*",
                "settings" : {
                "index.refresh_interval" : "5s"
            },
            "mappings" : {
                "_default_" : {
                    "dynamic_templates" : [ {
                        "string_fields" : {
                            "mapping" : {
                                "index" : "analyzed",
                                "omit_norms" : true,
                                "type" : "string",
                                "fields" : {
                                    "raw" : {
                                        "index" : "not_analyzed",
                                        "ignore_above" : 256,
                                        "type" : "string"
                                    }
                                }
                            },
                            "match_mapping_type" : "string",
                            "match" : "\*"
                        }
                    } ],
                    "properties" : {
                        "geoip" : {
                            "dynamic" : true,
                            "path" : "full",
                            "properties" : {
                                "location" : {
                                    "type" : "geo_point"
                                }
                            },
                            "type" : "object"
                        },
                        **"headers.Subject": {**
                            **"type": "string",**
                            **"index": "not_analyzed"**
                        **},**
                        "@version" : {
                            "index" : "not_analyzed",
                            "type" : "string"
                        }
                    },
                    "_all" : {
                        "enabled" : true
                    }
                }
            },
            "aliases" : { }
        }
    }

.. parsed-literal::

    $ :command:`curl -XGET /logstash-2014.12.04/_analyze?field=headers.Subject -d '1234-5678' | python -mjson.tool`
      % Total    % Received % Xferd  Average Speed   Time    Time     Time  Current
                                     Dload  Upload   Total   Spent    Left  Speed
    100   102  100    93  100     9    364     35 --:--:-- --:--:-- --:--:--   364
    {
        "tokens": [
            {
                "end_offset": 9,
                "position": 1,
                "start_offset": 0,
                "token": "1234-5678",
                "type": "word"
            }
        ]
    }

http://www.elasticsearch.org/guide/en/elasticsearch/guide/current/_finding_exact_values.html
