===============
Worker Handlers
===============

Event Notification Handlers
===========================

.. automodule:: bonnie.worker.handlers

Handler Bases
=============

.. autoclass:: bonnie.worker.handlers.base.HandlerBase
.. autoclass:: bonnie.worker.handlers.messagebase.MessageHandlerBase
.. autoclass:: bonnie.worker.handlers.mailboxbase.MailboxHandlerBase
