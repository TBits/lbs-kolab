======
Dealer
======

A dealer is used as the means for an IMAP server to emit
:term:`event notifications` to the Bonnie environment. Two forms of dealing
exist:

*   Synchronous (meaning blocking),

*   Asynchronous (meaning non-blocking).

A blocking dealer ensures the action placed against an IMAP server must await
the successful acceptance of the event having occured, and is particularly
cumbersome and therefore dangerous to implement. As such, at this point it
should be considered an academic exercise.

The asynchronous dealer should be used, and render Bonnie a near- real-time,
eventually consistent application suite.

.. automodule:: bonnie.dealer
