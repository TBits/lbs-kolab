.. _about-archival:

========
Archival
========

Archiving, in the context of this application suite, principally revolves
around the act of preservation of records.

It therefore implies these records do not necessarily need to be rendered
available in a near real-time production environment, and could be submitted
to slower, cheaper, larger-volume storage.

.. seealso::

    *   :ref:`about-backup-and-restore`
