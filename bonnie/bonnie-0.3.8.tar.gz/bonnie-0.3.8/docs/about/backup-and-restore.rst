.. _about-backup-and-restore:

================
Backup & Restore
================

Contrary to :ref:`about-archival`, backup and restore capabilities need to be
available to day-to-day operations of production environments more promptly, in
order to facilitate a work-flow against a variety of common issues; broken
hardware, mistakes by users, etc.
