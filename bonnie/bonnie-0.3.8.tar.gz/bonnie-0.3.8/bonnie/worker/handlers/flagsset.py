# -*- coding: utf-8 -*-
# Copyright 2010-2014 Kolab Systems AG (http://www.kolabsys.com)
#
# Jeroen van Meeuwen (Kolab Systems) <vanmeeuwen a kolabsys.com>
# Thomas Bruederli (Kolab Systems) <bruederli a kolabsys.com>
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
#

"""
    Base handler for an event notification of type 'FlagsSet'.
"""

from bonnie.worker.handlers import HandlerBase


class FlagsSetHandler(HandlerBase):
    """
        {
            "event":"FlagsSet",
            "mailboxID":"c1417483-e54d-43e0-88a4-06a832377aab",
            "modseq":4,
            "messages":1,
            "flagNames":"\\\\Answered",
            "pid":19681,
            "service":"imaps",
            "timestamp":"2018-06-19T09:56:40.116+02:00",
            "uidnext":2,
            "uidset":"1",
            "uri":"imap://kolab013.klab.cc/user/john.doe%40klab.cc;UIDVALIDITY=1529317681",
            "user":"john.doe@klab.cc",
            "vnd.cmu.midset":["<7a3a1149356e7705a4322bb44cce2ffe@klab.cc>"],
            "vnd.cmu.sessionId":"cyrus-imapd-19681-1529395000-1-3957065946565248241",
            "vnd.cmu.unseenMessages":0,
        }
    """

    event = 'FlagsSet'

    def __init__(self, *args, **kw):
        HandlerBase.__init__(self, *args, **kw)
