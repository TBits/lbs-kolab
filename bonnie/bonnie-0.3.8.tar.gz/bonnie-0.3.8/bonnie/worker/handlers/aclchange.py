# -*- coding: utf-8 -*-
# Copyright 2010-2014 Kolab Systems AG (http://www.kolabsys.com)
#
# Jeroen van Meeuwen (Kolab Systems) <vanmeeuwen a kolabsys.com>
# Thomas Bruederli (Kolab Systems) <bruederli a kolabsys.com>
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
#

"""
    Base handler for an event notification of type 'AclChange'
"""

from bonnie.worker.handlers import MailboxHandlerBase


class AclChangeHandler(MailboxHandlerBase):
    """
        Handler for an event that changes the ACL on a mailbox.

        When an ACL is updated, the current objects/folder will
        need to be considered obsolete, and updated with the
        contents of this notification.

        An example of such notification is:

        .. parsed-literal::

            {
                "aclRights": "lrswite",
                "aclSubject": "john.doe@klab.cc",
                "event": "AclChange",
                "mailboxID": "f0dd4cf3-bc06-450b-8fcf-06b1c5e07167",
                "pid": 24807,
                "service": "imaps",
                "timestamp": "2018-06-19T10:51:03.508+02:00",
                "uri": "imap://kolab013.klab.cc/user/jane.doe%40klab.cc;UIDVALIDITY=1529320204",
                "user": "jane/doe@klab.cc",
                "user_data": null,
                "user_id": null,
                "vnd.cmu.sessionId": "cyrus-imapd-24807-1529398263-1-6720352549146616500"
            }
    """

    event = 'AclChange'

    def __init__(self, *args, **kw):
        MailboxHandlerBase.__init__(self, *args, **kw)
