# Bitcask - A Log-Structured Hash Table for Fast Key/Value Data

[![Build Status](https://secure.travis-ci.org/basho/bitcask.png?branch=master)](http://travis-ci.org/basho/bitcask)

Bitcask uses the "rebar" build system, but we have provided a wrapper
Makefile so that simply running "make" at the top level should work.

Bitcask requires Erlang R14B04 or later.

