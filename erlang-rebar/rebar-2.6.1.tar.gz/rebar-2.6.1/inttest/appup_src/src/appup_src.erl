-module(appup_src).

-compile(export_all).

test() ->
    ok.
