-module(bazdep).

-export([bazdep/0]).

bazdep() ->
    bazdep.
