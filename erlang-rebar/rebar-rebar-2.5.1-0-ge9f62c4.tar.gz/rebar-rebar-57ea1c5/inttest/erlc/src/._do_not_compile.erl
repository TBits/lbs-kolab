syntax error
this is file is here to verify that rebar does not try to
compile files like OS X resource forks and should not be
processed at all
