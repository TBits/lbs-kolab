#!/usr/bin/php
<?php
    /*
     To configure the Kolab Webadmin user types database.
     Execute it on the Kolab server from /usr/share/kolab-webadmin/
    */

    if (php_sapi_name() != 'cli') {
        die("Not intended for execution through the webserver, sorry!");
    }

    require_once("lib/functions.php");

    $db   = SQL::get_instance();

    $result = $db->query("TRUNCATE `user_types`");

    $attributes = Array(
            "auto_form_fields" => Array(
                    "cn" => Array(
                            "data" => Array(
                                    "givenname",
                                    "sn",
                                ),
                        ),
                    "mail" => Array(
                            "data" => Array(
                                    "uid",
                                ),
                        ),
                    "nsroledn" => Array(
                            "optional" => true,
                        ),
                ),
            "form_fields" => Array(
                    "title" => Array(
                            "optional" => true,
                        ),
                    "givenname" => Array(),
                    "sn" => Array(),
                    "o" => Array(
                            "optional" => true,
                        ),
                    "street" => Array(
                            "optional" => true,
                        ),
                    "postalcode" => Array(
                            "optional" => true,
                        ),
                    "l" => Array(
                            "optional" => true,
                        ),
                    "c" => Array(
                            "type" => "select",
                            "value" => "normal",
                        ),
                    "telephonenumber" => Array(
                            "optional" => true,
                        ),
                    "mobile" => Array(
                            "optional" => true,
                        ),
                    "mailalternateaddress" => Array(
                            "optional" => false,
                        ),
                    "alias" => Array(
                            "type" => "list",
                            "optional" => true,
                        ),
                    "uid" => Array(
                            "optional" => true,
                        ),
                    "userpassword" => Array(
                            "type" => "password",
                            "optional" => true,
                        ),
                    "nsroledn" => Array(
                            "optional" => true,
                        ),
                ),
            "fields" => Array(
                    "mailquota" => Array(),
                    "objectclass" => Array(
                            "top",
                            "inetorgperson",
                            "kolabinetorgperson",
                            "mailrecipient",
                            "organizationalperson",
                            "country",
                            "person",
                        ),
                ),
        );

    $result = $db->query("INSERT INTO `user_types` (`key`, `name`, `description`, `attributes`, `used_for`) " .
                "VALUES ('individual','individual', 'individual'," .
                "'" . json_encode($attributes) . "', 'hosted')");

    $attributes = Array(
            "auto_form_fields" => Array(
                    "cn" => Array(
                            "data" => Array(
                                    "givenname",
                                    "sn",
                                ),
                        ),
                    "nsroledn" => Array(
                            "optional" => true,
                        ),
                ),
            "form_fields" => Array(
                    "givenname" => Array(),
                    "sn" => Array(),
                    "o" => Array(
                            "optional" => true,
                        ),
                    "street" => Array(
                            "optional" => true,
                        ),
                    "postalcode" => Array(
                            "optional" => true,
                        ),
                    "l" => Array(
                            "optional" => true,
                        ),
                    "c" => Array(
                            "type" => "select",
                            "value" => "normal",
                        ),
                    "telephonenumber" => Array(
                            "optional" => true,
                        ),
                    "mobile" => Array(
                            "optional" => true,
                        ),
                    "mail" => Array(
                            "validate" => false,
                        ),
                    "mailalternateaddress" => Array(),
                    "nsroledn" => Array(
                            "optional" => true,
                        ),
                    "uid" => Array(),
                    "userpassword" => Array(
                            "optional" => true,
                            "type" => "password",
                        ),
                ),
            "fields" => Array(
                    "mailquota" => Array(),
                    "nsroledn" => Array(
                            "cn=admin-user,%(base_dn)s",
                        ),
                    "objectclass" => Array(
                            "top",
                            "inetorgperson",
                            "kolabinetorgperson",
                            "organizationalperson",
                            "mailrecipient",
                            "country",
                            "person",
                        ),
                ),
        );


    $result = $db->query("INSERT INTO `user_types` (`key`, `name`, `description`, `attributes`, `used_for`) " .
                "VALUES ('organization','organization', 'organization'," .
                "'" . json_encode($attributes) . "', 'hosted')");

    $attributes = Array(
            "auto_form_fields" => Array(
                    "cn" => Array(
                            "data" => Array(
                                    "givenname",
                                    "sn",
                                ),
                        ),
                    "mail" => Array(
                            "data" => Array(
                                    "uid",
                                ),
                        ),
                    "nsroledn" => Array(
                            "optional" => true,
                        ),
                ),
            "form_fields" => Array(
                    "title" => Array(
                            "optional" => true,
                        ),
                    "givenname" => Array(),
                    "sn" => Array(),
                    "o" => Array(
                            "optional" => true,
                        ),
                    "street" => Array(
                            "optional" => true,
                        ),
                    "postalcode" => Array(
                            "optional" => true,
                        ),
                    "l" => Array(
                            "optional" => true,
                        ),
                    "telephonenumber" => Array(
                            "optional" => true,
                        ),
                    "mobile" => Array(
                            "optional" => true,
                        ),
                    "alias" => Array(
                            "type" => "list",
                            "optional" => true,
                        ),
                    "userpassword" => Array(
                            "type" => "password",
                            "optional" => true,
                        ),
                    "uid" => Array(
                            "optional" => true,
                        ),
                    "nsroledn" => Array(
                            "optional" => true,
                        ),
                ),
            "fields" => Array(
                    "mailquota" => Array(),
                    "objectclass" => Array(
                            "top",
                            "inetorgperson",
                            "kolabinetorgperson",
                            "mailrecipient",
                            "organizationalperson",
                            "person",
                        ),
                ),
        );

    $result = $db->query("INSERT INTO `user_types` (`key`, `name`, `description`, `attributes`, `used_for`) " .
                "VALUES ('organization-user','organization-user', 'organization-user'," .
                "'" . json_encode($attributes) . "', 'hosted')");

    $attributes = Array(
            "auto_form_fields" => Array(
                    "cn" => Array(
                            "data" => Array(
                                    "givenname",
                                    "sn",
                                ),
                        ),
                    "mail" => Array(
                            "data" => Array(
                                    "uid",
                                ),
                        ),
                    "nsroledn" => Array(
                            "optional" => true,
                        ),
                ),
            "form_fields" => Array(
                    "title" => Array(
                            "optional" => true,
                        ),
                    "givenname" => Array(),
                    "sn" => Array(),
                    "o" => Array(
                            "optional" => true,
                        ),
                    "street" => Array(
                            "optional" => true,
                        ),
                    "postalcode" => Array(
                            "optional" => true,
                        ),
                    "l" => Array(
                            "optional" => true,
                        ),
                    "telephonenumber" => Array(
                            "optional" => true,
                        ),
                    "mobile" => Array(
                            "optional" => true,
                        ),
                    "nsroledn" => Array(
                            "optional" => true,
                        ),
                    "userpassword" => Array(
                            "type" => "password",
                            "optional" => true,
                        ),
                    "uid" => Array(
                            "optional" => true,
                        ),
                ),
            "fields" => Array(
                    "objectclass" => Array(
                            "top",
                            "inetorgperson",
                            "kolabinetorgperson",
                            "organizationalperson",
                            "person",
                        ),
                ),
        );

    $result = $db->query("INSERT INTO `user_types` (`key`, `name`, `description`, `attributes`, `used_for`) " .
                "VALUES ('tenant-admin','tenant-admin', 'tenant-admin'," .
                "'" . json_encode($attributes) . "', '')");



?>
