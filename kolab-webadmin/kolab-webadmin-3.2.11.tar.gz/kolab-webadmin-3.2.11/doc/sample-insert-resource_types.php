#!/usr/bin/php
<?php

    if (isset($_SERVER["REQUEST_METHOD"]) && !empty($SERVER["REQUEST_METHOD"])) {
        die("Not intended for execution through the webserver, sorry!");
    }

    require_once("lib/functions.php");

    $db   = SQL::get_instance();

    $result = $db->query("TRUNCATE TABLE `resource_types`");

    $attributes = Array(
            "auto_form_fields" => Array(
                    "mail" => Array(
                            "data" => Array(
                                    "cn",
                                ),
                        ),
                ),
            "fields" => Array(
                    "objectclass" => Array(
                            "top",
                            "groupofuniquenames",
                            "kolabgroupofuniquenames",
                            "kolabresource",
                        ),
                ),
            "form_fields" => Array(
                    "cn" => Array(),
                    "ou" => Array(
                            "type" => "select",
                        ),
                    "uniquemember" => Array(
                            "type" => "list",
                            "autocomplete" => true,
                            "optional" => true,
                        ),
                    "owner" => Array(
                            "type" => "list",
                            "autocomplete" => true,
                            "optional" => true
                        ),
                    "kolabinvitationpolicy" => Array(
                            "type" => "list",
                            "optional" => true
                        ),
                ),
        );

    $result = $db->query("INSERT INTO `resource_types` (`key`, `name`, `description`, `attributes`) " .
                "VALUES ('collection','Resource Collection', 'A collection or pool of resources'," .
                "'" . json_encode($attributes) . "')");

    $attributes = Array(
            "auto_form_fields" => Array(
                    "cn" => Array(
                            "data" => Array(
                                    "cn",
                                ),
                        ),
                    "kolabtargetfolder" => Array(
                            "data" => Array(
                                    "cn",
                                ),
                        ),
                    "mail" => Array(
                            "data" => Array(
                                    "cn",
                                ),
                        ),
                ),
            "fields" => Array(
                    "objectclass" => Array(
                            "top",
                            "kolabsharedfolder",
                            "kolabresource",
                            "mailrecipient",
                        ),
                    "kolabfoldertype" => Array(
                            "event",
                        ),
                ),
            "form_fields" => Array(
                    "acl" => Array(
                            "type" => "imap_acl",
                            "optional" => true,
                        ),
                    "cn" => Array(),
                    "ou" => Array(
                            "type" => "select",
                        ),
                    "owner" => Array(
                            "type" => "list",
                            "autocomplete" => true,
                            "optional" => true
                        ),
                    "kolabinvitationpolicy" => Array(
                            "type" => "list",
                            "optional" => true
                        ),
                ),
        );

    $result = $db->query("INSERT INTO `resource_types` (`key`, `name`, `description`, `attributes`) " .
                "VALUES ('car','Car', 'A car'," .
                "'" . json_encode($attributes) . "')");

    $result = $db->query("INSERT INTO `resource_types` (`key`, `name`, `description`, `attributes`) " .
                "VALUES ('confroom','Conference Room', 'A conference room'," .
                "'" . json_encode($attributes) . "')");

    $result = $db->query("INSERT INTO `resource_types` (`key`, `name`, `description`, `attributes`) " .
                "VALUES ('projector','Projector', 'A portable overhead projector'," .
                "'" . json_encode($attributes) . "')");

    $result = $db->query("INSERT INTO `resource_types` (`key`, `name`, `description`, `attributes`) " .
                "VALUES ('footballtickets','Football Season Tickets', 'Season tickets to the game (pretty good seats too!)'," .
                "'" . json_encode($attributes) . "')");

?>
