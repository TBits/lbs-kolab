/*
 +--------------------------------------------------------------------------+
 | This file is part of the Kolab Web Admin Panel                           |
 |                                                                          |
 | Copyright (C) 2011-2014, Kolab Systems AG                                |
 |                                                                          |
 | This program is free software: you can redistribute it and/or modify     |
 | it under the terms of the GNU Affero General Public License as published |
 | by the Free Software Foundation, either version 3 of the License, or     |
 | (at your option) any later version.                                      |
 |                                                                          |
 | This program is distributed in the hope that it will be useful,          |
 | but WITHOUT ANY WARRANTY; without even the implied warranty of           |
 | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the             |
 | GNU Affero General Public License for more details.                      |
 |                                                                          |
 | You should have received a copy of the GNU Affero General Public License |
 | along with this program. If not, see <http://www.gnu.org/licenses/>      |
 +--------------------------------------------------------------------------+
 | Author: Aleksander Machniak <machniak@kolabsys.com>                      |
 +--------------------------------------------------------------------------+
*/

function kolab_admin()
{
  var self = this;

  this.env = {};
  this.translations = {};
  this.request_timeout = 300;
  this.message_time = 3000;
  this.events = {};
  this.attr_default_rx = /^(text|select|imap_acl)/;

  // set jQuery ajax options
  $.ajaxSetup({
    cache: false,
    error: function(request, status, err) { self.http_error(request, status, err); },
    beforeSend: function(xmlhttp) { xmlhttp.setRequestHeader('X-Session-Token', self.env.token); }
  });

  /*********************************************************/
  /*********          basic utilities              *********/
  /*********************************************************/

  // set environment variable(s)
  this.set_env = function(p, value)
  {
    if (p != null && typeof p === 'object' && !value)
      for (var n in p)
        this.env[n] = p[n];
    else
      this.env[p] = value;
  };

  // add a localized label(s) to the client environment
  this.tdef = function(p, value)
  {
    if (typeof p == 'string')
      this.translations[p] = value;
    else if (typeof p == 'object')
      $.extend(this.translations, p);
  };

  // return a localized string
  this.t = function(label)
  {
    if (this.translations[label])
      return this.translations[label];
    else
      return label;
  };

  // print a message into browser console
  this.log = function(msg)
  {
    if (window.console && console.log)
      console.log(msg);
  };

  // execute a specific command on the web client
  this.command = function(command, props, obj)
  {
    if (obj && obj.blur)
      obj.blur();

    if (this.busy)
      return false;

    this.set_busy(true, 'loading');

    var ret = undefined,
      func = command.replace(/[^a-z]/g, '_'),
      task = command.replace(/\.[a-z-_]+$/g, '');

    if (this[func] && typeof this[func] === 'function') {
      ret = this[func](props);
    }
    else {
      this.http_post(command, props);
    }

    // update menu state
    $('li', $('#navigation')).removeClass('active');
    $('li.'+task, ('#navigation')).addClass('active');

    if (ret === false)
      this.set_busy(false);

    return ret === false ? false : obj ? false : true;
  };

  this.set_busy = function(a, message)
  {
    if (a && message) {
      var msg = this.t(message);
      if (msg == message)
        msg = 'Loading...';

      this.display_message(msg, 'loading');
    }
    else if (!a) {
      this.hide_message('loading');
    }

    this.busy = a;

//    if (this.gui_objects.editform)
  //    this.lock_form(this.gui_objects.editform, a);

    // clear pending timer
    if (this.request_timer)
      clearTimeout(this.request_timer);

    // set timer for requests
    if (a && this.env.request_timeout)
      this.request_timer = window.setTimeout(function() { self.request_timed_out(); }, this.request_timeout * 1000);
  };

  // called when a request timed out
  this.request_timed_out = function()
  {
    this.set_busy(false);
    this.display_message('Request timed out!', 'error');
  };

  // Add variable to GET string, replace old value if exists
  this.add_url = function(url, name, value)
  {
    value = urlencode(value);

    if (/(\?.*)$/.test(url)) {
      var urldata = RegExp.$1,
        datax = RegExp('((\\?|&)'+RegExp.escape(name)+'=[^&]*)');

      if (datax.test(urldata))
        urldata = urldata.replace(datax, RegExp.$2 + name + '=' + value);
      else
        urldata += '&' + name + '=' + value

      return url.replace(/(\?.*)$/, urldata);
    }
    else
      return url + '?' + name + '=' + value;
  };

  this.trigger_event = function(event, data)
  {
    if (this.events[event])
      for (var i in this.events[event])
        this.events[event][i](data);
  };

  this.add_event_listener = function(event, func)
  {
    if (!this.events[event])
      this.events[event] = [];

    this.events[event].push(func);
  };


  /*********************************************************/
  /*********           GUI functionality           *********/
  /*********************************************************/

  // write to the document/window title
  this.set_pagetitle = function(title)
  {
    if (title && document.title)
      document.title = title;
  };

  // display a system message (types: loading, notice, error)
  this.display_message = function(msg, type, timeout)
  {
    var obj;

    if (!type)
      type = 'notice';
    if (msg)
      msg = this.t(msg);

    if (type == 'loading') {
      timeout = this.request_timeout * 1000;
      if (!msg)
        msg = this.t('loading');
    }
    else if (!timeout)
      timeout = this.message_time * (type == 'error' || type == 'warning' ? 2 : 1);

    obj = $('<div>');

    if (type != 'loading') {
      msg = '<div><span>' + msg + '</span></div>';
      obj.addClass(type).click(function() { return self.hide_message(); });
    }

    if (timeout > 0)
      window.setTimeout(function() { self.hide_message(type, type != 'loading'); }, timeout);

    if (type == 'loading')
      this.hide_message(type);

    obj.attr('id', type == 'loading' ? 'loading' : 'message')
      .appendTo('body').html(msg).show();
  };

  // make a message to disapear
  this.hide_message = function(type, fade)
  {
    if (type == 'loading')
      $('#loading').remove();
    else
      $('#message').fadeOut('normal', function() { $(this).remove(); });
  };

  this.set_watermark = function(id)
  {
    if (this.env.watermark)
      $('#'+id).html(this.env.watermark);
  }

  // modal dialog popup
  this.modal_dialog = function(content, buttons, opts)
  {
    var settings = {btns: {}},
      body = $('<div class="modal"></div>'),
      head, foot, footer = [];

    // title bar
    if (opts && opts.title)
      $('<div class="modal_header"></div>')
        .append($('<span>').text(opts.title))
        .appendTo(body);

    // dialog content
    if (typeof content != 'object')
      content = $('<div></div>').html(content);

    content.addClass('modal_msg').appendTo(body);

    // buttons
    $.each(buttons, function(i, v) {
      var n = i.replace(/[^a-z0-9_]/ig, '');
      settings.btns[n] = v;
      footer.push({name: n, label: self.t(i)});
    });

//    if (!settings.btns.cancel && (!opts || !opts.no_cancel))
//      settings.btns.cancel = function() { this.hide(); };

    if (footer.length) {
      foot = $('<div class="modal_btns"></div>');
      $.each(footer, function() {
        $('<div></div>').addClass('modal_btn_' + this.name).text(this.label).appendTo(foot);
      });

      body.append(foot);
    }

    // configure and display dialog
    body.wModal(settings).wModal('show');
  };

  this.tree_list_init = function()
  {
    $('table.list.tree span.expando').click(function() {
      var tr = $(this).parents('table.list.tree tr'),
        expanded = tr.hasClass('expanded'),
        level = tr.data('level') || 0,
        row = tr[0],
        found = false;

      tr[expanded ? 'removeClass' : 'addClass']('expanded');

      $('tr', tr.parent()).each(function() {
        if (this === row) {
          found = true;
          return;
        }

        if (!found)
          return;

        var r = $(this), l = r.data('level') || 0;

        if (l <= level)
          return false;

        if (!expanded && l == level+1)
          r.show();
        else if (expanded && l > level)
          r.hide().removeClass('expanded');
      });

      return false;
    });
  };

  // position and display popup
  this.popup_show = function(e, popup)
  {
    var popup = $(popup),
      pos = this.mouse_pos(e),
      win = $(window),
      w = popup.width(),
      h = popup.height(),
      left = pos.left - w,
      top = pos.top;

    if (top + h > win.height())
      top -= h;
    if (left + w > win.width())
      left -= w;

    popup.css({left: left + 'px', top: top + 'px'}).show();
    e.stopPropagation();
  };


  /********************************************************/
  /*********        Remote request methods        *********/
  /********************************************************/

  // compose a valid url with the given parameters
  this.url = function(action, query)
  {
    var k, param = {},
      querystring = typeof query === 'string' ? '&' + query : '';

    if (typeof action !== 'string')
      query = action;
    else if (!query || typeof query !== 'object')
      query = {};

    // overwrite task name
    if (action) {
      if (action.match(/^([a-z]+)/i))
        query.task = RegExp.$1;
      if (action.match(/[^a-z0-9-_]([a-z0-9-_]+)$/i))
        query.action = RegExp.$1;
    }

    // remove undefined values
    for (k in query) {
      if (query[k] !== undefined && query[k] !== null)
        param[k] = query[k];
    }

    return '?' + $.param(param) + querystring;
  };

  // send a http POST request to the server
  this.http_post = function(action, postdata)
  {
    var url = this.url(action);

    if (postdata && typeof postdata === 'object')
      postdata.remote = 1;
    else {
      if (!postdata)
        postdata = '';
      postdata += '&remote=1';
    }

    this.set_request_time();

    return $.ajax({
      type: 'POST', url: url, data: postdata, dataType: 'json',
      success: function(response) { kadm.http_response(response, action); },
      error: function(o, status, err) { kadm.http_error(o, status, err); }
    });
  };

  // send a http POST request to the API service
  this.api_post = function(action, postdata, func)
  {
    var url = 'api/' + action;

    if (!func) func = 'api_response';

    this.set_request_time();

    return $.ajax({
      type: 'POST', url: url, data: JSON.stringify(postdata), dataType: 'json',
      contentType: 'application/json; charset=utf-8',
      success: function(response) { kadm[func](response); },
      error: function(o, status, err) { kadm.http_error(o, status, err); }
    });
  };

  // handle HTTP response
  this.http_response = function(response, action)
  {
    var i;

    if (!response)
      return;

    // set env vars
    if (response.env)
      this.set_env(response.env);

    // we have translation labels to add
    if (typeof response.labels === 'object')
      this.tdef(response.labels);

    // HTML page elements
    if (response.objects)
      for (i in response.objects)
        $('#'+i).html(response.objects[i]);

    this.update_request_time();
    this.set_busy(false);

    // if we get javascript code from server -> execute it
    if (response.exec)
      eval(response.exec);

    response.action = action;
    this.trigger_event('http-response', response);
  };

  // handle HTTP request errors
  this.http_error = function(request, status, err)
  {
    var errmsg = request.statusText;

    this.set_busy(false);
    request.abort();

    if (request.status && errmsg)
      this.display_message(this.t('servererror') + ' (' + errmsg + ')', 'error');
  };

  this.api_response = function(response)
  {
    this.update_request_time();
    this.set_busy(false);

    if (!response || response.status != 'OK') {
      // Logout on invalid-session error
      if (response && response.code == 403)
        this.main_logout();
      else
        this.display_message(response && response.reason ? response.reason : this.t('servererror'), 'error');

      return false;
    }

    return true;
  };


  /*********************************************************/
  /*********     keyboard autocomplete methods     *********/
  /*********************************************************/

  this.ac_init = function(obj, props)
  {
    if (props && props.form) {
      if (i = $('[name="type_id"]', props.form).val())
        props.type_id = i;
      if (i = $('[name="object_type"]', props.form).val())
        props.object_type = i;
      if (i = $('[name="id"]', props.form).val())
        props.id = i;

      delete props['form'];
    }

    obj.keydown(function(e) { return kadm.ac_keydown(e, props); })
      .attr('autocomplete', 'off');
  };

  // handler for keyboard events on autocomplete-fields
  this.ac_keydown = function(e, props)
  {
    if (this.ac_timer)
      clearTimeout(this.ac_timer);

    var highlight, key = e.which;

    switch (key) {
      case 38:  // arrow up
      case 40:  // arrow down
        if (!this.ac_visible())
          break;

        var dir = key == 38 ? 1 : 0;

        highlight = $('.selected', this.ac_pane).get(0);

        if (!highlight)
          highlight = this.ac_pane.__ul.firstChild;

        if (highlight)
          this.ac_select(dir ? highlight.previousSibling : highlight.nextSibling);

        return e.stopPropagation();

      case 9:   // tab
        if (e.shiftKey || !this.ac_visible()) {
          this.ac_stop();
          return;
        }

      case 13:  // enter
        if (!this.ac_visible())
          return false;

        // insert selected item and hide selection pane
        this.ac_insert(this.ac_selected);
        this.ac_stop();

        e.stopPropagation();
        return false;

      case 27:  // escape
        this.ac_stop();
        return;

      case 37:  // left
      case 39:  // right
        if (!e.shiftKey)
          return;
    }

    // start timer
    this.ac_timer = window.setTimeout(function() { kadm.ac_start(props); }, 500);
    this.ac_input = e.target;

    return true;
  };

  this.ac_visible = function()
  {
    return (this.ac_selected !== null && this.ac_selected !== undefined && this.ac_value);
  };

  this.ac_select = function(node)
  {
    if (!node)
      return;

    var current = $('.selected', this.ac_pane);

    if (current.length)
      current.removeClass('selected');

    $(node).addClass('selected');
    this.ac_selected = node._id;
  };

  // autocomplete search processor
  this.ac_start = function(props)
  {
    var q = this.ac_input ? this.ac_input.value : null,
      min = this.env.autocomplete_min_length,
      old_value = this.ac_value,
      ac = this.ac_data;

    if (q === null)
      return;

    // trim query string
    q = $.trim(q);

    // Don't (re-)search if the last results are still active
    if (q == old_value)
      return;

    // Stop and destroy last search
    this.ac_stop();

    if (q.length && q.length < min) {
      this.display_message(this.t('search.acchars').replace('$min', min), 'notice', 2000);
      return;
    }

    this.ac_value = q;

    // ...string is empty
    if (!q.length)
      return;

    // ...new search value contains old one, but the old result was empty
    if (old_value && old_value.length && q.indexOf(old_value) == 0 && this.ac_result && !this.ac_result.length)
      return;

    var i, xhr, data = props,
      action = props && props.action ? props.action : 'form_value.list_options';

    this.ac_oninsert = props.oninsert;
    data.search = q;
    delete data['action'];
    delete data['insert_func'];

    this.display_message(this.t('search.loading'), 'loading');
    xhr = this.api_post(action, data, 'ac_result');
    this.ac_data = xhr;
  };

  this.ac_result = function(response)
  {
    // search stopped in meantime?
    if (!this.ac_value)
      return;

    if (!this.api_response(response))
      return;

    // ignore this outdated search response
    if (this.ac_input && response.result.search != this.ac_value)
      return;

    // display search results
    var i, ul, li, text,
      result = response.result.list,
      pos = $(this.ac_input).offset(),
      value = this.ac_value,
      rx = new RegExp('(' + RegExp.escape(value) + ')', 'ig');

    // create results pane if not present
    if (!this.ac_pane) {
      ul = $('<ul>');
      this.ac_pane = $('<div>').attr('id', 'autocompletepane')
        .css({ position:'absolute', 'z-index':30000 }).append(ul).appendTo(document.body);
      this.ac_pane.__ul = ul[0];
    }

    ul = this.ac_pane.__ul;

    // reset content
    ul.innerHTML = '';
    // move the results pane right under the input box
    this.ac_pane.css({left: (pos.left - 1)+'px', top: (pos.top + this.ac_input.offsetHeight - 1)+'px', display: 'none'});

    // add each result line to the list
    for (i in result) {
      text = result[i];
      li = document.createElement('LI');
      li.innerHTML = text.replace(rx, '##$1%%').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/##([^%]+)%%/g, '<b>$1</b>');
      li.onmouseover = function() { kadm.ac_select(this); };
      li.onmouseup = function() { kadm.ac_click(this) };
      li._id = i;
      ul.appendChild(li);
    }

    if (ul.childNodes.length) {
      this.ac_pane.show();

      // select the first
      li = $('li:first', ul);
      li.addClass('selected');
      this.ac_selected = li.get(0)._id;
    }

    this.env.ac_result = result;
  };

  this.ac_click = function(node)
  {
    if (this.ac_input)
      this.ac_input.focus();

    this.ac_insert(node._id);
    this.ac_stop();
  };

  this.ac_insert = function(id)
  {
    var val = this.env.ac_result[id];

    if (typeof this.ac_oninsert == 'function')
      this.ac_oninsert(id, val);
    else
      $(this.ac_input).val(val);
  };

  this.ac_blur = function()
  {
    if (this.ac_timer)
      clearTimeout(this.ac_timer);

    this.ac_input = null;
    this.ac_stop();
  };

  this.ac_stop = function()
  {
    this.ac_selected = null;
    this.ac_value = '';

    if (this.ac_pane)
      this.ac_pane.hide();

    this.ac_destroy();
  };

  // Clears autocomplete data/requests
  this.ac_destroy = function()
  {
    if (this.ac_data)
      this.ac_data.abort();

    this.ac_data = null;
    this.ac_info = null;
  };


  /*********************************************************/
  /*********            Forms widgets              *********/
  /*********************************************************/

  // Form initialization
  this.form_init = function(id)
  {
    var form = $('#'+id),
      aci_fields = $('textarea[data-type="aci"]', form);

    this.aci = {};
    this.acl = {};
    this.trigger_event('form-load', id);

    // replace some textarea fields with pretty/smart input lists
    $('textarea[data-type="list"]', form)
      .each(function() { kadm.form_list_element_wrapper(this); });
    // create smart select fields
    $('input[data-type="select"]', form)
      .each(function() { kadm.form_select_element_wrapper(this); });
    // create LDAP URL fields
    $('input[data-type="ldap_url"]:not(:disabled):not([readonly])', form)
      .each(function() { kadm.form_url_element_wrapper(this); });
    // create IMAP ACL fields
    $('textarea[data-type="acl"]', form)
      .each(function() { kadm.form_acl_element_wrapper(this); });
    // create ACI fields
    aci_fields.each(function() { kadm.form_aci_element_wrapper(this); });
    if (aci_fields.length)
      this.form_aci_init();
  };

  // Form serialization
  this.form_serialize = function(data)
  {
    var form = $(data.id);

    // smart list fields
    $('textarea[data-type="list"]:not(:disabled)', form).each(function() {
      var i, v, value = [],
        re = RegExp('^' + RegExp.escape(this.name) + '\[[0-9-]+\]$');

      for (i in data.json) {
        if (i.match(re)) {
          if (v = $('input[name="'+i+'"]', form).val())
            value.push(v);
          delete data.json[i];
        }
      }

      // autocompletion lists data is stored in env variable
      if (kadm.env.assoc_fields[this.name]) {
        value = [];
        for (i in kadm.env.assoc_fields[this.name])
          value.push(i);
      }

      data.json[this.name] = value;
    });

    // smart selects
    $('input[data-type="select"]', form).each(function() {
      delete data.json[this.name];
    });

    // LDAP URL fields
    $('input[data-type="ldap_url"]:not(:disabled):not([readonly])', form).each(function() {
      data.json = kadm.form_url_element_submit(this.name, data.json, form);
    });

    // IMAP ACL fields
    $('textarea[data-type="acl"]:not(:disabled):not([readonly])', form).each(function() {
      data.json = kadm.form_acl_element_submit(this.name, data.json, form);
    });

    // ACI fields
    $('textarea[data-type="aci"]:not(:disabled):not([readonly])', form).each(function() {
      data.json = kadm.form_aci_element_submit(this.name, data.json, form);
    });

    // text-separated fields (convert text into array)
    $('textarea[data-type="separated"]:not(:disabled)', form).each(function() {
      data.json[this.name] = data.json[this.name] ? data.json[this.name].split(/[\r\n]+/) : '';
    });

    // quota inputs
    $('input[data-type="quota"]', form).each(function() {
      var unit = $('select[name="' + this.name + '-unit"]').val();
      if (unit && this.value)
        data.json[this.name] = this.value + unit;
      delete data.json[this.name + '-unit'];
    });

    // "boolean" checkbox inputs
    $('input[type="checkbox"][value="TRUE"]', form).each(function() {
      data.json[this.name] = this.checked ? 'TRUE' : 'FALSE';
    });

    return data;
  };

  // Form element update handler
  this.form_element_update = function(data)
  {
    var elem = $('[name="'+data.name+'"]');

    if (!elem.length)
      return;

    if (elem.attr('data-type') == 'list') {
      // remove old wrapper
      $('span[class="listarea"]', elem.parent()).remove();
      // insert new list element
      this.form_list_element_wrapper(elem.get(0));
    }
  };

  // Replaces form element with smart list element
  this.form_list_element_wrapper = function(form_element)
  {
    var i = 0, j = 0, list = [], elem, e = $(form_element),
      form = form_element.form,
      disabled = e.attr('disabled'),
      readonly = e.attr('readonly'),
      autocomplete = e.attr('data-autocomplete'),
      maxlength = e.attr('data-maxlength'),
      maxcount = e.attr('data-maxcount'),
      area = $('<span class="listarea"></span>');

    e.hide();

    if (autocomplete)
      list = this.env.assoc_fields ? this.env.assoc_fields[form_element.name] : [];
    else if (form_element.value)
      list = form_element.value.split("\n");

    // Need at least one element
    if (!autocomplete || disabled || readonly) {
      $.each(list, function() { i++; });
      if (!i)
        list = [''];
    }

    // Create simple list for readonly/disabled
    if (disabled || readonly) {
      area.addClass('readonly');

      // add simple input rows
      $.each(list, function(i, v) {
        var elem = $('<input>');
        elem.attr({
          value: v,
          disabled: disabled,
          readonly: readonly,
          name: form_element.name + '[' + (j++) + ']'
          })
        elem = $('<span class="listelement">').append(elem);
        elem.appendTo(area);
      });
    }
    // extended widget with add/remove buttons and/or autocompletion
    else {
      // add autocompletion input
      if (autocomplete) {
        elem = this.form_list_element(form, {
          maxlength: maxlength,
          autocomplete: autocomplete,
          element: e
        }, -1);

        // Initialize autocompletion
        this.ac_init(elem, {
          form: form,
          attribute: form_element.name,
          oninsert: this.form_element_oninsert
        });

        // when max=1 we use only one input
        if (maxcount == 1) {
          $.each(list, function(i, v) {
            $('input', elem).val(v);
            return false;
          });

          list = [];
        }

        elem.appendTo(area);
        area.addClass('autocomplete');
      }

      // add input rows
      $.each(list, function(i, v) {
        var elem = kadm.form_list_element(form, {
          value: v,
          key: i,
          maxlength: maxlength,
          autocomplete: autocomplete,
          element: e
        }, j++);

        elem.appendTo(area);
      });
    }

    area.appendTo(form_element.parentNode);
  };

  // Creates smart list element
  this.form_list_element = function(form, data, idx)
  {
    var content, elem, input,
      key = data.key,
      orig = data.element
      ac = data.autocomplete;

    data.name = (orig ? orig.attr('name') : data.name) + '[' + idx + ']';
    data.readonly = (ac && idx >= 0);

    // remove internal attributes
    delete data['element'];
    delete data['autocomplete'];
    delete data['key'];

    // build element content
    content = '<span class="listelement"><span class="actions">'
      + (!ac ? '<span title="" class="add"></span>' : ac && idx == -1 ? '<span title="" class="search"></span>' : '')
      + (!ac || idx >= 0 ? '<span title="" class="reset"></span>' : '')
      + '</span><input type="text" autocomplete="off"></span>';

    elem = $(content);
    input = $('input', elem);

    // Set INPUT attributes
    input.attr(data);

    if (data.readonly)
      input.addClass('readonly');
    if (ac)
      input.addClass('autocomplete');

    // attach element creation event
    if (!ac)
      $('span[class="add"]', elem).click(function() {
        var name = data.name.replace(/\[[0-9]+\]$/, ''),
          span = $(this.parentNode.parentNode),
          maxcount = $('textarea[name="'+name+'"]').attr('data-maxcount');

        // check element count limit
        if (maxcount && maxcount <= span.parent().children().length) {
          alert(kadm.t('form.maxcount.exceeded'));
          return;
        }

        var dt = (new Date()).getTime(),
          elem = kadm.form_list_element(form, {name: name}, dt);

        kadm.ac_stop();
        span.after(elem);
        $('input', elem).focus();
      });

    // attach element deletion event
    if (!ac || idx >= 0)
      $('span[class="reset"]', elem).click(function() {
        var span = $(this.parentNode.parentNode),
          name = data.name.replace(/\[[0-9]+\]$/, ''),
          l = $('input[name^="' + name + '["]', form),
          key = $(this).data('key');

        if (l.length > 1 || $('input[name="' + name + '"]', form).attr('data-autocomplete'))
          span.remove();
        else
          $('input', span).val('').focus();

        // delete key from internal field representation
        if (key !== undefined && kadm.env.assoc_fields[name])
          delete kadm.env.assoc_fields[name][key];

        kadm.ac_stop();
      }).data('key', key);

    return elem;
  };

  this.form_element_oninsert = function(key, val)
  {
    var elem, input = $(this.ac_input).get(0),
      dt = (new Date()).getTime(),
      span = $(input.parentNode),
      name = input.name.replace(/\[-1\]$/, ''),
      af = kadm.env.assoc_fields,
      maxcount = $('textarea[name="'+name+'"]').attr('data-maxcount');

    if (maxcount == 1) {
      $(input).val(val);
      af[name] = {};
      af[name][key] = val;
      return;
    }

    // reset autocomplete input
    input.value = '';

    // check element count limit
    if (maxcount && maxcount <= span.parent().children().length - 1) {
      alert(kadm.t('form.maxcount.exceeded'));
      return;
    }

    // check if element doesn't exist on the list already
    if (!af[name])
      af[name] = {};
    if (af[name][key])
      return;

    // add element
    elem = kadm.form_list_element(input.form, {
      name: name,
      autocomplete: true,
      value: val
      }, dt);
    span.after(elem);

    // update field variable
    af[name][key] = val;
  };

  // Replaces form element with smart select element
  this.form_select_element_wrapper = function(form_element)
  {
    var e = $(form_element),
      form = form_element.form,
      name = form_element.name,
      elem = $('#selectlabel_' + name),
      area = $('<span class="listarea autocomplete select popup" id="selectarea_' + name + '"></span>'),
      content = $('<span class="listcontent" id="selectcontent_' + name + '"></span>'),
      list = this.env.assoc_fields ? this.env.assoc_fields[form_element.name] : [];

    if (elem.length) {
      $('#selectarea_' + name).remove();
      $('#selectcontent_' + name).remove();
    }
    else {
      elem = $('<span class="link" id="selectlabel_' + name + '"></span>')
        .css({cursor: 'pointer'})
        .click(function(e) {
          var popup = $('span.listarea', this.parentNode);
          kadm.popup_show(e, popup);
          $('input', popup).val('').focus();
          $('span.listcontent > span.listelement', popup).removeClass('selected').show();
        })
        .appendTo(form_element.parentNode);
    }

    elem.text(e.val());

    if (list.length <= 1)
      return;

    if (form_element.type != 'hidden') e.hide();

    elem = this.form_list_element(form, {
      autocomplete: true,
      element: e
    }, -1);

    elem.appendTo(area);
    content.appendTo(area);
    area.hide().appendTo(form_element.parentNode);

    // popup events
    $('input', area)
      .click(function(e) {
        // stop click on the popup
        e.stopPropagation();
      })
      .keypress(function(e) {
        // prevent form submission with Enter key
        if (e.which == 13)
          e.preventDefault();
      })
      .keydown(function(e) {
        // block Up/Down arrow keys,
        // in Firefox Up arrow moves cursor left
        if (e.which == 38 || e.which == 40)
          e.preventDefault();
      })
      .keyup(function(e) {
        // filtering
        var s = this.value,
          options = $('span.listcontent > span.listelement', area);

        // Enter key
        if (e.which == 13) {
          options.filter('.selected').click()
          return;
        }
        // Escape
        else if (e.which == 27) {
          area.hide();
          this.value = s = '';
        }
        // UP/Down arrows
        else if (e.which == 38 || e.which == 40) {
          options = options.not(':hidden');

          if (options.length <= 1)
            return;

          var focused,
            selected = options.filter('.selected'),
            index = options.index(selected);

          if (e.which == 40) {
            if (!(focused = options.get(index+1)))
              focused = options.get(index-1);
          }
          else {
            if (!(focused = options.get(index-1)))
              focused = options.get(index+1);
          }

          if (focused) {
            focused = $(focused);
            selected.removeClass('selected');
            focused.addClass('selected');

            var parent = focused.parent(),
              parent_height = parent.height(),
              parent_top = parent.get(0).scrollTop,
              top = focused.offset().top - parent.offset().top,
              height = focused.height();

            if (top < 0)
              parent.get(0).scrollTop = 0;
            else if (top >= parent_height)
              parent.get(0).scrollTop = top - parent_height + height + parent_top;
          }

          return;
        }

        if (!s) {
          options.show().removeClass('selected');
          return;
        }

        options.each(function() {
          var o = $(this), v = o.data('value');
          o[v.indexOf(s) != -1 ? 'show' : 'hide']().removeClass('selected');
        });

        options = options.not(':hidden');
        if (options.length == 1)
          options.addClass('selected');
      });

    // add option rows
    $.each(list, function(i, v) {
      var elem = kadm.form_select_option_element(form, {value: v, key: v, element: e});
      elem.appendTo(content);
    });
  };

  // Creates option element for smart select
  this.form_select_option_element = function(form, data)
  {
    // build element content
    var elem = $('<span class="listelement"></span>')
      .data('value', data.key).text(data.value)
      .click(function(e) {
        var val = $(this).data('value'),
          elem = $(data.element),
          old_val = elem.val();

        $('span.link', elem.parent()).text(val);
        elem.val(val);
        if (val != old_val)
          elem.change();
      });

    return elem;
  };

  // initialize ACI fields in form
  this.form_aci_init = function()
  {
    // get list of ldap attributes for ACI form
    if (!this.ldap_attributes) {
      this.api_post('form_value.select_options', {attributes: ['attribute']}, 'form_aci_init_response');
    }
  };

  this.form_aci_init_response = function(response)
  {
    if (!this.api_response(response))
      return;

    this.ldap_attributes = response.result.attribute ? response.result.attribute.list : [];
  };

  // Replaces form element with ACI element
  this.form_aci_element_wrapper = function(form_element)
  {
    var i, e = $(form_element),
      form = form_element.form,
      name = form_element.name,
      div = $('<div class="aci"></div>'),
      select = $('<select multiple="multiple" size="8"></select>'),
      table = $('<table class="acltable"><tr><td class="list"></td><td class="buttons"></td></tr></table>'),
      buttons = [
        $('<input type="button" />').attr({value: this.t('aci.new')}),
        $('<input type="button" />').attr({value: this.t('aci.edit'), disabled: true}),
        $('<input type="button" />').attr({value: this.t('aci.remove'), disabled: true})
      ],
      aci = this.parse_aci(e.val()) || [];
    this.aci[name] = aci;
    e.hide();

    // this.log(e.val());
    // this.log(aci);

    $.each(aci, function(i, entry) {
      $('<option></option>').val(i).text(entry.name).appendTo(select)
        .on('dblclick', function () { self.form_aci_dialog(name, this.value); });
    });

    select.attr('id', 'aci'+name).on('change', function() {
      var selected = $(this).val() || [];

      buttons[1].prop('disabled', selected.length != 1);
      buttons[2].prop('disabled', selected.length == 0);
    });

    // click on 'new' and 'edit' button
    buttons[0].on('click', function() { self.form_aci_dialog(name); });
    buttons[1].on('click', function() {
      var selected = select.val();
      self.form_aci_dialog(name, selected && selected.length ? selected[0] : null);
    });

    // click on 'remove' button
    buttons[2].on('click', function() {
      $.each(select.val() || [], function(i, v) {
        self.aci[name][v] = null;
        $('option[value="' + v + '"]', select).remove();
      });
      buttons[1].prop('disabled', true);
      buttons[2].prop('disabled', true);
    });

    $('.buttons', table).append(buttons);
    $('.list', table).append(select);
    div.append(table)

    $(form_element).parent().append(div);
  };

  // updates form data with ACI (on form submit)
  this.form_aci_element_submit = function(name, data, form)
  {
    data[name] = this.build_aci(this.aci[name]);

    return data;
  };

  // display aci dialog
  this.form_aci_dialog = function(name, id)
  {
    var aci = id ? this.aci[name][id] : {};

    this.aci_dialog_aci  = aci;
    this.aci_dialog_name = name;
    this.aci_dialog_id   = id;

    this.modal_dialog(this.form_aci_dialog_content(aci), this.form_aci_dialog_buttons());

    window.setTimeout(function() { $('#aci-name').focus(); }, 100);
  };

  // return aci dialog buttons
  this.form_aci_dialog_buttons = function()
  {
    var buttons = {
      'button.ok': function() {
        if (self.form_aci_dialog_submit()) {
          this.hide();
          $('#aci-dialog').remove();
        }
      },
      'button.cancel': function() {
        this.hide();
        $('#aci-dialog').remove();
      },
    };

    return buttons;
  };

  // build and return aci dialog content
  this.form_aci_dialog_content = function(aci)
  {
    var dialog = $('#aci-dialog');

    if (!dialog.length) {
      var i, tabs = [
        $('<fieldset></fieldset>').attr('id', 'aci-tab-users')
          .append($('<legend></legend>').text(this.t('aci.users')))
          .append(this.form_aci_dialog_tab_users()),
        $('<fieldset></fieldset>').attr('id', 'aci-tab-rights')
          .append($('<legend></legend>').text(this.t('aci.rights')))
          .append(this.form_aci_dialog_tab_rights()),
        $('<fieldset></fieldset>').attr('id', 'aci-tab-targets')
          .append($('<legend></legend>').text(this.t('aci.targets')))
          .append(this.form_aci_dialog_tab_targets())
      ];

      dialog = $('<div id="aci-dialog"><label></label><input id="aci-name" type="text" size="40" />'
          + '<form id="aci-form"></form></div>')
        .hide().appendTo('body');

      dialog.children('label').text(this.t('aci.aciname'));

      $('#aci-form').append(tabs);

      this.trigger_event('form-load', 'aci-form');
    }

    // reset form elements
    this.form_aci_dialog_reset(aci);

    return dialog.show();
  };

  this.form_aci_dialog_reset = function(aci)
  {
    var users = $('#aci-users').html(''),
      rights = aci.perms ? aci.perms[0].rights : [],
      inputs = $('#aci-rights input').prop('checked', false),
      target = $('#aci-targets-target').val(''),
      target_filter = $('#aci-targets-filter').val(''),
      target_operator = $('#aci-targets input[name="attr-operator"]'),
      rule = aci.perms ? aci.perms[0].type : 'userdn';

    $.each(rights, function(i, v) {
      $('#aci-rights-' + v).click();
    });

    $('#aci-name').val(aci.name);
    $('#aci-rights-type').val(aci.perms ? aci.perms[0].type : '');
    $('#aci-users-button-remove').prop('disabled', true);
    target_operator.filter('[value="="]').prop('checked', true);
    target_operator.filter('[value="!="]').prop('checked', false);

    $.each(aci.perms ? aci.perms : [], function(i, perm) {
      $.each(perm.rules || [], function(n, rule) {
        // these permission rules we do not support here
        if (!/^(userdn|groupdn|roledn)$/i.test(rule.keyword) || rule.operator != '=')
          return;

        $.each(rule.expression || [], function(x, v) {
          if (v.substr(0, 8) == 'ldap:///') {
            v = v.substr(8);
          }

          var t = v;
          if (t == 'all' || t == 'self' || t == 'anyone' || t == 'parent')
            t = self.t('aci.ldap-' + t);
          else if (/^cn=([^,]+)/.test(t))
            t = RegExp.$1;
          // @TODO: resolve users DN with user names

          $('<option></option>').attr({value: rule.keyword + ':' + v}).text(t).appendTo(users);
        });
      });
    });

    $.each(aci.targets || [], function(i, v) {
      switch (v.type) {
        case 'targetfilter':
          target_filter.val(v.expression);
          break;

        case 'targetattr':
          if (v.expression[0] == '*')
            $('#aci-targets-attr option').prop('selected', true);
          else
            $('#aci-targets-attr').val(v.expression);

          target_operator.filter('[value="="]').prop('checked', v.operator == '=');
          target_operator.filter('[value="!="]').prop('checked', v.operator == '!=');
          break;

        case 'target':
          target.val(v.expression);
          break;
      }
    });
  };

  // submits aci dialog, updates aci definition in form
  this.form_aci_dialog_submit = function()
  {
    var val, rules = [], rights = [],
      name_input = $('#aci-name'),
      name = name_input.val(),
      rights_type = $('#aci-rights-type').val(),
      aci_list = $('#aci' + this.aci_dialog_name),
      exists = false,
      aci = {perms: [], targets: [], version: '3.0', name: name};

    // sanity checks
    if (!name) {
      alert(this.t('aci.error.noname'));
      name_input.focus();
      return false;
    }

    $.each(this.aci[self.aci_dialog_name] || [], function(i, v) {
      if (v && v.name == name && (!self.aci_dialog_id || self.aci_dialog_id != i)) {
        exists = true;
        return false;
      }
    });

    if (exists) {
      alert(this.t('aci.error.exists'));
      name_input.focus();
      return false;
    }

    // permissions
    $('#aci-users option').each(function() {
      var keyword, value = this.value;

      /^([a-z]+):/.test(value);
      keyword = RegExp.$1;
      value   = value.substr(keyword.length + 1);

      rules.push({
        join: 'or',
        operator: '=',
        keyword: keyword,
        expression: ['ldap:///' + value]
      });
    });

    if (!rules.length) {
      alert(this.t('aci.error.nousers'));
      return false;
    }

    $('#aci-rights input').each(function() {
      if (this.checked) {
        if (this.value == 'all') {
          rights = ['all'];
          return false;
        }

        rights.push(this.value);
      }
    });

    if (!rights.length) {
      rights = ['all'];
      rights_type = rights_type == 'allow' ? 'deny' : 'allow';
    }

    aci.perms.push({
      rights: rights,
      type: rights_type,
      rules: rules
    });

    // targets
    if ((v = $('#aci-targets-attr').val() || []).length)
      aci.targets.push({
        type: 'targetattr',
        expression: v.length == $('#aci-targets-attr option').length ? ['*'] : v,
        operator: $('#aci-targets input[name="attr-operator"][value="!="]').is(':checked') ? '!=' : '=',
      });

    if (v = $('#aci-targets-target').val())
      aci.targets.push({
        type: 'target',
        expression: v,
        operator: '='
      });

    if (v = $('#aci-targets-filter').val())
      aci.targets.push({
        type: 'targetfilter',
        expression: v,
        operator: '=' // @TODO,
      });

    // this.log(aci);
    // this.log(this.build_aci([aci]));

    if (this.aci_dialog_id) {
      this.aci[this.aci_dialog_name][this.aci_dialog_id] = aci;
      $('option[value="' + this.aci_dialog_id + '"]', aci_list).text(aci.name);
    }
    else {
      this.aci[this.aci_dialog_name].push(aci);
      $('<option></option>').val(this.aci[this.aci_dialog_name].length-1)
        .text(aci.name)
        .appendTo(aci_list)
        .on('dblclick', function () { self.form_aci_dialog(self.aci_dialog_name, this.value); });
    }

    return true;
  };

  // tab Users in aci dialog
  this.form_aci_dialog_tab_users = function()
  {
    var select = $('<select id="aci-users" multiple="multiple" size="8"></select>'),
      table = $('<table class="acltable"><tr><td class="list"></td><td class="buttons"></td></tr></table>'),
      buttons = [
        $('<input type="button" />').attr({value: this.t('aci.new')}),
        $('<input type="button" id="aci-users-button-remove" />').attr({value: this.t('aci.remove'), disabled: true})
      ];

    select.on('change', function() {
      var selected = $(this).val() || [];
      buttons[1].attr('disabled', selected.length == 0);
    });

    // click on 'new' button
    buttons[0].on('click', function() { self.form_aci_user_dialog(); });

    // click on 'remove' button
    buttons[1].on('click', function() {
      $.each(select.val() || [], function(i, v) {
        $('option[value="' + v + '"]', select).remove();
      });

      $(this).prop('disabled', true);
    });

    $('.buttons', table).append(buttons);
    $('.list', table).append(select);

    return table;
  };

  // tab Rights in aci dialog
  this.form_aci_dialog_tab_rights = function()
  {
    var div = $('<div id="aci-rights"></div>'),
      select = $('<select id="aci-rights-type"></select>'),
      types = ['allow', 'deny'],
      rights = ['read', 'compare', 'search', 'write', 'selfwrite', 'delete', 'add', 'proxy', 'all'],
      inputs = [];

    $.each(rights, function(i, v) {
      var input = $('<input type="checkbox" name="aci-right[]" />').attr({value: v, id: 'aci-rights-' + v});
      inputs.push($('<label for="aci-rights-' + v + '"></label>').text(self.t('aci.' + v)).prepend(input));

      if (v == 'all')
        input.on('change', function() {
          var list = $('input:not(#aci-rights-all)', div);

          if (this.checked)
            list.prop({checked: true, disabled: true});
          else
            list.prop({disabled: false});
        });
    });

    $.each(types, function(i, v) {
      $('<option></option>').attr({value: v}).text(self.t('aci.' + v)).appendTo(select);
    });

    return div.append(select).append(inputs);
  };

  // tab Targets in aci dialog
  this.form_aci_dialog_tab_targets = function()
  {
    var opts = [],
      content = $('<div id="aci-targets"></div>'),
      target = $('<input id="aci-targets-target" type="text" size="40" />'),
      filter = $('<input id="aci-targets-filter" type="text" size="40" />'),
      button = $('<input type="button" id="aci-targets-targetbtn" />').val(this.t('aci.thisentry'))
        .on('click', function() { target.val('ldap:///' + self.env.entrydn); }),
      select = $('<select id="aci-targets-attr" multiple="multiple" size="8"></select>'),
      radio = [
        $('<label>').text(this.t('aci.selected')).prepend($('<input type="radio" name="attr-operator" value="=" />')),
        $('<label>').text(this.t('aci.other')).prepend($('<input type="radio" name="attr-operator" value="!=" />'))
      ];

    $.each(this.ldap_attributes, function(i, v) {
      var o = document.createElement('option');
      o.value = v.toLowerCase();
      $(o).text(v);
      opts.push(o);
    });

    if (opts.length)
      select.append(opts);

    content.append([
      $('<label>').text(this.t('aci.rights.target')), $('<div>').append([target, button]),
      $('<label>').text(this.t('aci.rights.filter')), $('<div>').append(filter),
      $('<label>').text(this.t('aci.rights.attrs')), $('<div>').append([select, radio[0], radio[1]])
    ]);

    return content;
  };

  this.form_aci_user_dialog = function()
  {
    var dialog = $('#aci-dialog'),
      content = $('<div id="aci-users-dialog"></div>'),
      search = $('<input id="aci-users-search" type="text" />'),
      search_btn = $('<input id="aci-users-search-button" type="button" />')
        .val(this.t('aci.search')).on('click', function() { self.form_aci_user_search(); }),
      results = $('<select id="aci-users-results" multiple="multiple" size="6"></select>'),
      selected = $('<select id="aci-users-selected" multiple="multiple" size="6"></select>'),
      groups = $('<select id="aci-users-group"></select>')
        .on('change', function() {
          results.html('');
          if (this.value == 'specials')
            $.each(['self', 'all', 'anyone', 'parent'], function(i, v) {
              if (!$('option[value="userdn:' + v + '"]', selected).length)
                $('<option></option>').attr({value: 'userdn:' + v}).text(self.t('aci.ldap-' + v))
                  .appendTo(results)
                  .on('dblclick', function() { self.form_aci_user_option_dblclick(this); });
            });
        }),
      options = ['users', 'groups', 'roles', /* 'admins', */ 'specials'],
      buttons = {
        'button.ok': function() {
          self.form_aci_user_dialog_submit();
          this.hide();
          $('#aci-users-dialog').remove();
          // bring back the main dialog
          self.modal_dialog(dialog, self.form_aci_dialog_buttons());
        },
        'button.cancel': function() {
          this.hide();
          $('#aci-users-dialog').remove();
          // bring back the main dialog
          self.modal_dialog(dialog, self.form_aci_dialog_buttons());
        }
      };

    $.each(options, function(i, v) {
      $('<option></option>').attr({value: v}).text(self.t('aci.type' + v)).appendTo(groups);
    });

    content.append([
      $('<label>').text(this.t('aci.usersearch')), $('<div>').append([search, groups, search_btn]),
      $('<label>').text(this.t('aci.usersearchresult')), $('<div>').append(results),
      $('<label>').text(this.t('aci.userselected')), $('<div>').append(selected)
    ]);

    this.modal_dialog(content, buttons);
  };

  this.form_aci_user_dialog_submit = function()
  {
    var user_list = $('#aci-users');

    $('#aci-users-selected option').each(function() {
      if (!$('option[value="' + this.value + '"]', user_list).length)
        $('<option></option>').attr({value: this.value}).text($(this).text()).appendTo(user_list);
    });
  };

  this.form_aci_user_search = function()
  {
    var search = $('#aci-users-search').val(),
      type = $('#aci-users-group').val(),
      val, props, attrs = {
        users: ['displayname', 'cn'],
        groups: ['cn'],
        roles: ['cn'],
      };

    if (search == '')
      return;

    if (type == 'specials') {
      $('#aci-users-results option').each(function() {
        $(this)[$(this).text().indexOf(search) == -1 ? 'hide' : 'show'];
      });
      return;
    }

    // reset results select
    $('#aci-users-results').html('');

    // build search post parameters
    val = {type: 'both', value: search};
    props = {attributes: ['cn', 'mail'], page_size: 10, sort_by: 'cn', search: {}};
    $.each(attrs[type], function(i, v) { props.search[v] = val; });

    // call search
    this.set_busy(true, 'searching');
    this.api_post(type + '.list', props, 'form_aci_user_search_response');
  };

  this.form_aci_user_search_response = function(response)
  {
    if (!this.api_response(response))
      return;

    var results = $('#aci-users-results'),
      selected = $('#aci-users-selected'),
      type = $('#aci-users-group').val(),
      prefixes = {users: 'userdn:', groups: 'groupdn:', roles: 'roledn:'},
      prefix = prefixes[type] || prefixes.users;

    $.each(response.result.list || {}, function(i, v) {
      var value = prefix + i;
      if (!$('option[value="' + value + '"]', selected).length) {
        name = v.cn;

        if (v.mail)
          name += ' (' + v.mail + ')';

        $('<option></option>').attr({value: value}).text(name)
          .appendTo(results)
          .on('dblclick', function() { self.form_aci_user_option_dblclick(this); });
      }
    });
  };

  this.form_aci_user_option_dblclick = function(elem)
  {
    var elem = $(elem), cloned = elem.clone(true),
      target = $('#aci-users-' + (elem.parent().attr('id') == 'aci-users-results' ? 'selected' : 'results'));

    if (!$('option[value="' + elem.val() + '"]', target).length) {
      cloned.appendTo(target);
      elem.remove();
    }
  };

  // Replaces form element with IMAP ACL element
  this.form_acl_element_wrapper = function(form_element)
  {
    var i, e = $(form_element),
      form = form_element.form,
      name = form_element.name,
      div = $('<div class="acl"></div>'),
      select = $('<select multiple="multiple" size="8"></select>'),
      table = $('<table class="acltable"><tr><td class="list"></td><td class="buttons"></td></tr></table>'),
      buttons = [
        $('<input type="button" />').attr({value: this.t('aci.new')}),
        $('<input type="button" />').attr({value: this.t('aci.edit'), disabled: true}),
        $('<input type="button" />').attr({value: this.t('aci.remove'), disabled: true})
      ],
      acl = this.parse_acl(e.val()) || [];

    this.acl[name] = acl;
    e.hide();

    // this.log(e.val());
    // this.log(acl);

    $.each(acl, function(i, entry) {
      $('<option></option>').val(i).text(entry.subject).appendTo(select)
        .on('dblclick', function () { self.form_acl_dialog(name, this.value); });
    });

    select.attr('id', 'acl'+name).on('change', function() {
      var selected = $(this).val() || [];

      buttons[1].prop('disabled', selected.length != 1);
      buttons[2].prop('disabled', selected.length == 0);
    });

    // click on 'new' and 'edit' button
    buttons[0].on('click', function() { self.form_acl_dialog(name); });
    buttons[1].on('click', function() {
      var selected = select.val();
      self.form_acl_dialog(name, selected && selected.length ? selected[0] : null);
    });

    // click on 'remove' button
    buttons[2].on('click', function() {
      $.each(select.val() || [], function(i, v) {
        self.acl[name][v] = null;
        $('option[value="' + v + '"]', select).remove();
      });
      buttons[1].prop('disabled', true);
      buttons[2].prop('disabled', true);
    });

    $('.buttons', table).append(buttons);
    $('.list', table).append(select);
    div.append(table)

    $(form_element).parent().append(div);
  };

  // updates form data with IMAP ACL (on form submit)
  this.form_acl_element_submit = function(name, data, form)
  {
    data[name] = this.build_acl(this.acl[name]);

    return data;
  };

  // display IMAP ACL dialog
  this.form_acl_dialog = function(name, id)
  {
    var acl = id ? this.acl[name][id] : {};

    this.acl_dialog_acl  = acl;
    this.acl_dialog_name = name;
    this.acl_dialog_id   = id;

    this.modal_dialog(this.form_acl_dialog_content(acl), this.form_acl_dialog_buttons());

    window.setTimeout(function() { $('#acl-subject').focus(); }, 100);
  };

  // return IMAP ACL dialog buttons
  this.form_acl_dialog_buttons = function()
  {
    var buttons = {
      'button.ok': function() {
        if (self.form_acl_dialog_submit()) {
          this.hide();
          $('#acl-dialog').remove();
        }
      },
      'button.cancel': function() {
        this.hide();
        $('#acl-dialog').remove();
      },
    };

    return buttons;
  };

  // build and return IMAP ACL dialog content
  this.form_acl_dialog_content = function(acl)
  {
    var dialog = $('<div id="acl-dialog"><form id="acl-form"><table class="form">'
        + '<tr><td class="label"></td><td class="value"></td></tr>'
        + '<tr><td class="label"></td><td class="value"></td></tr>'
        + '<tr><td class="label"></td><td class="value"></td></tr>'
        + '</table></form></div>'),
      rows = $('tr', dialog),
      rights_div = $('<div>'),
      spans = [$('<span>'), $('<span>')],
      subject_select = $('<select id="acl-subject"></select>')
        .on('change', function() {
          subject_input[$(this).val() == 'user' ? 'show' : 'hide']();
        }),
      subject_input = $('<input id="acl-subject-user" type="text" size="30" />'),
      select = $('<select id="acl-type"></select>')
        .on('change', function() {
          rights_div[$(this).val() == 'custom' ? 'show' : 'hide']();
        }),
// Not yet implemented
//      epoch_input = $('<input id="acl-epoch" type="text" size="13" />'),
      subjects = 'user,anyone,anonymous'.split(','),
      options = 'all,read-only,read-write,semi-full,full,custom'.split(','),
      rights = 'l,r,s,w,i,p,k,x,t,n,e,a'.split(',');

    $.each(subjects, function() {
      $('<option></option>').text(self.t('acl.'+this)).val(this).appendTo(subject_select);
    });

    $.each(options, function() {
      $('<option></option>').text(self.t('acl.'+this)).val(this).appendTo(select);
    });

    $.each(rights, function(i, v) {
      $('<label>')
        .append($('<input type="checkbox" />').val(v))
        .append($('<span>').text(self.t('acl.'+v)))
        .appendTo(spans[i > 5 ? 1 : 0]);
    });

    $('td.label', rows[0]).text(this.t('acl.identifier'));
    $('td.value', rows[0]).append(subject_select).append(subject_input);
    $('td.label', rows[1]).text(this.t('acl.rights'));
    $('td.value', rows[1]).append(select).append(rights_div.append(spans));
// Not yet implemented
//    $('td.label', rows[2]).text(this.t('acl.expire'));
//    $('td.value', rows[2]).append(epoch_input);

    dialog.hide().appendTo('body');

    this.trigger_event('form-load', 'acl-form');

    // reset form elements
    subject_select.val(acl.subject && acl.subject.match(/^(anyone|anonymous)$/i) ? acl.subject : 'user').change();
    subject_input.val(acl.subject && subject_select.val() == 'user' ? acl.subject : '');
// Not yet implemented
/*    epoch_input.val(this.unix_to_date(acl.epoch, true));
    epoch_input.datetimepicker({
      lang: 'en',
      format: 'Y-m-d H:i'
    });
*/
    var v = !acl.rights ? 'read-write' : $.inArray(acl.rights, options) != -1 ? acl.rights : 'custom';
    select.val(v).change();
    $.each(rights, function() {
      $('input[value="' + this + '"]', rights_div).prop('checked', v == 'custom' && acl.rights && acl.rights.indexOf(this) > -1);
    });

    // Initialize autocompletion
    this.ac_init(subject_input, {
      action: 'form_value.list_options',
      attribute: 'owner',
      result_key: 'mail',
      oninsert: function(key, val) { $(this.ac_input).val(key); },
      form: $('textarea[name="' + this.acl_dialog_name + '"]').parents('form')
    });

    return dialog.show();
  };

  // submits IMAP ACL dialog, updates acl definition in form
  this.form_acl_dialog_submit = function()
  {
    var acl, exists, subject = $('#acl-subject').val(),
      user_input = $('#acl-subject-user'),
      user = $.trim(user_input.val()),
      rights = $('#acl-type').val(),
// Not yet implemented
//      epoch = $.trim($('#acl-epoch').val()),
      acl_list = $('#acl' + this.acl_dialog_name);

    // sanity checks
    if (subject == 'user') {
      subject = user;
      if (!subject) {
        alert(this.t('acl.error.nouser'));
        user_input.focus();
        return false;
      }
    }

    $.each(this.acl[self.acl_dialog_name] || [], function(i, v) {
      if (v && v.subject == subject && (!self.acl_dialog_id || self.acl_dialog_id != i)) {
        exists = true;
        return false;
      }
    });

    if (exists) {
      alert(this.t('acl.error.subjectexists'));
      return false;
    }

    if (rights == 'custom') {
      rights = '';
      $('#acl-form input:checked').each(function() { rights += this.value; });

      if (!rights) {
        alert(this.t('acl.error.norights'));
        return false;
      }
    }

// Not yet implemented
/*    if (epoch) {
      if (epoch.match(/^([0-9]{4})-([0-9]{2})-([0-9]{2}) ([0-9]{2}):([0-9]{2})$/))
        epoch = Date.UTC(RegExp.$1, RegExp.$2 - 1, RegExp.$3, RegExp.$4, RegExp.$5) / 1000;
      else if (epoch.match(/^([0-9]{4})-([0-9]{2})-([0-9]{2})$/))
        epoch = Date.UTC(RegExp.$1, RegExp.$2 - 1, RegExp.$3, 23, 59) / 1000;
      else {
        alert(this.t('acl.error.invaliddate'));
        return false;
      }
    }
*/

//    acl = {subject: subject, rights: rights, epoch: epoch};
    acl = {subject: subject, rights: rights};

    // this.log(acl);
    // this.log(this.build_acl([acl]));

    if (this.acl_dialog_id) {
      this.acl[this.acl_dialog_name][this.acl_dialog_id] = acl;
      $('option[value="' + this.acl_dialog_id + '"]', acl_list).text(acl.subject);
    }
    else {
      this.acl[this.acl_dialog_name].push(acl);
      $('<option></option>').val(this.acl[this.acl_dialog_name].length-1)
        .text(acl.subject)
        .appendTo(acl_list)
        .on('dblclick', function () { self.form_acl_dialog(self.acl_dialog_name, this.value); });
    }

    return true;
  };

  // Replaces form element with LDAP URL element
  this.form_url_element_wrapper = function(form_element)
  {
    var i, e = $(form_element),
      form = form_element.form,
      name = form_element.name,
      ldap = this.parse_ldap_url(e.val()) || {},
      options = ['sub', 'one', 'base'],
      div = $('<div class="ldap_url"><table></table></div>'),
      host = $('<input type="text">').attr({name: 'ldap_host_'+name, size: 30, value: ldap.host, 'class': 'ldap_host'}),
      port = $('<input type="text">').attr({name: 'ldap_port_'+name, size: 5, value: ldap.port || '389'}),
      base = $('<input type="text">').attr({name: 'ldap_base_'+name, value: ldap.base}),
      scope = $('<select>').attr({name: 'ldap_scope_'+name}),
      filter = $('<ul>'),
      row_host = $('<tr class="ldap_host"><td></td><td></td></tr>'),
      row_base = $('<tr class="ldap_base"><td></td><td></td></tr>'),
      row_scope = $('<tr class="ldap_scope"><td></td><td></td></tr>'),
      row_filter = $('<tr class="ldap_filter"><td></td><td></td></tr>');

    for (i in options)
      $('<option>').val(options[i]).text(this.t('ldap.'+options[i])).appendTo(scope);
    scope.val(ldap.scope);

    for (i in ldap.filter)
      filter.append(this.form_url_filter_element(name, i, ldap.filter[i]));
    if (!$('li', filter).length)
      filter.append(this.form_url_filter_element(name, 0, {}));

    e.hide();

    $('td:first', row_host).text(this.t('ldap.host'));
    $('td:last', row_host).append(host).append($('<span>').text(':')).append(port);
    $('td:first', row_base).text(this.t('ldap.basedn'));
    $('td:last', row_base).append(base);
    $('td:first', row_scope).text(this.t('ldap.scope'));
    $('td:last', row_scope).append(scope);
    $('td:first', row_filter).text(this.t('ldap.conditions'));
    $('td:last', row_filter).append(filter);
    $('table', div).append(row_host).append(row_base).append(row_scope).append(row_filter);
    $(form_element).parent().append(div);
  };

  this.form_url_filter_element = function(name, idx, filter)
  {
    var options = ['any', 'both', 'prefix', 'suffix', 'exact'],
      filter_type = $('<select>').attr({name: 'ldap_filter_type_'+name+'['+idx+']'}),
      filter_name = $('<input type="text">').attr({name: 'ldap_filter_name_'+name+'['+idx+']'}),
      filter_value = $('<input type="text">').attr({name: 'ldap_filter_value_'+name+'['+idx+']'}),
      a_add = $('<a class="button add" href="#add"></a>').click(function() {
        var dt = new Date().getTime();
        $(this.parentNode.parentNode).append(kadm.form_url_filter_element(name, dt, {}));
      }).attr({title: this.t('add')}),
      a_del = $('<a class="button delete" href="#delete"></a>').click(function() {
        if ($('li', this.parentNode.parentNode).length > 1)
          $(this.parentNode).remove();
        else {
          $('input', this.parentNode).val('');
          $('select', this.parentNode).val('any').change();
        }
      }).attr({title: this.t('delete')}),
      li = $('<li>');

    for (i in options)
      $('<option>').val(options[i]).text(this.t('ldap.filter_'+options[i])).appendTo(filter_type);

    if (filter.type)
      filter_type.val(filter.type);
    if (filter.name)
      filter_name.val(filter.name);
    if (filter.value)
      filter_value.val(filter.value);

    filter_type.change(function() {
      filter_value.css({display: $(this).val() == 'any' ? 'none' : 'inline'});
    }).change();

    return li.append(filter_name).append(filter_type).append(filter_value)
      .append(a_del).append(a_add);
  };

  // updates form data with LDAP URL (on form submit)
  this.form_url_element_submit = function(name, data, form)
  {
    var i, rx = new RegExp('^ldap_(host|port|base|scope|filter_name|filter_type|filter_value)_'+name+'(\\[|$)');

    for (i in data)
      if (rx.test(i))
        delete data[i];

    data[name] = this.form_url_element_save(name, form);

    return data;
  };

  // updates LDAP URL field
  this.form_url_element_save = function(name, form)
  {
    var url, form = $(form), params = {
      host: $('input[name="ldap_host_'+name+'"]', form).val(),
      port: $('input[name="ldap_port_'+name+'"]', form).val(),
      base: $('input[name="ldap_base_'+name+'"]', form).val(),
      scope: $('select[name="ldap_scope_'+name+'"]', form).val(),
      filter: []};

    $('input[name^="ldap_filter_name_'+name+'"]', form).each(function() {
      if (this.value && /\[([^\]]+)\]/.test(this.name)) {
        var suffix = name + '[' + RegExp.$1 + ']',
          type = $('select[name="ldap_filter_type_'+suffix+'"]', form).val(),
          value = type == 'any' ? '' : $('input[name="ldap_filter_value_'+suffix+'"]', form).val();

        params.filter.push({name: this.value, type: type, value: value, join: 'AND', level: 0});
      }
    });

    url = this.build_ldap_url(params);
    $('input[name="'+name+'"]').val(url);

    return url;
  };


  /*********************************************************/
  /*********                 Forms                 *********/
  /*********************************************************/

  // disable/enable all fields of a form
  this.lock_form = function(form, lock)
  {
    if (!form || !form.elements)
      return;

    var n, len, elm;

    if (lock)
      this.disabled_form_elements = [];

    for (n=0, len=form.elements.length; n<len; n++) {
      elm = form.elements[n];

      if (elm.type == 'hidden')
        continue;
      // remember which elem was disabled before lock
      if (lock && elm.disabled)
        this.disabled_form_elements.push(elm);
      // check this.disabled_form_elements before inArray() as a workaround for FF5 bug
      // http://bugs.jquery.com/ticket/9873
      else if (lock || (this.disabled_form_elements && $.inArray(elm, this.disabled_form_elements)<0))
        elm.disabled = lock;
    }
  };

  this.serialize_form = function(id)
  {
    var json = {}, form = $(id), query = form.serializeArray();

    // convert to name-value object
    $.each(query, function() { json[this.name] = this.value; });

    // read extra (disabled) fields
    $.each(this.env.extra_fields || [], function() {
      var value = $('[name="' + this + '"]', form).val();
      if (value)
        json[this] = value;
    });

    // serializeArray() doesn't work properly for multi-select
    $('select[multiple="multiple"]', form).each(function() {
      var name = this.name;
      json[name] = [];
      $(':selected', this).each(function() {
        json[name].push(this.value);
      });
    });

    this.form_serialize({id: id, json: json});

    return json;
  };

  this.form_value_change = function(events)
  {
    var i, j, e, elem, name, elem_name,
      form = $('#'+this.env.form_id),
      id = $('[name="id"]', form).val(),
      type_id = $('[name="type_id"]', form).val(),
      object_type = $('[name="object_type"]', form).val(),
      data = {type_id: type_id, object_type: object_type, attributes: []};

    if (id)
      data.id = id;

    this.set_busy(true, 'loading');

    for (i=0; i<events.length; i++) {
      name = events[i];
      e = this.env.auto_fields[name];

      if (!e)
        continue;

      data.attributes.push(name);
      for (j=0; j<e.data.length; j++) {
        elem_name = e.data[j];
        if (!data[elem_name] && (elem = $('[name="'+elem_name+'"]', form)))
          data[elem_name] = elem.val();
      }
    }

    if (data.attributes.length)
      this.api_post('form_value.generate', data, 'form_value_response');
  };

  this.form_value_response = function(response)
  {
    var i, val, field;
    if (!this.api_response(response))
      return;

    for (i in response.result) {
      val = response.result[i];
      field = $('[name="'+i+'"]');
      // @TODO: indexed list support
      if ($.isArray(val))
        val = field.is('textarea') ? val.join("\n") : val.shift();
      field.val(val);

      this.form_element_update({name: i});
    }
  };

  this.form_value_error = function(name)
  {
    $('[name="'+name+'"]', $('#'+this.env.form_id)).addClass('error');
  }

  this.form_error_clear = function()
  {
    $('input,textarea', $('#'+this.env.form_id)).removeClass('error');
  }

  this.check_required_fields = function(data)
  {
    var i, n, is_empty, ret = true,
      req_fields = this.env.required_fields;

    for (i=0; i<req_fields.length; i++) {
      n = req_fields[i];
      is_empty = 0;

      if ($.isArray(data[n]))
        is_empty = (data[n].length == 0) ? 1 : 0;
      else
        is_empty = !data[n];

      if (is_empty) {
        this.form_value_error(n);
        ret = false;
      }
    }

    return ret;
  };

  /*********************************************************/
  /*********          Client commands              *********/
  /*********************************************************/

  this.main_logout = function(params)
  {
    location.href = '?task=main&action=logout' + (params ? '&' + $.param(params) : '');
    return false;
  };

  this.domain_info = function(id)
  {
    this.http_post('domain.info', {id: id});
  };

  this.domain_list = function(props)
  {
    this.list_handler('domain', props);
  };

  this.domain_delete = function(id)
  {
    this.env.delete_domain_id = id;
    return this.delete_handler(id, 'domain');
  };

  this.domain_save = function(reload, section)
  {
    return this.save_handler('domain', reload, section);
  };

  this.domain_delete_response = function(response)
  {
    // domain is not empty
    if (response && response.code == 450) {
      this.set_busy(false);

      if (confirm(this.t('domain.delete.force'))) {
        this.set_busy(true, 'deleting');
        this.api_post('domain.delete', {'id': this.env.delete_domain_id, force: 1}, 'domain_delete_response');
      }
    }
    else
      this.response_handler(response, 'domain.delete', 'domain.list', {refresh: 1});
  };

  this.domain_add_response = function(response)
  {
    this.response_handler(response, 'domain.add', 'domain.list', {refresh: 1});
  };

  this.domain_edit_response = function(response)
  {
    // domain is not empty and delete was requested
    if (response && response.code == 450) {
      this.set_busy(false);

      // warn the user and re-send the request
      if (confirm(this.t('domain.delete.force'))) {
        var data = this.serialize_form('#'+this.env.form_id);
        data.force = 1;

        this.set_busy(true, 'saving');
        this.api_post('domain.edit', data, 'domain_edit_response');
      }
    }
    else
      this.response_handler(response, 'domain.edit', 'domain.list', {refresh: 1});
  };

  this.user_info = function(id)
  {
    this.http_post('user.info', {'id': id});
  };

  this.user_list = function(props)
  {
    return this.list_handler('user', props);
  };

  this.user_delete = function(id)
  {
    return this.delete_handler(id, 'user');
  };

  this.user_save = function(reload, section)
  {
    var validate = function(obj, data) {
      // check password
      if (data.userpassword != data.userpassword2) {
        obj.display_message('user.password.mismatch', 'error');
        obj.form_value_error('userpassword2');
        return false;
      }

      delete data['userpassword2'];
      return data;
    };

    return this.save_handler('user', reload, section, validate);
  };

  this.user_delete_response = function(response)
  {
    this.response_handler(response, 'user.delete', 'user.list');
  };

  this.user_add_response = function(response)
  {
    this.response_handler(response, 'user.add', 'user.list');
  };

  this.user_edit_response = function(response)
  {
    this.response_handler(response, 'user.edit', 'user.list');
  };

  this.group_info = function(id)
  {
    this.http_post('group.info', {id: id});
  };

  this.group_list = function(props)
  {
    return this.list_handler('group', props);
  };

  this.group_delete = function(id)
  {
    return this.delete_handler(id, 'group');
  };

  this.group_save = function(reload, section)
  {
    return this.save_handler('group', reload, section);
  };

  this.group_delete_response = function(response)
  {
    this.response_handler(response, 'group.delete', 'group.list');
  };

  this.group_add_response = function(response)
  {
    this.response_handler(response, 'group.add', 'group.list');
  };

  this.group_edit_response = function(response)
  {
    this.response_handler(response, 'group.edit', 'group.list');
  };

  this.ou_info = function(id)
  {
    this.http_post('ou.info', {id: id});
  };

  this.ou_list = function(props)
  {
    return this.list_handler('ou', props);
  };

  this.ou_delete = function(id)
  {
    return this.delete_handler(id, 'ou');
  };

  this.ou_save = function(reload, section)
  {
    return this.save_handler('ou', reload, section);
  };

  this.ou_delete_response = function(response)
  {
    this.response_handler(response, 'ou.delete', 'ou.list');
  };

  this.ou_add_response = function(response)
  {
    this.response_handler(response, 'ou.add', 'ou.list');
  };

  this.ou_edit_response = function(response)
  {
    this.response_handler(response, 'ou.edit', 'ou.list');
  };

  this.resource_info = function(id)
  {
    this.http_post('resource.info', {id: id});
  };

  this.resource_list = function(props)
  {
    return this.list_handler('resource', props);
  };

  this.resource_delete = function(id)
  {
    return this.delete_handler(id, 'resource');
  };

  this.resource_save = function(reload, section)
  {
    return this.save_handler('resource', reload, section);
  };

  this.resource_delete_response = function(response)
  {
    this.response_handler(response, 'resource.delete', 'resource.list');
  };

  this.resource_add_response = function(response)
  {
    this.response_handler(response, 'resource.add', 'resource.list');
  };

  this.resource_edit_response = function(response)
  {
    this.response_handler(response, 'resource.edit', 'resource.list');
  };

  this.role_info = function(id)
  {
    this.http_post('role.info', {id: id});
  };

  this.role_list = function(props)
  {
    return this.list_handler('role', props);
  };

  this.role_delete = function(id)
  {
    return this.delete_handler(id, 'role');
  };

  this.role_save = function(reload, section)
  {
    return this.save_handler('role', reload, section);
  };

  this.role_delete_response = function(response)
  {
    this.response_handler(response, 'role.delete', 'role.list');
  };

  this.role_add_response = function(response)
  {
    this.response_handler(response, 'role.add', 'role.list');
  };

  this.role_edit_response = function(response)
  {
    this.response_handler(response, 'role.edit', 'role.list');
  };

  this.sharedfolder_info = function(id)
  {
    this.http_post('sharedfolder.info', {id: id});
  };

  this.sharedfolder_list = function(props)
  {
    return this.list_handler('sharedfolder', props);
  };

  this.sharedfolder_delete = function(id)
  {
    return this.delete_handler(id, 'sharedfolder');
  };

  this.sharedfolder_save = function(reload, section)
  {
    return this.save_handler('sharedfolder', reload, section);
  };

  this.sharedfolder_delete_response = function(response)
  {
    this.response_handler(response, 'sharedfolder.delete', 'sharedfolder.list');
  };

  this.sharedfolder_add_response = function(response)
  {
    this.response_handler(response, 'sharedfolder.add', 'sharedfolder.list');
  };

  this.sharedfolder_edit_response = function(response)
  {
    this.response_handler(response, 'sharedfolder.edit', 'sharedfolder.list');
  };

  this.settings_type_info = function(id)
  {
    this.http_post('settings.type_info', {id: id});
  };

  this.settings_type_add = function()
  {
    this.http_post('settings.type_add', {type: $('#type_list_filter').val()});
  };

  this.settings_type_list = function(props)
  {
    if (!props)
      props = {};

    if (props.search === undefined && this.env.search_request)
      props.search_request = this.env.search_request;

    props.type = $('#type_list_filter').val();

    this.http_post('settings.type_list', props);
  };

  this.type_delete = function(id)
  {
    return this.delete_handler(this.type_id_parse(id), 'type');
  };

  this.type_save = function(reload, section)
  {
    var i, n, attr, request = {},
      data = this.serialize_form('#'+this.env.form_id),
      action = data.id ? 'edit' : 'add',
      required = this.env.attributes_required || [];

    if (reload) {
      data.section = section;
      this.http_post('type.' + action, {data: data});
      return;
    }

    this.form_error_clear();

    if (!this.check_required_fields(data)) {
      this.display_message('form.required.empty', 'error');
      return false;
    }

    if (data.key.match(/[^a-z_-]/)) {
      this.display_message('attribute.key.invalid', 'error');
      return false;
    }

    request.id = data.id;
    request.key = data.key;
    request.name = data.name;
    request.type = data.type;
    request.description = data.description;
    request.used_for = data.used_for;
    request.is_default = data.is_default;
    request.attributes = {fields: {}, form_fields: {}, auto_form_fields: {}};
    request.attributes.fields.objectclass = data.objectclass;

    // Build attributes array compatible with the API format
    // @TODO: use attr_table format
    for (i in this.env.attr_table) {
      // attribute doesn't exist in specified object classes set
      if (!(n = this.env.attributes[i]))
        continue;

      // check required attributes
      if (required.length)
        required = $.map(required, function(a) { return a != n ? a : null; });

      attr = this.env.attr_table[i];
      data = {};

      if (attr.valtype == 'static') {
        request.attributes.fields[i] = attr.data;
        continue;
      }

      if (attr.type == 'list-autocomplete') {
        data.type = 'list';
        data.autocomplete = true;
      }
      else if (attr.type == 'text-autocomplete') {
        data.autocomplete = true;
      }
      else if (attr.type != 'text')
        data.type = attr.type;

      if ((attr.type == 'select' || attr.type == 'multiselect') && attr.values && attr.values.length)
        data.values = attr.values;

      if (attr.optional)
        data.optional = true;
      if (attr.maxcount)
        data.maxcount = attr.maxcount;
      if (attr.validate != 'default')
        data.validate = attr.validate;

      if (attr['default'] && attr.valtype == 'normal' && attr.type.match(this.attr_default_rx))
        data['default'] = attr['default'];

      if (attr.valtype == 'normal' || attr.valtype == 'auto')
        request.attributes.form_fields[i] = data;
      if (attr.valtype == 'auto' || attr.valtype == 'auto-readonly') {
        if (attr.data)
          data.data = attr.data.split(/,/);
        request.attributes.auto_form_fields[i] = data;
      }
    }

    if (required.length) {
      this.display_message(this.t('attribute.required.error').replace(/\$1/, required.join(',')), 'error');
      return false;
    }

    this.set_busy(true, 'saving');
    this.api_post('type.' + action, request, 'type_' + action + '_response');
  };

  this.type_delete_response = function(response)
  {
    this.response_handler(response, 'type.delete', 'settings.type_list');
  };

  this.type_add_response = function(response)
  {
    this.response_handler(response, 'type.add', 'settings.type_list');
  };

  this.type_edit_response = function(response)
  {
    this.response_handler(response, 'type.edit', 'settings.type_list');
  };

  /*********************************************************/
  /*********       Various helper methods          *********/
  /*********************************************************/

  // universal API response handler
  this.response_handler = function(response, action, list, list_params)
  {
    if (!this.api_response(response))
      return;

    this.display_message(action + '.success');

    var page = this.env.list_page,
      list_id = list.replace(/[^a-z]/g, '');

    // if objects list exists
    if ($('#'+list_id).length) {
      // goto previous page if last record on the current page has been deleted
      if (this.env.list_page > 1 && this.env.list_size == 1 && action.match(/\.delete/))
        page -= 1;

      if (!list_params)
        list_params = {};

      list_params.page = page;
      this.command(list, list_params);
      this.set_watermark('taskcontent');
    }
  };

  // universal list request handler
  this.list_handler = function(type, props)
  {
    if (!props)
      props = {};

    if (props.search === undefined && this.env.search_request)
      props.search_request = this.env.search_request;

    this.http_post(type + '.list', props);
  };

  // universal object delete handler
  this.delete_handler = function(request, type)
  {
    if (!confirm(this.t(type + '.delete.confirm')))
      return false;

    if (typeof request != 'object')
      request = {'id': request};

    this.set_busy(true, 'deleting');
    this.api_post(type + '.delete', request, type + '_delete_response');
  };

  // universal form save handler
  this.save_handler = function(type, reload, section, validation_function)
  {
    var data = this.serialize_form('#'+this.env.form_id),
      action = data.id ? 'edit' : 'add';

    if (reload) {
      // remove unchanged defaults
      $.each(this.env.default_values || [], function(i, v) {
        if (v == data[i])
          delete data[i];
      });

      data.section = section;
      this.http_post(type + '.' + action, {data: data});
      return false;
    }

    this.form_error_clear();

    if (validation_function)
      data = validation_function(this, data);

    if (data === false)
      return false;

    if (!this.check_required_fields(data)) {
      this.display_message('form.required.empty', 'error');
      return false;
    }

    this.set_busy(true, 'saving');
    this.api_post(type + '.' + action, data, type + '_' + action + '_response');

    return true;
  };

  // Parses object type identifier
  this.type_id_parse = function(id)
  {
    var id = String(id).split(':');
    return {type: id[0], id: id[1]};
  };

  // Removes attribute row
  this.type_attr_delete = function(attr)
  {
    $('#attr_table_row_' + attr).remove();
    $('select[name="attr_name"] > option[value="'+attr+'"]').show();

    delete this.env.attr_table[attr];
    this.type_attr_cancel();
  };

  // Displays attribute edition form
  this.type_attr_edit = function(attr)
  {
    var form = $('#type_attr_form');

    form.detach();
    $('#attr_table_row_'+attr).after(form);
    this.type_attr_form_init(attr);
    form.slideDown(400);
  };

  // Displays attribute addition form
  this.type_attr_add = function()
  {
    var form = $('#type_attr_form');

    form.detach();
    $('#type_attr_table > tbody').append(form);
    this.type_attr_form_init();
    form.slideDown(400);
  };

  // Saves attribute form, create/update attribute row
  this.type_attr_save = function()
  {
    var attr, row, data = {},
      form_data = this.serialize_form('#'+this.env.form_id),
      name_select = $('select[name="attr_name"]');

    // read attribute form data
    data.type = form_data.attr_type;
    data.valtype = form_data.attr_value;
    data.optional = form_data.attr_optional;
    data.validate = form_data.attr_validate;
    data.data = data.valtype != 'normal' ? form_data.attr_data : null;
    data.maxcount = data.type == 'list' || data.type == 'list-autocomplete' ? form_data.attr_maxcount : 0;
    data.values = data.type == 'select' || data.type == 'multiselect' ? form_data.attr_options : [];

    if (name_select.is(':visible')) {
      // new attribute
      attr = name_select.val();
      row = $('<tr><td class="name"></td><td class="type"></td><td class="readonly"></td>'
        +'<td class="optional"></td><td class="validate"></td><td class="actions">'
        +'<a class="button delete" title="delete" onclick="kadm.type_attr_delete(\''+attr+'\')" href="#delete"></a>'
        +'<a class="button edit" title="edit" onclick="kadm.type_attr_edit(\''+attr+'\')" href="#edit"></a></td></tr>')
        .attr('id', 'attr_table_row_' + attr).appendTo('#type_attr_table > tbody');
    }
    else {
      // edited attribute
      attr = $('span', name_select.parent()).text().toLowerCase();
      row = $('#attr_table_row_' + attr);
    }

    if (data.valtype != 'normal') {
      row.attr('title', this.t('attribute.value.' + (data.valtype == 'static' ? 'static' : 'auto')) + ': ' + data.data);
    }

    if (form_data.attr_default && data.valtype == 'normal' && data.type.match(this.attr_default_rx)) {
      data['default'] = form_data.attr_default;
    }

    // Update table row
    $('td.name', row).text(this.env.attributes[attr]);
    $('td.type', row).text(data.type);
    $('td.readonly', row).text(data.valtype == 'auto-readonly' ? this.env.yes_label : this.env.no_label);
    $('td.optional', row).text(data.optional ? this.env.yes_label : this.env.no_label);
    $('td.validate', row).text(this.t('attribute.validate.' + data.validate));

    // Update env data
    this.env.attr_table[attr] = data;

    this.type_attr_cancel();
  };

  // Hide attribute form
  this.type_attr_cancel = function()
  {
    $('#type_attr_form').hide();
  };

  this.type_attr_form_init = function(attr)
  {
    var name_select = $('select[name="attr_name"]'),
      data = attr ? this.env.attr_table[attr] : {},
      type = data.type || 'text';

    $('select[name="attr_type"]').val(type);
    $('select[name="attr_value"]').val(attr ? data.valtype : 'normal');
    $('select[name="attr_validate"]').val(data.validate || 'default');
    $('input[name="attr_default"]').val(data['default'] || '');
    $('input[name="attr_optional"]').prop('checked', attr ? data.optional : false);
    $('input[name="attr_data"]').val(data.data || '');
    $('input[name="attr_maxcount"]').val(data.maxcount || '');
    $('textarea[name="attr_options"]').val(data.values ? data.values.join("\n") : '');
    $('span', name_select.parent()).remove();

    if (attr) {
      name_select.hide().val(attr);
      $('<span></span>').text(this.env.attributes[attr] ? this.env.attributes[attr] : attr)
        .appendTo(name_select.parent());
    }
    else {
      this.type_attr_select_init();
      name_select.show();
    }

    this.form_element_update({name: 'attr_options'});
    this.type_attr_type_change();
    this.type_attr_value_change();
  };

  // Initialize attribute name selector
  this.type_attr_select_init = function()
  {
    var select = $('select[name="attr_name"]'),
      options = $('option', select);

    options.each(function() {
      if (kadm.env.attr_table[this.value])
        $(this).attr('disabled', true);
    });
    options.not(':disabled').first().attr('selected', true);
  };

  // Update attribute form on attribute name change
  this.type_attr_name_change = function(elem)
  {
    this.type_attr_value_change();
  };

  // Update attribute form on value type change
  this.type_attr_value_change = function(elem)
  {
    var type = $(elem || 'select[name="attr_value"]').val(),
      field_type = $('select[name="attr_type"]').val(),
      optional = $('#attr_form_row_optional'),
      select = $('select[name="attr_name"]').val(),
      attr_name = this.env.attributes[select],
      // only non-static and non-required attributes can be marked as optional
      opt = type != 'static' && $.inArray(attr_name, this.env.attributes_required) == -1;

    $('input[name="attr_data"]')[type != 'normal' ? 'show' : 'hide']();
    $('#attr_form_row_readonly')[type != 'static' ? 'show' : 'hide']();
    $('#attr_form_row_default')[type == 'normal' && field_type.match(this.attr_default_rx) ? 'show' : 'hide']();
    optional[opt ? 'show' : 'hide']();

    if (!opt)
      $('input', optional).attr('checked', false);
  };

  // Update attribute form on type change
  this.type_attr_type_change = function(elem)
  {
    var type = $(elem || 'select[name="attr_type"]').val(),
      val_type = $('select[name="attr_value"]').val();

    $('#attr_form_row_maxcount')[type == 'list' || type == 'list-autocomplete' ? 'show' : 'hide']();
    $('#attr_form_row_options')[type == 'select' || type == 'multiselect' ? 'show' : 'hide']();
    $('#attr_form_row_default')[val_type == 'normal' && type.match(this.attr_default_rx) ? 'show' : 'hide']();
  };

  // Update attributes list on object classes change
  this.type_attr_class_change = function(field)
  {
    var data = {attributes: 'attribute', classes: this.type_object_classes(field)};
    this.api_post('form_value.select_options', data, 'type_attr_class_change_response');
    this.type_attr_cancel();
  };

  // Update attributes list on object classes change - API response handler
  this.type_attr_class_change_response = function(response)
  {
    if (!this.api_response(response))
      return;

    var i, lc, list = response.result.attribute.list || [],
      required = response.result.attribute.required || [],
      select = $('select[name="attr_name"]');

    // remove objectClass from attributes list(s)
    required = $.map(required, function(a) { return a == 'objectClass' ? null : a; });
    list = $.map(list, function(a) { return a == 'objectClass' ? null : a; });

    // append special attributes
    $.each(this.env.special_attributes || [], function() {
      if ($.inArray(this, list) == -1)
        list.push(this);
    });
    list.sort();

    this.env.attributes = {};
    this.env.attributes_required = required;
    select.empty();

    for (i in list) {
      lc = list[i].toLowerCase();
      this.env.attributes[lc] = list[i];
      $('<option>').text(list[i]).val(lc).appendTo(select);
    }
  };

  // Return selected objectclasses array
  this.type_object_classes = function(field)
  {
    var classes = [];
    $('option:selected', $(field)).each(function() {
      classes.push(this.value);
    });
    return classes;
  };

  // Password generation - request
  this.generate_password = function(fieldname)
  {
    this.env.password_field = fieldname;
    this.set_busy(true, 'loading');
    // we can send only 'attributes' here, because password generation doesn't require object type name/id
    this.api_post('form_value.generate', {attributes: [fieldname]}, 'generate_password_response');
  };

  // Password generation - response handler
  this.generate_password_response = function(response)
  {
    if (!this.api_response(response))
      return;

    var f = this.env.password_field, pass = response.result[f];

    $('input[name="' + f + '"]').val(pass);
    $('input[name="' + f + '2"]').val(pass);
  };

  // convert ACI string into object
  this.parse_aci = function(aci_str)
  {
    var aci = [];

    $.each((aci_str || '').split(/\r?\n/), function(i, str) {
      var s, target, permission,
        or_rx = /\s*\|\|\s*/,
        entry = {targets: [], perms: []};

      // Syntax: (target)(version 3.0; acl "name";permission bindRules;)

      // target is optional and there can be many of it
      while (/^\(target/.test(str)) {
        if (s = str.match(/^\((target|targetattr|targetscope|targetcontrol|extop|targetfilter|targattrfilters)\s*([!=]+)\s*\"([^"]+)\"\)/)) {
          target = {operator: s[2], type: s[1], expression: s[3]};

          switch (target.type) {
            case 'targetattr':
            case 'targetcontrol':
            case 'extop':
              target.expression = target.expression.toLowerCase().split(or_rx);
              break;
          };

          entry.targets.push(target);
          str = str.substr(s[0].length);
        }
      }

      // there must be one version and acl entry
      if (s = str.match(/^\s*\(version\s*([0-9.]+)\s*;\s*acl\s*\"([^"]+)\";\s*/)) {
        entry.version = s[1];
        entry.name = s[2];

        str = str.substr(s[0].length);

        // there can be multiple permission/bindRule blocks
        $.each(str.split(';'), function(i, perm) {
          if (permission = self.parse_aci_permission(perm))
            entry.perms.push(permission);
        });
      }

      if (entry.name)
        aci.push(entry);
    });

    return aci;
  };

  this.parse_aci_permission = function(perm)
  {
    var s, rule, permission;

    if (s = perm.match(/^\s*(allow|deny)\s*\(([a-zA-Z, ]+)\)(.*)/)) {
      permission = {type: s[1], rules: [], rights: s[2].toLowerCase().split(/\s*,\s*/)};

      rule = s[3].replace(/^[ (]+/, '').replace(/[ )]+$/, '');

      while (s = rule.match(/^\s*(or|and|or not|and not)?\s*(userdn|groupdn|roledn|userattr|ip|dns|timeofday|dayofweek|authmethod|ssf)\s*([<>!=]+)\s*\"([^"]+)\"/i)) {
        permission.rules.push({
          join: permission.rules.length ? (s[1] || '').toUpperCase() : null,
          keyword: s[2],
          operator: s[3],
          expression: s[4].split(/\s*\|\|\s*/)
        });

        rule = rule.substr(s[0].length);
      }
    }

    return permission;
  };

  // convert ACI object into ACI array (of strings)
  this.build_aci = function(aci)
  {
    var result = [];

    $.each(aci, function(i, entry) {
      // skip removed entries
      if (!entry)
        return;

      var acl = [], tokens = [];
      $.each(entry.targets || [], function(i, target) {
        var txt = target.expression;

        if ($.isArray(txt))
          txt = txt.join(' || ');

        tokens.push('(' + target.type + ' ' + (target.operator || '=') + ' "' + txt + '")');
      });

      acl.push('version ' + entry.version);
      acl.push('acl "' + entry.name + '"');

      $.each(entry.perms || [], function(i, perm) {
        var num = 0, text = perm.type + ' (' + perm.rights.join(',') + ')';

        $.each(perm.rules || [], function(n, rule) {
          if (rule.join && num)
            text += ' ' + rule.join;
          text += ' ' + rule.keyword + ' ' + (rule.operator || '=') + ' "' + rule.expression.join(' || ') + '"';
          num++;
        });

        acl.push(text);
      });

      tokens.push('(' + acl.join('; ') + ';)');
      result.push(tokens.join(''));
    });

    return result;
  };

  // convert ACL string into object
  this.parse_acl = function(acl_str)
  {
    var acl = [];

    $.each((acl_str || '').split(/\r?\n/), function(i, str) {
      // Syntax subject, rights[, epoch]
      var entry = self.explode_quoted_str(str, ',');

      if (entry.length == 2 || entry.length == 3) {
// Not yet implemented
//        acl.push({subject: entry[0], rights: entry[1], epoch: entry[2] || 0});
        acl.push({subject: entry[0], rights: entry[1] || 0});
      }
    });

    return acl;
  };

  // convert IMAP ACL object into ACL array (of strings)
  this.build_acl = function(acl)
  {
    var result = [];

    $.each(acl, function(i, entry) {
      // skip removed and invalid entries
      if (!entry || !entry.subject || !entry.rights)
        return;

      var tokens = [], subject = entry.subject;

      if (subject.indexOf(',') > -1 || subject.indexOf('"') > -1)
        subject = subject.replace(/\\/g, '\\\\').replace(/"/g, '\\"');

      tokens.push(subject);
      tokens.push(entry.rights);
// Not yet implemented
//      if (entry.epoch)
//        tokens.push(entry.epoch);

      result.push(tokens.join(', '));
    });

    return result;
  };

  // LDAP URL parser
  this.parse_ldap_url = function(url)
  {
    var result = {},
      url_parser = /^([^:]+):\/\/([^\/]*)\/([^?]*)\?([^?]*)\?([^?]*)\?(.*)$/;
      matches = url_parser.exec(url);

    if (matches && matches[1])
      return {
        scheme: matches[1],
        host: matches[2],
        base: matches[3],
        attrs: matches[4],
        scope: matches[5],
        filter: this.parse_ldap_filter(matches[6])
      };
  };

  // LDAP filter parser
  this.parse_ldap_filter = function(filter)
  {
    var chr, next, elem, pos = 0, join, level = -1, res = [],
      len = filter ? filter.length : 0;

    if (!filter.match(/^\(.*\)$/))
      filter = '(' + filter + ')';

    while (len > pos) {
      chr = filter.charAt(pos);
      if (chr == '&') {
          join = 'AND';
          level++;
      }
      else if (chr == '|') {
          join = 'OR';
          level++;
      }
      else if (chr == '(') {
        next = filter.charAt(pos+1);
        if (next != '&' && next != '|') {
          next = filter.indexOf(')', pos);
          if (next > 0) {
            if (elem = this.parse_ldap_filter_entry(filter.substr(pos + 1, next - pos - 1))) {
              elem.join = join;
              elem.level = level;
              res.push(elem);
            }
            pos = next;
          }
        }
      }
      else if (chr == ')')
        level--;

      pos++;
    }

    return res;
  };

  // LDAP filter-entry parser
  this.parse_ldap_filter_entry = function(entry)
  {
    var type = 'exact', name, value;

    if (entry.match(/^([a-zA-Z0-9_-]+)=(.*)$/)) {
      name = RegExp.$1;
      value = RegExp.$2;

      if (value == '*') {
        value = ''
        type = 'any';
      }
      else if (value.match(/^\*(.+)\*$/)) {
        value = RegExp.$1;
        type = 'both';
      }
      else if (value.match(/^\*(.+)$/)) {
        value = RegExp.$1;
        type = 'suffix';
      }
      else if (value.match(/^(.+)\*$/)) {
        value = RegExp.$1;
        type = 'prefix';
      }

      return {name: name, type: type, value: value};
    }
  };

  // Builds LDAP filter string from the defined structure
  this.build_ldap_filter = function(filter)
  {
    var i, elem, str = '', last = -1, join = {'AND': '&', 'OR': '|'};

    for (i=0; i<filter.length; i++) {
      elem = filter[i];
      if (elem.level > last)
        str += (elem.join && filter.length > 1 ? join[elem.join] : '');
      else if (elem.level < last)
        str += ')';

      str += '(' + elem.name + '=';

      if (elem.type == 'any')
        str += '*';
      else if (elem.type == 'both')
        str += '*' + elem.value + '*';
      else if (elem.type == 'prefix')
        str += elem.value + '*';
      else if (elem.type == 'suffix')
        str += '*' + elem.value;
      else
        str += elem.value;

      str += ')';
      last = elem.level;
    }

    if (filter.length > 1)
      str = '(' + str + ')';

    return str;
  };

  // Builds LDAP URL string from the defined structure
  this.build_ldap_url = function(params)
  {
    var url = '';

    if (!params.filter.length && !params.base)
      return url;

    url += (params.scheme ? params.scheme : 'ldap') + '://';
    url += (params.host ? params.host + (params.port && params.port != 389 ? ':'+params.port : '') : '') + '/';
    url += (params.base ? params.base : '') + '?';
    url += (params.attrs ? params.attrs : '') + '?';
    url += (params.scope ? params.scope : '') + '?';
    if (params.filter)
      url += this.build_ldap_filter(params.filter);

    return url;
  };

  this.set_request_time = function()
  {
    this.env.request_time = (new Date()).getTime();
  };

  // Update request time element
  this.update_request_time = function()
  {
    if (this.env.request_time) {
      var t = ((new Date()).getTime() - this.env.request_time)/1000,
        el = $('#reqtime');
      el.text(el.text().replace(/[0-9.,]+/, t));
    }
  };

  // Return absolute mouse position of an event
  this.mouse_pos = function(e)
  {
    if (!e) e = window.event;

    var mX = (e.pageX) ? e.pageX : e.clientX,
      mY = (e.pageY) ? e.pageY : e.clientY;

    if (document.body && document.all) {
      mX += document.body.scrollLeft;
      mY += document.body.scrollTop;
    }

    if (e._offset) {
      mX += e._offset.left;
      mY += e._offset.top;
    }

    return { left:mX, top:mY };
  };

  this.explode_quoted_str = function(str, separator)
  {
    var i, c, q = false, p = 0, result = [], len = str.length;

    for (i=0; i<len; i++) {
      c = str.charAt(i);
      if (c == '"' && str.charAt(i-1) != '\\')
        q = q ? false : true;
      else if (!q && c == separator) {
        result.push(this.unescape_quoted_str(str.substr(p, i - p)));
        p = i + 1;
      }
    }

    result.push($.trim(p ? str.substr(p) : str));

    return result;
  };

  this.unescape_quoted_str = function(str)
  {
    str = $.trim(str || '');

    if (str.charAt(0) == '"')
      str = str.replace(/^"/, '').replace(/"$/, '')
        .replace(/\\(.?)/g, function(s, n1) {
          switch (n1) {
            case '\\':
              return '\\';
            return n1;
          }
        });

    return str;
  };

  // convert unix timestamp to datetime string
  this.unix_to_date = function(epoch, with_time)
  {
    if (!epoch)
      return '';

    var result, dt = new Date(epoch * 1000),
      dts = dt.toISOString(),
      parts = dts.split('T');

    result = parts[0];

    if (with_time)
      result += ' ' + parts[1].split(':').slice(0,2).join(':');

    return result;
  };
};

/**
 * Modal dialogs
 */
(function($) {
  $.fn.wModal = function(option, settings) {
    if (typeof option === 'object') {
      settings = option;
    }
    else if (typeof option === 'string') {
      var values = [],
        elements = this.each(function() {
          var data = $(this).data('modal');

          if (data) {
            if (option === 'show')
              data.show(settings || {});
            else if (option === 'hide')
              data.hide(settings || {});
            else if ($.fn.wModal.defaultSettings[option] !== undefined) {
              if (settings !== undefined)
                data.settings[option] = settings;
              else
                values.push(data.settings[option]);
            }
          }
        });

      if (values.length === 1)
        return values[0];
      else if (values.length > 0)
        return values;
      else
        return elements;
    }

    return this.each(function() {
      var _settings = $.extend({}, $.fn.wModal.defaultSettings, settings || {}),
        modal = new Modal(_settings, $(this)),
        $el = modal.generate();

      modal.pixel.append($el);

      $(this).data('modal', modal);
    });
  }

  $.fn.wModal.defaultSettings = {btns: {}, msg: null};

  function Modal(settings, elem)
  {
    this.modal = null;
    this.settings = settings;
    this.elem = elem;
    this.tempButtons = {};

    return this;
  }

  Modal.prototype =
  {
    generate: function()
    {
      var _this = this;

      if (this.modal) return this.modal;

      // bg - check if bg already exists
      if ($('#modal_bg').length) {
        this.bg = $('#modal_bg');
        this.pixel = $('#modal_pixel');
      }
      else {
        this.bg = $('<div id="modal_bg"></div>').css({position:'fixed', left:'0', top:'0', display:'none'});
        $('body').append(this.bg);
        $(window).resize(function() { if(_this.bg.is(':visible')) _this.resetBg.apply(_this); });

        // positioning pixel setting to body produces some weird effects with scrollbars when doing sliding effects
        this.pixel = $('<div id="modal_pixel"></div>').css({position:'fixed', left:'0', top:'0', width:'0', height:'0', lineHeight:'0', fontSize:'0'});
        $('body').append(this.pixel);
      }

      // modal
      this.modal = $('<div class="modal_holder"></div>').css({position:'absolute', display:'none'});
      this.modal.append(this.elem);

      $(window).resize(function() { if(_this.modal.is(':visible')) _this.resetModal.apply(_this); });

      this.resetBtns();

      return this.modal;
    },

    resetModal: function()
    {
      var modalWidth = this.modal.outerWidth(true),
        modalHeight = this.modal.outerHeight(true),
        viewWidth = $(window).width(),
        viewHeight = $(window).height(),
        left = (viewWidth/2) - (modalWidth/2),
        top = (viewHeight/2) - (modalHeight/2);

      this.modal.css({left:(left > 0 ? left + 'px' : 'auto'), top:(top > 0 ? top + 'px' : 'auto'), bottom: 'auto', right: 'auto'});
    },

    resetBg: function()
    {
      this.bg.css({width:$(window).width(), height:$(window).height()});
    },

    resetBtns: function(btns)
    {
      var btns = btns || this.settings.btns,
        _this = this;

      for (var btn in btns) {
        (function(btn) {
          _this.modal.find('.modal_btn_' + btn).unbind('click');
          _this.modal.find('.modal_btn_' + btn).click(function() {
            if (_this.tempBtns[btn])
              _this.tempBtns[btn].apply(_this);
            else
              btns[btn].apply(_this);
          });
        })(btn);
      }
    },

    show: function(settings)
    {
      this.tempBtns = settings.btns || {};
      this.resetBg();
      this.resetModal();
      this.pixel.children('.modal_holder').hide();

      var _this = this;
      this.bg.fadeIn(100, function(){ _this.modal.fadeIn(100); });
    },

    hide: function()
    {
      this.modal.hide().remove();
      this.bg.hide();
    }
  }
})(jQuery);

// Add escape() method to RegExp object
// http://dev.rubyonrails.org/changeset/7271
RegExp.escape = function(str)
{
  return String(str).replace(/([.*+?^=!:${}()|[\]\/\\])/g, '\\$1');
};

// make a string URL safe (and compatible with PHP's rawurlencode())
function urlencode(str)
{
  if (window.encodeURIComponent)
    return encodeURIComponent(str).replace('*', '%2A');

  return escape(str)
    .replace('+', '%2B')
    .replace('*', '%2A')
    .replace('/', '%2F')
    .replace('@', '%40');
};

// Initialize application object (don't change var name!)
var kadm = new kolab_admin();

// general click handler
$(document).click(function() {
  // destroy autocompletion
  kadm.ac_stop();
  $('.popup').hide();
});
