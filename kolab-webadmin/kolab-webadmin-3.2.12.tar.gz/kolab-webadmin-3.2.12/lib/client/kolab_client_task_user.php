<?php
/*
 +--------------------------------------------------------------------------+
 | This file is part of the Kolab Web Admin Panel                           |
 |                                                                          |
 | Copyright (C) 2011-2012, Kolab Systems AG                                |
 |                                                                          |
 | This program is free software: you can redistribute it and/or modify     |
 | it under the terms of the GNU Affero General Public License as published |
 | by the Free Software Foundation, either version 3 of the License, or     |
 | (at your option) any later version.                                      |
 |                                                                          |
 | This program is distributed in the hope that it will be useful,          |
 | but WITHOUT ANY WARRANTY; without even the implied warranty of           |
 | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the             |
 | GNU Affero General Public License for more details.                      |
 |                                                                          |
 | You should have received a copy of the GNU Affero General Public License |
 | along with this program. If not, see <http://www.gnu.org/licenses/>      |
 +--------------------------------------------------------------------------+
 | Author: Aleksander Machniak <machniak@kolabsys.com>                      |
 +--------------------------------------------------------------------------+
*/

class kolab_client_task_user extends kolab_client_task
{
    protected $ajax_only = true;

    protected $menu = array(
        'add'  => 'user.add',
    );

    protected $list_attribs = array('displayname', 'cn');

    /**
     * Default action.
     */
    public function action_default()
    {
        $this->output->set_object('content', 'user', true);
        $this->output->set_object('task_navigation', $this->menu());

        $this->action_list();

        // display form to add user if logged-in user has right to do so
        $caps = $this->get_capability('actions');
        if (!empty($caps['user.add'])) {
            $this->action_add();
        }
        else {
            $this->output->command('set_watermark', 'taskcontent');
        }
    }

    /**
     * User information (form) action.
     */
    public function action_info()
    {
        $id     = $this->get_input('id', 'POST');
        $result = $this->api_get('user.info', array('id' => $id));
        $user   = $result->get();
        $output = $this->user_form(null, $user);

        $this->output->set_object('taskcontent', $output);
    }

    /**
     * Users adding (form) action.
     */
    public function action_add()
    {
        $data   = $this->get_input('data', 'POST');
        $output = $this->user_form(null, $data, true);

        $this->output->set_object('taskcontent', $output);
    }

    private function user_form($attribs, $data = array())
    {
        if (empty($attribs['id'])) {
            $attribs['id'] = 'user-form';
        }

        // Form sections
        $sections = array(
            'personal'      => 'user.personal',
            'contact_info'  => 'user.contact_info',
            'system'        => 'user.system',
            'config'        => 'user.config',
            'asterisk'      => 'user.asterisk',
            'other'         => 'user.other',
        );

        // field-to-section map and fields order
        $fields_map = array(
            'type_id'                   => 'personal',
            'type_id_name'              => 'personal',

            /* Probably input */
            'givenname'                 => 'personal',
            'sn'                        => 'personal',
            /* Possibly input */
            'initials'                  => 'personal',
            'o'                         => 'personal',
            'title'                     => 'personal',
            /* Probably generated */
            'cn'                        => 'personal',
            'displayname'               => 'personal',
            'ou'                        => 'personal',
            'preferredlanguage'         => 'personal',

            /* Address lines together */
            'street'                    => 'contact_info',
            'postofficebox'             => 'contact_info',
            'roomnumber'                => 'contact_info',
            'postalcode'                => 'contact_info',
            'l'                         => 'contact_info',
            'c'                         => 'contact_info',
            /* Probably input */
            'mobile'                    => 'contact_info',
            'facsimiletelephonenumber'  => 'contact_info',
            'telephonenumber'           => 'contact_info',
            'homephone'                 => 'contact_info',
            'pager'                     => 'contact_info',
            'mail'                      => 'contact_info',
            'alias'                     => 'contact_info',
            'mailalternateaddress'      => 'contact_info',

            /* POSIX Attributes first */
            'uid'                       => 'system',
            'userpassword'              => 'system',
            'userpassword2'             => 'system',
            'uidnumber'                 => 'system',
            'gidnumber'                 => 'system',
            'homedirectory'             => 'system',
            'loginshell'                => 'system',

            'nsrole'                    => 'system',
            'nsroledn'                  => 'system',

            /* Kolab Settings */
            'kolabhomeserver'           => 'config',
            'mailhost'                  => 'config',
            'mailquota'                 => 'config',
            'cyrususerquota'            => 'config',
            'kolabfreebusyfuture'       => 'config',
            'kolabinvitationpolicy'     => 'config',
            'kolabdelegate'             => 'config',
            'kolaballowsmtprecipient'   => 'config',
            'kolaballowsmtpsender'      => 'config',
            'mailforwardingaddress'     => 'config',

            /* Asterisk Settings */
            'astaccountallowedcodec'    => 'asterisk',
            'astaccountcallerid'        => 'asterisk',
            'astaccountcontext'         => 'asterisk',
            'astaccountdefaultuser'     => 'asterisk',
            'astaccountdeny'            => 'asterisk',
            'astaccounthost'            => 'asterisk',
            'astaccountmailbox'         => 'asterisk',
            'astaccountnat'             => 'asterisk',
            'astaccountname'            => 'asterisk',
            'astaccountqualify'         => 'asterisk',
            'astaccountrealmedpassword' => 'asterisk',
            'astaccountregistrationexten'   => 'asterisk',
            'astaccountregistrationcontext' => 'asterisk',
            'astaccountsecret'          => 'asterisk',
            'astaccounttype'            => 'asterisk',
            'astcontext'                => 'asterisk',
            'astextension'              => 'asterisk',
            'astvoicemailpassword'      => 'asterisk',
        );

        // Prepare fields
        $form = $this->form_prepare('user', $data, array('userpassword2'), null, $fields_map['type_id']);
        list($fields, $types, $type, $add_mode) = $form;

        // Add password confirmation
        if (isset($fields['userpassword'])) {
            $fields['userpassword2'] = $fields['userpassword'];
            // Add 'Generate password' link
            if (empty($fields['userpassword']['readonly'])) {
                $fields['userpassword']['suffix'] = kolab_html::a(array(
                    'content' => $this->translate('password.generate'),
                    'href'    => '#',
                    'onclick' => "kadm.generate_password('userpassword')",
                    'class'   => 'nowrap',
                ));
            }
        }

        // Create mode
        if ($add_mode) {
            // copy password to password confirm field
            $data['userpassword2'] = $data['userpassword'];

            // Page title
            $title = $this->translate('user.add');
        }
        // Edit mode
        else {
            $title = $data['displayname'];
            if (empty($title)) {
                $title = $data['cn'];
            }

            // remove password
            $data['userpassword'] = '';
        }

        // Create form object and populate with fields
        $form = $this->form_create('user', $attribs, $sections, $fields, $fields_map, $data, $add_mode, $title);

        $this->output->add_translation('user.password.mismatch');

        return $form->output();
    }

    /**
     * List item handler
     */
    protected function list_item_handler($item)
    {
        return empty($item['displayname']) ? $item['cn'] : $item['displayname'];
    }

    /**
     * Returns true when current object matches logged user
     */
    protected function is_deletable($data)
    {
        return parent::is_deletable($data) && $data['id'] != $_SESSION['user']['id'];
    }
}
