This is the source code of Kolab Web Administration Panel


INTALLATION PROCEDURE
=====================

This package uses [Composer][1] to install and maintain required PHP libraries.
See doc/INSTALL for more details.

1. Install Composer

Execute this in the project root directory:

$ curl -s http://getcomposer.org/installer | php

This will create a file named composer.phar in the project directory.

2. Install Dependencies

$ cp composer.json-dist composer.json
$ php composer.phar install

4. Create database structure from doc/kolab_wap.sql.

5. Configure/Add [kolab_wap] section of /etc/kolab/kolab.conf file.
See doc/sample-kolab.conf.

6. Give write access for the webserver user to the 'logs' and 'cache' folders:

$ chown <www-user> logs
$ chown <www-user> cache

7. Configure your webserver to point to the public_html directory of this
package as document root. See doc/kolab-webadmin.conf for an example Apache config.

[1]: http://getcomposer.org
