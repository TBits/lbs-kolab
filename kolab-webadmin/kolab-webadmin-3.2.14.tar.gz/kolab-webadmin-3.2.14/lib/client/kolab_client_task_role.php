<?php
/*
 +--------------------------------------------------------------------------+
 | This file is part of the Kolab Web Admin Panel                           |
 |                                                                          |
 | Copyright (C) 2011-2012, Kolab Systems AG                                |
 |                                                                          |
 | This program is free software: you can redistribute it and/or modify     |
 | it under the terms of the GNU Affero General Public License as published |
 | by the Free Software Foundation, either version 3 of the License, or     |
 | (at your option) any later version.                                      |
 |                                                                          |
 | This program is distributed in the hope that it will be useful,          |
 | but WITHOUT ANY WARRANTY; without even the implied warranty of           |
 | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the             |
 | GNU Affero General Public License for more details.                      |
 |                                                                          |
 | You should have received a copy of the GNU Affero General Public License |
 | along with this program. If not, see <http://www.gnu.org/licenses/>      |
 +--------------------------------------------------------------------------+
 | Author: Aleksander Machniak <machniak@kolabsys.com>                      |
 +--------------------------------------------------------------------------+
*/

class kolab_client_task_role extends kolab_client_task
{
    protected $ajax_only = true;

    protected $menu = array(
        'add'  => 'role.add',
    );

    protected $list_attribs = array('cn');

    /**
     * Default action.
     */
    public function action_default()
    {
        $this->output->set_object('content', 'role', true);
        $this->output->set_object('task_navigation', $this->menu());

        $this->action_list();

        // display form to add role if logged-in user has right to do so
        $caps = $this->get_capability('actions');
        if (!empty($caps['role.add'])) {
            $this->action_add();
        }
        else {
            $this->output->command('set_watermark', 'taskcontent');
        }
    }

    /**
     * Role information (form) action.
     */
    public function action_info()
    {
        $id     = $this->get_input('id', 'POST');
        $result = $this->api_get('role.info', array('id' => $id));
        $role   = $result->get();
        $output = $this->role_form(null, $role);

        $this->output->set_object('taskcontent', $output);
    }

    /**
     * Roles adding (form) action.
     */
    public function action_add()
    {
        $data   = $this->get_input('data', 'POST');
        $output = $this->role_form(null, $data, true);

        $this->output->set_object('taskcontent', $output);
    }

    /**
     * Role edit/add form.
     */
    private function role_form($attribs, $data = array())
    {
        if (empty($attribs['id'])) {
            $attribs['id'] = 'role-form';
        }

        // Form sections
        $sections = array(
            'system'   => 'role.system',
            'other'    => 'role.other',
        );

        // field-to-section map and fields order
        $fields_map = array(
            'type_id'       => 'system',
            'type_id_name'  => 'system',
            'cn'            => 'system',
            'description'   => 'system',
        );

        // Prepare fields
        $form = $this->form_prepare('role', $data, array(), null, $fields_map['type_id']);
        list($fields, $types, $type, $add_mode) = $form;

        // Create form object and populate with fields
        $form = $this->form_create('role', $attribs, $sections, $fields, $fields_map, $data, $add_mode);

        return $form->output();
    }

    private function parse_members($list)
    {
        // convert to key=>value array, see kolab_api_service_form_value::list_options_uniquemember()
        foreach ($list as $idx => $value) {
            if (!empty($value['displayname'])) {
                $list[$idx] = $value['displayname'];
            } elseif (!empty($value['cn'])) {
                $list[$idx] = $value['cn'];
            } else {
                //console("No display name or cn for $idx");
            }

            if (!empty($value['mail'])) {
                $list[$idx] .= ' <' . $value['mail'] . '>';
            }
        }

        return $list;
    }

}
