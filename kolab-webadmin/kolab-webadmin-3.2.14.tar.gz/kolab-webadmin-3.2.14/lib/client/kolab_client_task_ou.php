<?php
/*
 +--------------------------------------------------------------------------+
 | This file is part of the Kolab Web Admin Panel                           |
 |                                                                          |
 | Copyright (C) 2011-2014, Kolab Systems AG                                |
 |                                                                          |
 | This program is free software: you can redistribute it and/or modify     |
 | it under the terms of the GNU Affero General Public License as published |
 | by the Free Software Foundation, either version 3 of the License, or     |
 | (at your option) any later version.                                      |
 |                                                                          |
 | This program is distributed in the hope that it will be useful,          |
 | but WITHOUT ANY WARRANTY; without even the implied warranty of           |
 | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the             |
 | GNU Affero General Public License for more details.                      |
 |                                                                          |
 | You should have received a copy of the GNU Affero General Public License |
 | along with this program. If not, see <http://www.gnu.org/licenses/>      |
 +--------------------------------------------------------------------------+
 | Author: Aleksander Machniak <machniak@kolabsys.com>                      |
 +--------------------------------------------------------------------------+
*/

class kolab_client_task_ou extends kolab_client_task
{
    protected $ajax_only = true;

    protected $menu = array(
        'add'  => 'ou.add',
    );

    protected $list_attribs   = array('ou');
    protected $search_attribs = array('name'  => array('ou'));


    /**
     * Default action.
     */
    public function action_default()
    {
        $this->output->set_object('content', 'ou', true);
        $this->output->set_object('task_navigation', $this->menu());

        $this->action_list();

        // display form to add OU if logged-in user has right to do so
        $caps = $this->get_capability('actions');
        if (!empty($caps['ou.add'])) {
            $this->action_add();
        }
        else {
            $this->output->command('set_watermark', 'taskcontent');
        }
    }

    /**
     * Organizational unit adding (form) action.
     */
    public function action_add()
    {
        $data   = $this->get_input('data', 'POST');
        $output = $this->ou_form(null, $data, true);

        $this->output->set_object('taskcontent', $output);
    }

    /**
     * Organizational unit information (form) action.
     */
    public function action_info()
    {
        $id     = $this->get_input('id', 'POST');
        $result = $this->api_get('ou.info', array('id' => $id));
        $unit   = $result->get();
        $output = $this->ou_form(null, $unit);

        $this->output->set_object('taskcontent', $output);
    }

    /**
     * OU list result handler, tree list builder
     */
    protected function list_result_handler($result, $head, $foot, $table_class)
    {
        $result = $this->ou_list_sort($result);
        $result = $this->ou_list_build_tree($result, $max_tree_level);

        foreach ($result as $idx => $item) {
            $class = array('selectable');
            $tree  = '';
            $style = '';

            if ($item['level']) {
                $tree .= '<span class="level" style="width:' . ($item['level'] * 16) . 'px"></span>';
                $style = 'display:none';
            }

            if ($item['has_children']) {
                $tree .= '<span class="expando font-icon"></span>';
            }
            else if ($max_tree_level) {
                $tree .= '<span class="spacer"></span>';
            }

            $i++;
            $cells = array();
            $cells[] = array(
                'class'   => 'name',
                'body'    => $tree . kolab_html::escape($item['name']),
                'onclick' => "kadm.command('ou.info', '" . kolab_utils::js_escape($idx) . "')",
            );

            $rows[] = array(
                'id'    => $i,
                'class' => implode(' ', $class),
                'cells' => $cells,
                'style' => $style,
                'data-level' => !empty($item['level']) ? $item['level'] : '',
            );
        }

        if ($max_tree_level) {
            $this->output->command('tree_list_init');
        }

        return array($rows, $head, '', $table_class . ' tree');
    }

    private function ou_form($attribs, $data = array())
    {
        if (empty($attribs['id'])) {
            $attribs['id'] = 'ou-form';
        }

        // Form sections
        $sections = array(
            'system' => 'ou.system',
            'aci'    => 'ou.aci',
            'other'  => 'ou.other',
        );

        // field-to-section map and fields order
        $fields_map = array(
            'type_id'         => 'system',
            'type_id_name'    => 'system',
            'ou'              => 'system',
            'base_dn'         => 'system',
            'description'     => 'system',

            'aci'             => 'aci',
        );

        // Prepare fields
        $form = $this->form_prepare('ou', $data, array(), null, $fields_map['type_id']);
        list($fields, $types, $type, $add_mode) = $form;

        // Add OU root selector
        $fields['base_dn'] = array(
            'section' => $fields_map['base_dn'],
            'type'    => kolab_form::INPUT_SELECT,
            'options' => array_merge(array(''), $this->ou_list()),
            'escaped' => true,
            'default' => $data['base_dn'],
        );

        // Create mode
        if ($add_mode) {
            // Page title
            $title = $this->translate('ou.add');
        }
        // Edit mode
        else {
            $title = $data['ou'];
        }

        // Create form object and populate with fields
        $form = $this->form_create('ou', $attribs, $sections, $fields, $fields_map, $data, $add_mode);

        $form->set_title(kolab_html::escape($title));

        return $form->output();
    }

    private function ou_list()
    {
        $result = $this->api_get('ous.list', null, array('page_size' => 999));
        $list   = (array) $result->get('list');

        $sorted = $this->ou_list_sort($list);

        return $this->ou_list_build($sorted);
    }

    private function ou_list_sort($list)
    {
        // build the list for sorting
        foreach (array_keys($list) as $dn) {
            $names     = $this->explode_dn($dn);
            $sort_name = $names['root'] . ':' . implode(',', array_reverse($names['path']));
            $list[$dn] = mb_strtolower($sort_name);
        }

        // sort
        asort($list, SORT_LOCALE_STRING);

        return $list;
    }

    private function ou_list_build($list)
    {
        // @TODO: this code assumes parent always exist
        foreach (array_keys($list) as $dn) {
            $item      = $this->parse_dn($dn);
            $list[$dn] = str_repeat('&nbsp;&nbsp;&nbsp;', $item['level']) . kolab_html::escape($item['name']);
        }

        return $list;
    }

    /**
     * Builds a tree from OUs list
     */
    private function ou_list_build_tree($list, &$max_level)
    {
        $last   = '';
        $result = array();

        foreach (array_keys($list) as $dn) {
            $item = $this->parse_dn($dn);

            if ($item['level']) {
                // create a parent unit entry if it does not exist (search result)
                $parent = $item['root'];

                foreach ($item['path'] as $sub) {
                    // convert special characters back into entities (#3744)
                    $sub    = str_replace(',', "\\2C", $sub);
                    $parent = "ou=$sub,$parent";

                    if (!isset($result[$parent])) {
                        $result[$parent] = $this->parse_dn($parent);
                        $last = $parent;
                    }

                    $result[$parent]['has_children'] = true;
                }
            }

            $result[$dn] = $item;
            $last        = $dn;
            $max_level   = max($max_level, $item['level']);
        }

        return $result;
    }

    /**
     * Parse OU DN string into an array
     */
    private function parse_dn($dn)
    {
        $items = $this->explode_dn($dn);

        return array(
            'name'  => array_shift($items['path']),
            'path'  => array_reverse($items['path']),
            'level' => count($items['path']),
            'root'  => $items['root'],
        );
    }

    /**
     * Tokenizes OU's DN string
     */
    private function explode_dn($dn)
    {
        $path = kolab_utils::explode_dn($dn);
        $root = array();

        foreach ($path as $idx => $item) {
            $pos = strpos($item, '=');
            $key = substr($item, 0, $pos);

            if ($key != 'ou') {
                unset($path[$idx]);
                // convert special characters back into entities (#3744)
                $root[] = str_replace(',', "\\2C", $item);
            }
            else {
                $path[$idx] = substr($item, $pos + 1);
            }
        }

        return array(
            'root' => implode(',', $root),
            'path' => $path,
        );
    }
}
