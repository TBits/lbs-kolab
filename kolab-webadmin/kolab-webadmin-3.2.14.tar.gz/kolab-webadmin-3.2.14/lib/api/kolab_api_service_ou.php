<?php
/*
 +--------------------------------------------------------------------------+
 | This file is part of the Kolab Web Admin Panel                           |
 |                                                                          |
 | Copyright (C) 2011-2014, Kolab Systems AG                                |
 |                                                                          |
 | This program is free software: you can redistribute it and/or modify     |
 | it under the terms of the GNU Affero General Public License as published |
 | by the Free Software Foundation, either version 3 of the License, or     |
 | (at your option) any later version.                                      |
 |                                                                          |
 | This program is distributed in the hope that it will be useful,          |
 | but WITHOUT ANY WARRANTY; without even the implied warranty of           |
 | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the             |
 | GNU Affero General Public License for more details.                      |
 |                                                                          |
 | You should have received a copy of the GNU Affero General Public License |
 | along with this program. If not, see <http://www.gnu.org/licenses/>      |
 +--------------------------------------------------------------------------+
 | Author: Aleksander Machniak <machniak@kolabsys.com>                      |
 | Author: Jeroen van Meeuwen <vanmeeuwen@kolabsys.com>                     |
 +--------------------------------------------------------------------------+
*/

/**
 *
 */
class kolab_api_service_ou extends kolab_api_service
{
    /**
     * Returns service capabilities.
     *
     * @param string $domain Domain name
     *
     * @return array Capabilities list
     */
    public function capabilities($domain)
    {
        $auth             = Auth::get_instance($domain);
        $effective_rights = $auth->list_rights('ou');
        $rights           = array();

        if (in_array('add', $effective_rights['entryLevelRights'])) {
            $rights['add'] = "w";
        }

        if (in_array('delete', $effective_rights['entryLevelRights'])) {
            $rights['delete'] = "w";
        }

        if (in_array('modrdn', $effective_rights['entryLevelRights'])) {
            $rights['edit'] = "w";
        }

        if (in_array('read', $effective_rights['entryLevelRights'])) {
            $rights['info'] = "r";
            $rights['find'] = "r";
            $rights['members_list'] = "r";
        }

        $rights['effective_rights'] = "r";

        return $rights;
    }

    /**
     * Create organizational unit.
     *
     * @param array $get   GET parameters
     * @param array $post  POST parameters
     *
     * @return array|bool Unit attributes or False on failure
     */
    public function ou_add($getdata, $postdata)
    {
        $attributes = $this->parse_input_attributes('ou', $postdata);
        $auth       = Auth::get_instance();
        $result     = $auth->organizationalunit_add($attributes, $postdata['type_id']);

        if ($result) {
            if ($id = $this->unique_attribute_value($result)) {
                $attributes['id'] = $id;
            }

            return $attributes;
        }

        return FALSE;
    }

    /**
     * Delete organizational unit.
     *
     * @param array $get   GET parameters
     * @param array $post  POST parameters
     *
     * @return bool True on success, False on failure
     */
    public function ou_delete($getdata, $postdata)
    {
        if (empty($postdata['id'])) {
            return FALSE;
        }

        // TODO: Input validation
        $auth   = Auth::get_instance();
        $result = $auth->organizationalunit_delete($postdata['id']);

        if ($result) {
            return $result;
        }

        return FALSE;
    }

    public function ou_edit($getdata, $postdata)
    {
        $unit_attributes = $this->parse_input_attributes('ou', $postdata);

        $auth   = Auth::get_instance();
        $result = $auth->organizationalunit_edit($postdata['id'], $unit_attributes, $postdata['type_id']);

        // @TODO: return unique attribute or all attributes as ou_add()
        if ($result) {
            return true;
        }

        return false;
    }

    public function ou_effective_rights($getdata, $postdata)
    {
        $auth = Auth::get_instance();

        // Org. units are special in that they are ldapsubentries.
        if (!empty($getdata['id'])) {
            $unique_attr = self::unique_attribute();
            $unit        = $auth->organizationalunit_find_by_attribute(array($unique_attr => $getdata['id']));

            if (is_array($unit) && count($unit) == 1) {
                $unit_dn = key($unit);
            }
        }

        $effective_rights = $auth->list_rights(empty($unit_dn) ? 'ou' : $unit_dn);

        return $effective_rights;
    }

    /**
     * Organizational unit information.
     *
     * @param array $get   GET parameters
     * @param array $post  POST parameters
     *
     * @return array|bool Unit attributes or False on failure
     */
    public function ou_info($getdata, $postdata)
    {
        if (empty($getdata['id'])) {
            return false;
        }

        $auth   = Auth::get_instance();
        $attrs  = $this->object_attributes('ou');
        $result = $auth->organizationalunit_info($getdata['id'], $attrs);

        // normalize result
        $result = $this->parse_result_attributes('ou', $result);

        if ($result) {
            // get base_dn "attribute" for the API client
            $dn = substr($result['entrydn'], strlen($result['ou']) + 4);
            if (strpos($dn, 'ou=') === 0) {
                $result['base_dn'] = $dn;
            }

            return $result;
        }

        return false;
    }

    /**
     * Find organizational unit and return its data.
     * It is a combination of ou.info and ous.list with search capabilities
     * If the search returns only one record we'll return unit data.
     *
     * @param array $get   GET parameters
     * @param array $post  POST parameters
     *
     * @return array|bool Unit attributes, False on error
     */
    public function ou_find($get, $post)
    {
        $auth       = Auth::get_instance();
        $attributes = array('');
        $params     = array('page_size' => 2);
        $search     = $this->parse_list_search($post);

        // find OU(s)
        $units = $auth->list_organizationalunits(null, $attributes, $search, $params);

        if (empty($units) || empty($units['list']) || $units['count'] > 1) {
            return false;
        }

        // get OU data
        $attrs  = $this->object_attributes('ou');
        $result = $auth->organizationalunit_info(key($units['list']), $attrs);

        // normalize result
        $result = $this->parse_result_attributes('ou', $result);

        if ($result) {
            return $result;
        }

        return false;
    }
}
