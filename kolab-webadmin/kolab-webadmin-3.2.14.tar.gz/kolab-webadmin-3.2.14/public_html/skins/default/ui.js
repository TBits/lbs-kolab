/*
 +--------------------------------------------------------------------------+
 | This file is part of the Kolab Web Admin Panel                           |
 |                                                                          |
 | Copyright (C) 2011-2012, Kolab Systems AG                                |
 |                                                                          |
 | This program is free software: you can redistribute it and/or modify     |
 | it under the terms of the GNU Affero General Public License as published |
 | by the Free Software Foundation, either version 3 of the License, or     |
 | (at your option) any later version.                                      |
 |                                                                          |
 | This program is distributed in the hope that it will be useful,          |
 | but WITHOUT ANY WARRANTY; without even the implied warranty of           |
 | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the             |
 | GNU Affero General Public License for more details.                      |
 |                                                                          |
 | You should have received a copy of the GNU Affero General Public License |
 | along with this program. If not, see <http://www.gnu.org/licenses/>      |
 +--------------------------------------------------------------------------+
 | Author: Aleksander Machniak <machniak@kolabsys.com>                      |
 +--------------------------------------------------------------------------+
*/

/**
 * Search form events
 */
function search_init(command)
{
  kadm.env.search_command = command;

  $('#searchinput').addClass('form-control').attr('placeholder', kadm.t('search'))
    .keypress(function(e) {
      if (this.value && e.which == 13) { // ENTER key
        var props = kadm.serialize_form('#search-form');
        props.search = this.value;

        kadm.command(kadm.env.search_command, props);
      }
    })
};

function search_reset()
{
  kadm.command(kadm.env.search_command, {search: ''});
};

function search_details()
{
  var div = $('div.searchdetails', $('#search'));

  if (!div.is(':visible'))
    div.slideDown(200);
  else
    div.slideUp(200);
};

/**
 * Fieldsets-to-tabs converter
 * Warning: don't place "caller" <script> inside page element (id)
 */
function init_tabs(id, current)
{
  var content = $('#'+id),
    fs = content.children('fieldset');

  if (!fs.length)
    return;

  // TODO: preselect the current tab

  content.each(function(idx, item) {
    var tabs = [], nav = $('<ul>').attr({'class': 'nav nav-tabs', role: 'tablist'});

    $(this).addClass('tab-content').children('fieldset').each(function(i, fieldset) {
      var tab, id = fieldset.id || ('tab' + idx + '-' + i),
        tab_class = $(fieldset).data('navlink-class');

      $(fieldset).addClass('tab-pane').attr({id: id, role: 'tabpanel'});
      tab = $('<li>').addClass('nav-item').append(
        $('<a>').addClass('nav-link' + (tab_class ? ' ' + tab_class : ''))
          .attr({role: 'tab', 'href': '#' + id})
          .text($('legend', fieldset).first().text())
          .click(function(e) { $(this).tab('show'); return false; })
        );
      $('legend', fieldset).first().hide();
      tabs.push(tab);
    });

    // create the navigation bar
    nav.append(tabs).insertBefore(item);

    // activate the first tab
    $('a.nav-link', nav).first().click();
  });
};

// Domain selector initializer
function domain_selector()
{
  // domain selector
  if (kadm.env.domains && kadm.env.domains.length > 1) {
    var form = $('#domain-selector-form');

    kadm.env.assoc_fields = {domain: kadm.env.domains};
    kadm.form_init('domain-selector-form');

    $('input[name="domain"]', form).change(function() {
      window.location = '?domain=' + urlencode(this.value);
    });
  }
};

// Form "onload" handler
function form_load(id)
{
  if (id != 'search-form')
    init_tabs(id);

  if (id == 'type-form') {
    // add double-click event on attributes list
    $('#type_attr_table tbody').on('dblclick', 'tr:not("#type_attr_form")', function() {
      var button = $('a.button.edit', this);
      if (button.length)
        button.click();
    });
  }
};

// UI loader
function ui_load()
{
  domain_selector();

  // set minimum width of the page
  var width = $('#logo').width() + 50;
  $('#navigation li').each(function() { width += $(this).width(); });
  $('body').css('min-width', width);
};

// API response handler
function http_response(response)
{
  // update domain selector
  if (response.action == 'domain.list')
    domain_selector();
};

/**
 * UI Initialization
 */
kadm.add_event_listener('form-load', form_load);
kadm.add_event_listener('http-response', http_response);
$(window).on('load', function() { ui_load(); });
