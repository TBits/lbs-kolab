My `composer.json`:

```json
...replace me...
```

Output of `composer diagnose`:

```
...replace me...
```

When I run this command:

```
...replace me...
```

I get the following output:

```
...replace me...
```

And I expected this to happen:
