#!/bin/bash

version=$1

git archive --prefix=roundcubemail-skin-kolab-${version}/ HEAD | \
    gzip -c > roundcubemail-skin-kolab-${version}.tar.gz

git archive --prefix=roundcubemail-skin-kolab-now-${version}/ HEAD | \
    gzip -c > roundcubemail-skin-kolab-now-${version}.tar.gz

git archive --prefix=roundcubemail-skin-plesk-${version}/ HEAD | \
    gzip -c > roundcubemail-skin-plesk-${version}.tar.gz
