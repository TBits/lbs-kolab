#!/bin/bash

version=$1

git archive --prefix=roundcubemail-skin-base4kids-${version}/ HEAD | \
    gzip -c > roundcubemail-skin-base4kids-${version}.tar.gz

git archive --prefix=roundcubemail-skin-contargo-${version}/ HEAD | \
    gzip -c > roundcubemail-skin-contargo-${version}.tar.gz

git archive --prefix=roundcubemail-skin-kolab-${version}/ HEAD | \
    gzip -c > roundcubemail-skin-kolab-${version}.tar.gz

git archive --prefix=roundcubemail-skin-now-${version}/ HEAD | \
    gzip -c > roundcubemail-skin-now-${version}.tar.gz

git archive --prefix=roundcubemail-skin-plesk-${version}/ HEAD | \
    gzip -c > roundcubemail-skin-plesk-${version}.tar.gz
