<?php

/**
 +--------------------------------------------------------------------------+
 | This file is part of the Kolab REST API                                  |
 |                                                                          |
 | Copyright (C) 2012-2015, Kolab Systems AG                                |
 |                                                                          |
 | This program is free software: you can redistribute it and/or modify     |
 | it under the terms of the GNU Affero General Public License as published |
 | by the Free Software Foundation, either version 3 of the License, or     |
 | (at your option) any later version.                                      |
 |                                                                          |
 | This program is distributed in the hope that it will be useful,          |
 | but WITHOUT ANY WARRANTY; without even the implied warranty of           |
 | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the             |
 | GNU Affero General Public License for more details.                      |
 |                                                                          |
 | You should have received a copy of the GNU Affero General Public License |
 | along with this program. If not, see <http://www.gnu.org/licenses/>      |
 +--------------------------------------------------------------------------+
 | Author: Aleksander Machniak <machniak@kolabsys.com>                      |
 +--------------------------------------------------------------------------+
*/

abstract class kolab_api_output
{
    const STATUS_OK    = 200;
    const STATUS_EMPTY = 204;

    protected $api;
    protected $messages = array(
        self::STATUS_OK    => 'OK',
        self::STATUS_EMPTY => 'No content',
    );


    /**
     * Factory method to create output object
     * according to the API request input
     *
     * @param kolab_api The API
     *
     * @return kolab_api_output Output object
     */
    public static function factory($api)
    {
        // default mode of kolab format
        $mode = 'xml';

        $modes_map = array(
//            'text/html' => 'html',
//            'application/html+xml' => 'xml',
            'application/xml'      => 'xml',
            'application/json'     => 'json',
        );

        foreach ((array) $api->input->supports as $type) {
            if ($_mode = $modes_map[$type]) {
                $mode = $_mode;
                break;
            }
        }
$mode = 'json';
        $class = "kolab_api_output_$mode";
        return new $class($api);
    }

    /**
     * Object constructor
     *
     * @param kolab_api The API
     */
    public function __construct($api)
    {
        $this->api = $api;
    }

    /**
     * Set response headers (must be done before send()).
     *
     * @param array Response headers
     * @param array Context (folder_uid, object_uid, object)
     */
    public function headers($headers, $context = null)
    {
        if ($this->api->filter) {
            $this->api->filter->headers($headers, $context);
        }

        if (!empty($headers)) {
            if ($this->api->config->get('kolab_api_debug')) {
                rcube::console($headers);
            }

            foreach ((array) $headers as $header => $value) {
                header($header . ': ' . $value);
            }
        }
    }

    /**
     * Send status of successful (empty) response
     *
     * @param int  $status Status code
     * @param bool $exit   Call exit()
     */
    public function send_status($status, $exit = true)
    {
        if ($this->api->filter) {
            $this->api->filter->send_status($status);
        }

        $message = $this->messages[$status];

        header("HTTP/1.1 $status $message");

        if ($exit) {
            exit;
        }
    }

    /**
     * Send successful response
     *
     * @param mixed  Response data
     * @param string Data type
     * @param array  Context (folder_uid, object_uid, object)
     */
    abstract function send($data, $type, $context = null);
}
