<?php

/**
 +--------------------------------------------------------------------------+
 | This file is part of the Kolab REST API                                  |
 |                                                                          |
 | Copyright (C) 2012-2015, Kolab Systems AG                                |
 |                                                                          |
 | This program is free software: you can redistribute it and/or modify     |
 | it under the terms of the GNU Affero General Public License as published |
 | by the Free Software Foundation, either version 3 of the License, or     |
 | (at your option) any later version.                                      |
 |                                                                          |
 | This program is distributed in the hope that it will be useful,          |
 | but WITHOUT ANY WARRANTY; without even the implied warranty of           |
 | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the             |
 | GNU Affero General Public License for more details.                      |
 |                                                                          |
 | You should have received a copy of the GNU Affero General Public License |
 | along with this program. If not, see <http://www.gnu.org/licenses/>      |
 +--------------------------------------------------------------------------+
 | Author: Aleksander Machniak <machniak@kolabsys.com>                      |
 +--------------------------------------------------------------------------+
*/

class kolab_api_input_json_attachment
{

    /**
     * Convert attachment input array into an array that can
     * be handled by the API
     *
     * @param array              Request body
     * @param rcube_message_part Original object data (on update)
     */
    public function input(&$data, $original = null)
    {
        if (empty($data) || !is_array($data)) {
            throw new kolab_api_exception(kolab_api_exception::INVALID_REQUEST);
        }

        $result = new rcube_message_part;
        $empty  = true;

        // supported attachment data fields
        $fields = array(
//            'id',
            'mimetype',
//            'size',
            'filename',
            'disposition',
            'content-id',
            'content-location',
            'upload-id',
        );

        // first unset rcube_message_part defaults
        $result->mimetype = null;
        $result->encoding = null;

        foreach ($fields as $field) {
            if (!array_key_exists($field, $data)) {
                continue;
            }

            $value = $data[$field];
            $empty = false;

            switch ($field) {
            case 'content-id':
            case 'content-location':
            case 'upload-id':
                $field = str_replace('-', '_', $field);
                break;
            }

            // add the value to the result
            if ($value !== null && $value !== '' && (!is_array($value) || !empty($value))) {
                // make sure we have utf-8 here
                $value = rcube_charset::clean($value);
            }

            $result->{$field} = $value;
        }

        if ($empty) {
            throw new kolab_api_exception(kolab_api_exception::INVALID_REQUEST);
        }

        $data = $result;
    }
}
