<?php

/**
 +--------------------------------------------------------------------------+
 | This file is part of the Kolab REST API                                  |
 |                                                                          |
 | Copyright (C) 2012-2015, Kolab Systems AG                                |
 |                                                                          |
 | This program is free software: you can redistribute it and/or modify     |
 | it under the terms of the GNU Affero General Public License as published |
 | by the Free Software Foundation, either version 3 of the License, or     |
 | (at your option) any later version.                                      |
 |                                                                          |
 | This program is distributed in the hope that it will be useful,          |
 | but WITHOUT ANY WARRANTY; without even the implied warranty of           |
 | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the             |
 | GNU Affero General Public License for more details.                      |
 |                                                                          |
 | You should have received a copy of the GNU Affero General Public License |
 | along with this program. If not, see <http://www.gnu.org/licenses/>      |
 +--------------------------------------------------------------------------+
 | Author: Aleksander Machniak <machniak@kolabsys.com>                      |
 +--------------------------------------------------------------------------+
*/

class kolab_api_input_json_folder
{

    /**
     * Convert folder input array into internal format
     *
     * @param array            Request body
     * @param kolab_api_folder Original object data (on update)
     */
    public function input(&$data, $original = null)
    {
        // folder objects don't need to be converted
        // we do some sanity check only

        if (empty($data) || !is_array($data)) {
            throw new kolab_api_exception(kolab_api_exception::INVALID_REQUEST);
        }

        if ($original) {
            $result = $original;
        }
        // hack for unit-tests
        else if (class_exists('kolab_api_tests_folder', false)) {
            $result = new kolab_api_tests_folder;
        }
        else {
            $result = new kolab_api_folder;
        }

        foreach (array('name', 'parent', 'type', 'subscribed') as $key) {
            $result->{$key} = $data[$key];
        }

        if (!$result->changed() || !$result->valid()) {
            throw new kolab_api_exception(kolab_api_exception::INVALID_REQUEST);
        }

        $data = $result;
    }
}
