<?php

/**
 +--------------------------------------------------------------------------+
 | This file is part of the Kolab REST API                                  |
 |                                                                          |
 | Copyright (C) 2012-2015, Kolab Systems AG                                |
 |                                                                          |
 | This program is free software: you can redistribute it and/or modify     |
 | it under the terms of the GNU Affero General Public License as published |
 | by the Free Software Foundation, either version 3 of the License, or     |
 | (at your option) any later version.                                      |
 |                                                                          |
 | This program is distributed in the hope that it will be useful,          |
 | but WITHOUT ANY WARRANTY; without even the implied warranty of           |
 | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the             |
 | GNU Affero General Public License for more details.                      |
 |                                                                          |
 | You should have received a copy of the GNU Affero General Public License |
 | along with this program. If not, see <http://www.gnu.org/licenses/>      |
 +--------------------------------------------------------------------------+
 | Author: Aleksander Machniak <machniak@kolabsys.com>                      |
 +--------------------------------------------------------------------------+
*/

class kolab_api_input_json_task
{
    // map xml/json attributes into internal (kolab_format)
    protected $field_map = array(
        'description' => 'description',
        'title'       => 'summary',
        'sensitivity' => 'class',
        'sequence'    => 'sequence',
        'categories'  => 'categories',
        'created'     => 'created',
        'changed'     => 'dtstamp',
        'complete'    => 'percent-complete',
        'status'      => 'status',
        'start'       => 'dtstart',
        'due'         => 'due',
        'parent_id'   => 'related-to',
        'location'    => 'location',
        'priority'    => 'priority',
        'url'         => 'url',
        'attendees'   => 'attendee',
        'organizer'   => 'organizer',
        'recurrence'  => 'rrule',
    );


    /**
     * Convert task input array into an array that can
     * be handled by kolab_storage_folder::save()
     *
     * @param array Request body
     * @param array Original object data (on update)
     */
    public function input(&$data, $original = null)
    {
        if (empty($data) || !is_array($data)) {
            throw new kolab_api_exception(kolab_api_exception::INVALID_REQUEST);
        }

        foreach ($this->field_map as $kolab => $api) {
            if (!array_key_exists($api, $data)) {
                continue;
            }

            $value = $data[$api];

            switch ($kolab) {
            case 'sensitivity':
                if ($value) {
                    $value = strtolower($value);
                }
                break;

            case 'parent_id':
                // kolab_format_task supports only one parent
                if (is_array($value)) {
                    $value = $value[0];
                }
                break;

            case 'created':
            case 'changed':
            case 'start':
            case 'due':
                $value = kolab_api_input_json::to_datetime($value);
                break;

            case 'attendees':
                $value = kolab_api_input_json::parse_attendees($value);
                break;

            case 'organizer':
                if (!empty($value)) {
                    $value = kolab_api_input_json::parse_attendees(array($value));
                    $value = $value[0];
                }
                break;
            }

            $result[$kolab] = $value;
        }

        // @TOOD: alarms

        kolab_api_input_json::parse_recurrence($data, $result);

        // x-custom fields
        kolab_api_input_json::add_x_custom($data, $result);

        if (empty($result)) {
            throw new kolab_api_exception(kolab_api_exception::INVALID_REQUEST);
        }

        if (!empty($original)) {
            $result = array_merge($original, $result);
        }

        $data = $result;
    }
}
