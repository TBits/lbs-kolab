<?php

/**
 +--------------------------------------------------------------------------+
 | This file is part of the Kolab REST API                                  |
 |                                                                          |
 | Copyright (C) 2012-2015, Kolab Systems AG                                |
 |                                                                          |
 | This program is free software: you can redistribute it and/or modify     |
 | it under the terms of the GNU Affero General Public License as published |
 | by the Free Software Foundation, either version 3 of the License, or     |
 | (at your option) any later version.                                      |
 |                                                                          |
 | This program is distributed in the hope that it will be useful,          |
 | but WITHOUT ANY WARRANTY; without even the implied warranty of           |
 | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the             |
 | GNU Affero General Public License for more details.                      |
 |                                                                          |
 | You should have received a copy of the GNU Affero General Public License |
 | along with this program. If not, see <http://www.gnu.org/licenses/>      |
 +--------------------------------------------------------------------------+
 | Author: Aleksander Machniak <machniak@kolabsys.com>                      |
 +--------------------------------------------------------------------------+
*/

class kolab_api_input_json_contact
{
    // map xml/json attributes into internal (kolab_format)
    protected $field_map = array(
//        'created'     => 'creation-date',
        'changed'     => 'rev',
        'categories'  => 'categories',
        'kind'        => 'kind', // not supported by kolab_format_contact
        'freebusyurl' => 'fburl',
        'notes'       => 'note',
        'name'        => 'fn',
        'jobtitle'    => 'title',
        'nickname'    => 'nickname',
        'birthday'    => 'bday',
        'anniversary' => 'anniversary',
        'photo'       => 'photo',
        'gender'      => 'gender',
        'im'          => 'impp',
        'lang'        => 'lang',
        'geo'         => 'geo',      // not supported by kolab_format_contact
        'x-crypto'    => 'x-crypto', // not supported by kolab_format_contact
        // the rest of properties is handled separately
    );

    protected $address_props = array(
        // 'parameters',
        // 'pobox',
        // 'ext',
        'street',
        'locality',
        'region',
        'code',
        'country'
    );

    protected $gendermap = array(
        'M' => 'male',
        'F' => 'female',
    );


    /**
     * Convert contact input array into an array that can
     * be handled by kolab_storage_folder::save()
     *
     * @param array Request body
     * @param array Original object data (on update)
     */
    public function input(&$data, $original = null)
    {
        if (empty($data) || !is_array($data)) {
            throw new kolab_api_exception(kolab_api_exception::INVALID_REQUEST);
        }

        foreach ($this->field_map as $kolab => $api) {
            if (!array_key_exists($api, $data)) {
                continue;
            }

            $value = $data[$api];

            switch ($kolab) {
            case 'gender':
                $value = $this->gendermap[$value];
                break;

            case 'created':
            case 'changed':
            case 'birthday':
            case 'anniversary':
                $value = kolab_api_input_json::to_datetime($value);
                break;

            case 'photo':
                if (preg_match('/^(data:image\/[a-z]+;base64,).+$/i', $value, $m)) {
                    $value = base64_decode(substr($value, strlen($m[1])));
                }
                else {
                    continue 2;
                }
                break;

            case 'jobtitle':
                $value = (array) $value;
                break;

            case 'kind':
                if ($value == 'group') {
                    $result['_type'] = 'distribution-list';
                }
                break;
            }

            $result[$kolab] = $value;
        }

        // contact name properties
        if (array_key_exists('n', $data)) {
            $name_attrs = array(
                'surname'    => 'surname',
                'firstname'  => 'given',
                'middlename' => 'additional',
                'prefix'     => 'prefix',
                'suffix'     => 'suffix',
            );

            foreach ($name_attrs as $kolab => $api) {
                $result[$kolab] = $data['n'][$api];
            }
        }

        // contact additional properties
        if (array_key_exists('group', $data)) {
            $group_changed          = true;
            $result['organization'] = null;
            $result['department']   = null;
            $result['profession']   = null;
            $result['manager']      = null;
            $result['assistant']    = null;

            foreach ((array) $data['group'] as $idx => $entry) {
                // organization, department
                if ($idx == 'org') {
                    if (is_array($entry) && count($entry) > 1) {
                        $result['organization'] = $entry[0];
                        $result['department']   = $entry[1];
                    }
                    else {
                        $result['organization'] = is_array($entry) ? $entry[0] : $entry;
                    }
                }
                // profession
                else if ($idx == 'role') {
                    $result['profession'] = $entry;
                }
                // manager, assistant
                else if ($idx == 'related') {
                    foreach ((array) $entry as $item) {
                        if ($item['text'] !== null) {
                            foreach (array('manager', 'assistant') as $i) {
                                if ($item['parameters']['type'] == "x-$i") {
                                    $result[$i] = $item['text'];
                                }
                            }
                        }
                    }
                }
                // office address
                else if ($idx == 'adr') {
                    $address = array('type' => 'office');
                    foreach ($this->address_props as $prop) {
                        if ($entry[$prop] !== null) {
                            $address[$prop] = $entry[$prop];
                        }
                    }

                    $result['address'][] = $address;
                }
            }
        }

        // website url
        if (array_key_exists('url', $data)) {
            $result['website'] = array();

            foreach ((array) $data['url'] as $url) {
                if (is_array($url) && $url['url']) {
                    $result['website'][] = array(
                        'url'  => $url['url'],
                        'type' => $url['parameters']['type'],
                    );
                }
                else if ($url) {
                    $result['website'][] = array('url' => $url);
                }
            }
        }

        // home and work address
        if (array_key_exists('adr', $data)) {
            $adr_changed = true;

            foreach ((array) $data['adr'] as $addr) {
                $address = array('type' => $addr['parameters']['type']);
                foreach ($this->address_props as $prop) {
                    if ($addr[$prop] !== null) {
                        $address[$prop] = $addr[$prop];
                    }
                }

                $result['address'][] = $address;
            }
        }

        // spouse, children
        if (array_key_exists('related', $data)) {
            $result['spouse']   = null;
            $result['children'] = array();

            foreach ($data['related'] as $entry) {
                if (isset($entry['text'])) {
                    $type = $entry['parameters']['type'];
                    if ($type == 'spouse') {
                        $result['spouse'] = $entry['text'];
                    }
                    else if ($type == 'child') {
                        $result['children'][] = $entry['text'];
                    }
                }
            }
        }

        // phone numbers
        if (array_key_exists('tel', $data)) {
            $result['phone'] = array();

            foreach ((array) $data['tel'] as $phone) {
                if (!empty($phone) && isset($phone['text'])) {
                    $type = implode('', (array) $phone['parameters']['type']);

                    $aliases = array(
                        'faxhome'   => 'homefax',
                        'faxwork'   => 'workfax',
                        'x-car'     => 'car',
                        'textphone' => 'other',
                        'cell'      => 'mobile',
                        'voice'     => 'main',
                    );

                    $result['phone'][] = array(
                        'type'   => $aliases[$type] ?: $type,
                        'number' => $phone['text'],
                    );
                }
            }
        }

        // email addresses
        if (array_key_exists('email', $data)) {
            $result['email'] = array();

            foreach ($data['email'] as $email) {
                if (!empty($email)) {
                    if (!is_array($email)) {
                        $result['email'][] = array(
                            'type'    => 'other',
                            'address' => $email,
                        );
                    }
                    else if (isset($email['text'])) {
                        $type = implode('', (array) $email['parameters']['type']);
                        $result['email'][] = array(
                            'type'    => $type ? $type : 'other',
                            'address' => $email['text'],
                        );
                    }
                }
            }
        }

        // PGP or S/MIME key
        if (array_key_exists('key', $data)) {
            $key_types = array(
                'pgp-keys'   => 'pgppublickey',
                'pkcs7-mime' => 'pkcs7publickey',
            );

            foreach ($key_types as $type) {
                $result[$type] = null;
            }

            foreach ((array) $data['key'] as $key) {
                if (preg_match('#^data:application/(pgp-keys|pkcs7-mime);base64,#', $key, $m)) {
                    $result[$key_types[$m[1]]] = base64_decode(substr($key, strlen($m[0])));
                }
            }
        }

        // Group members
        if (!empty($data['member'])) {
            $result['member'] = array();

            foreach ((array) $data['member'] as $member) {
                $uri_params = array();
                if (stripos($member, 'urn:uuid:') === 0) {
                    if ($uid = substr($member, 9)) {
                        $result['member'][] = array('uid' => $uid);
                    }
                }
                else if ($email = kolab_api_input_json::parse_mailto_uri($member, $uri_params)) {
                    $result['member'][] = array(
                        'email' => $email,
                        'name'  => $uri_params['cn'],
                    );
                }
            }
        }

        // x-custom fields
        kolab_api_input_json::add_x_custom($data, $result);

        // @TODO: which contact properties should we require?
        if (empty($result)) {
            throw new kolab_api_exception(kolab_api_exception::INVALID_REQUEST);
        }

        if (!empty($original)) {
            // fix addresses merging...
            $addresses = (array) $original['address'];

            // unset office address
            if ($group_changed) {
                foreach ($addresses as $idx => $adr) {
                    if ($adr['type'] == 'office') {
                        unset($addresses[$idx]);
                    }
                }
            }

            // unset other addresses
            if ($adr_changed) {
                foreach ($addresses as $idx => $adr) {
                    if ($adr['type'] != 'office') {
                        unset($addresses[$idx]);
                    }
                }
            }

            // merge old and new addresses
            if (isset($result['address']) && !empty($addresses)) {
                $result['address'] = array_merge($result['address'], $addresses);
            }

            $result = array_merge($original, $result);
        }

        $data = $result;
    }
}
