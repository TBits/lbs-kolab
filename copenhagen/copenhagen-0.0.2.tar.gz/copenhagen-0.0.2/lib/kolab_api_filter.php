<?php

/**
 +--------------------------------------------------------------------------+
 | This file is part of the Kolab REST API                                  |
 |                                                                          |
 | Copyright (C) 2012-2015, Kolab Systems AG                                |
 |                                                                          |
 | This program is free software: you can redistribute it and/or modify     |
 | it under the terms of the GNU Affero General Public License as published |
 | by the Free Software Foundation, either version 3 of the License, or     |
 | (at your option) any later version.                                      |
 |                                                                          |
 | This program is distributed in the hope that it will be useful,          |
 | but WITHOUT ANY WARRANTY; without even the implied warranty of           |
 | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the             |
 | GNU Affero General Public License for more details.                      |
 |                                                                          |
 | You should have received a copy of the GNU Affero General Public License |
 | along with this program. If not, see <http://www.gnu.org/licenses/>      |
 +--------------------------------------------------------------------------+
 | Author: Aleksander Machniak <machniak@kolabsys.com>                      |
 +--------------------------------------------------------------------------+
*/

abstract class kolab_api_filter
{
    /**
     * Modify initial request path
     *
     * @param array (Exploded) request path
     */
    abstract function path(&$path);

    /**
     * Executed before every api action
     *
     * @param kolab_api_input Request data
     */
    abstract function input(&$input);

    /**
     * Executed when parsing request body
     *
     * @param array  Request body
     * @param string Object type
     * @param array  Original object data (set on update requests)
     */
    abstract function input_body(&$data, $type, $original = null);

    /**
     * Apply filter on output data
     *
     * @param array  Result data
     * @param string Object type
     * @param array  Context (folder_uid, object_uid, object)
     * @param array  Optional attributes filter
     */
    abstract function output(&$output, $type, $context, $attrs_filter = array());

    /**
     * Executed for response headers
     *
     * @param array Response headers
     * @param array Context (folder_uid, object_uid, object)
     */
    abstract function headers(&$headers, $context = null);

    /**
     * Executed for empty response status
     *
     * @param int Status code
     */
    abstract function send_status(&$status);
}
