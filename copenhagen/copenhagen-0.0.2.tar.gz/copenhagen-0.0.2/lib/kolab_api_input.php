<?php

/**
 +--------------------------------------------------------------------------+
 | This file is part of the Kolab REST API                                  |
 |                                                                          |
 | Copyright (C) 2012-2015, Kolab Systems AG                                |
 |                                                                          |
 | This program is free software: you can redistribute it and/or modify     |
 | it under the terms of the GNU Affero General Public License as published |
 | by the Free Software Foundation, either version 3 of the License, or     |
 | (at your option) any later version.                                      |
 |                                                                          |
 | This program is distributed in the hope that it will be useful,          |
 | but WITHOUT ANY WARRANTY; without even the implied warranty of           |
 | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the             |
 | GNU Affero General Public License for more details.                      |
 |                                                                          |
 | You should have received a copy of the GNU Affero General Public License |
 | along with this program. If not, see <http://www.gnu.org/licenses/>      |
 +--------------------------------------------------------------------------+
 | Author: Aleksander Machniak <machniak@kolabsys.com>                      |
 +--------------------------------------------------------------------------+
*/

abstract class kolab_api_input
{
    public $method;
    public $action;
    public $path     = array();
    public $args     = array();
    public $supports = array();
    public $headers  = array();
    public $api;
    public $filter;
    public $input_body;



    /**
     * Factory method to create input object
     * according to the API request input
     *
     * @param kolab_api The API
     *
     * @return kolab_api_input Output object
     */
    public static function factory($api)
    {
        // default mode
        $mode = 'json';

        $class = "kolab_api_input_$mode";
        return new $class($api);
    }

    /**
     * Object constructor
     */
    public function __construct($api)
    {
        $this->api    = $api;
        $this->method = $_SERVER['REQUEST_METHOD'];

        if ($this->method == 'POST' && !empty($_SERVER['HTTP_X_HTTP_METHOD'])) {
            $this->method = $_SERVER['HTTP_X_HTTP_METHOD'];
        }

        $this->path = self::request_path($this->filter);

        // remove first argument - action name
        $this->action = array_shift($this->path);

        if ($this->api->config->get('kolab_api_debug')) {
            rcube::console($this->method . ': ' . self::request_uri());
            // @TODO: log request input data for PUT/POST
        }

        $accept_header = strtolower(rcube_utils::request_header('Accept'));
        list($this->supports,) = explode(';', $accept_header);
        $this->supports        = explode(',', $this->supports);

        // store GET arguments
        $this->args = $_GET;
        unset($this->args['api']);
        unset($this->args['request']);
    }

    /**
     * Parse request arguments
     *
     * @return array Request arguments
     */
    public static function request_path(&$filter = null)
    {
        $api  = (string) $_GET['api'];
        $path = explode('/', trim((string) $_GET['request'], ' /'));

        // map api specific request to Kolab API
        if ($api && class_exists("kolab_api_filter_$api")) {
            $class  = "kolab_api_filter_$api";
            $filter = new $class;
            $filter->path($path);
        }

        foreach ($path as $idx => $value) {
            $path[$idx] = strip_tags($value);
        }

        $path[0] = strtolower($path[0]);

        return $path;
    }

    /**
     * Return request URI (for logging)
     */
    public static function request_uri()
    {
        $url = trim((string) $_GET['request'], ' /');
        list($uri, $params) = explode('?', $_SERVER['REQUEST_URI']);

        if ($params) {
            $url .= '?' . $params;
        }

        return $url;
    }

    /**
     * Return specified request header value
     *
     * @param string $name Header name
     *
     * @return string Header value
     */
    public function request_header($name)
    {
        if (empty($name)) {
            return;
        }

        if (!array_key_exists($name, $this->headers)) {
            $this->headers[$name] = rcube_utils::request_header($name);
        }

        return $this->headers[$name];
    }

    /**
     * Get request data (JSON)
     *
     * @param string Expected object type
     * @param bool   Disable filters application
     * @param array  Original object data (set on update requests)
     *
     * @return array Request data
     */
    abstract function input($type = null, $disable_filters = false, $original = null);
}
