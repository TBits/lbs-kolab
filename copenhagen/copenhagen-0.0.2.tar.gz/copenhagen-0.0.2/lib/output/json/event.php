<?php

/**
 +--------------------------------------------------------------------------+
 | This file is part of the Kolab REST API                                  |
 |                                                                          |
 | Copyright (C) 2012-2015, Kolab Systems AG                                |
 |                                                                          |
 | This program is free software: you can redistribute it and/or modify     |
 | it under the terms of the GNU Affero General Public License as published |
 | by the Free Software Foundation, either version 3 of the License, or     |
 | (at your option) any later version.                                      |
 |                                                                          |
 | This program is distributed in the hope that it will be useful,          |
 | but WITHOUT ANY WARRANTY; without even the implied warranty of           |
 | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the             |
 | GNU Affero General Public License for more details.                      |
 |                                                                          |
 | You should have received a copy of the GNU Affero General Public License |
 | along with this program. If not, see <http://www.gnu.org/licenses/>      |
 +--------------------------------------------------------------------------+
 | Author: Aleksander Machniak <machniak@kolabsys.com>                      |
 +--------------------------------------------------------------------------+
*/

class kolab_api_output_json_event
{
    protected $output;
    protected $attrs_filter;
    protected $array_elements = array(
        'attach',
        'attendee',
        'categories',
        'x-custom',
        'valarm',
    );


    /**
     * Object constructor
     *
     * @param kolab_api_output Output object
     */
    public function __construct($output)
    {
        $this->output = $output;
    }

    /**
     * Convert data into an array
     *
     * @param array Data
     * @param array Optional attributes filter
     *
     * @return array Data
     */
    public function element($data, $attrs_filter = array())
    {
        // partial data
        if (is_array($data) && count($data) == 1) {
            return $data;
        }

        $this->attrs_filter = $attrs_filter;

        $result = $this->output->object_to_array($data, 'event', 'vevent');
        $result = array_map(array($this, 'subelement'), $result);

        $event = array_shift($result);

        if (!empty($result) && (empty($attrs_filter) || in_array('exceptions', $attrs_filter))) {
            $event['exceptions'] = $result;
        }

        return $event;
    }

    /**
     * Event properties converter
     */
    protected function subelement($element)
    {
        if (!empty($this->attrs_filter)) {
            $element['properties'] = array_intersect_key($element['properties'],
                array_combine($this->attrs_filter, $this->attrs_filter));
        }

        // add 'components' to the result
        if (!empty($element['components'])) {
            $element['properties'] += (array) $element['components'];
        }

        $element = $element['properties'];

        kolab_api_output_json::parse_array_result($element, $this->array_elements);

        // make sure exdate/rdate format is unified
        kolab_api_output_json::parse_recurrence($element);

        return $element;
    }
}
