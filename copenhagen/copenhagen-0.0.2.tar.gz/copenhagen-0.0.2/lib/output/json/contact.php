<?php

/**
 +--------------------------------------------------------------------------+
 | This file is part of the Kolab REST API                                  |
 |                                                                          |
 | Copyright (C) 2012-2015, Kolab Systems AG                                |
 |                                                                          |
 | This program is free software: you can redistribute it and/or modify     |
 | it under the terms of the GNU Affero General Public License as published |
 | by the Free Software Foundation, either version 3 of the License, or     |
 | (at your option) any later version.                                      |
 |                                                                          |
 | This program is distributed in the hope that it will be useful,          |
 | but WITHOUT ANY WARRANTY; without even the implied warranty of           |
 | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the             |
 | GNU Affero General Public License for more details.                      |
 |                                                                          |
 | You should have received a copy of the GNU Affero General Public License |
 | along with this program. If not, see <http://www.gnu.org/licenses/>      |
 +--------------------------------------------------------------------------+
 | Author: Aleksander Machniak <machniak@kolabsys.com>                      |
 +--------------------------------------------------------------------------+
*/

class kolab_api_output_json_contact
{
    protected $output;
    protected $array_elements = array(
//        'group', // @TODO
        'adr',
        'related',
        'url',
        'lang',
        'tel',
        'impp',
        'email',
        'geo',
        'key',
        'title',
        'categories',
        'member', //dist-list
        'x-custom',
    );


    /**
     * Object constructor
     *
     * @param kolab_api_output Output object
     */
    public function __construct($output)
    {
        $this->output = $output;
    }

    /**
     * Convert data into an array
     *
     * @param array Data
     * @param array Optional attributes filter
     *
     * @return array Data
     */
    public function element($data, $attrs_filter = array())
    {
        // partial data
        if (is_array($data) && count($data) == 1) {
            $attrs_filter = array(key($data));
        }

        $result = $this->output->object_to_array($data, 'contact', 'vcard', $attrs_filter, $this->array_elements);
        $result = $result[0];

        if ($result['uid'] && strpos($result['uid'], 'urn:uuid:') === 0) {
            $result['uid'] = substr($result['uid'], 9);
        }

        return $result;
    }
}
