<?php

/**
 +--------------------------------------------------------------------------+
 | This file is part of the Kolab REST API                                  |
 |                                                                          |
 | Copyright (C) 2012-2015, Kolab Systems AG                                |
 |                                                                          |
 | This program is free software: you can redistribute it and/or modify     |
 | it under the terms of the GNU Affero General Public License as published |
 | by the Free Software Foundation, either version 3 of the License, or     |
 | (at your option) any later version.                                      |
 |                                                                          |
 | This program is distributed in the hope that it will be useful,          |
 | but WITHOUT ANY WARRANTY; without even the implied warranty of           |
 | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the             |
 | GNU Affero General Public License for more details.                      |
 |                                                                          |
 | You should have received a copy of the GNU Affero General Public License |
 | along with this program. If not, see <http://www.gnu.org/licenses/>      |
 +--------------------------------------------------------------------------+
 | Author: Aleksander Machniak <machniak@kolabsys.com>                      |
 +--------------------------------------------------------------------------+
*/

class kolab_api_output_xml extends kolab_api_output
{
    public static $prod_id;
    public static $version;
    public static $x_version;

    /**
     * Object constructor
     *
     * @param kolab_api The API
     */
    public function __construct($api)
    {
        $this->api = $api;

        self::$prod_id   = 'Kolab REST API ' . kolab_api::VERSION;
        self::$version   = '2.0';
        self::$x_version = '3.1.0';
    }

    /**
     * Send successful response
     *
     * @param mixed  Response data
     * @param string Data type
     * @param array  Context (folder_uid, object_uid, object)
     * @param array  Optional attributes filter
     */
    public function send($data, $type, $context = null, $attrs_filter = array())
    {
        // Set output type
        // @TODO: object specific content-type, e.g. application/calendar+xml?
        $this->headers(array('Content-Type' => "application/xml; charset=utf-8"));

        list($type, $mode) = explode('-', $type);

        if ($mode != 'list') {
            $data = array($data);
        }

        $class = "kolab_api_output_xml_$type";
        $model = new $class($this);
        $debug = $this->api->config->get('kolab_api_debug');

        // create XML document
        $xml = new DOMDocument('1.0', RCUBE_CHARSET);
        $xml->xmlStandalone = false;
        $xml->formatOutput  = $debug;

        $dom = $model->structure($xml);

        foreach ($data as $item) {
            $model->append_element($item, $dom, $attrs_filter);
        }

        // generate XML output
        $result = $xml->saveXML();
        $xml    = null;

        if ($debug) {
            rcube::console(rtrim($result));
        }

        $this->send_status(kolab_api_output::STATUS_OK, false);

        // send XML output
        echo $result;
        exit;
    }

    /**
     * Helper to convert kolab_format object into DOMDocument
     *
     * @param kolab_format Object
     *
     * @return DOMDocument
     */
    public function object_to_dom($object, $type = null)
    {
        // load old object to preserve data we don't understand/process
        if (is_object($object['_formatobj'])) {
            $format = $object['_formatobj'];
        }

        // create new kolab_format instance
        if (!$format) {
            $format = kolab_format::factory($type, kolab_storage::$version);

            if (PEAR::isError($format)) {
                return;
            }

            $format->set($object);
        }

        $xml = $format->write(kolab_storage::$version);

        if (empty($xml) || !$format->is_valid() || !$format->uid) {
            return;
        }

        // parse XML
        $doc = new DOMDocument();
        $doc->loadXML($xml);

        return $doc;
    }

    /**
     * Attributes filter - removes attributes not listed in $attrs_filter
     *
     * @param DOMElement XML element
     * @param array      Attributes list
     */
    public static function attrs_filter(&$node, $attrs_filter)
    {
        if (empty($attrs_filter)) {
            return;
        }

        // @TODO
    }
}
