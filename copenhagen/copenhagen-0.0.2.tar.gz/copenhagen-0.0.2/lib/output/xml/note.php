<?php

/**
 +--------------------------------------------------------------------------+
 | This file is part of the Kolab REST API                                  |
 |                                                                          |
 | Copyright (C) 2012-2015, Kolab Systems AG                                |
 |                                                                          |
 | This program is free software: you can redistribute it and/or modify     |
 | it under the terms of the GNU Affero General Public License as published |
 | by the Free Software Foundation, either version 3 of the License, or     |
 | (at your option) any later version.                                      |
 |                                                                          |
 | This program is distributed in the hope that it will be useful,          |
 | but WITHOUT ANY WARRANTY; without even the implied warranty of           |
 | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the             |
 | GNU Affero General Public License for more details.                      |
 |                                                                          |
 | You should have received a copy of the GNU Affero General Public License |
 | along with this program. If not, see <http://www.gnu.org/licenses/>      |
 +--------------------------------------------------------------------------+
 | Author: Aleksander Machniak <machniak@kolabsys.com>                      |
 +--------------------------------------------------------------------------+
*/

class kolab_api_output_xml_note
{
    const XMLNS = "http://kolab.org";

    protected $output;


    /**
     * Object constructor
     *
     * @param kolab_api_output Output object
     */
    public function __construct($output)
    {
        $this->output = $output;
    }

    /**
     * Convert data array into XML
     *
     * @param array      Data object
     * @param DOMElement XML element
     * @param array      Optional attributes filter
     */
    public function append_element($data, $xml, $attrs_filter = array())
    {
        $dom = $this->output->object_to_dom($data, 'note');

        if ($dom) {
            // get 'note' element
            $content = $dom->getElementsByTagName('note');

            // and copy it into output 'notes' element
            foreach ($content as $element) {
                $node = $xml->ownerDocument->importNode($element, true);
                kolab_api_output_xml::attrs_filter($node, $attrs_filter);
                $xml->appendChild($node);
            }
        }
    }

    /**
     * Add model-specific structure to the XML document
     *
     * @param DOMDocument XML Document
     *
     * @return DOMNode Element to which object structure will be added
     */
    public function structure($xml)
    {
        $doc = $xml->createElement('notes');
        $doc->setAttribute('xmlns', self::XMLNS);
        $doc->setAttribute('version', '3.0');
        $xml->appendChild($doc);

        return $doc;
    }
}
