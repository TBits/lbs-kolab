<?php

/**
 +--------------------------------------------------------------------------+
 | This file is part of the Kolab REST API                                  |
 |                                                                          |
 | Copyright (C) 2012-2015, Kolab Systems AG                                |
 |                                                                          |
 | This program is free software: you can redistribute it and/or modify     |
 | it under the terms of the GNU Affero General Public License as published |
 | by the Free Software Foundation, either version 3 of the License, or     |
 | (at your option) any later version.                                      |
 |                                                                          |
 | This program is distributed in the hope that it will be useful,          |
 | but WITHOUT ANY WARRANTY; without even the implied warranty of           |
 | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the             |
 | GNU Affero General Public License for more details.                      |
 |                                                                          |
 | You should have received a copy of the GNU Affero General Public License |
 | along with this program. If not, see <http://www.gnu.org/licenses/>      |
 +--------------------------------------------------------------------------+
 | Author: Aleksander Machniak <machniak@kolabsys.com>                      |
 +--------------------------------------------------------------------------+
*/

class kolab_api_output_xml_event
{
    const XMLNS = "urn:ietf:params:xml:ns:icalendar-2.0";

    protected $output;
    protected $type    = 'event';
    protected $wrapper = 'vevent';


    /**
     * Object constructor
     *
     * @param kolab_api_output Output object
     */
    public function __construct($output)
    {
        $this->output = $output;
    }

    /**
     * Convert data array into XML
     *
     * @param array      Data object
     * @param DOMElement XML element
     * @param array      Optional attributes filter
     */
    public function append_element($data, $xml, $attrs_filter = array())
    {
        $dom = $this->output->object_to_dom($data, $this->type);

        if ($dom) {
            // get object element(s)
            $content = $dom->getElementsByTagName($this->wrapper);

            // and copy it into output 'components' element
            foreach ($content as $element) {
                $node = $xml->ownerDocument->importNode($element, true);
                kolab_api_output_xml::attrs_filter($node, $attrs_filter);
                $xml->appendChild($node);
            }
        }
    }

    /**
     * Add model-specific structure to the XML document
     *
     * @param DOMDocument XML Document
     *
     * @return DOMNode Element to which object structure will be added
     */
    public function structure($xml)
    {
        $icalendar  = $xml->createElement('icalendar');
        $vcalendar  = $xml->createElement('vcalendar');
        $properties = $xml->createElement('properties');
        $components = $xml->createElement('components');

        $props = array(
            'prodid'          => kolab_api_output_xml::$prod_id,
            'version'         => kolab_api_output_xml::$version,
            'x-kolab-version' => kolab_api_output_xml::$x_version,
        );

        foreach ($props as $name => $value) {
            $prop = $xml->createElement($name);
            $prop->appendChild($xml->createElement('text', $value));
            $properties->appendChild($prop);
        }

        $icalendar->setAttribute('xmlns', self::XMLNS);
        $vcalendar->appendChild($properties);
        $vcalendar->appendChild($components);
        $icalendar->appendChild($vcalendar);
        $xml->appendChild($icalendar);

        return $components;
    }
}
