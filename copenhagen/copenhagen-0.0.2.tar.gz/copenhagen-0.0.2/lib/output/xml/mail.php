<?php

/**
 +--------------------------------------------------------------------------+
 | This file is part of the Kolab REST API                                  |
 |                                                                          |
 | Copyright (C) 2012-2015, Kolab Systems AG                                |
 |                                                                          |
 | This program is free software: you can redistribute it and/or modify     |
 | it under the terms of the GNU Affero General Public License as published |
 | by the Free Software Foundation, either version 3 of the License, or     |
 | (at your option) any later version.                                      |
 |                                                                          |
 | This program is distributed in the hope that it will be useful,          |
 | but WITHOUT ANY WARRANTY; without even the implied warranty of           |
 | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the             |
 | GNU Affero General Public License for more details.                      |
 |                                                                          |
 | You should have received a copy of the GNU Affero General Public License |
 | along with this program. If not, see <http://www.gnu.org/licenses/>      |
 +--------------------------------------------------------------------------+
 | Author: Aleksander Machniak <machniak@kolabsys.com>                      |
 +--------------------------------------------------------------------------+
*/

class kolab_api_output_xml_mail
{
    protected $output;


    /**
     * Object constructor
     *
     * @param kolab_api_output Output object
     */
    public function __construct($output)
    {
        $this->output = $output;
    }

    /**
     * Convert data array into XML
     *
     * @param array|kolab_api_mail Object data
     * @param DOMElement           XML element
     * @param array                Optional attributes filter
     */
    public function append_element($data, $xml, $attrs_filter = array())
    {
        $dom  = $xml->ownerDocument->createElement('message');
        $data = is_array($data) ? $data : $data->data($attrs_filter);

        foreach ($data as $name => $v) {
            if ($v !== null && $v !== '') {
                $this->add_element($xml, $dom, $name, $v);
            }
        }

        if ($dom->hasChildNodes()) {
            $xml->appendChild($dom);
        }
    }

    /**
     * Add model-specific structure to the XML document
     *
     * @param DOMDocument XML Document
     *
     * @return DOMNode Element to which object structure will be added
     */
    public function structure($xml)
    {
        $list = $xml->createElement('messages');
        $xml->appendChild($list);

        return $list;
    }

    /**
     * Add element to the XML document
     */
    protected function add_element($xml, $parent, $name, $value)
    {
        // @TODO: "array to xml dom php"
    }
}
