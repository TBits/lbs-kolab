<?php

/**
 +--------------------------------------------------------------------------+
 | This file is part of the Kolab REST API                                  |
 |                                                                          |
 | Copyright (C) 2012-2015, Kolab Systems AG                                |
 |                                                                          |
 | This program is free software: you can redistribute it and/or modify     |
 | it under the terms of the GNU Affero General Public License as published |
 | by the Free Software Foundation, either version 3 of the License, or     |
 | (at your option) any later version.                                      |
 |                                                                          |
 | This program is distributed in the hope that it will be useful,          |
 | but WITHOUT ANY WARRANTY; without even the implied warranty of           |
 | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the             |
 | GNU Affero General Public License for more details.                      |
 |                                                                          |
 | You should have received a copy of the GNU Affero General Public License |
 | along with this program. If not, see <http://www.gnu.org/licenses/>      |
 +--------------------------------------------------------------------------+
 | Author: Aleksander Machniak <machniak@kolabsys.com>                      |
 +--------------------------------------------------------------------------+
*/

class kolab_api extends rcube
{
    const APP_NAME = 'Kolab REST API';
    const VERSION  = '0.1';

    public $backend;
    public $filter;
    public $input;
    public $output;

    /**
     * Current time in UTC. Use it to override
     * system time, e.g. for unit-testing.
     *
     * @var DateTime
     */
    public static $now;

    protected $model;


    /**
     * This implements the 'singleton' design pattern
     *
     * @return kolab_api The one and only instance
     */
    public static function get_instance()
    {
        if (!self::$instance || !is_a(self::$instance, 'kolab_api')) {
            $path    = kolab_api_input::request_path();
            $request = array_shift($path) ?: 'info';
            $class   = 'kolab_api_' . $request;

            if (!$request || !class_exists($class)) {
                throw new kolab_api_exception(kolab_api_exception::NOT_FOUND, array(
                        'line'    => __LINE__,
                        'file'    => __FILE__,
                        'message' => "Invalid request method: $request"
                ));
            }

            self::$instance = new $class();
            self::$instance->startup();
        }

        return self::$instance;
    }

    /**
     * Initial startup function
     * to register session, create database and imap connections
     */
    protected function startup()
    {
        $this->init(self::INIT_WITH_DB | self::INIT_WITH_PLUGINS);

        // Get list of plugins
        // WARNING: We can use only plugins that are prepared for this
        //          e.g. are not using output or rcmail objects or
        //          doesn't throw errors when using them
        $plugins = (array) $this->config->get('kolab_api_plugins', array('kolab_auth'));
        $plugins = array_unique(array_merge($plugins, array('libkolab')));

        // this way we're compatible with Roundcube Framework 1.2
        // we can't use load_plugins() here
        foreach ($plugins as $plugin) {
            $this->plugins->load_plugin($plugin, true);
        }
    }

    /**
     * Exception handler
     *
     * @param kolab_api_exception Exception
     */
    public static function exception_handler($exception)
    {
        $code    = $exception->getCode();
        $message = $exception->getMessage();

        if ($code == 401) {
            header('WWW-Authenticate: Basic realm="' . self::APP_NAME .'"');
        }

        if (!$exception instanceof kolab_api_exception) {
            rcube::raise_error($exception, true, false);
        }

        header("HTTP/1.1 $code $message");
        exit;
    }

    /**
     * Program execution handler
     */
    protected function initialize_handler()
    {
        // Handle request input
        $this->input = kolab_api_input::factory($this);

        // Get input/output filter
        $this->filter = $this->input->filter;

        // Start session, validate it and authenticate the user if needed
        if (!$this->session_validate()) {
            $this->authenticate();
            $authenticated = true;
        }

        // Initialize backend
        $this->backend = kolab_api_backend::get_instance();

        // set response output class
        $this->output = kolab_api_output::factory($this);

        // Filter the input, we want this after authentication
        if ($this->filter) {
            $this->filter->input($this->input);
        }

        if ($authenticated) {
            $this->output->headers(array('X-Session-Token' => session_id()));
        }
    }

    /**
     * Script shutdown handler
     */
    public function shutdown()
    {
        parent::shutdown();

        // write performance stats to logs/console
        if ($this->config->get('devel_mode')) {
            if (function_exists('memory_get_peak_usage'))
                $mem = memory_get_peak_usage();
            else if (function_exists('memory_get_usage'))
                $mem = memory_get_usage();

            $log = trim(kolab_api_input::request_uri() . ($mem ? sprintf(' [%.1f MB]', $mem/1024/1024) : ''));

            if (defined('KOLAB_API_START')) {
                rcube::print_timer(KOLAB_API_START, $log);
            }
            else {
                rcube::console($log);
            }
        }
    }

    /**
     * Validate the submitted session token
     */
    protected function session_validate()
    {
        $sess_id = $this->input->request_header('X-Session-Token');

        if (empty($sess_id)) {
            session_start();
            return false;
        }

        session_id($sess_id);
        session_start();

        // Session timeout
        $timeout = $this->config->get('kolab_api_session_timeout');
        if ($timeout && $_SESSION['time'] && $_SESSION['time'] < time() - $timeout) {
            $_SESSION = array();
            return false;
        }

        // update session time
        $_SESSION['time'] = time();

        return true;
    }

    /**
     * Authentication request handler (HTTP Auth)
     */
    protected function authenticate()
    {
        if (!empty($_SERVER['PHP_AUTH_USER'])) {
            $username = $_SERVER['PHP_AUTH_USER'];
            $password = $_SERVER['PHP_AUTH_PW'];
        }
        // when used with (f)cgi no PHP_AUTH* variables are available without defining a special rewrite rule
        else if (!isset($_SERVER['PHP_AUTH_USER'])) {
            // "Basic didhfiefdhfu4fjfjdsa34drsdfterrde..."
            if (isset($_SERVER['REMOTE_USER'])) {
                $basicAuthData = base64_decode(substr($_SERVER['REMOTE_USER'], 6));
            }
            else if (isset($_SERVER['REDIRECT_REMOTE_USER'])) {
                $basicAuthData = base64_decode(substr($_SERVER['REDIRECT_REMOTE_USER'], 6));
            }
            else if (isset($_SERVER['Authorization'])) {
                $basicAuthData = base64_decode(substr($_SERVER['Authorization'], 6));
            }
            else if (isset($_SERVER['HTTP_AUTHORIZATION'])) {
                $basicAuthData = base64_decode(substr($_SERVER['HTTP_AUTHORIZATION'], 6));
            }

            if (isset($basicAuthData) && !empty($basicAuthData)) {
                list($username, $password) = explode(':', $basicAuthData);
            }
        }

        if (!empty($username)) {
            $backend = kolab_api_backend::get_instance();
            $result  = $backend->authenticate($username, $password);
        }

        if (empty($result)) {
            throw new kolab_api_exception(kolab_api_exception::UNAUTHORIZED);
        }

        $_SESSION['time'] = time();
    }

    /**
     * Handle API request
     */
    public function run()
    {
        $this->initialize_handler();

        $path   = $this->input->path;
        $method = $this->input->method;

        if (!$path[1] && $path[0] && $method == 'POST') {
            $this->api_object_create();
        }
        else if ($path[1]) {
            switch (strtolower($path[2])) {
            case 'attachments':
                if ($method == 'HEAD') {
                    $this->api_object_count_attachments();
                }
                else if ($method == 'GET') {
                    $this->api_object_list_attachments();
                }
                break;

            case '':
                if ($method == 'GET') {
                    $this->api_object_info();
                }
                else if ($method == 'PUT') {
                    $this->api_object_update();
                }
                else if ($method == 'HEAD') {
                    $this->api_object_exists();
                }
                else if ($method == 'DELETE') {
                    $this->api_object_delete();
                }
            }
        }

        throw new kolab_api_exception(kolab_api_exception::NOT_FOUND);
    }

    /**
     * Fetch object info
     */
    protected function api_object_info()
    {
        $folder  = $this->input->path[0];
        $uid     = $this->input->path[1];
        $object  = $this->backend->object_get($folder, $uid);
        $context = array('folder_uid' => $folder, 'object' => $object);
        $props   = $this->input->args['properties'] ? explode(',', $this->input->args['properties']) : null;

        $this->output->send($object, $this->model, $context, $props);
    }

    /**
     * Create an object
     */
    protected function api_object_create()
    {
        $folder  = $this->input->path[0];
        $input   = $this->input->input($this->model);
        $context = array('folder_uid' => $folder);

        $uid = $this->backend->object_create($folder, $input, $this->model);

        $this->output->send(array('uid' => $uid), $this->model, $context, array('uid'));
    }

    /**
     * Update specified object
     */
    protected function api_object_update()
    {
        $folder  = $this->input->path[0];
        $uid     = $this->input->path[1];
        $object  = $this->backend->object_get($folder, $uid);
        $context = array(
            'folder_uid' => $folder,
            'object_uid' => $uid,
            'object'     => $object,
        );

        // parse input and merge with current data (result is in kolab_format/kolab_api_mail)
        $input = $this->input->input($this->model, false, $object);

        // update object on the backend
        $uid = $this->backend->object_update($folder, $input, $this->model);

        $this->output->send(array('uid' => $uid), $this->model, $context, array('uid'));
    }

    /**
     * Check if specified object exists
     */
    protected function api_object_exists()
    {
        $folder = $this->input->path[0];
        $uid    = $this->input->path[1];
        $object = $this->backend->object_get($folder, $uid);

        $this->output->send_status(kolab_api_output::STATUS_OK);
    }

    /**
     * Remove specified object
     */
    protected function api_object_delete()
    {
        $folder = $this->input->path[0];
        $uid    = $this->input->path[1];
        $object = $this->backend->object_get($folder, $uid);

        $this->backend->objects_delete($folder, array($uid));

        $this->output->send_status(kolab_api_output::STATUS_EMPTY);
    }

    /**
     * Count object attachments
     */
    protected function api_object_count_attachments()
    {
        $folder  = $this->input->path[0];
        $uid     = $this->input->path[1];
        $object  = $this->backend->object_get($folder, $uid);
        $context = array(
            'folder_uid' => $folder,
            'object_uid' => $uid,
            'object'     => $object,
        );

        $count = !empty($object['_attachments']) ? count($object['_attachments']) : 0;

        $this->output->headers(array('X-Count' => $count), $context);
        $this->output->send_status(kolab_api_output::STATUS_OK);
    }

    /**
     * List object attachments
     */
    protected function api_object_list_attachments()
    {
        $folder  = $this->input->path[0];
        $uid     = $this->input->path[1];
        $object  = $this->backend->object_get($folder, $uid);
        $props   = $this->input->args['properties'] ? explode(',', $this->input->args['properties']) : null;
        $context = array(
            'folder_uid' => $folder,
            'object_uid' => $uid,
            'object'     => $object,
        );

        // @TODO: currently Kolab format (libkolabxml) allows attachments
        // in events, tasks and notes. We should support them also in contacts

        $list = $this->get_object_attachments($object);

        $this->output->send($list, 'attachment-list', $context, $props);
    }

    /**
     * Extract attachments from the object, depending if it's
     * Kolab object or email message
     */
    protected function get_object_attachments($object)
    {
        // this is a kolab_format object data
        if (is_array($object)) {
            $list = (array) $object['_attachments'];

            foreach ($list as $idx => $att) {
                $attachment = new rcube_message_part;

                $attachment->mime_id     = $att['id'];
                $attachment->filename    = $att['name'];
                $attachment->mimetype    = $att['mimetype'];
                $attachment->size        = $att['size'];
                $attachment->disposition = 'attachment';
                $attachment->encoding    = $att['encoding'];

                $list[$idx] = $attachment;
            }
        }
        // this is kolab_api_mail or rcube_message(_header)
        else {
            $list = (array) $object->attachments;
        }

        return $list;
    }

    /**
     * Convert kolab_format object into API format
     *
     * @param array  Object data in kolab_format
     * @param string Object type
     *
     * @return array Object data in API format
     */
    public function get_object_data($object, $type)
    {
        $output = $this->output;

        if (!$this->output instanceof kolab_api_output_json) {
            $class  = "kolab_api_output_json";
            $output = new $class($this);
        }

        return $output->convert($object, $type);
    }

    /**
     * Returns RFC2822 formatted current date in user's timezone
     *
     * @return string Date
     */
    public function user_date()
    {
        // get user's timezone
        try {
            $tz   = new DateTimeZone($this->config->get('timezone'));
            $date = self::$now ?: new DateTime('now');
            $date->setTimezone($tz);
        }
        catch (Exception $e) {
            $date = new DateTime();
        }

        return $date->format('r');
    }
}
