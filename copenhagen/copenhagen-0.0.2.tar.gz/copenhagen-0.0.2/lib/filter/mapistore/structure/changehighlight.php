<?php

/**
 +--------------------------------------------------------------------------+
 | This file is part of the Kolab REST API                                  |
 |                                                                          |
 | Copyright (C) 2012-2015, Kolab Systems AG                                |
 |                                                                          |
 | This program is free software: you can redistribute it and/or modify     |
 | it under the terms of the GNU Affero General Public License as published |
 | by the Free Software Foundation, either version 3 of the License, or     |
 | (at your option) any later version.                                      |
 |                                                                          |
 | This program is distributed in the hope that it will be useful,          |
 | but WITHOUT ANY WARRANTY; without even the implied warranty of           |
 | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the             |
 | GNU Affero General Public License for more details.                      |
 |                                                                          |
 | You should have received a copy of the GNU Affero General Public License |
 | along with this program. If not, see <http://www.gnu.org/licenses/>      |
 +--------------------------------------------------------------------------+
 | Author: Aleksander Machniak <machniak@kolabsys.com>                      |
 +--------------------------------------------------------------------------+
*/

/**
 * ChangeHighlight structure definition according to MS-OXOCAL 2.2.1.44.3
 */
class kolab_api_filter_mapistore_structure_changehighlight extends kolab_api_filter_mapistore_structure
{
    protected $structure = array(
        'ChangeHighlightSize'   => array('type' => 'ULONG'),
        'ChangeHighlightValue'  => array('type' => 'ULONG', 'default' => 0),
        'Reserved'              => array('type' => 'STRING'),
    );

    /**
     * Convert binary input into internal structure
     *
     * @param string $input  Binary representation of the structure
     * @param bool   $base64 Set to TRUE if the input is base64-encoded
     *
     * @return int Number of bytes read from the binary input
     */
    public function input($input, $base64 = false)
    {
        if ($base64) {
            $input = base64_decode($input);
        }

        // Read size
        $unpack = unpack('V', substr($input, 0, 4));
        $value  = $unpack[1];

        $this->structure['Reserved']['length'] = $value - 4;

        return parent::input($input, false);
    }

    /**
     * Convert internal structure into binary string
     *
     * @param bool $base64 Enables base64 encoding of the output
     *
     * @return string Binary representation of the structure
     */
    public function output($base64 = false)
    {
        $this->data['ChangeHighlightSize'] = strlen($this->data['Reserved']) + 4;

        return parent::output($base64);
    }
}
