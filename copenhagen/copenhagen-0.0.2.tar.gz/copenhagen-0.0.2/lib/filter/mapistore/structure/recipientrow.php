<?php

/**
 +--------------------------------------------------------------------------+
 | This file is part of the Kolab REST API                                  |
 |                                                                          |
 | Copyright (C) 2012-2015, Kolab Systems AG                                |
 |                                                                          |
 | This program is free software: you can redistribute it and/or modify     |
 | it under the terms of the GNU Affero General Public License as published |
 | by the Free Software Foundation, either version 3 of the License, or     |
 | (at your option) any later version.                                      |
 |                                                                          |
 | This program is distributed in the hope that it will be useful,          |
 | but WITHOUT ANY WARRANTY; without even the implied warranty of           |
 | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the             |
 | GNU Affero General Public License for more details.                      |
 |                                                                          |
 | You should have received a copy of the GNU Affero General Public License |
 | along with this program. If not, see <http://www.gnu.org/licenses/>      |
 +--------------------------------------------------------------------------+
 | Author: Aleksander Machniak <machniak@kolabsys.com>                      |
 +--------------------------------------------------------------------------+
*/

/**
 * RecipientRow structure definition according to MS-OXCDATA 2.8.3
 */
class kolab_api_filter_mapistore_structure_recipientrow extends kolab_api_filter_mapistore_structure
{
    protected $structure = array(
        'RecipientFlags'        => array('type' => 'kolab_api_filter_mapistore_structure_recipientflags'),
        'AddressPrefixUsed'     => array('type' => 'BYTE'),
        'DisplayType'           => array('type' => 'WORD'),
        'X500DN'                => array('type' => 'STRING'),
        'EntryIdSize'           => array('type' => 'WORD', 'default' => 0),
        'EntryId'               => array('type' => 'STRING'),
        'SearchKeySize'         => array('type' => 'WORD'),
        'SearchKey'             => array(),
        'AddressType'           => array(),
        'EmailAddress'          => array(),
        'DisplayName'           => array(),
        'SimpleDisplayName'     => array(),
        'TransmittableDisplayName' => array(),
        'RecipientColumnCount'  => array('type' => 'WORD'),
        'RecipientProperties'   => array('type' => '[kolab_api_filter_mapistore_structure_propertyrow]'),
    );

    const DISPLAYTYPE_USER          = 0x00;
    const DISPLAYTYPE_LIST          = 0x01;
    const DISPLAYTYPE_FORUM         = 0x02;
    const DISPLAYTYPE_AGENT         = 0x03;
    const DISPLAYTYPE_ABOOK         = 0x04;
    const DISPLAYTYPE_PRIVATE       = 0x05;
    const DISPLAYTYPE_ABOOK_REMOTE  = 0x06;
}
