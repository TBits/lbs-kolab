<?php

/**
 +--------------------------------------------------------------------------+
 | This file is part of the Kolab REST API                                  |
 |                                                                          |
 | Copyright (C) 2012-2015, Kolab Systems AG                                |
 |                                                                          |
 | This program is free software: you can redistribute it and/or modify     |
 | it under the terms of the GNU Affero General Public License as published |
 | by the Free Software Foundation, either version 3 of the License, or     |
 | (at your option) any later version.                                      |
 |                                                                          |
 | This program is distributed in the hope that it will be useful,          |
 | but WITHOUT ANY WARRANTY; without even the implied warranty of           |
 | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the             |
 | GNU Affero General Public License for more details.                      |
 |                                                                          |
 | You should have received a copy of the GNU Affero General Public License |
 | along with this program. If not, see <http://www.gnu.org/licenses/>      |
 +--------------------------------------------------------------------------+
 | Author: Aleksander Machniak <machniak@kolabsys.com>                      |
 +--------------------------------------------------------------------------+
*/

/**
 * AppointmentRecurrencePattern structure definition according to MS-OXOCAL 2.2.1.44.5
 */
class kolab_api_filter_mapistore_structure_appointmentrecurrencepattern extends kolab_api_filter_mapistore_structure
{
    protected $structure = array(
        'RecurrencePattern'     => array('type' => 'kolab_api_filter_mapistore_structure_recurrencepattern'),
        'ReaderVersion'         => array('type' => 'ULONG', 'default' => 0x00003006),
        'WriterVersion'         => array('type' => 'ULONG', 'default' => 0x00003009),
        'StartTimeOffset'       => array('type' => 'ULONG'),
        'EndTimeOffset'         => array('type' => 'ULONG'),
        'ExceptionCount'        => array('type' => 'WORD'),
        'ExceptionInfo'         => array('type' => '[kolab_api_filter_mapistore_structure_exceptioninfo]', 'counter' => 'ExceptionCount'),
        'ReservedBlock1Size'    => array('type' => 'ULONG', 'default' => 0),
        'ReservedBlock1'        => array('type' => 'STRING', 'counter' => 'ReservedBlock1Size'),
        'ExtendedException'     => array('type' => '[kolab_api_filter_mapistore_structure_extendedexception]', 'counter' => 'ExceptionCount'),
        'ReservedBlock2Size'    => array('type' => 'ULONG', 'default' => 0),
        'ReservedBlock2'        => array('type' => 'STRING', 'counter' => 'ReservedBlock2Size'),
    );

    /**
     * Convert internal structure into binary string
     *
     * @param bool $base64 Enables base64 encoding of the output
     *
     * @return string Binary representation of the structure
     */
    public function output($base64 = false)
    {
        if (count($this->data['ExceptionInfo']) != count($this->data['ExtendedException'])) {
            throw new kolab_api_exception(kolab_api_exception::SERVER_ERROR, array(
                    'line'    => __LINE__,
                    'file'    => __FILE__,
                    'message' => 'ExceptionInfo and ExtendedException need to be of the same size'
            ));
        }

        $this->data['ExceptionCount']     = count($this->data['ExceptionInfo']);
        $this->data['ReservedBlock1Size'] = strlen($this->data['ReservedBlock1']);
        $this->data['ReservedBlock2Size'] = strlen($this->data['ReservedBlock2']);

        return parent::output($base64);
    }
}
