<?php

/**
 +--------------------------------------------------------------------------+
 | This file is part of the Kolab REST API                                  |
 |                                                                          |
 | Copyright (C) 2012-2015, Kolab Systems AG                                |
 |                                                                          |
 | This program is free software: you can redistribute it and/or modify     |
 | it under the terms of the GNU Affero General Public License as published |
 | by the Free Software Foundation, either version 3 of the License, or     |
 | (at your option) any later version.                                      |
 |                                                                          |
 | This program is distributed in the hope that it will be useful,          |
 | but WITHOUT ANY WARRANTY; without even the implied warranty of           |
 | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the             |
 | GNU Affero General Public License for more details.                      |
 |                                                                          |
 | You should have received a copy of the GNU Affero General Public License |
 | along with this program. If not, see <http://www.gnu.org/licenses/>      |
 +--------------------------------------------------------------------------+
 | Author: Aleksander Machniak <machniak@kolabsys.com>                      |
 +--------------------------------------------------------------------------+
*/

/**
 * PidLidAppointmentTimeZoneDefinitionRecur structure definition according to MS-OXOCAL 2.2.1.41
 */
class kolab_api_filter_mapistore_structure_timezonedefinition extends kolab_api_filter_mapistore_structure
{
    protected $structure = array(
        'MajorVersion'  => array('type' => 'BYTE', 'default' => 0x02),
        'MinorVersion'  => array('type' => 'BYTE', 'default' => 0x01),
        'cbHeader'      => array('type' => 'WORD'),
        'Reserved'      => array('type' => 'WORD', 'default' => 0x0002),
        'cchKeyName'    => array('type' => 'WORD'),
        'KeyName'       => array('type' => 'WSTRING', 'counter' => 'cchKeyName', 'default' => ''),
        'cRules'        => array('type' => 'WORD'),
        'TZRules'       => array('type' => '[kolab_api_filter_mapistore_structure_tzrule]', 'counter' => 'cRules'),
    );


    /**
     * Convert binary input into internal structure
     *
     * @param string $input  Binary representation of the structure
     * @param bool   $base64 Set to TRUE if the input is base64-encoded
     *
     * @return int Number of bytes read from the binary input
     */
/*
    public function input($input, $base64 = false)
    {
        if ($base64) {
            $input = base64_decode($input);
        }

        // Read KeyName field size
        $unpack = unpack('V', substr($input, 6, 2));
        $value  = $unpack[1];

        $this->structure['KeyName']['length'] = $value;

        return parent::input($input, false);
    }
*/
    /**
     * Convert internal structure into binary string
     *
     * @param bool $base64 Enables base64 encoding of the output
     *
     * @return string Binary representation of the structure
     */
    public function output($base64 = false)
    {
        $this->data['cRules'] = count($this->data['TZRules']);

        if ($this->data['cRules'] < 1) {
            throw new kolab_api_exception(kolab_api_exception::SERVER_ERROR, array(
                    'line'    => __LINE__,
                    'file'    => __FILE__,
                    'message' => 'No TZRules specified in ' . get_class($this),
            ));
        }

        if ($this->data['cRules'] > 1024) {
            throw new kolab_api_exception(kolab_api_exception::SERVER_ERROR, array(
                    'line'    => __LINE__,
                    'file'    => __FILE__,
                    'message' => 'Too many TZRules specified in ' . get_class($this)
                        . ' (' . $this->data['cRules'] . ' > 1024)',
            ));
        }

        $this->data['cchKeyName'] = mb_strlen($this->data['KeyName']);

        if ($this->data['cchKeyName'] > 260) {
            $this->data['cchKeyName'] = 260;
            $this->data['KeyName']    = mb_substr($this->data['KeyName'], 0, 260);
        }

        $this->data['cbHeader'] = 6 + $this->data['cchKeyName'] * 2;

        return parent::output($base64);
    }
}
