<?php

/**
 +--------------------------------------------------------------------------+
 | This file is part of the Kolab REST API                                  |
 |                                                                          |
 | Copyright (C) 2012-2015, Kolab Systems AG                                |
 |                                                                          |
 | This program is free software: you can redistribute it and/or modify     |
 | it under the terms of the GNU Affero General Public License as published |
 | by the Free Software Foundation, either version 3 of the License, or     |
 | (at your option) any later version.                                      |
 |                                                                          |
 | This program is distributed in the hope that it will be useful,          |
 | but WITHOUT ANY WARRANTY; without even the implied warranty of           |
 | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the             |
 | GNU Affero General Public License for more details.                      |
 |                                                                          |
 | You should have received a copy of the GNU Affero General Public License |
 | along with this program. If not, see <http://www.gnu.org/licenses/>      |
 +--------------------------------------------------------------------------+
 | Author: Aleksander Machniak <machniak@kolabsys.com>                      |
 +--------------------------------------------------------------------------+
*/

/**
 * TimeZoneStruct structure definition according to MS-OXOCAL 2.2.1.39
 */
class kolab_api_filter_mapistore_structure_timezonestruct extends kolab_api_filter_mapistore_structure
{
    protected $structure = array(
        'Bias'          => array('type' => 'LONG'),
        'StandardBias'  => array('type' => 'LONG'),
        'DaylightBias'  => array('type' => 'LONG'),
        'StandardYear'  => array('type' => 'WORD', 'default' => 0),
        'StandardDate'  => array('type' => 'SYSTEMTIME'),
        'DaylightYear'  => array('type' => 'WORD', 'default' => 0),
        'DaylightDate'  => array('type' => 'SYSTEMTIME'),
    );

    /**
     * Convert object data into timezone name.
     * If conversion is not possible 'UTC' will be returned.
     *
     * @param string $preferred Preferred timezone, used when MAPI structure
     *                          resolves to more than one timezone.
     *
     * @return sting Timezone name
     */
    public function to_tzname($preferred = null)
    {
        $tz = new kolab_api_filter_mapistore_timezone;

        foreach (array('Bias', 'StandardBias', 'DaylightBias') as $key) {
            $tz->{$key} = $this->{$key};
        }

        foreach (array('Standard', 'Daylight') as $key) {
            if ($systime = $this->{$key . 'Date'}) {
                $tz->{$key . 'Year'}         = $systime->{'Year'};
                $tz->{$key . 'Month'}        = $systime->{'Month'};
                $tz->{$key . 'DayOfWeek'}    = $systime->{'DayOfWeek'};
                $tz->{$key . 'Day'}          = $systime->{'Day'};
                $tz->{$key . 'Hour'}         = $systime->{'Hour'};
                $tz->{$key . 'Minute'}       = $systime->{'Minute'};
//                $tz->{$key . 'Second'}       = $systime->{'Second'};
//                $tz->{$key . 'Milliseconds'} = $systime->{'Milliseconds'};
            }
        }

        return $tz->get_timezone($preferred);
    }

    /**
     * Create class instance from PHP DateTime
     *
     * @param DateTime $date    PHP DateTime object
     * @param bool     $no_year Reset the Year to 0
     *
     * @return kolab_api_filter_mapistore_structure_timezonestruct
     */
    public static function from_datetime($date, $no_year = false)
    {
        $tz     = kolab_api_filter_mapistore_timezone::from_date($date);
        $result = new self;

        foreach (array('Bias', 'StandardBias', 'DaylightBias') as $key) {
            $result->{$key} = $tz->{$key};
        }

        foreach (array('Standard', 'Daylight') as $key) {
            $result->{$key . 'Date'} = new kolab_api_filter_mapistore_structure_systemtime(array(
                    'Year'          => $no_year ? 0 : $tz->{$key . 'Year'},
                    'Month'         => $tz->{$key . 'Month'},
                    'DayOfWeek'     => $tz->{$key . 'DayOfWeek'},
                    'Day'           => $tz->{$key . 'Day'},
                    'Hour'          => $tz->{$key . 'Hour'},
                    'Minute'        => $tz->{$key . 'Minute'},
//                    'Second'        => 0,
//                    'Milliseconds'  => 0,
            ));
        }

        $result->StandardYear = $result->StandardDate->Year;
        $result->DaylightYear = $result->DaylightDate->Year;

        return $result;
    }
}
