<?php

/**
 +--------------------------------------------------------------------------+
 | This file is part of the Kolab REST API                                  |
 |                                                                          |
 | Copyright (C) 2012-2015, Kolab Systems AG                                |
 |                                                                          |
 | This program is free software: you can redistribute it and/or modify     |
 | it under the terms of the GNU Affero General Public License as published |
 | by the Free Software Foundation, either version 3 of the License, or     |
 | (at your option) any later version.                                      |
 |                                                                          |
 | This program is distributed in the hope that it will be useful,          |
 | but WITHOUT ANY WARRANTY; without even the implied warranty of           |
 | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the             |
 | GNU Affero General Public License for more details.                      |
 |                                                                          |
 | You should have received a copy of the GNU Affero General Public License |
 | along with this program. If not, see <http://www.gnu.org/licenses/>      |
 +--------------------------------------------------------------------------+
 | Author: Aleksander Machniak <machniak@kolabsys.com>                      |
 +--------------------------------------------------------------------------+
*/

/**
 * ExceptionInfo structure definition according to MS-OXOCAL 2.2.1.44.2
 */
class kolab_api_filter_mapistore_structure_exceptioninfo extends kolab_api_filter_mapistore_structure
{
    protected $structure = array(
        'StartDateTime'         => array('type' => 'ULONG'),
        'EndDateTime'           => array('type' => 'ULONG'),
        'OriginalStartDate'     => array('type' => 'ULONG'),
        'OverrideFlags'         => array('type' => 'WORD'),
        'SubjectLength'         => array('type' => 'WORD'),
        'SubjectLength2'        => array('type' => 'WORD'),
        'Subject'               => array('type' => 'STRING', 'counter' => 'SubjectLength2'),
        'MeetingType'           => array('type' => 'ULONG'),
        'ReminderDelta'         => array('type' => 'ULONG'),
        'ReminderSet'           => array('type' => 'ULONG'),
        'LocationLength'        => array('type' => 'WORD'),
        'LocationLength2'       => array('type' => 'WORD'),
        'Location'              => array('type' => 'STRING', 'counter' => 'LocationLength2'),
        'BusyStatus'            => array('type' => 'ULONG'),
        'Attachment'            => array('type' => 'ULONG'),
        'SubType'               => array('type' => 'ULONG'),
        'AppointmentColor'      => array('type' => 'ULONG'),
    );

    const OVERRIDEFLAGS_ARO_SUBJECT             = 0x0001;
    const OVERRIDEFLAGS_ARO_MEETINGTYPE         = 0x0002;
    const OVERRIDEFLAGS_ARO_REMINDERDELTA       = 0x0004;
    const OVERRIDEFLAGS_ARO_REMINDER            = 0x0008;
    const OVERRIDEFLAGS_ARO_LOCATION            = 0x0010;
    const OVERRIDEFLAGS_ARO_BUSYSTATUS          = 0x0020;
    const OVERRIDEFLAGS_ARO_ATTACHMENT          = 0x0040;
    const OVERRIDEFLAGS_ARO_SUBTYPE             = 0x0080;
    const OVERRIDEFLAGS_ARO_APPTCOLOR           = 0x0100;
    const OVERRIDEFLAGS_ARO_EXCEPTIONAL_BODY    = 0x0200;

    /**
     * Convert binary input into internal structure
     *
     * @param string $input  Binary representation of the structure
     * @param bool   $base64 Set to TRUE if the input is base64-encoded
     *
     * @return int Number of bytes read from the binary input
     */
    public function input($input, $base64 = false)
    {
        if ($base64) {
            $input = base64_decode($input);
        }

        // Read OverrideFlags
        $unpack = unpack('v', substr($input, 12, 2));
        $value  = $unpack[1];

        $this->data['OverrideFlags'] = $value;

        // modify structure according to OverrideFlags
        $this->set_structure();

        return parent::input($input, false);
    }

    /**
     * Convert internal structure into binary string
     *
     * @param bool $base64 Enables base64 encoding of the output
     *
     * @return string Binary representation of the structure
     */
    public function output($base64 = false)
    {
        $flags = 0;

        if ($this->data['Subject'] !== null) {
            $flags += self::OVERRIDEFLAGS_ARO_SUBJECT;
            $length = strlen($this->data['Subject']);

            $this->data['SubjectLength2'] = $length;
            $this->data['SubjectLength']  = $length + 1;
        }

        if ($this->data['Location'] !== null) {
            $flags += self::OVERRIDEFLAGS_ARO_LOCATION;
            $length = strlen($this->data['Location']);

            $this->data['LocationLength2'] = $length;
            $this->data['LocationLength']  = $length + 1;
        }

        if ($this->data['MeetingType'] !== null) {
            $flags += self::OVERRIDEFLAGS_ARO_MEETINGTYPE;
        }

        if ($this->data['ReminderDelta'] !== null) {
            $flags += self::OVERRIDEFLAGS_ARO_REMINDERDELTA;
        }

        if ($this->data['ReminderSet'] !== null) {
            $flags += self::OVERRIDEFLAGS_ARO_REMINDER;
        }

        if ($this->data['BusyStatus'] !== null) {
            $flags += self::OVERRIDEFLAGS_ARO_BUSYSTATUS;
        }

        if ($this->data['Attachment'] !== null) {
            $flags += self::OVERRIDEFLAGS_ARO_ATTACHMENT;
        }

        if ($this->data['SubType'] !== null) {
            $flags += self::OVERRIDEFLAGS_ARO_SUBTYPE;
        }

        if ($this->data['AppointmentColor'] !== null) {
            $flags += self::OVERRIDEFLAGS_ARO_APPTCOLOR;
        }

        $this->data['OverrideFlags'] = $flags;

        $this->set_structure();
        return parent::output($base64);
    }

    /**
     * Modify the structure according to OverrideFlags
     */
    protected function set_structure()
    {
        $flags = $this->data['OverrideFlags'];

        // Enable/Disable structure fields according to OverrideFlags
        if (!($flags & self::OVERRIDEFLAGS_ARO_SUBJECT)) {
            $this->structure['Subject']['type']        = 'EMPTY';
            $this->structure['SubjectLength']['type']  = 'EMPTY';
            $this->structure['SubjectLength2']['type'] = 'EMPTY';
        }

        if (!($flags & self::OVERRIDEFLAGS_ARO_MEETINGTYPE)) {
            $this->structure['MeetingType']['type'] = 'EMPTY';
        }

        if (!($flags & self::OVERRIDEFLAGS_ARO_REMINDERDELTA)) {
            $this->structure['ReminderDelta']['type'] = 'EMPTY';
        }

        if (!($flags & self::OVERRIDEFLAGS_ARO_REMINDER)) {
            $this->structure['ReminderSet']['type'] = 'EMPTY';
        }

        if (!($flags & self::OVERRIDEFLAGS_ARO_LOCATION)) {
            $this->structure['Location']['type']        = 'EMPTY';
            $this->structure['LocationLength']['type']  = 'EMPTY';
            $this->structure['LocationLength2']['type'] = 'EMPTY';
        }

        if (!($flags & self::OVERRIDEFLAGS_ARO_BUSYSTATUS)) {
            $this->structure['BusyStatus']['type'] = 'EMPTY';
        }

        if (!($flags & self::OVERRIDEFLAGS_ARO_ATTACHMENT)) {
            $this->structure['Attachment']['type'] = 'EMPTY';
        }

        if (!($flags & self::OVERRIDEFLAGS_ARO_SUBTYPE)) {
            $this->structure['SubType']['type'] = 'EMPTY';
        }

        if (!($flags & self::OVERRIDEFLAGS_ARO_APPTCOLOR)) {
            $this->structure['AppointmentColor']['type'] = 'EMPTY';
        }

        if ($flags & self::OVERRIDEFLAGS_ARO_EXCEPTIONAL_BODY) {
            // @TODO
        }
    }
}
