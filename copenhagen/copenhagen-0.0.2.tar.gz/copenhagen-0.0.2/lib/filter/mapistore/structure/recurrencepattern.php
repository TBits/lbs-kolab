<?php

/**
 +--------------------------------------------------------------------------+
 | This file is part of the Kolab REST API                                  |
 |                                                                          |
 | Copyright (C) 2012-2015, Kolab Systems AG                                |
 |                                                                          |
 | This program is free software: you can redistribute it and/or modify     |
 | it under the terms of the GNU Affero General Public License as published |
 | by the Free Software Foundation, either version 3 of the License, or     |
 | (at your option) any later version.                                      |
 |                                                                          |
 | This program is distributed in the hope that it will be useful,          |
 | but WITHOUT ANY WARRANTY; without even the implied warranty of           |
 | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the             |
 | GNU Affero General Public License for more details.                      |
 |                                                                          |
 | You should have received a copy of the GNU Affero General Public License |
 | along with this program. If not, see <http://www.gnu.org/licenses/>      |
 +--------------------------------------------------------------------------+
 | Author: Aleksander Machniak <machniak@kolabsys.com>                      |
 +--------------------------------------------------------------------------+
*/

/**
 * RecurrencePattern structure definition according to MS-OXOCAL 2.2.1.44.1
 */
class kolab_api_filter_mapistore_structure_recurrencepattern extends kolab_api_filter_mapistore_structure
{
    protected $structure = array(
        'ReaderVersion'         => array('type' => 'WORD', 'default' => 0x3004),
        'WriterVersion'         => array('type' => 'WORD', 'default' => 0x3004),
        'RecurFrequency'        => array('type' => 'WORD'),
        'PatternType'           => array('type' => 'WORD'),
        'CalendarType'          => array('type' => 'WORD', 'default' => 0x0000),
        'FirstDateTime'         => array('type' => 'ULONG'),
        'Period'                => array('type' => 'ULONG'),
        'SlidingFlag'           => array('type' => 'ULONG', 'default' => 0x00000000),
        'PatternTypeSpecific'   => array('type' => 'EMPTY'), // default for PatternType=0
        'EndType'               => array('type' => 'ULONG'),
        'OccurrenceCount'       => array('type' => 'ULONG', 'default' => 0x0000000A),
        'FirstDOW'              => array('type' => 'ULONG', 'default' => 0x00000000),
        'DeletedInstanceCount'  => array('type' => 'ULONG', 'default' => 0x00000000),
        'DeletedInstanceDates'  => array('type' => 'ULONG[]', 'counter' => 'DeletedInstanceCount'),
        'ModifiedInstanceCount' => array('type' => 'ULONG', 'default' => 0x00000000),
        'ModifiedInstanceDates' => array('type' => 'ULONG[]', 'counter' => 'ModifiedInstanceCount'),
        'StartDate'             => array('type' => 'ULONG'),
        'EndDate'               => array('type' => 'ULONG'),
    );

    const RECURFREQUENCY_DAILY   = 0x200A;
    const RECURFREQUENCY_WEEKLY  = 0x200B;
    const RECURFREQUENCY_MONTHLY = 0x200C;
    const RECURFREQUENCY_YEARLY  = 0x200D;

    const PATTERNTYPE_DAY        = 0x0000;
    const PATTERNTYPE_WEEK       = 0x0001;
    const PATTERNTYPE_MONTH      = 0x0002;
    const PATTERNTYPE_MONTHEND   = 0x0004;
    const PATTERNTYPE_MONTHNTH   = 0x0003;
    const PATTERNTYPE_HJMONTH    = 0x000A;
    const PATTERNTYPE_HJMONTHNTH = 0x000B;
    const PATTERNTYPE_HJMONTHEND = 0x000C;

    const CALENDARTYPE_DEFAULT                  = 0x0000;
    const CALENDARTYPE_GREGORIAN                = 0x0001;
    const CALENDARTYPE_GREGORIAN_US             = 0x0002;
    const CALENDARTYPE_JAPAN                    = 0x0003;
    const CALENDARTYPE_TAIWAN                   = 0x0004;
    const CALENDARTYPE_KOREA                    = 0x0005;
    const CALENDARTYPE_HIJRI                    = 0x0006;
    const CALENDARTYPE_THAI                     = 0x0007;
    const CALENDARTYPE_HEBREW                   = 0x0008;
    const CALENDARTYPE_GREGORIAN_ME_FRENCH      = 0x0009;
    const CALENDARTYPE_GREGORIAN_ARABIC         = 0x000A;
    const CALENDARTYPE_GREGORIAN_XLIT_ENGLISH   = 0x000B;
    const CALENDARTYPE_GREGORIAN_XLIT_FRENCH    = 0x000C;
    const CALENDARTYPE_LUNAR_JAPANESE           = 0x000E;
    const CALENDARTYPE_CHINESE_LUNAR            = 0x000F;
    const CALENDARTYPE_SAKA                     = 0x0010;
    const CALENDARTYPE_LUNAR_ETO_CHN            = 0x0011;
    const CALENDARTYPE_LUNAR_ETO_KOR            = 0x0012;
    const CALENDARTYPE_LUNAR_ROKUYOU            = 0x0013;
    const CALENDARTYPE_LUNAR_KOREAN             = 0x0014;
    const CALENDARTYPE_UMALQURA                 = 0x0017;

    const ENDTYPE_AFTER = 0x00002021;
    const ENDTYPE_NOCC  = 0x00002022;
    const ENDTYPE_NEVER = 0x00002023; // can be 0xffffffff

    const FIRSTDOW_SUNDAY       = 0x00000000;
    const FIRSTDOW_MONDAY       = 0x00000001;
    const FIRSTDOW_TUESDAY      = 0x00000002;
    const FIRSTDOW_WEDNESDAY    = 0x00000003;
    const FIRSTDOW_THURSDAY     = 0x00000004;
    const FIRSTDOW_FRIDAY       = 0x00000005;
    const FIRSTDOW_SATURDAY     = 0x00000006;

    /**
     * Convert binary input into internal structure
     *
     * @param string $input  Binary representation of the structure
     * @param bool   $base64 Set to TRUE if the input is base64-encoded
     *
     * @return int Number of bytes read from the binary input
     */
    public function input($input, $base64 = false)
    {
        if ($base64) {
            $input = base64_decode($input);
        }

        // Read PatternType
        $unpack = unpack('v', substr($input, 6, 2));
        $value  = $unpack[1];

        $this->data['PatternType'] = $value;

        // modify structure according to PatternType
        $this->set_structure();

        return parent::input($input, false);
    }

    /**
     * Convert internal structure into binary string
     *
     * @param bool $base64 Enables base64 encoding of the output
     *
     * @return string Binary representation of the structure
     */
    public function output($base64 = false)
    {
        $this->set_structure();

        $this->data['DeletedInstanceDates']  = (array) $this->data['DeletedInstanceDates'];
        $this->data['ModifiedInstanceDates'] = (array) $this->data['ModifiedInstanceDates'];
        $this->data['DeletedInstanceCount']  = count($this->data['DeletedInstanceDates']);
        $this->data['ModifiedInstanceCount'] = count($this->data['ModifiedInstanceDates']);

        return parent::output($base64);
    }

    /**
     * Modify the structure according to PatternType
     */
    protected function set_structure()
    {
        // Set PatternTypeSpecific field type according to PatternType
        switch ($this->data['PatternType']) {
        case self::PATTERNTYPE_WEEK:
        case self::PATTERNTYPE_MONTH:
        case self::PATTERNTYPE_MONTHEND:
        case self::PATTERNTYPE_HJMONTH:
        case self::PATTERNTYPE_HJMONTHEND:
            $this->structure['PatternTypeSpecific']['type'] = 'ULONG';
            break;

        case self::PATTERNTYPE_MONTHNTH:
        case self::PATTERNTYPE_HJMONTHNTH:
            $this->structure['PatternTypeSpecific']['type'] = 'ULONG[2]';
            break;

        case self::PATTERNTYPE_DAY:
        default:
            $this->structure['PatternTypeSpecific']['type'] = 'EMPTY';
            break;
        }
    }
}
