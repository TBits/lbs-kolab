<?php

/**
 +--------------------------------------------------------------------------+
 | This file is part of the Kolab REST API                                  |
 |                                                                          |
 | Copyright (C) 2012-2015, Kolab Systems AG                                |
 |                                                                          |
 | This program is free software: you can redistribute it and/or modify     |
 | it under the terms of the GNU Affero General Public License as published |
 | by the Free Software Foundation, either version 3 of the License, or     |
 | (at your option) any later version.                                      |
 |                                                                          |
 | This program is distributed in the hope that it will be useful,          |
 | but WITHOUT ANY WARRANTY; without even the implied warranty of           |
 | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the             |
 | GNU Affero General Public License for more details.                      |
 |                                                                          |
 | You should have received a copy of the GNU Affero General Public License |
 | along with this program. If not, see <http://www.gnu.org/licenses/>      |
 +--------------------------------------------------------------------------+
 | Author: Aleksander Machniak <machniak@kolabsys.com>                      |
 +--------------------------------------------------------------------------+
*/

/**
 * ExtendedException structure definition according to MS-OXOCAL 2.2.1.44.4
 */
class kolab_api_filter_mapistore_structure_extendedexception extends kolab_api_filter_mapistore_structure
{
    protected $parent;
    protected $structure = array(
        'ChangeHighlight'       => array('type' => 'kolab_api_filter_mapistore_structure_changehighlight'),
        'ReservedBlockEE1Size'  => array('type' => 'ULONG', 'default' => 0),
        'ReservedBlockEE1'      => array('type' => 'STRING', 'counter' => 'ReservedBlockEE1Size'),
        'StartDateTime'         => array('type' => 'ULONG'),
        'EndDateTime'           => array('type' => 'ULONG'),
        'OriginalStartDate'     => array('type' => 'ULONG'),
        'WideCharSubjectLength' => array('type' => 'WORD',),
        'WideCharSubject'       => array('type' => 'WSTRING', 'counter' => 'WideCharSubjectLength'),
        'WideCharLocationLength' => array('type' => 'WORD'),
        'WideCharLocation'      => array('type' => 'WSTRING', 'counter' => 'WideCharLocationLength'),
        'ReservedBlockEE2Size'  => array('type' => 'ULONG', 'default' => 0),
        'ReservedBlockEE2'      => array('type' => 'STRING', 'counter' => 'ReservedBlockEE2Size'),
    );

    /**
     * Convert binary input into internal structure
     *
     * @param string $input  Binary representation of the structure
     * @param bool   $base64 Set to TRUE if the input is base64-encoded
     * @param object $parent Parent structure
     * @param int    $index  Index in the parent property array
     *
     * @return int Number of bytes read from the binary input
     */
    public function input($input, $base64 = false, $parent = null, $index = null)
    {
        if ($base64) {
            $input = base64_decode($input);
        }

        // read OverrideFlags from matching ExceptionInfo
        if (empty($parent) || $index === null || !array_key_exists($index, (array) $parent->ExceptionInfo)) {
            throw new kolab_api_exception(kolab_api_exception::SERVER_ERROR, array(
                    'line'    => __LINE__,
                    'file'    => __FILE__,
                    'message' => 'Missing ExceptionInfo structure for ' . get_class($this)
            ));
        }

        $flags = $parent->ExceptionInfo[$index]->OverrideFlags;

        if (!($flags & kolab_api_filter_mapistore_structure_exceptioninfo::OVERRIDEFLAGS_ARO_SUBJECT)) {
            $no_subject = true;
            $this->structure['WideCharSubject']['type']       = 'EMPTY';
            $this->structure['WideCharSubjectLength']['type'] = 'EMPTY';
        }

        if (!($flags & kolab_api_filter_mapistore_structure_exceptioninfo::OVERRIDEFLAGS_ARO_LOCATION)) {
            $no_location = true;
            $this->structure['WideCharLocation']['type']       = 'EMPTY';
            $this->structure['WideCharLocationLength']['type'] = 'EMPTY';
        }

        if ($no_subject && $no_location) {
            $this->structure['StartDateTime']['type']     = 'EMPTY';
            $this->structure['EndDateTime']['type']       = 'EMPTY';
            $this->structure['OriginalStartDate']['type'] = 'EMPTY';
        }

        return parent::input($input, false);
    }

    /**
     * Convert internal structure into binary string
     *
     * @param bool $base64 Enables base64 encoding of the output
     *
     * @return string Binary representation of the structure
     */
    public function output($base64 = false)
    {
        if ($this->data['WideCharSubject'] !== null) {
            $got_subject = true;
            $this->data['WideCharSubjectLength'] = mb_strlen($this->data['WideCharSubject']);
        }
        else {
            $this->structure['WideCharSubjectLength']['type'] = 'EMPTY';
            $this->structure['WideCharSubject']['type']       = 'EMPTY';
        }

        if ($this->data['WideCharLocation'] !== null) {
            $got_location = true;
            $this->data['WideCharLocationLength'] = mb_strlen($this->data['WideCharLocation']);
        }
        else {
            $this->structure['WideCharLocationLength']['type'] = 'EMPTY';
            $this->structure['WideCharLocation']['type']       = 'EMPTY';
        }

        if (!$got_subject && !$got_location) {
            $this->structure['StartDateTime']['type']     = 'EMPTY';
            $this->structure['EndDateTime']['type']       = 'EMPTY';
            $this->structure['OriginalStartDate']['type'] = 'EMPTY';
        }

        return parent::output($base64);
    }

    /**
     * Returns instance of this class with default values set
     *
     * @return kolab_api_filter_mapistore_structure_extendedexception Object instance
     */
    public static function get_empty()
    {
        return new self(array(
            'ChangeHighlight' => new kolab_api_filter_mapistore_structure_changehighlight(),
        ));
    }
}
