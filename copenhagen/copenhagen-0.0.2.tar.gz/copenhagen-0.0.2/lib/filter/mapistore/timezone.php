<?php

/**
 +--------------------------------------------------------------------------+
 | This file is part of the Kolab REST API                                  |
 |                                                                          |
 | Copyright (C) 2012-2015, Kolab Systems AG                                |
 |                                                                          |
 | This program is free software: you can redistribute it and/or modify     |
 | it under the terms of the GNU Affero General Public License as published |
 | by the Free Software Foundation, either version 3 of the License, or     |
 | (at your option) any later version.                                      |
 |                                                                          |
 | This program is distributed in the hope that it will be useful,          |
 | but WITHOUT ANY WARRANTY; without even the implied warranty of           |
 | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the             |
 | GNU Affero General Public License for more details.                      |
 |                                                                          |
 | You should have received a copy of the GNU Affero General Public License |
 | along with this program. If not, see <http://www.gnu.org/licenses/>      |
 +--------------------------------------------------------------------------+
 | Author: Aleksander Machniak <machniak@kolabsys.com>                      |
 +--------------------------------------------------------------------------+
*/

/**
 * Utility functions for converting Timezone from/to MAPI format(s).
 */
class kolab_api_filter_mapistore_timezone
{
    public $Bias                 = 0;
    public $StandardYear         = 0;
    public $StandardMonth        = 0;
    public $StandardDayOfWeek    = 0;
    public $StandardDay          = 0;
    public $StandardHour         = 0;
    public $StandardMinute       = 0;
    public $StandardSecond       = 0;
    public $StandardMilliseconds = 0;
    public $StandardBias         = 0;
    public $DaylightYear         = 0;
    public $DaylightMonth        = 0;
    public $DaylightDay          = 0;
    public $DaylightDayOfWeek    = 0;
    public $DaylightHour         = 0;
    public $DaylightMinute       = 0;
    public $DaylightSecond       = 0;
    public $DaylightMilliseconds = 0;
    public $DaylightBias         = 0;

    /**
     * PidLidTimeZone property values
     *
     * @var array
     */
    protected static $tz_data = array(
        0  => array(0,          null,               null),
        1  => array(720,        array(10, 0, 5, 2), array(3, 0, 5, 1)),
        2  => array(660,        array(9, 0, 5, 2),  array(3, 0, 5, 1)),
        3  => array(660,        array(10, 0, 5, 3), array(3, 0, 5, 2)),
        4  => array(660,        array(10, 0, 5, 3), array(3, 0, 5, 2)),
        5  => array(600,        array(9, 0, 5, 1),  array(3, 0, 5, 0)),
        6  => array(660,        array(9, 0, 5, 1),  array(3, 0, 5, 0)),
        7  => array(600,        array(10, 0, 5, 4), array(3, 0, 5, 3)),
        8  => array(900,        array(2, 0, 2, 2),  array(10, 0, 3, 2)),
        9  => array(960,        array(11, 0, 1, 2), array(3, 0, 2, 2)),
        10 => array(1020,       array(11, 0, 1, 2), array(3, 0, 2, 2)),
        11 => array(1080,       array(11, 0, 1, 2), array(3, 0, 2, 2)),
        12 => array(1140,       array(11, 0, 1, 2), array(3, 0, 2, 2)),
        13 => array(1200,       array(11, 0, 1, 2), array(3, 0, 2, 2)),
        14 => array(1260,       array(11, 0, 1, 2), array(3, 0, 2, 2)),
        15 => array(1320,       null,               null),
        16 => array(1380,       null,               null),
        17 => array(0,          array(4, 0, 1, 3),  array(9, 0, 5, 2)),
        18 => array(120,        array(3, 0, 5, 3),  array(10, 0, 5, 2)),
        19 => array(150,        array(3, 0, 5, 3),  array(10, 0, 5, 2)),
        20 => array(180,        null,               null),
        21 => array(240,        null,               null),
        22 => array(300,        null,               null),
        23 => array(390,        null,               null),
        24 => array(480,        null,               null),
        25 => array(510,        array(9, 2, 4, 2),  array(3, 0, 1, 2)),
        26 => array(540,        null,               null),
        27 => array(600,        array(9, 0, 3, 2),  array(3, 5, 5, 2)),
        28 => array(930,        array(11, 0, 1, 0), array(3, 0, 2, 0)),
        29 => array(780,        array(10, 0, 5, 1), array(3, 0, 5, 0)),
        30 => array(840,        array(10, 0, 5, 1), array(3, 0, 5, 0)),
        31 => array(720,        null,               null),
        32 => array(900,        null,               null),
        33 => array(960,        null,               null),
        34 => array(1020,       null,               null),
        35 => array(10200,      null,               null),
        36 => array(1080,       null,               null),
        37 => array(1080,       array(10, 0, 5, 2), array(4, 0, 1, 2)),
        38 => array(1140,       null,               null),
        39 => array(1440,       null,               null),
        40 => array(0,          null,               null),
        41 => array(60,         null,               null),
        42 => array(120,        array(3, 0, 5, 2),  array(10, 0, 1, 2)),
        43 => array(120,        null,               null),
        44 => array(150,        null,               null),
        45 => array(240,        array(9, 0, 2, 2),  array(4, 0, 2, 2)),
        46 => array(360,        null,               null),
        47 => array(420,        null,               null),
        48 => array(450,        null,               null),
        49 => array(600,        array(9, 4, 5, 2),  array(5, 5, 1, 2)),
        50 => array(600,        null,               null),
        51 => array(540,        array(10, 0, 5, 1), array(3, 0, 5, 0)),
        52 => array(120,        array(3, 0, 5, 2),  array(8, 0, 5, 2)),
        53 => array(120,        array(4, 0, 1, 3),  array(10, 0, 5, 2)),
        54 => array(150,        array(4, 0, 1, 3),  array(10, 0, 5, 2)),
        55 => array(120,        array(4, 0, 1, 3),  array(10, 0, 1, 2)),
        56 => array(960,        array(3, 6, 2, 23), array(10, 6, 2, 23)),
        57 => array(240,        array(3, 0, 5, 3),  array(10, 0, 5, 2)),
        58 => array(1140,       array(10, 0, 5, 2), array(4, 0, 1, 2)),
        59 => array(1200,       array(10, 0, 5, 2), array(4, 0, 1, 2)),
    );


    /**
     * Create class instance from DateTime object
     *
     * @param DateTime $date A date object.
     *
     * @return kolab_api_filter_mapistore_timezone
     */
    public static function from_date($date)
    {
        $result = new self;

        list($standard, $daylight) = self::get_transitions($date);

        if (!empty($standard)) {
            $result->Bias = $standard['offset'] / 60 * -1;

            if (!empty($daylight)) {
                self::set_transition($result, $standard, 'Standard');
                self::set_transition($result, $daylight, 'Daylight');

                $result->StandardHour += $daylight['offset'] / 3600;
                $result->DaylightHour += $standard['offset'] / 3600;
                $result->DaylightBias = ($daylight['offset'] - $standard['offset']) / 60 * -1;
            }
        }

        return $result;
    }

    /**
     * Attempt to guess the timezone identifier from the current object data.
     *
     * If preferred timezone is specified and it matches current data
     * it will be returned, otherwise it returns any matching timezone or UTC.
     *
     * @param string $preferred The preferred timezone.
     *
     * @return string The timezone identifier
     */
    public function get_timezone($preferred = null)
    {
        // Tries to guess the correct start date depending on object
        // property, falls back to current date.
        if (!empty($this->StandardYear)) {
            $datetime = new DateTime($this->StandardYear . '-01-01');
        }
        else {
            $datetime = new DateTime('1 year ago');
        }

        // If preferred TZ is not specified, try one configured on the server
        // it's likely better than just selecting the first matching TZ.
        if (!$preferred) {
            $preferred = date_default_timezone_get();
        }

        // First check the preferred timezone
        if ($preferred && $this->check_timezone($preferred, $datetime)) {
            return $preferred;
        }

        // @TODO: for better results we should first check
        // more common areas of the globe and maybe skip some e.g. Arctica.

        foreach (DateTimeZone::listIdentifiers() as $timezone) {
            if ($this->check_timezone($timezone, $datetime)) {
                return $timezone;
            }
        }

        return 'UTC';
    }

    /**
     * Get PidLidTimeZone value from PHP DateTime
     *
     * @param DateTime $date A date object.
     *
     * @return int Timezone identifier, NULL if not found
     */
    public static function get_int_from_date($date)
    {
        $tz = self::from_date($date);

        foreach (self::$tz_data as $int => $data) {
            if ($tz->Bias == self::from_mapi_offset($data[0])
                && $tz->StandardMonth == $data[1][0]
                && $tz->StandardDayOfWeek == $data[1][1]
                && $tz->StandardDay == $data[1][2]
                && $tz->StandardHour == $data[1][3]
                && $tz->DaylightMonth == $data[2][0]
                && $tz->DaylightDayOfWeek == $data[2][1]
                && $tz->DaylightDay == $data[2][2]
                && $tz->DaylightHour == $data[2][3]
            ) {
                return $int;
            }
        }
    }

    /**
     * Attempt to guess the timezone identifier from PidLidTimeZone value.
     *
     * If preferred timezone is specified and it matches current data
     * it will be returned, otherwise it returns any matching timezone or UTC.
     *
     * @param int    $tz_id     MAPI PidLidTimeZone property value
     * @param string $preferred The preferred timezone
     *
     * @return string The timezone identifier
     */
    public static function get_timezone_from_int($tz_id, $preferred = null)
    {
        $data = self::$tz_data[(int) $tz_id];

        if (empty($data)) {
            return 'UTC';
        }

        $tz = new self;

        // fill self object with data from timezone definition
        if (!empty($data[1])) {
            foreach (array('Standard', 'Daylight') as $idx => $type) {
                foreach (array('Month', 'DayOfWeek', 'Day', 'Hour') as $i => $item) {
                    $tz->{$type . $item} = $data[$idx + 1][$i];
                }
            }
        }

        $tz->Bias         = self::from_mapi_offset($data[0]);
        $tz->DaylightBias = -60; // @FIXME

        return $tz->get_timezone($preferred);
    }

    /**
     * Converts PidLidTimeZone offset for comparison with Bias value
     */
    protected static function from_mapi_offset($offset)
    {
        // MAPI's PidLidTimeZone offset is in minutes from UTC+12
        // and it's always positive and <= 24 * 60.
        if ($offset >= 12 * 60) {
            $offset -= 12 * 60;
        }
        else {
            $offset = (12 * 60 - $offset) * -1;
        }

        return $offset;
    }

    /**
     * Get the transition data for moving from DST to STD time.
     *
     * @param DateTime $date The date to start from and specified timezone.
     *
     * @return array An array containing the the STD and DST transitions
     */
    protected static function get_transitions($date)
    {
        $standard  = array();
        $daylight  = array();
        $timezone  = $date->getTimezone();
        $date_year = $date->format('Y');

        // get timezone transitions in specified year
        $transitions = $timezone->getTransitions(
            mktime(0, 0, 0, 12, 1, $date_year - 1),
            mktime(24, 0, 0, 12, 31, $date_year)
        );

        if ($transitions === false) {
            return array();
        }

        foreach ($transitions as $i => $transition) {
            try {
               $d = new DateTime($transition['time']);
            }
            catch (Exception $e) {
                continue;
            }

            $year = $d->format('Y');

            if ($year == $date_year && isset($transitions[$i + 1])) {
                $next = new DateTime($transitions[$i + 1]['time']);
                if ($year == $next->format('Y')) {
                    $daylight = $transition['isdst'] ? $transition : $transitions[$i + 1];
                    $standard = $transition['isdst'] ? $transitions[$i + 1] : $transition;
                }
                else {
                    $daylight = $transition['isdst'] ? $transition: null;
                    $standard = $transition['isdst'] ? null : $transition;
                }

                break;
            }
            else if ($i == count($transitions) - 1) {
                $standard = $transition;
            }
        }

        return array($standard, $daylight);
    }

    /**
     * Calculate and set the offsets for the specified transition
     *
     * @param self   $object     Self class instance
     * @param array  $transition A transition hash from DateTimeZone::getTransitions()
     * @param string $type       Transition type - daylight or standard
     */
    protected static function set_transition($object, $transition, $type)
    {
        $date = new DateTime($transition['time']);

        $object->{$type . 'Year'}      = (int) $date->format('Y');
        $object->{$type . 'Month'}     = (int) $date->format('n');
        $object->{$type . 'DayOfWeek'} = (int) $date->format('w');
        $object->{$type . 'Hour'}      = (int) $date->format('H');
        $object->{$type . 'Minute'}    = (int) $date->format('i');

        for ($i = 5; $i > 0; $i--) {
            if (self::is_nth_occurrence_in_month($transition['time'], $i)) {
                $object->{$type . 'Day'} = $i;
                break;
            }
        }
    }

    /**
     * Check if the given timezone matches the current object and also
     * evaluate the daylight saving time transitions for this timezone if necessary.
     *
     * @param string   $timezone The timezone identifier
     * @param DateTime $datetime The date to check
     *
     * @return boolean
     */
    protected function check_timezone($timezone, $datetime)
    {
        try {
            $datetime->setTimezone(new DateTimeZone($timezone));

            list($standard, $daylight) = self::get_transitions($datetime);

            return $this->check_transition($standard, $daylight);
        }
        catch (Exception $e) {
        }

        return false;
    }

    /**
     * Check if the given Standard and Daylight time transitions match
     * current object data.
     *
     * @param array $sandard  The Standard time transition data.
     * @param array $daylight The Daylight time transition data.
     *
     * @return boolean
     */
    protected function check_transition($standard, $daylight)
    {
        if (empty($standard)) {
            return false;
        }

        $standard_offset = ($this->Bias + $this->StandardBias) * 60 * -1;

        if ($standard_offset == $standard['offset']) {
            // There's no DST to compare
            if (empty($daylight) || empty($daylight['isdst'])) {
                return empty($this->DaylightMonth);
            }

            // the milestone is sending a positive value for DaylightBias while it should send a negative value
            $daylight_offset           = ($this->Bias + $this->DaylightBias) * 60 * -1;
            $daylight_offset_milestone = ($this->Bias + ($this->DaylightBias * -1)) * 60 * -1;

            if ($daylight_offset == $daylight['offset'] || $daylight_offset_milestone == $daylight['offset']) {
                $standard_dt = new DateTime($standard['time']);
                $daylight_dt = new DateTime($daylight['time']);

                if ($standard_dt->format('n') == $this->StandardMonth
                    && $daylight_dt->format('n') == $this->DaylightMonth
                    && $standard_dt->format('w') == $this->StandardDayOfWeek
                    && $daylight_dt->format('w') == $this->DaylightDayOfWeek
                ) {
                    return self::is_nth_occurrence_in_month($daylight['time'], $this->DaylightDay)
                        && self::is_nth_occurrence_in_month($standard['time'], $this->StandardDay);
                }
            }
        }

        return false;
    }

    /**
     * Test if the weekday of the given timestamp is the nth occurrence of this
     * weekday within its month, where '5' indicates the last occurrence even if
     * there is less than five occurences.
     *
     * @param string  $datetime   The datetime string representation
     * @param integer $occurrence 1 to 5, where 5 indicates the final occurrence
     *                            during the month if that day of the week does
     *                            not occur 5 times
     * @return boolean
     */
    protected static function is_nth_occurrence_in_month($datetime, $occurrence)
    {
        $original   = new DateTime($datetime);
        $orig_month = $original->format('n');
        $modified   = clone $original;

        if ($occurrence == 5) {
            $modified  = $modified->modify('1 week');
            $mod_month = $modified->format('n');

            // modified month is after the original
            return $mod_month > $orig_month || ($mod_month == 1 && $orig_month == 12);
        }

        $modified->modify(sprintf('-%d weeks', $occurrence - 1));
        $mod_month = $modified->format('n');

        if ($mod_month != $orig_month) {
            return false;
        }

        $modified = clone($original);
        $modified->modify(sprintf('-%d weeks', $occurrence));
        $mod_month = $modified->format('n');

        // modified month is earlier than original
        return $mod_month < $orig_month || ($mod_month == 12 && $orig_month == 1);
    }
}
