<?php

/**
 +--------------------------------------------------------------------------+
 | This file is part of the Kolab REST API                                  |
 |                                                                          |
 | Copyright (C) 2012-2015, Kolab Systems AG                                |
 |                                                                          |
 | This program is free software: you can redistribute it and/or modify     |
 | it under the terms of the GNU Affero General Public License as published |
 | by the Free Software Foundation, either version 3 of the License, or     |
 | (at your option) any later version.                                      |
 |                                                                          |
 | This program is distributed in the hope that it will be useful,          |
 | but WITHOUT ANY WARRANTY; without even the implied warranty of           |
 | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the             |
 | GNU Affero General Public License for more details.                      |
 |                                                                          |
 | You should have received a copy of the GNU Affero General Public License |
 | along with this program. If not, see <http://www.gnu.org/licenses/>      |
 +--------------------------------------------------------------------------+
 | Author: Aleksander Machniak <machniak@kolabsys.com>                      |
 +--------------------------------------------------------------------------+
*/

class kolab_api_filter_mapistore_note extends kolab_api_filter_mapistore_common
{
    protected $model = 'note';
    protected $map   = array(
        // note specific props [MS-OXNOTE]
        'PidLidNoteColor'         => 'x-custom.MAPI:PidLidNoteColor',   // PtypInteger32
        'PidLidNoteHeight'        => 'x-custom.MAPI:PidLidNoteHeight',  // PtypInteger32
        'PidLidNoteWidth'         => 'x-custom.MAPI:PidLidNoteWidth',   // PtypInteger32
        'PidLidNoteX'             => 'x-custom.MAPI:PidLidNoteX',       // PtypInteger32
        'PidLidNoteY'             => 'x-custom.MAPI:PidLidNoteY',       // PtypInteger32
        // common props [MS-OXCMSG]
        'PidTagBody'              => '', // 'description'
        'PidTagHtml'              => '',
        'PidTagMessageClass'      => '',
        'PidTagSubject'           => 'summary',
        'PidTagNormalizedSubject' => '', // @TODO: abbreviated note body
        'PidTagIconIndex'         => '', // @TODO: depends on PidLidNoteColor
    );

    protected $color_map = array(
        '0000FF' => 0x00000000, // blue
        '008000' => 0x00000001, // green
        'FFC0CB' => 0x00000002, // pink
        'FFFF00' => 0x00000003, // yellow
        'FFFFFF' => 0x00000004, // white
    );


    /**
     * Convert Kolab to MAPI
     *
     * @param array Data
     * @param array Context (folder_uid, object_uid, object)
     *
     * @return array Data
     */
    public function output($data, $context = null)
    {
        $result = array(
            'PidTagMessageClass' => 'IPM.StickyNote',
            // notes do not have attachments in MAPI
            // 'PidTagHasAttachments' => 0,
            // mapistore REST API specific properties
            'collection' => 'notes',
        );

        foreach ($this->map as $mapi_idx => $kolab_idx) {
            if (empty($kolab_idx)) {
                continue;
            }

            $value = $this->get_kolab_value($data, $kolab_idx);

            if ($value === null) {
                continue;
            }

            switch ($mapi_idx) {
            case 'PidLidNoteColor':
            case 'PidLidNoteHeight':
            case 'PidLidNoteWidth':
            case 'PidLidNoteX':
            case 'PidLidNoteY':
                $value = (int) $value;
                break;
            }

            $result[$mapi_idx] = $value;
        }

        // body can be in plain text format only
        $this->body_from_kolab($data, $result, 'description', 'plain');

        $this->parse_common_props($result, $data, $context);

        return $result;
    }

    /**
     * Convert from MAPI to Kolab
     *
     * @param array Data
     * @param array Data of the object that is being updated
     *
     * @return array Data
     */
    public function input($data, $object = null)
    {
        $result = array();

        foreach ($this->map as $mapi_idx => $kolab_idx) {
            if (empty($kolab_idx)) {
                continue;
            }

            if (!array_key_exists($mapi_idx, $data)) {
                continue;
            }

            $value = $data[$mapi_idx];

            $result[$kolab_idx] = $value;
        }

        // body
        $this->body_to_kolab($data, $result, 'description');

        $this->convert_common_props($result, $data, $object);

        return $result;
    }

    /**
     * Returns the attributes names mapping
     */
    public function map()
    {
        $map = array_filter($this->map);

        return $map;
    }
}
