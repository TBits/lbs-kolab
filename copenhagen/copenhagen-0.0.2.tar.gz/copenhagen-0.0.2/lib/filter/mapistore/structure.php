<?php

/**
 +--------------------------------------------------------------------------+
 | This file is part of the Kolab REST API                                  |
 |                                                                          |
 | Copyright (C) 2012-2015, Kolab Systems AG                                |
 |                                                                          |
 | This program is free software: you can redistribute it and/or modify     |
 | it under the terms of the GNU Affero General Public License as published |
 | by the Free Software Foundation, either version 3 of the License, or     |
 | (at your option) any later version.                                      |
 |                                                                          |
 | This program is distributed in the hope that it will be useful,          |
 | but WITHOUT ANY WARRANTY; without even the implied warranty of           |
 | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the             |
 | GNU Affero General Public License for more details.                      |
 |                                                                          |
 | You should have received a copy of the GNU Affero General Public License |
 | along with this program. If not, see <http://www.gnu.org/licenses/>      |
 +--------------------------------------------------------------------------+
 | Author: Aleksander Machniak <machniak@kolabsys.com>                      |
 +--------------------------------------------------------------------------+
*/

/**
 * MAPI structures handler
 */
class kolab_api_filter_mapistore_structure
{
    protected $structure = array();
    protected $data      = array();
    protected $lengths   = array(
        'BYTE'       => 1,
        'WORD'       => 2,
        'LONG'       => 4,
        'ULONG'      => 4,
        'SYSTEMTIME' => 16,
    );

    const WSTRING_CHARSET = 'UCS-2LE'; // UTF-16LE (?)


    /**
     * Class constructor
     *
     * @param array Structure data properties
     */
    public function __construct($data = array())
    {
        if (!empty($data)) {
            $this->data = $data;
        }
    }

    /**
     * Convert binary input into internal structure
     *
     * @param string $input  Binary representation of the structure
     * @param bool   $base64 Set to TRUE if the input is base64-encoded
     * @param object $parent Parent structure
     *
     * @return int Number of bytes read from the binary input
     */
    public function input($input, $base64 = false, $parent = null)
    {
        if ($base64) {
            $input = base64_decode($input);
        }

        $input_length = strlen($input);
        $position     = 0;
        $counter      = 0;

        foreach ($this->structure as $idx => $struct) {
            $length   = 0;
            $class    = null;
            $is_array = false;
            $count    = 1;

            switch ($struct['type']) {
            case 'EMPTY':
                continue 2;

            case 'STRING':
                $length = $struct['length'] ?: (int) $this->data[$struct['counter']];
                break;

            case 'WSTRING':
                $length = $struct['length'] ?: ((int) $this->data[$struct['counter']]) * 2;
                break;

            case 'BYTE':
            case 'WORD':
            case 'LONG':
            case 'ULONG':
            case 'SYSTEMTIME':
            default:
                if (preg_match('/^(LONG|ULONG|WORD|BYTE)\[([0-9]*)\]$/', $struct['type'], $m)) {
                    $is_array = true;
                    $count    = $m[2] ? $m[2] : (int) $this->data[$struct['counter']];
                    $struct['type'] = $m[1];
                    $length = $this->lengths[$struct['type']];
                }
                else if (preg_match('/^(\[?)(kolab_api_[a-z_]+)\]?$/', $struct['type'], $m)) {
                    $length   = 0;
                    $class    = $m[2];
                    $is_array = !empty($m[1]);
                    $count    = $is_array ? (int) $this->data[$struct['counter']] : 1;
                }
                else {
                    $length = $this->lengths[$struct['type']];
                }
            }

            if ($length && $position >= $input_length) {
                throw new kolab_api_exception(kolab_api_exception::SERVER_ERROR, array(
                        'line'    => __LINE__,
                        'file'    => __FILE__,
                        'message' => 'Invalid MAPI structure for ' . get_class($this)
                ));
            }

            for ($i = 0; $i < $count; $i++) {
                if ($length) {
                    $value     = substr($input, $position, $length);
                    $position += $length;
                }
                else {
                    $value = null;
                }

                switch ($struct['type']) {
                case 'WSTRING':
                    $value = rcube_charset::convert($value, self::WSTRING_CHARSET, RCUBE_CHARSET);
                    // no-break

                case 'STRING':
                    break;

                case 'BYTE':
                    $value = ord($value);
                    break;

                case 'WORD':
                    $unpack = unpack('v', $value);
                    $value  = $unpack[1];
                    break;

                case 'LONG':
                    $unpack = unpack('l', $value);
                    $value  = $unpack[1];
                    break;

                case 'ULONG':
                    $unpack = unpack('V', $value);
                    $value  = $unpack[1];
                    break;

                case 'SYSTEMTIME':
                    $structure = new kolab_api_filter_mapistore_structure_systemtime;
                    $structure->input($value, false, $this, $is_array ? $i : null);
                    $value = $structure;
                    break;

                default:
                    $structure = new $class;
                    $position += $structure->input(substr($input, $position), false, $this, $is_array ? $i : null);
                    $value = $structure;
                }

                if ($value !== null) {
                    if ($is_array) {
                        $this->data[$idx][] = $value;
                    }
                    else {
                        $this->data[$idx] = $value;
                    }
                }
            }
        }

        return $position;
    }

    /**
     * Convert internal structure into binary string
     *
     * @param bool $base64 Enables base64 encoding of the output
     *
     * @return string Binary representation of the structure
     */
    public function output($base64 = false)
    {
        $output = '';

        foreach ($this->structure as $idx => $struct) {
            if (!array_key_exists($idx, $this->data)) {
                if ($struct['counter'] && !$this->data[$struct['counter']]) {
                    continue;
                }
                else if (!isset($struct['default']) && $struct['type'] !== 'STRING' && $struct['type'] !== 'EMPTY') {
                    throw new kolab_api_exception(kolab_api_exception::SERVER_ERROR, array(
                        'line'    => __LINE__,
                        'file'    => __FILE__,
                        'message' => "Missing property " . get_class($this) . "::$idx",
                    ));
                }
                else {
                    $value = $struct['default'];
                }
            }
            else {
                $value = $this->data[$idx];
            }

            switch ($struct['type']) {
            case 'EMPTY':
                break;

            case 'WSTRING':
                $value = rcube_charset::convert($value, RCUBE_CHARSET, self::WSTRING_CHARSET);
                // no-break

            case 'STRING':
                $output .= $value;
                break;

            case 'BYTE':
                $output .= chr((int) $value);
                break;

            case 'WORD':
                $output .= pack('v', $value);
                break;

            case 'LONG':
                $output .= pack('l', $value);
                break;

            case 'ULONG':
                $output .= pack('V', (int) $value);
                break;

            case 'SYSTEMTIME':
                if ($value instanceof kolab_api_filter_mapistore_structure_systemtime) {
                    $output .= $value->output();
                }
                else {
                    $output .= pack('llll', 0, 0, 0, 0);
                }
                break;

            default:
                if (preg_match('/^(LONG|WORD|ULONG|BYTE)\[([0-9]*)\]$/', $struct['type'], $m)) {
                    $count = $m[2] ? $m[2] : count((array) $value);
                    for ($x = 0; $x < $count; $x++) {
                        switch ($m[1]) {
                        case 'BYTE':
                            $output .= chr((int) $value[$x]);
                            break;

                        case 'WORD':
                            $output .= pack('v', $value[$x]);
                            break;

                        case 'LONG':
                            $output .= pack('l', $value[$x]);
                            break;

                        case 'ULONG':
                            $output .= pack('V', $value[$x]);
                            break;
                        }
                    }
                }
                else if (preg_match('/^\[?(kolab_api_[a-z_]+)\]?$/', $struct['type'], $m)) {
                    $type = $m[1];
                    if (!is_array($value)) {
                        $value = !empty($value) ? array($value) : array();
                    }

                    foreach ($value as $v) {
                        if (!($v instanceof $type)) {
                            throw new kolab_api_exception(kolab_api_exception::SERVER_ERROR, array(
                                'line'    => __LINE__,
                                'file'    => __FILE__,
                                'message' => "Expected object of type $type"
                            ));
                        }

                        $output .= $v->output();
                    }
                }
            }
        }

        if ($base64) {
            $output = base64_encode($output);
        }

        return $output;
    }

    /**
     * Sets class data item
     */
    public function __set($name, $value)
    {
        if (!array_key_exists($name, $this->structure)) {
            throw new kolab_api_exception(kolab_api_exception::SERVER_ERROR, array(
                    'line'    => __LINE__,
                    'file'    => __FILE__,
                    'message' => 'Invalid member of MAPI structure: ' . get_class($this) . '::' . $name
            ));
        }

        $this->data[$name] = $value;
    }

    /**
     * Gets class data item
     */
    public function __get($name)
    {
        if (!array_key_exists($name, $this->structure)) {
            throw new kolab_api_exception(kolab_api_exception::SERVER_ERROR, array(
                    'line'    => __LINE__,
                    'file'    => __FILE__,
                    'message' => 'Invalid member of MAPI structure: ' . get_class($this) . '::' . $name
            ));
        }

        if (array_key_exists($name, $this->data)) {
            return $this->data[$name];
        }

        return $this->structure[$name]['default'];
    }
}
