<?php

/**
 +--------------------------------------------------------------------------+
 | This file is part of the Kolab REST API                                  |
 |                                                                          |
 | Copyright (C) 2012-2015, Kolab Systems AG                                |
 |                                                                          |
 | This program is free software: you can redistribute it and/or modify     |
 | it under the terms of the GNU Affero General Public License as published |
 | by the Free Software Foundation, either version 3 of the License, or     |
 | (at your option) any later version.                                      |
 |                                                                          |
 | This program is distributed in the hope that it will be useful,          |
 | but WITHOUT ANY WARRANTY; without even the implied warranty of           |
 | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the             |
 | GNU Affero General Public License for more details.                      |
 |                                                                          |
 | You should have received a copy of the GNU Affero General Public License |
 | along with this program. If not, see <http://www.gnu.org/licenses/>      |
 +--------------------------------------------------------------------------+
 | Author: Aleksander Machniak <machniak@kolabsys.com>                      |
 +--------------------------------------------------------------------------+
*/

class kolab_api_filter_mapistore_contact extends kolab_api_filter_mapistore_common
{
    const PHOTO_ATTACHMENT_ID = 9999;

    protected $model = 'contact';
    protected $map   = array(
        // contact name properties [MS-OXOCNTC]
        'PidTagNickname'             => 'nickname',         // PtypString
        'PidTagGeneration'           => 'n.suffix',         // PtypString
        'PidTagDisplayNamePrefix'    => 'n.prefix',         // PtypString
        'PidTagSurname'              => 'n.surname',        // PtypString
        'PidTagMiddleName'           => 'n.additional',     // PtypString
        'PidTagGivenName'            => 'n.given',          // PtypString
        'PidTagInitials'             => 'x-custom.MAPI:PidTagInitials', // PtypString
        'PidTagDisplayName'          => 'fn',               // PtypString
        'PidLidYomiFirstName'        => '',                 // PtypString
        'PidLidYomiLastName'         => '',                 // PtypString
        'PidLidFileUnder'            => '',                 // PtypString
        'PidLidFileUnderId'          => '',                 // PtypInteger32
        'PidLidFileUnderList'        => '',                 // PtypMultipleInteger32
        // electronic and phisical address properties
        'PidTagPrimaryFaxNumber'     => 'x-custom.MAPI:PidTagPrimaryFaxNumber',  // PtypString
        'PidTagBusinessFaxNumber'    => 'x-custom.MAPI:PidTagBusinessFaxNumber', // PtypString
        'PidTagHomeFaxNumber'               => '',          // PtypString
        'PidTagHomeAddressStreet'           => '',          // PtypString
        'PidTagHomeAddressCity'             => '',          // PtypString
        'PidTagHomeAddressStateOrProvince'  => '',          // PtypString
        'PidTagHomeAddressPostalCode'       => '',          // PtypString
        'PidTagHomeAddressCountry'          => '',          // PtypString
        'PidLidHomeAddressCountryCode'      => '',          // PtypString
        'PidTagHomeAddressPostOfficeBox'    => '',          // PtypString
        'PidLidHomeAddress'                 => '', // @TODO: ?
        'PidLidWorkAddressStreet'           => '',          // PtypString
        'PidLidWorkAddressCity'             => '',          // PtypString
        'PidLidWorkAddressState'            => '',          // PtypString
        'PidLidWorkAddressPostalCode'       => '',          // PtypString
        'PidLidWorkAddressCountry'          => '',          // PtypString
        'PidLidWorkAddressCountryCode'      => '',          // PtypString
        'PidLidWorkAddressPostOfficeBox'    => '',          // PtypString
        'PidLidWorkAddress'                 => '', // @TODO: ?
        'PidTagOtherAddressStreet'          => '',          // PtypString
        'PidTagOtherAddressCity'            => '',          // PtypString
        'PidTagOtherAddressStateOrProvince' => '',          // PtypString
        'PidTagOtherAddressPostalCode'      => '',          // PtypString
        'PidTagOtherAddressCountry'         => '',          // PtypString
        'PidLidOtherAddressCountryCode'     => '',          // PtypString
        'PidTagOtherAddressPostOfficeBox'   => '',          // PtypString
        'PidLidOtherAddress'                => '', // @TODO: ? // PtypString
        'PidTagStreetAddress'            => '', // @TODO: ? // PtypString
        'PidTagLocality'                 => '', // @TODO: ? // PtypString
        'PidTagStateOrProvince'          => '', // @TODO: ? // PtypString
        'PidTagPostalCode'               => '', // @TODO: ? // PtypString
        'PidTagCountry'                  => '', // @TODO: ? // PtypString
        'PidLidAddressCountryCode'       => '', // @TODO: ? // PtypString
        'PidTagPostOfficeBox'            => '', // @TODO: ? // PtypString
        'PidTagPostalAddress'            => '', // @TODO: ? // PtypString
        'PidLidPostalAddressId'          => '',             // PtypInteger32
        'PidTagPagerTelephoneNumber'     => '',             // PtypString
        'PidTagCallbackTelephoneNumber'  => '',             // PtypString
        'PidTagBusinessTelephoneNumber'  => '',             // PtypString
        'PidTagHomeTelephoneNumber'      => '',             // PtypString
        'PidTagPrimaryTelephoneNumber'   => '',             // PtypString
        'PidTagBusiness2TelephoneNumber' => '',             // PtypString
        'PidTagMobileTelephoneNumber'    => '',             // PtypString
        'PidTagRadioTelephoneNumber'     => '',             // PtypString
        'PidTagCarTelephoneNumber'       => '',             // PtypString
        'PidTagOtherTelephoneNumber'     => '',             // PtypString
        'PidTagAssistantTelephoneNumber' => '',             // PtypString
        'PidTagHome2TelephoneNumber'                            => 'x-custom.MAPI:PidTagHome2TelephoneNumber',
        'PidTagTelecommunicationsDeviceForDeafTelephoneNumber'  => 'x-custom.MAPI:PidTagTelecommunicationsDeviceForDeafTelephoneNumber',
        'PidTagCompanyMainTelephoneNumber'                      => 'x-custom.MAPI:PidTagCompanyMainTelephoneNumber',
        'PidTagTelexNumber'             => '',              // PtypString
        'PidTagIsdnNumber'              => '',              // PtypString
        'PidLidAddressBookProviderEmailList' => '',         // PtypMultipleInteger32, @TODO: ?
        'PidLidAddressBookProviderArrayType' => '',         // PtypInteger32, @TODO: ?
        // event properties
        'PidTagBirthday'                => 'bday',          // PtypTime, UTC
        'PidLidBirthdayLocal'           => '',              // PtypTime, @TODO
        'PidLidBirthdayEventEntryId'    => '',              // PtypBinary
        'PidTagWeddingAnniversary'      => 'anniversary',   // PtypTime, UTC
        'PidLidWeddingAnniversaryLocal' => '',              // PtypTime, @TODO
        'PidLidAnniversaryEventEntryId' => '',              // PtypBinary
        // professional properties
        'PidTagTitle'                   => 'title',         // PtypString
        'PidTagCompanyName'             => '',              // PtypString
        'PidLidYomiCompanyName'         => '',              // PtypString
        'PidTagDepartmentName'          => '',              // PtypString
        'PidTagOfficeLocation'          => 'x-custom.MAPI:PidTagOfficeLocation', // PtypString
        'PidTagManagerName'             => '',              // PtypString
        'PidTagAssistant'               => '',              // PtypString
        'PidTagProfession'              => 'group.role',    // PtypString
        'PidLidHasPicture'              => '',              // PtypBoolean, more about photo attachments in MS-OXOCNTC
        // other properties
        'PidTagHobbies'                 => 'x-custom.MAPI:PidTagHobbies',   // PtypString
        'PidTagSpouseName'              => '',                              // PtypString
        'PidTagLanguage'                => 'lang',                          // PtypString
        'PidTagLocation'                => 'x-custom.MAPI:PidTagLocation',  // PtypString
        'PidLidInstantMessagingAddress' => 'impp',                          // PtypString
        'PidTagOrganizationalIdNumber'  => 'x-custom.MAPI:PidTagOrganizationalIdNumber',// PtypString
        'PidTagCustomerId'              => 'x-custom.MAPI:PidTagCustomerId',        // PtypString
        'PidTagGovernmentIdNumber'      => 'x-custom.MAPI:PidTagGovernmentIdNumber',// PtypString
        'PidTagPersonalHomePage'        => 'url',                                   // PtypString
        'PidTagBusinessHomePage'        => 'x-custom.MAPI:PidTagBussinessHomePage', // PtypString
        'PidTagFtpSite'                 => 'x-custom.MAPI:PidTagFtpSite',           // PtypString
        'PidTagReferredByName'          => 'x-custom.MAPI:PidTagReferredByName',    // PtypString
        'PidLidBilling'                 => 'x-custom.MAPI:PidLidBilling',           // PtypString
        'PidLidFreeBusyLocation'        => 'fburl',     // PtypString
        'PidTagChildrenNames'           => '',          // PtypMultipleString
        'PidTagGender'                  => 'gender',    // PtypString
        'PidTagUserX509Certificate'     => 'key',       // PtypMultipleBinary
        'PidTagMessageClass'            => '',          // PtypString: IPM.Contact, IPM.DistList
        'PidTagBody'                    => '', // 'note' // PtypString
        // contact aggregation properties - skipped

        'PidTagLastModificationTime'    => 'rev',       // PtypTime
        // distribution lists [MS-OXOCNTC]
        'PidLidDistributionListName'            => '',      // PtypString = PidTagDisplayName
        'PidLidDistributionListMembers'         => '',      // PtypMultipleBinary
        'PidLidDistributionListOneOffMembers'   => '',      // PtypMultipleBinary
        'PidLidDistributionListChecksum'        => '',      // PtypInteger32
        'PidLidDistributionListStream'          => '',      // PtypBinary
    );

    protected $gender_map = array(
        0 => '',
        1 => 'F',
        2 => 'M',
    );

    protected $phone_map = array(
        'PidTagPagerTelephoneNumber'    => 'pager',
        'PidTagBusinessTelephoneNumber' => 'work',
        'PidTagHomeTelephoneNumber'     => 'home',
        'PidTagMobileTelephoneNumber'   => 'cell',
        'PidTagCarTelephoneNumber'      => 'x-car',
        'PidTagOtherTelephoneNumber'    => 'textphone',
        'PidTagBusinessFaxNumber'       => 'faxwork',
        'PidTagHomeFaxNumber'           => 'faxhome',
    );

    protected $email_map = array(
        'PidLidEmail1EmailAddress' => 'home',
        'PidLidEmail2EmailAddress' => 'work',
        'PidLidEmail3EmailAddress' => 'other',
    );

    protected $address_ids = array(
        'home'  => 0x00000001,
        'work'  => 0x00000002,
        'other' => 0x00000003,
    );


    /**
     * Convert Kolab to MAPI
     *
     * @param array Data
     * @param array Context (folder_uid, object_uid, object)
     *
     * @return array Data
     */
    public function output($data, $context = null)
    {
        $result = array(
            'PidTagMessageClass' => $data['kind'] == 'group' ? 'IPM.DistList' : 'IPM.Contact',
            // mapistore REST API specific properties
            'collection' => 'contacts',
        );

        foreach ($this->map as $mapi_idx => $kolab_idx) {
            if (empty($kolab_idx)) {
                continue;
            }

            $value = $this->get_kolab_value($data, $kolab_idx);

            if ($value === null) {
                continue;
            }

            switch ($mapi_idx) {
            case 'PidTagGender':
                $value = (int) array_search($value, $this->gender_map);
                break;

            case 'PidTagPersonalHomePage':
            case 'PidLidInstantMessagingAddress':
                if (is_array($value)) {
                    $value = $value[0];
                }
                break;

            case 'PidTagBirthday':
            case 'PidTagWeddingAnniversary':
            case 'PidTagLastModificationTime':
                $value = $this->date_php2mapi($value, false);
                break;

            case 'PidTagUserX509Certificate':
                foreach ((array) $value as $val) {
                    if ($val && preg_match('|^data:application/pkcs7-mime;base64,|i', $val, $m)) {
                        $result[$mapi_idx] = substr($val, strlen($m[0]));
                        continue 3;
                    }
                }
                $value = null;

                break;

            case 'PidTagTitle':
                if (is_array($value)) {
                    $value = $value[0];
                }
                break;
            }

            if ($value === null) {
                continue;
            }

            $result[$mapi_idx] = $value;
        }

        // notes can be in plain text format only?
        $this->body_from_kolab($data, $result, 'note');

        // contact photo attachment [MS-OXVCARD 2.1.3.2.4]
        if (!empty($data['photo'])) {
            // @TODO: check if photo is one of .bmp, .gif, .jpeg, .png
            // Photo in MAPI is handled as attachment
            // Set PidTagAttachmentContactPhoto=true on attachment object
            $result['PidLidHasPicture'] = true;
            // @FIXME: should we set PidTagHasAttachments?
        }

        // Organization/Department
        $organization = $data['group']['org'];
        if (is_array($organization)) {
            $result['PidTagCompanyName']    = $organization[0];
            $result['PidTagDepartmentName'] = $organization[1];
        }
        else if ($organization !== null) {
            $result['PidTagCompanyName'] = $organization;
        }

        // Manager/Assistant
        $related = $data['group']['related'];
        if ($related && $related['parameters']) {
            $related = array($related);
        }

        foreach ((array) $related as $rel) {
            $type = $rel['parameters']['type'];
            if ($type == 'x-manager') {
                $result['PidTagManagerName'] = $rel['text'];
            }
            else if ($type == 'x-assistant') {
                $result['PidTagAssistant'] = $rel['text'];
            }
        }

        // Children, Spouse
        foreach ((array) $data['related'] as $rel) {
            $type = $rel['parameters']['type'];
            if ($type == 'child') {
                $result['PidTagChildrensNames'][] = $rel['text'];
            }
            else if ($type == 'spouse') {
                $result['PidTagSpouseName'] = $rel['text'];
            }
        }

        // Emails
        $email_map = array_flip($this->email_map);
        foreach ((array) $data['email'] as $email) {
            $type = is_array($email) ? $email['parameters']['type'] : 'other';
            $key  = $email_map[$type] ?: $email_map['other'];
            // @TODO: This may be addr-spec (RFC5322), we should parse it
            // and fill also *AddressType and *DisplayName
            $result[$key] = is_array($email) ? $email['text'] : $email;
        }

        // Phone(s)
        $phone_map = array_flip($this->phone_map);
        $phones    = $data['tel'];
        if ($phones && $phones['parameters']) {
            $phones = array($phones);
        }

        foreach ((array) $phones as $phone) {
            $type = implode('', (array)$phone['parameters']['type']);

            if ($phone['text'] && ($idx = $phone_map[$type])) {
                $result[$idx] = $phone['text'];
            }
        }

        // Addresses(s)
        $addresses = $data['adr'];
        if ($addresses && $addresses['parameters']) {
            $addresses = array($addresses);
        }

        foreach ((array) $addresses as $addr) {
            $type    = $addr['parameters']['type'];
            $pref    = $addr['parameters']['pref'];
            $address = null;

            if ($type == 'home') {
                $address = array(
                    'PidTagHomeAddressStreet'          => $addr['street'],
                    'PidTagHomeAddressCity'            => $addr['locality'],
                    'PidTagHomeAddressStateOrProvince' => $addr['region'],
                    'PidTagHomeAddressPostalCode'      => $addr['code'],
                    'PidTagHomeAddressCountry'         => $addr['country'],
                    'PidTagHomeAddressPostOfficeBox'   => $addr['pobox'],
                );
            }
            else if ($type == 'work') {
                $address = array(
                    'PidLidWorkAddressStreet'        => $addr['street'],
                    'PidLidWorkAddressCity'          => $addr['locality'],
                    'PidLidWorkAddressState'         => $addr['region'],
                    'PidLidWorkAddressPostalCode'    => $addr['code'],
                    'PidLidWorkAddressCountry'       => $addr['country'],
                    'PidLidWorkAddressPostOfficeBox' => $addr['pobox'],
                );
            }

            if (!empty($address)) {
                $result = array_merge($result, array_filter($address));

                if (!empty($pref)) {
                    $result['PidLidPostalAddressId'] = $this->address_ids[$type];
                }
            }
        }

        $other_adr_map = array(
            'street'   => 'PidTagOtherAddressStreet',
            'locality' => 'PidTagOtherAddressCity',
            'region'   => 'PidTagOtherAddressStateOrProvince',
            'code'     => 'PidTagOtherAddressPostalCode',
            'country'  => 'PidTagOtherAddressCountry',
            'pobox'    => 'PidTagOtherAddressPostOfficeBox',
        );

        foreach ((array) $data['group']['adr'] as $idx => $value) {
            if ($value && ($key = $other_adr_map[$idx])) {
                $result[$key] = $value;
            }
        }

        // Group members
        $this->members_from_kolab($data, $result);

        $this->parse_common_props($result, $data, $context);

        return $result;
    }

    /**
     * Convert from MAPI to Kolab
     *
     * @param array Data
     * @param array Data of the object that is being updated
     *
     * @return array Data
     */
    public function input($data, $object = null)
    {
        $result = array();

        foreach ($this->map as $mapi_idx => $kolab_idx) {
            if (empty($kolab_idx)) {
                continue;
            }

            if (!array_key_exists($mapi_idx, $data)) {
                continue;
            }

            $value = $data[$mapi_idx];

            switch ($mapi_idx) {
            case 'PidTagBirthday':
            case 'PidTagWeddingAnniversary':
                if ($value) {
                    $value = $this->date_mapi2php($value);
                    $value = $value->format('Y-m-d');
                }
                break;

            case 'PidTagLastModificationTime':
                if ($value) {
                    $value = $this->date_mapi2php($value);
                    $value = $value->format('Y-m-d\TH:i:s\Z');
                }
                break;

            case 'PidTagGender':
                $value = $this->gender_map[(int)$value];
                break;

            case 'PidTagUserX509Certificate':
                if (!empty($value)) {
                    $value = array('data:application/pkcs7-mime;base64,' . $value);
                }
                break;

            case 'PidTagPersonalHomePage':
            case 'PidLidInstantMessagingAddress':
                if (!empty($value)) {
                    $value = array($value);
                }
                break;
            }

            $this->set_kolab_value($result, $kolab_idx, $value);
        }

        // notes
        $this->body_to_kolab($data, $result, 'note', 'plain');

        if (!empty($data['PidTagMessageClass'])) {
            $result['kind'] = stripos($data['PidTagMessageClass'], 'IPM.DistList') === 0 ? 'group' : 'individual';
        }

        // MS-OXVCARD 2.1.3.2.1
        if (!empty($data['PidTagNormalizedSubject']) && empty($data['PidTagDisplayName'])) {
            $result['fn'] = $data['PidTagNormalizedSubject'];
        }

        // Organization/Department
        if ($data['PidTagCompanyName']) {
            $result['group']['org'][] = $data['PidTagCompanyName'];
        }
        if (!empty($data['PidTagDepartmentName'])) {
            $result['group']['org'][] = $data['PidTagDepartmentName'];
        }

        // Manager
        if ($data['PidTagManagerName']) {
            $result['group']['related'][] = array(
                'parameters' => array('type' => 'x-manager'),
                'text'       => $data['PidTagManagerName'],
            );
        }

        // Assistant
        if ($data['PidTagAssistant']) {
            $result['group']['related'][] = array(
                'parameters' => array('type' => 'x-assistant'),
                'text'       => $data['PidTagAssistant'],
            );
        }

        // Spouse
        if ($data['PidTagSpouseName']) {
            $result['related'][] = array(
                'parameters' => array('type' => 'spouse'),
                'text'       => $data['PidTagSpouseName'],
            );
        }

        // Children
        foreach ((array) $data['PidTagChildrensNames'] as $child) {
            $result['related'][] = array(
                'parameters' => array('type' => 'child'),
                'text'       => $child,
            );
        }

        // Emails
        foreach ($this->email_map as $mapi_idx => $type) {
            if ($email = $data[$mapi_idx]) {
                $result['email'][] = array(
                    'parameters' => array('type' => $type),
                    'text'       => $email,
                );
            }
        }

        // Phone(s)
        foreach ($this->phone_map as $mapi_idx => $type) {
            if (array_key_exists($mapi_idx, $data)) {
                // first remove the old phone...
                if (!empty($object['tel'])) {
                    foreach ($object['tel'] as $idx => $phone) {
                        $pt = implode('', (array) $phone['parameters']['type']);
                        if ($pt == $type) {
                            unset($object['tel'][$idx]);
                        }
                    }
                }

                if ($tel = $data[$mapi_idx]) {
                    if (preg_match('/^fax(work|home)$/', $type, $m)) {
                        $type = array('fax', $m[1]);
                    }

                    // and add it to the list
                    $result['tel'][] = array(
                        'parameters' => array('type' => $type),
                        'text'       => $tel,
                    );
                }
            }
        }

        if (!empty($object['tel'])) {
            $result['tel'] = array_merge((array) $result['tel'], (array) $object['tel']);
        }

        // Preferred (mailing) address
        if ($data['PidLidPostalAddressId']) {
            $map  = array_flip($this->address_ids);
            $pref = $map[$data['PidLidPostalAddressId']];
        }

        // Home address
        $address = array();
        $adr_map = array(
            'PidTagHomeAddressStreet'          => 'street',
            'PidTagHomeAddressCity'            => 'locality',
            'PidTagHomeAddressStateOrProvince' => 'region',
            'PidTagHomeAddressPostalCode'      => 'code',
            'PidTagHomeAddressCountry'         => 'country',
            'PidTagHomeAddressPostOfficeBox'   => 'pobox',
        );

        foreach ($adr_map as $mapi_idx => $idx) {
            if ($adr = $data[$mapi_idx]) {
                $address[$idx] = $adr;
            }
        }

        if (!empty($address)) {
            $type = array('parameters' => array('type' => 'home'));
            if ($pref == 'home') {
                $type['parameters']['pref'] = 1;
            }

            $result['adr'][] = array_merge($address, $type);
        }

        // Work address
        $address = array();
        $adr_map = array(
            'PidLidWorkAddressStreet'        => 'street',
            'PidLidWorkAddressCity'          => 'locality',
            'PidLidWorkAddressState'         => 'region',
            'PidLidWorkAddressPostalCode'    => 'code',
            'PidLidWorkAddressCountry'       => 'country',
            'PidLidWorkAddressPostOfficeBox' => 'pobox',
        );

        foreach ($adr_map as $mapi_idx => $idx) {
            if ($adr = $data[$mapi_idx]) {
                $address[$idx] = $adr;
            }
        }
        if (!empty($address)) {
            $type = array('parameters' => array('type' => 'work'));
            if ($pref == 'work') {
                $type['parameters']['pref'] = 1;
            }

            $result['adr'][] = array_merge($address, $type);
        }

        // Office address
        $address = array();
        $adr_map = array(
            'PidTagOtherAddressStreet'          => 'street',
            'PidTagOtherAddressCity'            => 'locality',
            'PidTagOtherAddressStateOrProvince' => 'region',
            'PidTagOtherAddressPostalCode'      => 'code',
            'PidTagOtherAddressCountry'         => 'country',
            'PidTagOtherAddressPostOfficeBox'   => 'pobox',
        );

        foreach ($adr_map as $mapi_idx => $idx) {
            if ($adr = $data[$mapi_idx]) {
                $address[$idx] = $adr;
            }
        }
        if (!empty($address)) {
            $type = array();
            if ($pref == 'other') {
                $type['parameters']['pref'] = 1;
            }

            $result['group']['adr'] = array_merge($address, $type);
        }

        // Group members
        $this->members_to_kolab($data, $result);

        $this->convert_common_props($result, $data, $object);

        return $result;
    }

    /**
     * Returns the attributes names mapping
     */
    public function map()
    {
        $map = array_filter($this->map);

        $map['PidTagBody'] = 'note';

        return $map;
    }

    /**
     * Return attachment data for photo of the contact
     *
     * @param array $contact Contact data
     *
     * @return array Attachment data
     */
    public static function photo_attachment($contact)
    {
        if (!empty($contact['photo'])) {
            $bin_data = $contact['photo'];
            $mimetype = rcube_mime::file_content_type($bin_data, 'ContactPicture.jpg', 'image/jpeg', true);

            list(, $type) = explode('/', $mimetype);
            $ext = $type == 'jpeg' ? 'jpg' : $type;

            // @TODO: Do we need to convert to JPEG?
            // [MS-OXOCNTC]: The value of the PidTagAttachDataBinary property,
            // which is the contents of the attachment, SHOULD be in JPEG format.
            // Support for other formats is as determined by the implementer.

            $attachment = array(
                'is-photo' => true,
                'filename' => 'ContactPicture.' . $ext,
                'size'     => strlen($bin_data),
                'content'  => $bin_data,
                'mimetype' => $mimetype,
                'id'       => self::PHOTO_ATTACHMENT_ID,
            );

            if ($attachment['size']) {
                return $attachment;
            }
        }
    }

    /**
     * Convert Kolab members list into MAPI properties
     */
    protected function members_from_kolab($data, &$result)
    {
        // @TODO
        foreach ((array) $data['member'] as $member) {

        }
    }

    /**
     * Convert MAPI properties into Kolab member array
     */
    protected function members_to_kolab($data, &$result)
    {
        // @TODO
    }
}
