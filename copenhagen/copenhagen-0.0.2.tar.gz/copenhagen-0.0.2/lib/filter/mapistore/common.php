<?php

/**
 +--------------------------------------------------------------------------+
 | This file is part of the Kolab REST API                                  |
 |                                                                          |
 | Copyright (C) 2012-2015, Kolab Systems AG                                |
 |                                                                          |
 | This program is free software: you can redistribute it and/or modify     |
 | it under the terms of the GNU Affero General Public License as published |
 | by the Free Software Foundation, either version 3 of the License, or     |
 | (at your option) any later version.                                      |
 |                                                                          |
 | This program is distributed in the hope that it will be useful,          |
 | but WITHOUT ANY WARRANTY; without even the implied warranty of           |
 | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the             |
 | GNU Affero General Public License for more details.                      |
 |                                                                          |
 | You should have received a copy of the GNU Affero General Public License |
 | along with this program. If not, see <http://www.gnu.org/licenses/>      |
 +--------------------------------------------------------------------------+
 | Author: Aleksander Machniak <machniak@kolabsys.com>                      |
 +--------------------------------------------------------------------------+
*/

class kolab_api_filter_mapistore_common
{
    // PidTagObjectType property values
    const OBJECT_STORE              = 0x00000001;
    const OBJECT_ABOOK              = 0x00000002;
    const OBJECT_ABOOK_CONTAINER    = 0x00000004;
    const OBJECT_MESSAGE            = 0x00000005;
    const OBJECT_USER               = 0x00000006;
    const OBJECT_ATTACHMENT         = 0x00000007;
    const OBJECT_DISTLIST           = 0x00000008;

    // Common properties [MS-OXCMSG]
    protected static $common_map = array(
//        'PidTagAccess'               => '',                       // PtypInteger32
//        'PidTagAccessLevel'          => '',                       // PtypInteger32, 0 - read-only, 1 - modify
//        'PidTagChangeKey'            => '',                       // PtypBinary
        'PidTagCreationTime'         => 'creation-date',            // PtypTime, UTC
        'PidTagLastModificationTime' => 'last-modification-date',   // PtypTime, UTC
//        'PidTagLastModifierName'     => '',                       // PtypString
//        'PidTagObjectType'           => '',                       // PtypInteger32
        'PidTagHasAttachments'       => 'attach',                   // PtypBoolean
//        'PidTagRecordKey'            => '',                       // PtypBinary
//        'PidTagSearchKey'            => '',                       // PtypBinary
        'PidNameKeywords'            => 'categories',
    );

    protected $recipient_track_status_map = array(
        'TENTATIVE' => 0x00000002,
        'ACCEPTED'  => 0x00000003,
        'DECLINED'  => 0x00000004,
    );

    protected $recipient_type_map = array(
        'NON-PARTICIPANT'   => 0x00000004,
        'OPT-PARTICIPANT'   => 0x00000002,
        'REQ-PARTICIPANT'   => 0x00000001,
        'CHAIR'             => 0x00000001,
    );

    /**
     * Mapping of weekdays
     */
    protected static $recurrence_day_map = array(
        'SU'  => 0x00000000,
        'MO'  => 0x00000001,
        'TU'  => 0x00000002,
        'WE'  => 0x00000003,
        'TH'  => 0x00000004,
        'FR'  => 0x00000005,
        'SA'  => 0x00000006,
        'BYDAY-SU'  => 0x00000001,
        'BYDAY-MO'  => 0x00000002,
        'BYDAY-TU'  => 0x00000004,
        'BYDAY-WE'  => 0x00000008,
        'BYDAY-TH'  => 0x00000010,
        'BYDAY-FR'  => 0x00000020,
        'BYDAY-SA'  => 0x00000040,
    );


    /**
     * Extracts data from kolab data array
     */
    public static function get_kolab_value($data, $name)
    {
        $name_items = explode('.', $name);
        $count      = count($name_items);
        $value      = $data[$name_items[0]];

        // special handling of x-custom properties
        if ($name_items[0] === 'x-custom') {
            foreach ((array) $value as $custom) {
                if ($custom['identifier'] === $name_items[1]) {
                    return $custom['value'];
                }
            }

            return;
        }

        for ($i = 1; $i < $count; $i++) {
            if (!is_array($value)) {
                return null;
            }

            list($key, $num) = explode(':', $name_items[$i]);
            $value = $value[$key];

            if ($num !== null && $value !== null) {
                $value = is_array($value) ? $value[$num] : null;
            }
        }

        return $value;
    }

    /**
     * Sets specified kolab data item
     */
    public static function set_kolab_value(&$data, $name, $value)
    {
        $name_items = explode('.', $name);
        $count      = count($name_items);
        $element    = &$data;

        // x-custom properties
        if ($name_items[0] === 'x-custom') {
            // this is supposed to be converted later by parse_common_props()
            $data[$name] = $value;
            return;
        }

        if ($count > 1) {
            for ($i = 0; $i < $count - 1; $i++) {
                $key = $name_items[$i];
                if (!array_key_exists($key, $element)) {
                    $element[$key] = array();
                }

                $element = &$element[$key];
            }
        }

        $element[$name_items[$count - 1]] = $value;
    }

    /**
     * Parse common properties in object data (convert into MAPI format)
     */
    protected function parse_common_props(&$result, $data, $context = array())
    {
        if (empty($context)) {
            // @TODO: throw exception?
            return;
        }

        if ($data['uid'] && $context['folder_uid']) {
            $result['id'] = kolab_api_filter_mapistore::uid_encode($context['folder_uid'], $data['uid']);
        }

        if ($context['folder_uid']) {
            $result['parent_id'] = $context['folder_uid'];
        }

        foreach (self::$common_map as $mapi_idx => $kolab_idx) {
            if (!isset($result[$mapi_idx]) && ($value = $data[$kolab_idx]) !== null) {
                switch ($mapi_idx) {
                case 'PidTagCreationTime':
                case 'PidTagLastModificationTime':
                    $result[$mapi_idx] = self::date_php2mapi($value, true);
                    break;

                case 'PidTagHasAttachments':
                    if (!empty($value) && $this->model != 'note') {
                        $result[$mapi_idx] = true;
                    }
                    break;

                case 'PidNameKeywords':
                    $result[$mapi_idx] = self::parse_categories((array) $value);
                    break;
                }
            }
        }

        // set object type
        switch ($this->model) {
        case 'attachment':
            $result['PidTagObjectType'] = self::OBJECT_ATTACHMENT;
            break;

        case 'folder':
        case 'info':
            // no object type for folders
            break;

        default:
            if ($result['PidTagMessageClass'] == 'IPM.DistList') {
                $result['PidTagObjectType'] = self::OBJECT_DISTLIST;
            }
            else {
                $result['PidTagObjectType'] = self::OBJECT_MESSAGE;
            }
        }
    }

    /**
     * Convert common properties into kolab format
     */
    protected function convert_common_props(&$result, $data, $original)
    {
        // @TODO: id, parent_id?
        foreach (self::$common_map as $mapi_idx => $kolab_idx) {
            if (array_key_exists($mapi_idx, $data) && !array_key_exists($kolab_idx, $result)) {
                $value = $data[$mapi_idx];

                switch ($mapi_idx) {
                case 'PidTagCreationTime':
                case 'PidTagLastModificationTime':
                    if ($value) {
                        $dt = self::date_mapi2php($value);
                        $result[$kolab_idx] = $dt->format('Y-m-d\TH:i:s\Z');
                    }
                    break;

                default:
                    if ($value) {
                        $result[$kolab_idx] = $value;
                    }
                    break;
                }
            }
        }

        // Handle x-custom fields
        foreach ((array) $result as $key => $value) {
            if (strpos($key, 'x-custom.') === 0) {
                unset($result[$key]);
                $key = substr($key, 9);

                foreach ((array) $original['x-custom'] as $idx => $custom) {
                    if ($custom['identifier'] == $key) {
                        if ($value) {
                            $original['x-custom'][$idx]['value'] = $value;
                        }
                        else {
                            unset($original['x-custom'][$idx]);
                        }

                        $x_custom_update = true;
                        continue 2;
                    }
                }

                if ($value) {
                    $original['x-custom'][] = array(
                        'identifier' => $key,
                        'value'      => $value,
                    );
                }

                $x_custom_update = true;
            }
        }

        if ($x_custom_update) {
            $result['x-custom'] = array_values($original['x-custom']);
        }
    }

    /**
     * Filter property names with mapping (kolab <> MAPI)
     *
     * @param array $attrs   Property names
     * @param bool  $reverse Reverse mapping
     *
     * @return array Property names
     */
    public function attributes_filter($attrs, $reverse = false)
    {
        $map    = array_merge(self::$common_map, $this->map());
        $result = array();

        // add some special common attributes
        $map['PidTagMessageClass'] = 'PidTagMessageClass';
        $map['collection']         = 'collection';
        if (!isset($map['id'])) {
            $map['id'] = 'uid';
        }

        foreach ($attrs as $attr) {
            if ($reverse) {
                if ($name = array_search($attr, $map)) {
                    $result[] = $name;
                }
            }
            else if ($name = $map[$attr]) {
                $result[] = $name;
            }
        }

        return $result;
    }

    /**
     * Return properties map
     */
    protected function map()
    {
        return array();
    }

    /**
     * Parse categories according to [MS-OXCICAL 2.1.3.1.1.20.3]
     *
     * @param array Categories
     *
     * @return array Categories
     */
    public static function parse_categories($categories)
    {
        if (!is_array($categories)) {
            return;
        }

        $result = array();

        foreach ($categories as $idx => $val) {
            $val = preg_replace('/(\x3B|\x2C|\x06\x1B|\xFE\x54|\xFF\x1B)/', '', $val);
            $val = preg_replace('/\s+/', ' ', $val);
            $val = trim($val);
            $len = mb_strlen($val);

            if ($len) {
                if ($len > 255) {
                    $val = mb_substr($val, 0, 255);
                }

                $result[mb_strtolower($val)] = $val;
            }
        }

        return array_values($result);
    }

    /**
     * Convert Kolab 'attendee' specification into MAPI recipient
     * and add it to the result
     */
    protected function attendee_to_recipient($attendee, &$result, $is_organizer = false)
    {
        $email  = $attendee['cal-address'];
        $params = (array) $attendee['parameters'];

        // parse mailto string
        if (strpos($email, 'mailto:') === 0) {
            $email = urldecode(substr($email, 7));
        }

        $emails = rcube_mime::decode_address_list($email, 1);

        if (!empty($email)) {
            $email     = $emails[key($emails)];
            $recipient = array(
                'PidTagAddressType'  => 'SMTP',
                'PidTagDisplayName'  => $params['cn'] ?: $email['name'],
                'PidTagDisplayType'  => 0,
                'PidTagEmailAddress' => $email['mailto'],
            );

            if ($is_organizer) {
                $recipient['PidTagRecipientFlags'] = 0x00000003;
                $recipient['PidTagRecipientType']  = 0x00000001;
            }
            else {
                $recipient['PidTagRecipientFlags']       = 0x00000001;
                $recipient['PidTagRecipientTrackStatus'] = (int) $this->recipient_track_status_map[$params['partstat']];
                $recipient['PidTagRecipientType']        = $this->to_recipient_type($params['cutype'], $params['role']);
            }

            $recipient['PidTagRecipientDisplayName'] = $recipient['PidTagDisplayName'];

            $result['recipients'][] = $recipient;

            if (strtoupper($params['rsvp']) == 'TRUE') {
                $result['PidTagReplyRequested']    = true;
                $result['PidTagResponseRequested'] = true;
            }
        }
    }

    /**
     * Convert MAPI recipient into Kolab attendee
     */
    protected function recipient_to_attendee($recipient, &$result)
    {
        if ($email = $recipient['PidTagEmailAddress']) {
            $mailto = 'mailto:' . rawurlencode($email);

            $attendee = array(
                'cal-address' => $mailto,
                'parameters'  => array(
                    'cn' => $recipient['PidTagDisplayName'] ?: $recipient['PidTagRecipientDisplayName'],
                ),
            );

            if ($recipient['PidTagRecipientFlags'] == 0x00000003) {
                $result['organizer'] = $attendee;
            }
            else {
                switch ($recipient['PidTagRecipientType']) {
                case 0x00000004:
                    $role = 'NON-PARTICIPANT';
                    break;

                case 0x00000003:
                    $cutype = 'RESOURCE';
                    break;

                case 0x00000002:
                    $role = 'OPT-PARTICIPANT';
                    break;

                case 0x00000001:
                    $role = 'REQ-PARTICIPANT';
                    break;
                }

                $map      = array_flip($this->recipient_track_status_map);
                $partstat = $map[$recipient['PidTagRecipientTrackStatus']] ?: 'NEEDS-ACTION';

                // @TODO: rsvp?
                $attendee['parameters']['cutype']   = $cutype;
                $attendee['parameters']['role']     = $role;
                $attendee['parameters']['partstat'] = $partstat;

                $result['attendee'][] = $attendee;
            }
        }
    }

    /**
     * Convert Kolab valarm specification into MAPI properties
     *
     * @param array $data   Kolab object
     * @param array $result Object data (MAPI format)
     */
    protected function alarm_from_kolab($data, &$result)
    {
        // [MS-OXCICAL] 2.1.3.1.1.20.62
        foreach ((array) $data['valarm'] as $alarm) {
            if (!empty($alarm['properties']) && $alarm['properties']['action'] != 'DISPLAY') {
                continue;
            }

            // @TODO alarms with Date-Time instead of Duration
            $trigger = $alarm['properties']['trigger'];

            if ($trigger['duration']
                && $trigger['parameters']['related'] != 'END'
                && ($delta = self::reminder_duration_to_delta($trigger['duration']))
            ) {
                // Find next instance of the appointment (in UTC)
                $now = kolab_api::$now ?: new DateTime('now', new DateTimeZone('UTC'));

                if ($data['dtstart']) {
                    $dtstart = kolab_api_input_json::to_datetime($data['dtstart']);

                    // check if start date is from the future
                    if ($dtstart > $now) {
                        $reminder_time = $dtstart;
                    }
                    // find next occurence
                    else {
                        kolab_api_input_json::parse_recurrence($data, $res);

                        if (!empty($res['recurrence'])) {
                            $recurlib = libcalendaring::get_recurrence();
                            $recurlib->init($res['recurrence'], $now);
                            $next = $recurlib->next();

                            if ($next) {
                                $reminder_time = $next;
                            }
                        }
                    }
                }

                $result['PidLidReminderDelta'] = $delta;

                // If all instances are in the past, don't set ReminderTime nor ReminderSet
                if ($reminder_time) {
                    $signal_time = clone $reminder_time;
                    $signal_time->sub(new DateInterval('PT' . $delta . 'M'));

                    $result['PidLidReminderSet']        = true;
                    $result['PidLidReminderTime']       = $this->date_php2mapi($reminder_time, true);
                    $result['PidLidReminderSignalTime'] = $this->date_php2mapi($signal_time, true);
                }

                // MAPI supports only one alarm
                break;
            }
        }
    }

    /**
     * Convert MAPI recurrence into Kolab (MS-OXICAL: 2.1.3.2.2)
     *
     * @param string $data   MAPI object
     * @param array  $result Kolab object
     */
    protected function alarm_to_kolab($data, &$result)
    {
        if ($data['PidLidReminderSet'] && ($delta = $data['PidLidReminderDelta'])) {
            $duration = self::reminder_delta_to_duration($delta);
            $alarm    = array(
                'action'      => 'DISPLAY',
                'trigger'     => array('duration' => $duration),
            //    'description' => 'Reminder',
            );

            $result['valarm'] = array(array('properties' => $alarm));
        }
        else if (array_key_exists('PidLidReminderSet', $data) || array_key_exists('PidLidReminderDelta', $data)) {
            $result['valarm'] = array();
        }
    }

    /**
     * Convert PidLidReminderDelta value into xCal duration
     */
    protected static function reminder_delta_to_duration($delta)
    {
        if ($delta == 0x5AE980E1) {
            $delta = 15;
        }

        $delta = (int) $delta;

        return "-PT{$delta}M";
    }

    /**
     * Convert Kolab alarm duration into PidLidReminderDelta
     */
    protected static function reminder_duration_to_delta($duration)
    {
        if ($duration && preg_match('/^-[PT]*([0-9]+)([WDHMS])$/', $duration, $matches)) {
            $value = intval($matches[1]);

            switch ($matches[2]) {
            case 'S': $value = intval(round($value/60)); break;
            case 'H': $value *= 60; break;
            case 'D': $value *= 24 * 60; break;
            case 'W': $value *= 7 * 24 * 60; break;
            }

            return $value;
        }
    }

    /**
     * Convert Kolab recurrence specification into MAPI properties
     *
     * @param array $data   Kolab object
     * @param array $object Object data (MAPI format)
     */
    protected function recurrence_from_kolab($data, &$object)
    {
        if ((empty($data['rrule']) || empty($data['rrule']['recur']))
            && (empty($data['rdate']) || empty($data['rdate']['date']))
        ) {
            return false;
        }

        // Get event/task start date for FirstDateTime calculations
        if ($dtstart = kolab_api_input_json::to_datetime($data['dtstart'])) {
            // StartDate: Set to the date portion of DTSTART, in the time zone specified
            //   by PidLidTimeZoneStruct. This date is stored in minutes after
            //   midnight Jan 1, 1601. Note that this value MUST always be
            //   evenly divisible by 1440.
            // EndDate: Set to the start date of the last instance of a recurrence, in the
            //   time zone specified by PidLidTimeZoneStruct. This date is
            //   stored in minutes after midnight January 1, 1601. If the
            //   recurrence is infinite, set EndDate to 0x5AE980DF. Note that
            //   this value MUST always be evenly divisible by 1440, except for
            //   the special value 0x5AE980DF.

            $startdate = clone $dtstart;
            $startdate->setTime(0, 0, 0);
            $startdate = self::date_php2mapi($startdate, true);
            $startdate = intval($startdate / 60);

            if ($mod = ($startdate % 1440)) {
                $startdate -= $mod;
            }

            // @TODO: get first occurrence of the event using libcalendaring_recurrence class ?
        }
        else {
            rcube::raise_error(array(
                    'line'    => __LINE__,
                    'file'    => __FILE__,
                    'message' => "Found recurring {$this->model} without start date, skipping recurrence",
                ), true, false);

            return false;
        }

        $rule   = (array) ($data['rrule'] ? $data['rrule']['recur'] : null);
        $result = array(
            'Period'          => $rule && $rule['interval'] ? $rule['interval'] : 1,
            'FirstDOW'        => self::day2bitmask($rule['wkst'] ?: 'MO'),
            'OccurrenceCount' => 0x0000000A,
            'StartDate'       => $startdate,
            'EndDate'         => 0x5AE980DF,
            'FirstDateTime'   => $startdate,
            'CalendarType'    => kolab_api_filter_mapistore_structure_recurrencepattern::CALENDARTYPE_DEFAULT,
            'ModifiedInstanceDates' => array(),
            'DeletedInstanceDates'  => array(),
        );

        switch ($rule['freq']) {
        case 'DAILY':
            $result['RecurFrequency'] = kolab_api_filter_mapistore_structure_recurrencepattern::RECURFREQUENCY_DAILY;
            $result['PatternType']    = kolab_api_filter_mapistore_structure_recurrencepattern::PATTERNTYPE_DAY;
            $result['Period']        *= 1440;
            break;

        case 'WEEKLY':
            // if BYDAY does not exist use day from DTSTART
            if (empty($rule['byday'])) {
                $rule['byday'] = strtoupper($startdate->format('S'));
            }

            $result['RecurFrequency'] = kolab_api_filter_mapistore_structure_recurrencepattern::RECURFREQUENCY_WEEKLY;
            $result['PatternType']    = kolab_api_filter_mapistore_structure_recurrencepattern::PATTERNTYPE_WEEK;
            $result['PatternTypeSpecific'] = self::day2bitmask($rule['byday'], 'BYDAY-');
            break;

        case 'MONTHLY':
            $result['RecurFrequency'] = kolab_api_filter_mapistore_structure_recurrencepattern::RECURFREQUENCY_MONTHLY;

            if (!empty($rule['bymonthday'])) {
                // MAPI doesn't support multi-valued month days
                $month_day = min(explode(',', $rule['bymonthday']));

                $result['PatternType'] = kolab_api_filter_mapistore_structure_recurrencepattern::PATTERNTYPE_MONTH;
                $result['PatternTypeSpecific'] = $month_day == -1 ? 0x0000001F : $month_day;
            }
            else {
                $result['PatternType'] = kolab_api_filter_mapistore_structure_recurrencepattern::PATTERNTYPE_MONTHNTH;
                $result['PatternTypeSpecific'][] = self::day2bitmask($rule['byday'], 'BYDAY-');

                if (!empty($rule['bysetpos'])) {
                    $result['PatternTypeSpecific'][] = $rule['bysetpos'] == -1 ? 0x00000005 : $rule['bysetpos'];
                }
            }

            break;

        case 'YEARLY':
            $result['RecurFrequency']  = kolab_api_filter_mapistore_structure_recurrencepattern::RECURFREQUENCY_YEARLY;
            $result['Period']         *= 12;

            // MAPI doesn't support multi-valued months
            if ($rule['bymonth']) {
                // @TODO: set $startdate
            }

            if (!empty($rule['bymonthday'])) {
                // MAPI doesn't support multi-valued month days
                $month_day = min(explode(',', $rule['bymonthday']));

                $result['PatternType'] = kolab_api_filter_mapistore_structure_recurrencepattern::PATTERNTYPE_MONTHNTH;
                $result['PatternTypeSpecific'] = array(0, $month_day == -1 ? 0x0000001F : $month_day);
            }
            else {
                $result['PatternType'] = kolab_api_filter_mapistore_structure_recurrencepattern::PATTERNTYPE_MONTHNTH;
                $result['PatternTypeSpecific'][] = self::day2bitmask($rule['byday'], 'BYDAY-');

                if (!empty($rule['bysetpos'])) {
                    $result['PatternTypeSpecific'][] = $rule['bysetpos'] == -1 ? 0x00000005 : $rule['bysetpos'];
                }
            }

            break;
        }

        // [MS-OXOTASK] 2.2.2.2.15 says that tasks do not have Deleted/Modified instances
        // does that mean there's also no exceptions support for tasks? It looks so.

        $exception_info     = array();
        $extended_exception = array();

        // Custom occurrences (RDATE)
        if ($this->model != 'task' && !empty($data['rdate'])) {
            foreach ((array) $data['rdate']['date'] as $dt) {
                try {
                    $dt = new DateTime($dt, $dtstart->getTimezone());
                    $dt->setTime(0, 0, 0);
                    $dt = self::date_php2minutes($dt);

                    $result['ModifiedInstanceDates'][] = $dt;
                    $result['DeletedInstanceDates'][]  = $dt;

                    $exception_info[] = new kolab_api_filter_mapistore_structure_exceptioninfo(array(
                        'StartDateTime'     => $dt,
                        'EndDateTime'       => $dt + $object['PidLidAppointmentDuration'],
                        'OriginalStartDate' => $dt,
                        'OverrideFlags'     => 0,
                    ));

                    $extended_exception[] = kolab_api_filter_mapistore_structure_extendedexception::get_empty();
                }
                catch (Exception $e) {
                }
            }

            $result['EndType']        = kolab_api_filter_mapistore_structure_recurrencepattern::ENDTYPE_NOCC;
            $result['OccurenceCount'] = count($result['ModifiedInstanceDates']);

            // @FIXME: Kolab format says there can be RDATE and/or RRULE
            // MAPI specification says there must be RRULE if RDATE is specified
            if (!$result['RecurFrequency']) {
                $result['RecurFrequency'] = 0;
                $result['PatternType']    = 0;
            }
        }

        if ($rule && !empty($rule['until'])) {
            $result['EndType'] = kolab_api_filter_mapistore_structure_recurrencepattern::ENDTYPE_AFTER;
        }
        else if ($rule && !empty($rule['count'])) {
            $result['EndType']         = kolab_api_filter_mapistore_structure_recurrencepattern::ENDTYPE_NOCC;
            $result['OccurrenceCount'] = $rule['count'];
        }
        else if (!isset($result['EndType'])) {
            $result['EndType'] = kolab_api_filter_mapistore_structure_recurrencepattern::ENDTYPE_NEVER;
        }

        // calculate EndDate
        if ($rule && $result['EndType'] != kolab_api_filter_mapistore_structure_recurrencepattern::ENDTYPE_NEVER) {
            kolab_api_input_json::parse_recurrence($data, $res);

            if (!empty($res['recurrence'])) {
                try {
                    $recurlib = libcalendaring::get_recurrence();
                    $recurlib->init($res['recurrence'], $dtstart);
                    $end = $recurlib->end();

                    if ($end) {
                        $result['EndDate'] = intval(self::date_php2mapi($end) / 60);
                    }
                }
                catch (Exception $e) {
                    rcube::raise_error($e, true, false);
                }
            }
        }

        // Deleted instances (EXDATE)
        if ($this->model != 'task' && !empty($data['exdate'])) {
            if (!empty($data['exdate']['date'])) {
                $exceptions = (array) $data['exdate']['date'];
            }
            else if (!empty($data['exdate']['date-time'])) {
                $exceptions = (array) $data['exdate']['date-time'];
            }
            else {
                $exceptions = array();
            }

            // convert date(-time)s to numbers
            foreach ($exceptions as $idx => $dt) {
                try {
                    $dt = new DateTime($dt, $dtstart->getTimezone());
                    $dt->setTime(0, 0, 0);
                    $dt = self::date_php2minutes($dt);

//                    $result['ModifiedInstanceDates'][] = $dt;
                    $result['DeletedInstanceDates'][]  = $dt;
                }
                catch (Exception $e) {
                    rcube::raise_error($e, true, false);
                }
            }
        }

        // Exceptions
        // @TODO: Support range=THISANDFUTURE
        foreach ((array) $data['exceptions'] as $exception) {
            if (!empty($exception['recurrence-id'])) {
                try {
                    $dt = new DateTime($exception['recurrence-id'], $dtstart->getTimezone());
                    $dt->setTime(0, 0, 0);

                    // exception_info [MS-OXCICAL] 2.1.3.1.1.20.18 (page 61)
                    $exception_data       = $this->exception_from_kolab($exception, $data, $object);
                    $exception_info[]     = $exception_data[0];
                    $extended_exception[] = $exception_data[1];

                    $result['ModifiedInstanceDates'][] = self::date_php2minutes($dt);
                    $object['PidTagHasAttachments']    = true;
                }
                catch (Exception $e) {
                    rcube::raise_error($e, true, false);
                }
            }
        }

        // [MS-OXCICAL] 2.1.3.1.1.20.13: Sort and make exceptions valid
        foreach (array('DeletedInstanceDates', 'ModifiedInstanceDates') as $key) {
            if (!empty($result[$key])) {
                sort($result[$key]);
                $result[$key] = array_values(array_unique(array_filter($result[$key])));
            }
        }

        $rp = new kolab_api_filter_mapistore_structure_recurrencepattern($result);

        if ($this->model == 'task') {
            $object['PidLidTaskRecurrence'] = $rp->output(true);
            $object['PidLidTaskFRecurring'] = true;
            return true;
        }

        $byhour   = $rule['byhour'] ? min(explode(',', $rule['byhour'])) : 0;
        $byminute = $rule['byminute'] ? min(explode(',', $rule['byminute'])) : 0;
        $offset   = 60 * intval($byhour) + intval($byminute);

        $arp = array(
            'RecurrencePattern' => $rp,
            'StartTimeOffset'   => $offset,
            'EndTimeOffset'     => $offset + $object['PidLidAppointmentDuration'],
            'ExceptionInfo'     => $exception_info,
            'ExtendedException' => $extended_exception,
        );

        $arp = new kolab_api_filter_mapistore_structure_appointmentrecurrencepattern($arp);

        $object['PidLidAppointmentRecur'] = $arp->output(true);

        return true;
    }

    /**
     * Convert MAPI recurrence into Kolab (MS-OXICAL: 2.1.3.2.2)
     *
     * @param string $rule   MAPI binary representation of recurrence rule
     * @param array  $object Kolab object
     */
    protected function recurrence_to_kolab($rule, &$object)
    {
        if (empty($rule)) {
            return array();
        }

        // parse binary (Appointment)RecurrencePattern
        if ($this->model == 'event') {
            $arp = new kolab_api_filter_mapistore_structure_appointmentrecurrencepattern();
            $arp->input($rule, true);
            $rp = $arp->RecurrencePattern;
        }
        else {
            $rp = new kolab_api_filter_mapistore_structure_recurrencepattern();
            $rp->input($rule, true);
        }

        $result = array(
            'interval' => $rp->Period,
        );

        switch ($rp->PatternType) {
        case kolab_api_filter_mapistore_structure_recurrencepattern::PATTERNTYPE_DAY:
            $result['freq']      = 'DAILY';
            $result['interval'] /= 1440;

            if ($arp) {
                $result['byhour']   = floor($arp->StartTimeOffset / 60);
                $result['byminute'] = $arp->StartTimeOffset - $result['byhour'] * 60;
            }

            break;

        case kolab_api_filter_mapistore_structure_recurrencepattern::PATTERNTYPE_WEEK:
            $result['freq']  = 'WEEKLY';
            $result['byday'] = self::bitmask2day($rp->PatternTypeSpecific);

            if ($rp->Period >= 1) {
                $result['wkst'] = self::bitmask2day($rp->FirstDOW);
            }

            break;

        default: // monthly/yearly
            $evenly_divisible = $rp->Period % 12 == 0;

            switch ($rp->PatternType) {
            case kolab_api_filter_mapistore_structure_recurrencepattern::PATTERNTYPE_MONTH:
            case kolab_api_filter_mapistore_structure_recurrencepattern::PATTERNTYPE_MONTHEND:
                $result['freq'] = $evenly_divisible ? 'YEARLY' : 'MONTHLY';
                break;

            case kolab_api_filter_mapistore_structure_recurrencepattern::PATTERNTYPE_MONTHNTH:
            case kolab_api_filter_mapistore_structure_recurrencepattern::PATTERNTYPE_HJMONTHNTH:
                $result['freq'] = $evenly_divisible ? 'YEARLY-NTH' : 'MONTHLY-NTH';
                break;

            default:
                // not-supported
                return;
            }

            if ($result['freq'] = 'MONTHLY') {
                $rule['bymonthday'] = intval($rp->PatternTypeSpecific == 0x0000001F ? -1 : $rp->PatternTypeSpecific);
            }
            else if ($result['freq'] = 'MONTHLY-NTH') {
                $result['freq']  = 'MONTHLY';
                $result['byday'] = self::bitmask2day($rp->PatternTypeSpecific[0]);

                if ($rp->PatternTypeSpecific[1]) {
                    $result['bysetpos'] = intval($rp->PatternTypeSpecific[1] == 0x00000005 ? -1 : $rp->PatternTypeSpecific[1]);
                }
            }
            else if ($result['freq'] = 'YEARLY') {
                $result['interval'] /= 12;
                $rule['bymonthday'] = intval($rp->PatternTypeSpecific == 0x0000001F ? -1 : $rp->PatternTypeSpecific);
                $rule['bymonth']    = 0;// @TODO: month from FirstDateTime
            }
            else if ($result['freq'] = 'YEARLY-NTH') {
                $result['freq']      = 'YEARLY';
                $result['interval'] /= 12;
                $result['byday']     = self::bitmask2day($rp->PatternTypeSpecific[0]);
                $result['bymonth']   = 0;// @TODO: month from FirstDateTime

                if ($rp->PatternTypeSpecific[1]) {
                    $result['bysetpos'] = intval($rp->PatternTypeSpecific[1] == 0x00000005 ? -1 : $rp->PatternTypeSpecific[1]);
                }
            }
        }

        if ($rp->EndType == kolab_api_filter_mapistore_structure_recurrencepattern::ENDTYPE_AFTER) {
            // @TODO: set UNTIL to EndDate + StartTimeOffset, or the midnight of EndDate
        }
        else if ($rp->EndType == kolab_api_filter_mapistore_structure_recurrencepattern::ENDTYPE_NOCC) {
            $result['count'] = $rp->OccurrenceCount;
        }

        if ($result['interval'] == 1) {
            unset($result['interval']);
        }

        $object['rrule']['recur'] = $result;
        $object['exdate']         = array();
        $object['rdate']          = array();

//        $exception_info     = (array) $rp->ExceptionInfo;
//        $extended_exception = (array) $rp->ExtendedException;
        $modified_dates     = (array) $rp->ModifiedInstanceDates;
        $deleted_dates      = (array) $rp->DeletedInstanceDates;

        // Deleted/Modified exceptions (EXDATE/RDATE)
        foreach ($deleted_dates as $date) {
            $idx = in_array($date, $modified_dates) ? 'rdate' : 'exdate';
            $dt  = self::date_minutes2php($date);

            if ($dt) {
                $object[$idx]['date'][] = $dt->format('Y-m-d');
            }
        }
    }

    /**
     * Convert Kolab exception specification into MAPI exception
     *
     * @param array $exception Kolab event exception data
     * @param array $event     Kolab event data
     * @param array $object    Main event data (MAPI format)
     *
     * @return array Contains exceptioninfo and extendedexception structures
     */
    protected function exception_from_kolab($exception, $event, &$object)
    {
        if ($this->model != 'event') {
            throw new Exception("Exceptions are not supported on {$this->model} objects.");
        }

        $ex = $this->output($exception);

        // exception_info [MS-OXCICAL] 2.1.3.1.1.20.18 (page 61)
        $map = array(
            'Subject'       => 'PidTagSubject',
            'ReminderDelta' => 'PidLidReminderDelta',
            'ReminderSet'   => 'PidLidReminderSet',
            'Location'      => 'PidLidLocation',
            'BusyStatus'    => 'PidLidBusyStatus',
            'SubType'       => 'PidLidAppointmentSubType',
            // 'AppointmentColor', 'Attachment', 'MeetingType'
        );

        // OriginalStartDate is a date-time at which the instance would have occured
        // if it were not an exception (in event timezone)

        $exception_date = kolab_api_input_json::to_datetime($exception['recurrence-id']);
        if (!$exception_date) {
            throw new Exception("Recurrence exception with no date?. Skipping.");
        }

        $event_start   = kolab_api_input_json::to_datetime($event['dtstart']);
        $orig_start_dt = clone $event_start;
        $orig_start_dt->setDate($exception_date->format('Y'), $exception_date->format('n'), $exception_date->format('j'));

        if (!empty($exception['dtstart'])) {
            $start_dt = kolab_api_input_json::to_datetime($exception['dtstart']);
        }
        else {
            $start_dt = $orig_start_dt;
        }

        if (!empty($exception['dtend'])) {
            $end_dt = kolab_api_input_json::to_datetime($exception['dtend']);
            // for all-day events dtstart == dtend, move dtend to the next day
            if ($end_dt <= $start_dt) {
                $end_dt->add(new DateInterval("PT24H"));
            }
        }
        else if ($minutes = $object['PidLidAppointmentDuration']) {
            $end_dt = clone $start_dt;
            $end_dt->add(new DateInterval("PT{$minutes}M"));
        }

        $exception_info = array(
            'StartDateTime'     => $this->date_php2minutes($start_dt),
            'EndDateTime'       => $this->date_php2minutes($end_dt),
            'OriginalStartDate' => $this->date_php2minutes($orig_start_dt),
        );

        $extended_exception = array(
            // @TODO: set ChangeHighligh appropriately
            'ChangeHighlight' => new kolab_api_filter_mapistore_structure_changehighlight(),
        );

        foreach ($map as $key => $prop) {
            if (isset($ex[$prop]) && $ex[$prop] != $object[$prop]) {
                $exception_info[$key] = $ex[$prop];

                if ($key == 'Location' || $key == 'Subject') {
                    $extended_exception["WideChar$key"] = $ex[$prop];
                }
            }
        }

        // some properties are needed when subject or location changed
        if (count($extended_exception) > 1) {
            $extended_exception['StartDateTime']     = $exception_info['StartDateTime'];
            $extended_exception['EndDateTime']       = $exception_info['EndDateTime'];
            $extended_exception['OriginalStartDate'] = $exception_info['OriginalStartDate'];
        }

        $exception_info     = new kolab_api_filter_mapistore_structure_exceptioninfo($exception_info);
        $extended_exception = new kolab_api_filter_mapistore_structure_extendedexception($extended_exception);

        return array($exception_info, $extended_exception);
    }

    /**
     * Convert Kolab description property into MAPI body properties
     *
     * @param array  $data   Kolab object
     * @param array  $result Object data (MAPI format)
     * @param string $field  Kolab object property name
     * @param string $force  Force output format (plain|html)
     */
    protected function body_from_kolab($data, &$result, $field = 'description', $force = null)
    {
        $text = $data[$field];

        if (self::is_html($text)) {
            // some objects does not support HTML e.g. notes
            if ($force == 'plain') {
                $h2t = new rcube_html2text($text, false, false, 0);
                $result['PidTagBody'] = trim($h2t->get_text());
            }
            else {
                $result['PidTagHtml'] = $text;
            }
        }
        else if ($text) {
            $result['PidTagBody'] = $text;
        }
    }

    /**
     * Convert MAPI body properties into Kolab
     *
     * @param string $data   MAPI object
     * @param array  $result Kolab object
     * @param string $field  Kolab object property name
     * @param string $force  Force output format (plain|html)
     */
    protected function body_to_kolab($data, &$result, $field = 'description', $force = null)
    {
        // Kolab supports HTML and plain text but not RTF

        if (array_key_exists('PidTagRtfCompressed', $data)) {
            require_once 'rtf.php';

            $rtf  = new rtf(base64_decode($data['PidTagRtfCompressed']));
            $text = $rtf->parse($force ?: 'html');
        }
        else if (array_key_exists('PidTagHtml', $data)) {
            $text = $data['PidTagHtml'];
            // some objects does not support HTML e.g. contacts
            if ($force == 'plain') {
                $h2t  = new rcube_html2text($text, false, false, 0);
                $text = trim($h2t->get_text());
            }
        }
        else if (array_key_exists('PidTagBody', $data)) {
            $text = $data['PidTagBody'];
        }

        if (isset($text)) {
            $result[$field] = $text;
        }
    }

    /**
     * Returns number of minutes between midnight 1601-01-01
     * and specified UTC DateTime
     */
    public static function date_php2minutes($date)
    {
        $start = new DateTime('1601-01-01 00:00:00 UTC');

        // make sure the specified date is in UTC
        $date->setTimezone(new DateTimeZone('UTC'));

        return (int) round(($date->getTimestamp() - $start->getTimestamp()) / 60);
    }

    /**
     * Convert number of minutes between midnight 1601-01-01 (UTC) into PHP DateTime
     *
     * @return DateTime|bool DateTime object or False on failure
     */
    public static function date_minutes2php($minutes)
    {
        $datetime = new DateTime('1601-01-01 00:00:00 UTC');
        $interval = new DateInterval(sprintf('PT%dM', $minutes));

        return $datetime->add($interval);
    }

    /**
     * Convert DateTime object to MAPI date format
     */
    public static function date_php2mapi($date, $utc = true, $time = null)
    {
        // convert string to DateTime
        if (!is_object($date) && !empty($date)) {
            // convert date to datetime on 00:00:00
            if (preg_match('/^([0-9]{4})-?([0-9]{2})-?([0-9]{2})$/', $date, $m)) {
                $date = $m[1] . '-' . $m[2] . '-' . $m[3] . 'T00:00:00+00:00';
            }

            $date = new DateTime($date);
        }
        else if (is_object($date)) {
            if ($utc) {
                // clone the date object if we're going to change timezone
                $date = clone $date;
            }
        }
        else {
            return;
        }

        if ($utc) {
            $date->setTimezone(new DateTimeZone('UTC'));
        }

        if (!empty($time)) {
            $date->setTime((int) $time['hour'], (int) $time['minute'], (int) $time['second']);
        }

        // MAPI PTypTime is 64-bit integer representing the number
        // of 100-nanosecond intervals since January 1, 1601.
        // Mapistore format for this type is a float number

        // However, it looks like Mapistore uses unix timestamps (i.e. 1970-01-01 is a base)
        // which means we can't set e.g. birthday dates before 1970 ?!

        // seconds since 1601-01-01 00:00:00
        $seconds = floatval($date->format('U')) + 11644473600;
/*
        if ($microseconds = intval($date->format('u'))) {
            $seconds += $microseconds/1000000;
        }
*/
        return $seconds;
    }

    /**
     * Convert date-time from MAPI format to DateTime
     */
    public static function date_mapi2php($date)
    {
        $seconds = floatval(sprintf('%.0f', $date));

        // assumes we're working with dates after 1970-01-01
        $dt = new DateTime('@' . intval($seconds - 11644473600), new DateTimeZone('UTC'));
/*
        if ($microseconds = intval(($date - $seconds) * 1000000)) {
            $dt = new DateTime($dt->format('Y-m-d H:i:s') . '.' . $microseconds, $dt->getTimezone());
        }
*/
        return $dt;
    }

    /**
     * Setting PidTagRecipientType according to [MS-OXCICAL 2.1.3.1.1.20.2]
     */
    protected function to_recipient_type($cutype, $role)
    {
        if ($cutype && in_array($cutype, array('RESOURCE', 'ROOM'))) {
            return 0x00000003;
        }

        if ($role && ($type = $this->recipient_type_map[$role])) {
            return $type;
        }

        return 0x00000001;
    }

    /**
     * Converts string of days (TU,TH) to bitmask used by MAPI
     *
     * @param string $days
     *
     * @return int
     */
    protected static function day2bitmask($days, $prefix = '')
    {
        $days   = explode(',', $days);
        $result = 0;

        foreach ($days as $day) {
            $result = $result + self::$recurrence_day_map[$prefix.$day];
        }

        return $result;
    }

    /**
     * Convert bitmask used by MAPI to string of days (TU,TH)
     *
     * @param int $days
     *
     * @return string
     */
    protected static function bitmask2day($days)
    {
        $days_arr = array();

        foreach (self::$recurrence_day_map as $day => $bit) {
            if (($days & $bit) === $bit) {
                $days_arr[] = preg_replace('/^BYDAY-/', '', $day);
            }
        }

        $result = implode(',', $days_arr);

        return $result;
    }

    /**
     * Determine whether the given event description is HTML formatted
     */
    protected static function is_html($text)
    {
        // check for opening and closing <html> or <body> tags
        return preg_match('/<(html|body)(\s+[a-z]|>)/', $text, $m) && strpos($text, '</' . $m[1] . '>') > 0;
    }
}
