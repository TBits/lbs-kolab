<?php

/**
 +--------------------------------------------------------------------------+
 | This file is part of the Kolab REST API                                  |
 |                                                                          |
 | Copyright (C) 2012-2015, Kolab Systems AG                                |
 |                                                                          |
 | This program is free software: you can redistribute it and/or modify     |
 | it under the terms of the GNU Affero General Public License as published |
 | by the Free Software Foundation, either version 3 of the License, or     |
 | (at your option) any later version.                                      |
 |                                                                          |
 | This program is distributed in the hope that it will be useful,          |
 | but WITHOUT ANY WARRANTY; without even the implied warranty of           |
 | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the             |
 | GNU Affero General Public License for more details.                      |
 |                                                                          |
 | You should have received a copy of the GNU Affero General Public License |
 | along with this program. If not, see <http://www.gnu.org/licenses/>      |
 +--------------------------------------------------------------------------+
 | Author: Aleksander Machniak <machniak@kolabsys.com>                      |
 +--------------------------------------------------------------------------+
*/

class kolab_api_filter_mapistore_attachment extends kolab_api_filter_mapistore_common
{
    protected $model = 'attachment';
    protected $map   = array(
        // attachment props [MS-OXCMSG]
        'PidTagLastModificationTime'    => '',                  // PtypTime
        'PidTagCreationTime'            => '',                  // PtypTime
        'PidTagDisplayName'             => 'filename',          // PtypString
        'PidTagAttachSize'              => 'size',              // PtypInteger32
        'PidTagAttachNumber'            => '',                  // PtypInteger32, @TODO: unique attachment index within a message
        'PidTagAttachDataBinary'        => '',                  // PtypBinary
        'PidTagAttachDataObject'        => 'data-object',       // PtypBinary
        'PidTagAttachMethod'            => '',                  // PtypInteger32
        'PidTagAttachLongFilename'      => 'filename',          // PtypString, filename with extension
        'PidTagAttachFilename'          => '',                  // PtypString, filename in 8.3 form
        'PidTagAttachExtension'         => '',                  // PtypString
        'PidTagAttachLongPathname'      => '',                  // PtypString
        'PidTagAttachPathname'          => '',                  // PtypString
        'PidTagAttachTag'               => '',                  // PtypBinary
        'PidTagRenderingPosition'       => '',                  // PtypInteger32
        'PidTagAttachRendering'         => '',                  // PtypBinary
        'PidTagAttachFlags'             => '',                  // PtypInteger32
        'PidTagAttachTransportName'     => '',                  // PtypString
        'PidTagAttachEncoding'          => '',                  // PtypBinary
        'PidTagAttachAdditionalInformation' => '',              // PtypBinary
        'PidTagAttachmentLinkId'        => '',                  // PtypInteger32
        'PidTagAttachmentFlags'         => 'attachment-flags',  // PtypInteger32
        'PidTagAttachmentHidden'        => 'is-hidden',         // PtypBoolean
        'PidTagTextAttachmentCharset'   => 'charset',           // PtypString
        // MIME props [MS-OXCMSG]
        'PidTagAttachMimeTag'                   => 'mimetype',          // PtypString
        'PidTagAttachContentId'                 => 'content-id',        // PtypString
        'PidTagAttachContentLocation'           => 'content-location',  // PtypString
        'PidTagAttachContentBase'               => '',                  // PtypString
        'PidTagAttachPayloadClass'              => '',                  // PtypString
        'PidTagAttachPayloadProviderGuidString' => '',                  // PtypString
        'PidNameAttachmentMacContentType'       => '',                  // PtypString
        'PidNameAttachmentMacInfo'              => '',                  // PtypBinary
        // Contact photo [MS-OXOCNTC]
        'PidTagAttachmentContactPhoto'      => 'is-photo',          // PtypBoolean
        // Event exceptions [MS-OXOCAL]
        'PidTagExceptionStartTime'          => 'start-time',        // PtypTime
        'PidTagExceptionEndTime'            => 'end-time',          // PtypTime
        'PidTagExceptionReplaceTime'        => 'replace-time',      // PtypTime
    );

    /**
     * Methods for PidTagAttachMethod
     */
    protected $methods = array(
        'afNone'            => 0x00000001,
        'afByValue'         => 0x00000001,
        'afByReference'     => 0x00000002,
        'afByReferenceOnly' => 0x00000004,
        'afEmbeddedMessage' => 0x00000005,
        'afStorage'         => 0x00000006,
    );

    /**
     * Flags for PidTagAttachFlags
     */
    protected $flags = array(
        'attInvisibleInHtml' => 0x00000001,
        'attInvisibleInRtf'  => 0x00000002,
        'attRenderedInBody'  => 0x00000004,
    );


    /**
     * Convert Kolab to MAPI
     *
     * @param array Data
     * @param array Context (folder_uid, object_uid, object)
     *
     * @return array Data
     */
    public function output($data, $context = null)
    {
        $result = array(
            // mapistore REST API specific properties
            'collection' => 'attachments',
        );

        // @TODO: Set PidTagAccessLevel depending if a message is in Drafts or not
        // or the attachment belongs to a kolab object in writeable folder?

        foreach ($this->map as $mapi_idx => $kolab_idx) {
            if (empty($kolab_idx)) {
                continue;
            }

            $value = $this->get_kolab_value($data, $kolab_idx);

            if ($value === null) {
                continue;
            }

            $result[$mapi_idx] = $value;
        }

        if (($pos = strrpos($data['filename'], '.')) !== false) {
            $result['PidTagAttachExtension'] = substr($data['filename'], $pos);
        }

        // Store attachment body in base64
        // @TODO: shouldn't we do this only in attachment.info request?
        if ($data['content']) {
            $result['PidTagAttachDataBinary'] = base64_encode($data['content']);
        }
        else if (empty($result['PidTagAttachDataObject'])) {
            $result['PidTagAttachDataBinary'] = $this->attachment_body($context['object'], $data, true);
        }

        if ($result['PidTagAttachDataObject']) {
            $result['PidTagAttachMethod'] = $this->methods['afEmbeddedMessage'];
        }
        else if (!isset($result['PidTagAttachMethod'])) {
            $result['PidTagAttachMethod'] = $this->methods['afByValue'];
        }

        $this->parse_common_props($result, $data, $context);

        $result['id'] = kolab_api_filter_mapistore::uid_encode($context['folder_uid'], $context['object_uid'], $data['id']);

        return $result;
    }

    /**
     * Convert from MAPI to Kolab
     *
     * @param array Data
     * @param array Data of the object that is being updated
     *
     * @return array Data
     */
    public function input($data, $object = null)
    {
        $result = array();

        foreach ($this->map as $mapi_idx => $kolab_idx) {
            if (empty($kolab_idx)) {
                continue;
            }

            if (!array_key_exists($mapi_idx, $data)) {
                continue;
            }

            $value = $data[$mapi_idx];

            $result[$kolab_idx] = $value;
        }

        if ($data['PidTagAttachDataBinary']) {
            $stream = base64_decode($data['PidTagAttachDataBinary']);
            $result['upload-id'] = $sess_key = 'MAPIATTACH';
            $_SESSION['uploads'][$sess_key] = array(
                'group'    => 'kolab_upload',
                'name'     => $data['PidTagDisplayName'],
                'mimetype' => rcube_mime::file_content_type($stream, $data['PidTagDisplayName'], 'application/octet-stream', true),
                'data'     => $stream,
                'size'     => strlen($stream),
            );
        }

        return $result;
    }

    /**
     * Returns the attributes names mapping
     */
    public function map()
    {
        $map = array_filter($this->map);

        $map['PidTagAttachExtension'] = 'filename';
        $map['id']                    = 'id';

        return $map;
    }

    /**
     * Get attachment body
     */
    protected function attachment_body($object, $attachment, $encoded = false)
    {
        if (empty($object)) {
            return;
        }

        $api  = kolab_api::get_instance();
        $body = $api->backend->attachment_get($object, $attachment['id']);

        return $encoded ? base64_encode($body) : $body;
    }
}
