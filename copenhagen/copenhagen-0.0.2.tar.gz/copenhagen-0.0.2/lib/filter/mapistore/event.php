<?php

/**
 +--------------------------------------------------------------------------+
 | This file is part of the Kolab REST API                                  |
 |                                                                          |
 | Copyright (C) 2012-2015, Kolab Systems AG                                |
 |                                                                          |
 | This program is free software: you can redistribute it and/or modify     |
 | it under the terms of the GNU Affero General Public License as published |
 | by the Free Software Foundation, either version 3 of the License, or     |
 | (at your option) any later version.                                      |
 |                                                                          |
 | This program is distributed in the hope that it will be useful,          |
 | but WITHOUT ANY WARRANTY; without even the implied warranty of           |
 | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the             |
 | GNU Affero General Public License for more details.                      |
 |                                                                          |
 | You should have received a copy of the GNU Affero General Public License |
 | along with this program. If not, see <http://www.gnu.org/licenses/>      |
 +--------------------------------------------------------------------------+
 | Author: Aleksander Machniak <machniak@kolabsys.com>                      |
 +--------------------------------------------------------------------------+
*/

class kolab_api_filter_mapistore_event extends kolab_api_filter_mapistore_common
{
    const EXCEPTION_CLASS = 'IPM.OLE.CLASS.{00061055-0000-0000-C000-000000000046}';

    protected $model = 'event';
    protected $map   = array(
        // common properties [MS-OXOCAL]
        'PidLidAppointmentSequence'         => 'sequence',      // PtypInteger32
        'PidLidBusyStatus'                  => '',              // PtypInteger32, @TODO: X-MICROSOFT-CDO-BUSYSTATUS
        'PidLidAppointmentAuxiliaryFlags'   => '',              // PtypInteger32
        'PidLidLocation'                    => 'location',      // PtypString
        'PidLidAppointmentStartWhole'       => 'dtstart',       // PtypTime, UTC
        'PidLidAppointmentEndWhole'         => 'dtend',         // PtypTime, UTC
        'PidLidAppointmentDuration'         => '',              // PtypInteger32, optional
        'PidLidAppointmentSubType'          => '',              // PtypBoolean
        'PidLidAppointmentStateFlags'       => '',              // PtypInteger32
        'PidLidResponseStatus'              => '',              // PtypInteger32
        'PidLidRecurring'                   => '',              // PtypBoolean
        'PidLidIsRecurring'                 => '',              // PtypBoolean
        'PidLidClipStart'                   => '',              // PtypTime
        'PidLidClipEnd'                     => '',              // PtypTime
        'PidLidAllAttendeesString'          => '',              // PtypString
        'PidLidToAttendeesString'           => '',              // PtypString
        'PidLidCCAttendeesString'           => '',              // PtypString
        'PidLidNonSendableTo'               => '',              // PtypString
        'PidLidNonSendableCc'               => '',              // PtypString
        'PidLidNonSendableBcc'              => '',              // PtypString
        'PidLidNonSendToTrackStatus'        => '',              // PtypMultipleInteger32
        'PidLidNonSendCcTrackStatus'        => '',              // PtypMultipleInteger32
        'PidLidNonSendBccTrackStatus'       => '',              // PtypMultipleInteger32
        'PidLidAppointmentUnsendableRecipients' => '',          // PtypBinary, optional
        'PidLidAppointmentNotAllowPropose'  => '',              // PtypBoolean, @TODO: X-MICROSOFT-CDO-DISALLOW-COUNTER
        'PidLidGlobalObjectId'              => '',              // PtypBinary
        'PidLidCleanGlobalObjectId'         => '',              // PtypBinary
        'PidTagOwnerAppointmentId'          => '',              // PtypInteger32, @TODO: X-MICROSOFT-CDO-OWNERAPPTID
        'PidTagStartDate'                   => '',              // PtypTime
        'PidTagEndDate'                     => '',              // PtypTime
        'PidLidCommonStart'                 => '',              // PtypTime
        'PidLidCommonEnd'                   => '',              // PtypTime
        'PidLidOwnerCriticalChange'         => '',              // PtypTime, @TODO: X-MICROSOFT-CDO-CRITICAL-CHANGE
        'PidLidIsException'                 => '',              // PtypBoolean
        'PidTagResponseRequested'           => '',              // PtypBoolean
        'PidTagReplyRequested'              => '',              // PtypBoolean
        'PidLidTimeZoneStruct'              => '',              // PtypBinary
        'PidLidTimeZoneDescription'         => '',              // PtypString
        'PidLidAppointmentTimeZoneDefinitionRecur'          => '',  // PtypBinary
        'PidLidAppointmentTimeZoneDefinitionStartDisplay'   => '',  // PtypBinary
        'PidLidAppointmentTimeZoneDefinitionEndDisplay'     => '',  // PtypBinary
        'PidLidAppointmentRecur'            => '',              // PtypBinary
        'PidLidRecurrenceType'              => '',              // PtypInteger32
        'PidLidRecurrencePattern'           => '',              // PtypString
        'PidLidLinkedTaskItems'             => '',              // PtypMultipleBinary
        'PidLidMeetingWorkspaceUrl'         => '',              // PtypString
        'PidTagIconIndex'                   => '',              // PtypInteger32
        'PidLidAppointmentColor'            => '',              // PtypInteger32
        'PidLidAppointmentReplyTime'        => '', // @TODO: X-MICROSOFT-CDO-REPLYTIME
        'PidLidIntendedBusyStatus'          => '', // @TODO: X-MICROSOFT-CDO-INTENDEDSTATUS
        // calendar object properties [MS-OXOCAL]
        'PidTagMessageClass'        => '',
        'PidLidSideEffects'         => '',          // PtypInteger32
        'PidLidFExceptionAttendees' => '',          // PtypBoolean
        'PidLidClientIntent'        => '',          // PtypInteger32
        // common props [MS-OXCMSG]
        'PidTagSubject'             => 'summary',
        'PidTagBody'                => '',
        'PidTagHtml'                => '',
        'PidTagNativeBody'          => '',
        'PidTagBodyHtml'            => '',
        'PidTagRtfCompressed'       => '',
        'PidTagInternetCodepage'    => '',
        'PidTagContentId'           => '',
        'PidTagBodyContentLocation' => '',
        'PidTagImportance'          => 'priority',
        'PidTagSensitivity'         => 'class',
        'PidLidPrivate'             => '',
        'PidTagHasAttachments'      => 'attach',
        'PidTagCreationTime'        => 'created',
        'PidTagLastModificationTime' => 'dtstamp',
        // reminder properties [MS-OXORMDR]
        'PidLidReminderSet'         => '',          // PtypBoolean
        'PidLidReminderSignalTime'  => '',          // PtypTime
        'PidLidReminderDelta'       => '',          // PtypInteger32
        'PidLidReminderTime'        => '',          // PtypTime
        'PidLidReminderOverride'    => '',          // PtypBoolean
        'PidLidReminderPlaySound'   => '',          // PtypBoolean
        'PidLidReminderFileParameter' => '',        // PtypString
        'PidTagReplyTime'           => '',          // PtypTime
        'PidLidReminderType'        => '',          // PtypInteger32
    );

    /**
     * Message importance for PidTagImportance as defined in [MS-OXCMSG]
     */
    protected $importance = array(
        0 => 0x00000000,
        1 => 0x00000002,
        2 => 0x00000002,
        3 => 0x00000002,
        4 => 0x00000002,
        5 => 0x00000001,
        6 => 0x00000000,
        7 => 0x00000000,
        8 => 0x00000000,
        9 => 0x00000000,
    );

    /**
     * Message sesnitivity for PidTagSensitivity as defined in [MS-OXCMSG]
     */
    protected $sensitivity = array(
        'public'       => 0x00000000,
        'personal'     => 0x00000001,
        'private'      => 0x00000002,
        'confidential' => 0x00000003,
    );


    /**
     * Convert Kolab to MAPI
     *
     * @param array Data
     * @param array Context (folder_uid, object_uid, object)
     *
     * @return array Data
     */
    public function output($data, $context = null)
    {
        $result = array(
            'PidTagMessageClass' => !empty($data['recurrence-id']) ? self::EXCEPTION_CLASS : 'IPM.Appointment',
            // mapistore REST API specific properties
            'collection' => 'calendars',
        );

        foreach ($this->map as $mapi_idx => $kolab_idx) {
            if (empty($kolab_idx)) {
                continue;
            }

            $value = $this->get_kolab_value($data, $kolab_idx);

            if ($value === null) {
                continue;
            }

            switch ($mapi_idx) {
            case 'PidTagSensitivity':
                $value = (int) $this->sensitivity[strtolower($value)];
                break;

            case 'PidTagCreationTime':
            case 'PidTagLastModificationTime':
                $value = $this->date_php2mapi($value, true);
                break;

            case 'PidTagImportance':
                $value = (int) $this->importance[(int) $value];
                break;

            case 'PidLidAppointmentStartWhole':
            case 'PidLidAppointmentEndWhole':
                $dt    = kolab_api_input_json::to_datetime($value);
                $value = $this->date_php2mapi($dt, true);

                // this is all-day event
                if ($dt->_dateonly) {
                    $result['PidLidAppointmentSubType'] = 0x00000001;
                }
                else if (empty($data['rrule']) && $dt->getTimezone()->getName() != 'UTC') {
                    $idx = sprintf('PidLidAppointmentTimeZoneDefinition%sDisplay',
                        strpos($mapi_idx, 'Start') ? 'Start' : 'End');

                    $result[$idx] = $this->timezone_definition($dt);
                }

                break;

            case 'PidTagHasAttachments':
                $value = !empty($value);
                break;
            }

            $result[$mapi_idx] = $value;
        }

        // event description
        $this->body_from_kolab($data, $result);

        // fix end date-time of all-day event
        if ($result['PidLidAppointmentSubType'] && $result['PidLidAppointmentStartWhole']
            && $result['PidLidAppointmentStartWhole'] == $result['PidLidAppointmentEndWhole']
        ) {
            $result['PidLidAppointmentEndWhole'] += 24 * 60 * 60;
        }

        // Organizer
        if (!empty($data['organizer'])) {
            $this->attendee_to_recipient($data['organizer'], $result, true);
        }

        // Attendees [MS-OXCICAL 2.1.3.1.1.20.2]
        foreach ((array) $data['attendee'] as $attendee) {
            $this->attendee_to_recipient($attendee, $result);
        }

        // PidLidAppointmentDuration
        if ($result['PidLidAppointmentStartWhole'] && $result['PidLidAppointmentEndWhole']) {
            $result['PidLidAppointmentDuration'] = (int) round(($result['PidLidAppointmentEndWhole'] - $result['PidLidAppointmentStartWhole']) / 60);
        }
        else if ($result['PidLidAppointmentStartWhole'] && $data['duration']) {
            try {
                $interval = new DateInterval($data['duration']);
                $duration = min(24 * 60, $interval->i + $interval->h * 60 + $interval->d * 24 * 60);

                $result['PidLidAppointmentDuration'] = $duration;
                $result['PidLidAppointmentEndWhole'] = $result['PidLidAppointmentStartWhole'] + $duration * 60;
            }
            catch (Exception $e) {
                rcube::raise_error($e, true, false);
            }
        }

        // @TODO: resources?

        // Recurrence
        if ($this->recurrence_from_kolab($data, $result)) {
            if ($dt && $dt->getTimezone()->getName() != 'UTC') {
                $result['PidLidTimeZoneStruct']      = $this->timezone_structure($dt);
                $result['PidLidTimeZoneDescription'] = $this->timezone_description($dt);
            }
        }

        // Alarms (MAPI supports only one)
        $this->alarm_from_kolab($data, $result);

        $this->parse_common_props($result, $data, $context);

        return $result;
    }

    /**
     * Convert from MAPI to Kolab
     *
     * @param array Data
     * @param array Data of the object that is being updated
     *
     * @return array Data
     */
    public function input($data, $object = null)
    {
        $result = array();

        if ($data['PidLidTimeZoneStruct']) {
            $timezone = $this->timezone_structure_to_tzname($data['PidLidTimeZoneStruct']);
        }

        foreach ($this->map as $mapi_idx => $kolab_idx) {
            if (empty($kolab_idx)) {
                continue;
            }

            if (!array_key_exists($mapi_idx, $data)) {
                continue;
            }

            $value = $data[$mapi_idx];

            switch ($mapi_idx) {
            case 'PidTagImportance':
                $map = array(
                    0x00000002 => 1,
                    0x00000001 => 5,
                    0x00000000 => 9,
                );

                $value = (int) $map[(int) $value];
                break;

            case 'PidTagSensitivity':
                $map   = array_flip($this->sensitivity);
                $value = $map[$value];
                break;

            case 'PidTagCreationTime':
            case 'PidTagLastModificationTime':
                if ($value) {
                    $value = $this->date_mapi2php($value);
                    $value = $value->format('Y-m-d\TH:i:s\Z');
                }
                break;

            case 'PidLidAppointmentStartWhole':
            case 'PidLidAppointmentEndWhole':
                if ($value) {
                    $datetime = $this->date_mapi2php($value);
                    $datetime->_dateonly = !empty($data['PidLidAppointmentSubType']);

                    $tz_idx = sprintf('PidLidAppointmentTimeZoneDefinition%sDisplay',
                        strpos($mapi_idx, 'Start') ? 'Start' : 'End');

                    if ($data[$tz_idx]) {
                        $tz = $this->timezone_definition_to_tzname($data[$tz_idx]);
                    }
                    else {
                        $tz = $timezone;
                    }

                    $value = kolab_api_input_json::from_datetime($datetime, $tz);
                }
                break;
            }

            $result[$kolab_idx] = $value;
        }

        // event description
        $this->body_to_kolab($data, $result);

        // Recurrence
        if (array_key_exists('PidLidAppointmentRecur', $data)) {
            $this->recurrence_to_kolab($data['PidLidAppointmentRecur'], $result);
        }

        // Alarms (MAPI supports only one, DISPLAY)
        $this->alarm_to_kolab($data, $result);

        if (array_key_exists('recipients', $data)) {
            $result['attendee']  = array();
            $result['organizer'] = array();

            foreach ((array) $data['recipients'] as $recipient) {
                $this->recipient_to_attendee($recipient, $result);
            }
        }

        // @TODO: exception, resources

        $this->convert_common_props($result, $data, $object);

        return $result;
    }

    /**
     * Returns the attributes names mapping
     */
    public function map()
    {
        $map = array_filter($this->map);

        // @TODO: add properties that are not in the map
        $map['PidLidAppointmentRecur'] = 'rrule';
        $map['PidTagBody']             = 'description';

        return $map;
    }

    /**
     * Generate PidLidTimeZoneDescription string for a timezone
     * specified in a DateTime object
     */
    protected static function timezone_description($datetime)
    {
        $timezone    = $datetime->getTimezone();
        $location    = $timezone->getLocation();
        $description = $location['comments'];
        $offset      = $timezone->getOffset($datetime);

        // some location descriptions are useful, but some are not really
        // replace with timezone name in such cases
        if (!$description || strpos($description, 'location') !== false) {
            $description = $timezone->getName();
        }

        if ($description == 'Z') {
            $description = 'UTC';
        }

        // convert seconds into hours offset format
        $hours   = round(abs($offset)/3600);
        $minutes = round((abs($offset) - $hours * 3600) / 60);
        $offset  = sprintf('%s%02d:%02d', $offset < 0 ? '-' : '+', $hours, $minutes);

        return sprintf('(GMT%s) %s', $offset, $description);
    }

    /**
     * Generate PidLidTimeZoneDefinitionRecur blob for a timezone
     * specified in a DateTime object
     */
    protected static function timezone_definition($datetime)
    {
        $timezone = $datetime->getTimezone();
        $tzrule   = kolab_api_filter_mapistore_structure_tzrule::from_datetime($datetime);
        $tzrule->Flags = kolab_api_filter_mapistore_structure_tzrule::FLAG_EFFECTIVE; // @FIXME

        $tzdef = new kolab_api_filter_mapistore_structure_timezonedefinition(array(
                'TZRules' => array($tzrule),
                'KeyName' => $timezone->getName(),
        ));

        return $tzdef->output(true);
    }

    /**
     * Generate PidLidTimeZoneStruct blob for a timezone
     * specified in a DateTime object
     */
    protected static function timezone_structure($datetime)
    {
        $tzs = kolab_api_filter_mapistore_structure_timezonestruct::from_datetime($datetime, true);
        return $tzs->output(true);
    }

    /**
     * Parse PidLidTimeZoneStruct blob and convert to timezone name
     */
    protected static function timezone_structure_to_tzname($data)
    {
        $api = kolab_api::get_instance();
        $tzs = new kolab_api_filter_mapistore_structure_timezonestruct;
        $tzs->input($data, true);

        return $tzs->to_tzname($api->config->get('timezone'));
    }

    /**
     * Parse PidLidTimeZoneDefinitionRecur blob and convert to timezone name
     */
    protected static function timezone_definition_to_tzname($data)
    {
        $api   = kolab_api::get_instance();
        $tzdef = new kolab_api_filter_mapistore_structure_timezonedefinition;
        $tzdef->input($data, true);

        // Note: we ignore KeyName as it most likely will not contain Olson TZ name

        foreach ($tzdef->TZRules as $tzrule) {
            if ($tzname = $tzrule->to_tzname($api->config->get('timezone'))) {
                return $tzname;
            }
        }
    }

    /**
     * Return attachments for event exceptions
     *
     * @param array $event Event object data (API format)
     *
     * @return array Attachments list
     */
    public function exception_attachments($event)
    {
        $attachments = array();

        foreach ((array) $event['exceptions'] as $exception) {
            $rid = kolab_api_input_json::to_datetime($exception['recurrence-id']);
            if (!$rid) {
                // sanity check
                continue;
            }

            // @TODO: the object should be of type PtypObject encoded in a way
            // described in https://msdn.microsoft.com/en-us/library/ee218131%28v=exchg.80%29.aspx
            // Would be nice if Openchange would generate the blob on their side
            $object = $this->output($exception);

            // remove internal properties
            unset($object['collection']);

            $start_time = $end_time = null;

            if (!empty($exception['dtstart'])) {
                $dt = kolab_api_input_json::to_datetime($exception['dtstart']);
                $start_time = $this->date_php2mapi($dt, false);
            }

            if (!empty($exception['dtend'])) {
                $dt = kolab_api_input_json::to_datetime($exception['dtend']);
                $end_time = $this->date_php2mapi($dt, false);

                if ($end_time == $start_time) {
                    $end_time += 24 * 60 * 60;
                }
            }

            // "replace-time" is a date-time at which the instance would have occured
            // if it were not an exception (in UTC)
            $dtstart = kolab_api_input_json::to_datetime($event['dtstart']);
            $dtstart->setDate($rid->format('Y'), $rid->format('n'), $rid->format('j'));
            $replace_time = $this->date_php2mapi($dtstart, true);

            $attachments[] = array(
                'id'           => self::recurrence_id($rid, $event['dtstart']),
                'filename'     => $object['PidTagSubject'] ?: $event['summary'],
                'data-object'  => $object,
                'start-time'   => $start_time,
                'end-time'     => $end_time,
                'replace-time' => $replace_time,
                // properties required for exception attachments
                'is-hidden'          => true,
                'rendering-position' => 0xFFFFFFFF,
                'attachment-flags'   => 0x00000002,
            );
        }

        return $attachments;
    }

    /**
     * Generate recurrence-id identifier for exception attachment
     *
     * @param DateTime              Recurrence date (recurrence-id)
     * @param DateTime|array|string Event start date-time
     *
     * @return int Attachment identifier
     */
    public static function recurrence_id($date, $start_date)
    {
        if (!$start_date instanceof DateTime) {
            $start_date = kolab_api_input_json::to_datetime($start_date);
        }

        return $date->format($start_date->_dateonly ? 'Ymd' : 'YmdHi');
    }
}
