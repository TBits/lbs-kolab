<?php

/**
 +--------------------------------------------------------------------------+
 | This file is part of the Kolab REST API                                  |
 |                                                                          |
 | Copyright (C) 2012-2015, Kolab Systems AG                                |
 |                                                                          |
 | This program is free software: you can redistribute it and/or modify     |
 | it under the terms of the GNU Affero General Public License as published |
 | by the Free Software Foundation, either version 3 of the License, or     |
 | (at your option) any later version.                                      |
 |                                                                          |
 | This program is distributed in the hope that it will be useful,          |
 | but WITHOUT ANY WARRANTY; without even the implied warranty of           |
 | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the             |
 | GNU Affero General Public License for more details.                      |
 |                                                                          |
 | You should have received a copy of the GNU Affero General Public License |
 | along with this program. If not, see <http://www.gnu.org/licenses/>      |
 +--------------------------------------------------------------------------+
 | Author: Aleksander Machniak <machniak@kolabsys.com>                      |
 +--------------------------------------------------------------------------+
*/

class kolab_api_filter_mapistore_folder extends kolab_api_filter_mapistore_common
{
    const TYPE_ROOT    = 0;
    const TYPE_GENERIC = 1;
    const TYPE_SEARCH  = 2;

    const FOLDER_ROOT         = 0;
    const FOLDER_MSGROOT      = 1;

    const FOLDER_INBOX        = 10;
    const FOLDER_OUTBOX       = 11;
    const FOLDER_DRAFTS       = 12;
    const FOLDER_SENT         = 13;
    const FOLDER_DELETED_ITEMS = 14;
    const FOLDER_CONTACTS     = 15;
    const FOLDER_CALENDAR     = 16;
    const FOLDER_TASKS        = 17;
    const FOLDER_NOTES        = 18;
    const FOLDER_JOURNAL      = 19;
//    const FOLDER_FALLBACK     = -1;

    const FOLDER_DEFERRED     = 101;
    const FOLDER_SPOOLER      = 102;
    const FOLDER_COMMON_VIEWS = 103;
    const FOLDER_SCHEDULE     = 104;
    const FOLDER_FINDER       = 105;
    const FOLDER_VIEW         = 106;
    const FOLDER_SHORTCUTS    = 107;

    protected $model = 'folder';
    protected $map   = array(
        // [MS-OXCFOLD] read-only properties
        'PidTagAccess'                => '',
        'PidTagChangeKey'             => '',
        'PidTagCreationTime'          => 'uidvalidity',     // PtypTime
        'PidTagLastModificationTime'  => '',                // PtypTime
        'PidTagContentCount'          => 'exists',          // PtypInteger32
        'PidTagContentUnreadCount'    => 'unread',          // PtypInteger32
        'PidTagDeletedOn'             => '',                // PtypTime
//        'PidTagAddressbookEntryId'    => '',              // PtypBinary
        'PidTagFolderId'              => '',                // PtypInteger64
        'PidTagParentEntryId'         => '',                // PtypBinary
        'PidTagHierarchyChangeNumber' => '',                // PtypInteger32,
        'PidTagMessageSize'           => 'size',            // PtypInteger32, size of all messages
        'PidTagMessageSizeExtended'   => '',                // PtypInteger64
        'PidTagSubfolders'            => 'children',        // PtypBoolean
        'PidTagLocalCommitTime'       => '',                // PtypTime, last change time in UTC
        'PidTagLocalCommitTimeMax'    => '',                // PtypTime
        'PidTagDeletedCountTotal'     => 'deleted',         // PtypInteger32

        // read-write properties
        'PidTagAttributeHidden'       => '',                // PtypBoolean
        'PidTagComment'               => 'comment',         // PtypString, @TODO: store in folder annotation?
        'PidTagContainerClass'        => 'type',            // PtypString, IPF.*
        'PidTagContainerHierarchy'    => '',                // PtypObject
        'PidTagDisplayName'           => 'name',            // PtypString
        'PidTagFolderAssociatedContents' => '',             // PtypObject
        'PidTagFolderType'            => '', // PtypInteger32, 0 - namespace roots, 1 - other, 2 - virtual/search folders
        'PidTagRights'                => '',                // PtypInteger32
        'PidTagAccessControlListData' => '',                // PtypBinary, see [MS-OXCPERM]
    );

    protected $type_map = array(
        ''        => 'IPF.Note',
        'mail'    => 'IPF.Note',
        'task'    => 'IPF.Task',
        'note'    => 'IPF.StickyNote',
        'event'   => 'IPF.Appointment',
        'journal' => 'IPF.Journal',
        'contact' => 'IPF.Contact',
    );

    public static $builtin_folders = array(
        // Roots
        self::FOLDER_ROOT => array(
            'name'    => 'Root',
            'comment' => '/',
            'parent'  => -1,
            'hidden'  => false,
            'role'    => -1,
            'system_idx' => true,
        ),
        self::FOLDER_MSGROOT => array(
            'name'    => 'MsgRoot',
            'comment' => '/',
            'parent'  => -1,
            'hidden'  => false,
            'role'    => -1,
            'system_idx' => true,
        ),
        // IPM subtree (and openchange "contexts")
        self::FOLDER_INBOX => array(
            'name'   => 'INBOX',
            'parent' => self::FOLDER_MSGROOT,
            'role'   => 0,
            'type'   => 'mail.inbox',
        ),
        self::FOLDER_OUTBOX => array(
            'name'   => 'Outbox',
            'parent' => self::FOLDER_MSGROOT,
            'role'   => 3,
        ),
        self::FOLDER_DRAFTS => array(
            'name'   => 'Drafts',
            'parent' => self::FOLDER_MSGROOT,
            'role'   => 1,
            'type'   => 'mail.drafts',
        ),
        self::FOLDER_SENT => array(
            'name'   => 'Sent Items',
            'parent' => self::FOLDER_MSGROOT,
            'role'   => 2,
            'type'   => 'mail.sentitems',
        ),
        self::FOLDER_DELETED_ITEMS => array(
            'name'   => 'Deleted Items',
            'parent' => self::FOLDER_MSGROOT,
            'role'   => 4,
            'type'   => 'mail.wastebasket',
        ),
        self::FOLDER_CONTACTS => array(
            'name'   => 'Contacts',
            'parent' => self::FOLDER_MSGROOT,
            'role'   => 6,
            'type'   => 'contact.default',
        ),
        self::FOLDER_CALENDAR => array(
            'name'   => 'Calendar',
            'parent' => self::FOLDER_MSGROOT,
            'role'   => 5,
            'type'   => 'event.default',
        ),
        self::FOLDER_TASKS => array(
            'name'   => 'Tasks',
            'parent' => self::FOLDER_MSGROOT,
            'role'   => 7,
            'type'   => 'task.default',
        ),
        self::FOLDER_NOTES => array(
            'name'   => 'Notes',
            'parent' => self::FOLDER_MSGROOT,
            'role'   => 8,
            'type'   => 'note.default',
        ),
        self::FOLDER_JOURNAL => array(
            'name'   => 'Journal',
            'parent' => self::FOLDER_MSGROOT,
            'role'   => 9,
            'type'   => 'journal.default',
        ),

        // Non-IPM Subtree
        self::FOLDER_DEFERRED => array(
            'name'   => 'Deferred Action',
            'parent' => self::FOLDER_ROOT,
        ),
        self::FOLDER_SPOOLER => array(
            'name'   => 'Spooler Queue',
            'parent' => self::FOLDER_ROOT,
        ),
        self::FOLDER_COMMON_VIEWS => array(
            'name'   => 'Common Views',
            'parent' => self::FOLDER_ROOT,
        ),
        self::FOLDER_SCHEDULE => array(
            'name'   => 'Schedule',
            'parent' => self::FOLDER_ROOT,
        ),
        self::FOLDER_FINDER => array(
            'name'   => 'Finder',
            'parent' => self::FOLDER_ROOT,
        ),
        self::FOLDER_VIEW => array(
            'name'   => 'View',
            'parent' => self::FOLDER_ROOT,
        ),
        self::FOLDER_SHORTCUTS => array(
            'name'   => 'Shortcuts',
            'parent' => self::FOLDER_ROOT,
        ),
    );

    protected $table = 'copenhagen_folderdata';


    /**
     * Convert Kolab to MAPI
     *
     * @param array Data
     * @param array Context (folder_uid, object_uid, object)
     *
     * @return array Data
     */
    public function output($data, $context = null)
    {
        list($type, ) = explode('.', $data['type']);

        $type = $this->type_map[(string)$type];
        $api  = kolab_api::get_instance();

        // skip folders of unsupported type
        if (empty($type)) {
            return;
        }

        if (!isset($data['parent'])) {
            $data['parent'] = 1;
        }

        // skip folders that are not subfolders of the specified folder,
        // in list-mode MAPI always requests for one-level of the hierarchy (?)
        if ($api->input->path[1] == 'folders') {
            $parent = $api->input->path[0];

            if ($data['parent'] != $parent) {
                return;
            }
        }

        $result = array(
            // mapistore properties
            'id'                   => $data['uid'],
            'collection'           => 'folders',
            // MAPI properties
            'PidTagDisplayName'    => $data['name'],
            'PidTagContainerClass' => $type,
            // the property is required by OpenChange
            // @TODO: use ACL
            'PidTagRights' => 0x00000080 | 0x00000020 | 0x00000002,
        );

        if ($data['uid'] === 1 || $data['uid'] === 0) {
            $result['PidTagFolderType'] = self::TYPE_ROOT;
        }
        else {
            $result['PidTagFolderType'] = self::TYPE_GENERIC;
        }

        if (isset($data['parent'])) {
            $result['parent_id'] = $data['parent'];
        }

        if (isset($data['comment'])) {
            $result['PidTagComment'] = $data['comment'];
        }
        else {
            // it looks that the property always have to be set
            $result['PidTagComment'] = '';
        }

        // special Mapistore props
        foreach (array('role', 'system_idx', 'hidden') as $prop) {
            if (isset($data[$prop])) {
                $result[$prop] = $data[$prop];
            }
        }

        // set appropriate system_idx for special-folders
        if (!$result['system_idx']) {
            foreach (self::$builtin_folders as $idx => $fold) {
                if ($fold['type'] && $fold['type'] == $data['type']) {
                    $result['system_idx'] = $idx;
                }
            }
        }

        // If we're not in list mode we can return more properties
        $props = array(
            'PidTagCreationTime',
            'PidTagLastModificationTime',
            'PidTagContentCount',
            'PidTagContentUnreadCount',
            'PidTagMessageSize',
            'PidTagSubfolders',
            'PidTagDeletedCountTotal',
        );

        foreach ($props as $prop_name) {
            $key   = $this->map[$prop_name];
            $value = null;

            if (array_key_exists($key, $data)) {
                $value = $data[$key];
            }
            else if ($context['object']
                && (empty($api->filter->attrs_filter) || in_array($prop_name, $api->filter->attrs_filter))
            ) {
                $value = $context['object']->{$key};
            }

            if ($value === null) {
                continue;
            }

            switch ($prop_name) {
            case 'PidTagCreationTime':
                $value = $this->date_php2mapi('@' . $value, true);
                break;

            case 'PidTagLastModificationTime':
                // @TODO
                break;

            case 'PidTagContentCount':
            case 'PidTagContentUnreadCount':
            case 'PidTagMessageSize':
            case 'PidTagDeletedCountTotal':
                $value = (int) $value;
                break;

            case 'PidTagSubfolders':
                $value = $value > 0;
                break;
            }

            $result[$prop_name] = $value;
        }

        // If we're not in list mode we can return more properties
        if ($context['object']) {
            $folder_data = $this->get_folder_data($result['id']);
            if (!empty($folder_data)) {
                if (!empty($api->filter->attrs_filter)) {
                    $folder_data = array_intersect_key($folder_data, array_flip($api->filter->attrs_filter));
                }

                $result = array_merge($folder_data, $result);
            }
        }

        $result = array_filter($result, function($v) { return $v !== null; });

        return $result;
    }

    /**
     * Convert from MAPI to Kolab
     *
     * @param array Data
     * @param array Data of the object that is being updated
     *
     * @return array Data
     */
    public function input($data, $object = null)
    {
        $api    = kolab_api::get_instance();
        $result = array();

        // mapistore properties
        if ($data['id']) {
            $result['uid'] = $data['id'];
        }

        if ($data['parent_id'] && $data['parent_id'] != self::FOLDER_MSGROOT) {
            $result['parent'] = $data['parent_id'];
        }

        // MAPI properties
        if ($data['PidTagDisplayName']) {
            $result['name'] = $data['PidTagDisplayName'];
        }

        if ($data['PidTagContainerClass']) {
            // @TODO: what if folder is already a *.default or *.sentitems, etc.
            // we should keep the subtype intact
            $map = array_flip($this->type_map);
            $result['type'] = $map[$data['PidTagContainerClass']];
        }

        // Save the request data, so it can be stored in database later
        $api->filter->output_metadata['folder'] = $data;

        return $result;
    }

    /**
     * Returns the attributes names mapping
     */
    public function map()
    {
        $map = array_filter($this->map);

        $map['parent_id']            = 'parent';
        $map['PidTagContainerClass'] = 'type';
        $map['PidTagFolderType']     = 'PidTagFolderType';

        return $map;
    }

    /**
     * Update folder metadata after successful create or update
     */
    public function save_metadata($data)
    {
        $folder = $data['id'];
        $remove = array('id', 'parent_id', 'PidTagDisplayName');
        $data   = array_diff_key($data, array_flip($remove));

        if (!empty($data)) {
            $folder_data = $this->get_folder_data($folder);
            $folder_data = array_merge($folder_data, $data);
            $folder_data = array_filter($folder_data, function($v) { return $v !== null; });

            $this->set_folder_data($folder, $folder_data);
        }
    }

    /**
     * Get saved folder metadata
     */
    protected function get_folder_data($folder)
    {
        // don't store data on built-in folders
        if (is_numeric($folder) && $folder < 10000) {
            return array();
        }

        $api    = kolab_api::get_instance();
        $db     = $api->get_dbh();
        $table  = $db->table_name($this->table);

        $query = $db->query("SELECT * FROM `$table`"
            . " WHERE `folder` = ?", (string) $folder);

        if ($db->is_error($query)) {
            throw new kolab_api_exception(kolab_api_exception::SERVER_ERROR);
        }

        if ($row = $db->fetch_assoc($query)) {
            $result = json_decode($row['data'], true);
        }

        return $result ?: array();
    }

    /**
     * Save folder metadata
     */
    protected function set_folder_data($folder, $data)
    {
        // don't store data on built-in folders
        if (is_numeric($folder) && $folder < 10000) {
            return false;
        }

        $api    = kolab_api::get_instance();
        $db     = $api->get_dbh();
        $table  = $db->table_name($this->table);

        $query = $db->query("UPDATE `{$table}` SET `data` = ? WHERE `folder` = ?",
            json_encode($data), (string) $folder);

        if ($db->is_error($query)) {
            throw new kolab_api_exception(kolab_api_exception::SERVER_ERROR);
        }

        if (!$db->affected_rows($query)) {
            $query = $db->query("INSERT INTO `{$table}`"
                . " (`folder`, `data`) VALUES (?, ?) ",
                (string) $folder, json_encode($data));

            if ($db->is_error($query)) {
                throw new kolab_api_exception(kolab_api_exception::SERVER_ERROR);
            }
        }

        return true;
    }
}
