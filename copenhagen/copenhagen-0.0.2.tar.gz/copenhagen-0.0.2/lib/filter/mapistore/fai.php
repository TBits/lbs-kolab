<?php

/**
 +--------------------------------------------------------------------------+
 | This file is part of the Kolab REST API                                  |
 |                                                                          |
 | Copyright (C) 2012-2015, Kolab Systems AG                                |
 |                                                                          |
 | This program is free software: you can redistribute it and/or modify     |
 | it under the terms of the GNU Affero General Public License as published |
 | by the Free Software Foundation, either version 3 of the License, or     |
 | (at your option) any later version.                                      |
 |                                                                          |
 | This program is distributed in the hope that it will be useful,          |
 | but WITHOUT ANY WARRANTY; without even the implied warranty of           |
 | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the             |
 | GNU Affero General Public License for more details.                      |
 |                                                                          |
 | You should have received a copy of the GNU Affero General Public License |
 | along with this program. If not, see <http://www.gnu.org/licenses/>      |
 +--------------------------------------------------------------------------+
 | Author: Aleksander Machniak <machniak@kolabsys.com>                      |
 +--------------------------------------------------------------------------+
*/

class kolab_api_filter_mapistore_fai extends kolab_api_filter_mapistore_common
{
    protected $output;
    protected $db;
    protected $table = 'copenhagen_fai';


    public function __construct()
    {
        $api = kolab_api::get_instance();

        $this->db     = $api->get_dbh();
        $this->output = $api->output;
        $this->table  = $this->db->table_name($this->table);
    }

    /**
     * Handle FAI actions
     */
    public function actions_handler($input)
    {
        $method = $input->method;

        if ($input->path[0] && $input->path[1] === null && $method == 'POST') {
            $object = $input->input(null, true);
            $this->object_create($object);
        }
        else if ($input->path[0]) {
            switch (strtolower($input->path[1])) {
            case 'attachments':
                if ($method == 'HEAD') {
                    $this->count_attachments($input->path[0]);
                }
                else if ($method == 'GET') {
                    $this->list_attachments($input->path[0]);
                }
                break;

            case '':
                if ($method == 'GET') {
                    $this->object_info($input->path[0]);
                }
                else if ($method == 'PUT') {
                    $object       = $input->input(null, true);
                    $object['id'] = $input->path[0];
                    $this->object_update($object);
                }
                else if ($method == 'HEAD') {
                    $this->object_exists($input->path[0]);
                }
                else if ($method == 'DELETE') {
                    $this->object_delete($input->path[0]);
                }
            }
        }

        throw new kolab_api_exception(kolab_api_exception::NOT_FOUND);
    }

    /**
     * Count FAI objects in a folder
     */
    public function count_objects($folder)
    {
        $res = $this->db->query("SELECT COUNT(*) FROM `{$this->table}`"
            . " WHERE `folder` = ?", (string) $folder);

        if ($this->db->is_error($res)) {
            throw new kolab_api_exception(kolab_api_exception::SERVER_ERROR);
        }

        $row = $this->db->fetch_array($res);

        return $row ? (int) $row[0] : 0;
    }

    /**
     * List FAI objects in a folder
     */
    public function list_objects($folder)
    {
        $res = $this->db->query("SELECT * FROM `{$this->table}`"
            . " WHERE `folder` = ? ORDER BY `id`", (string) $folder);

        if ($this->db->is_error($res)) {
            throw new kolab_api_exception(kolab_api_exception::SERVER_ERROR);
        }

        $result = array();

        while ($row = $this->db->fetch_assoc($res)) {
            if (($object = json_decode($row['data'], true)) !== false) {
                $object['id']         = $row['id'];
                $object['parent_id']  = $row['folder'];
                $object['collection'] = 'fai';

                $result[] = $object;
            }
        }

        return $result;
    }

    /**
     * Create FAI object
     */
    public function object_create($object)
    {
        $folder = $object['parent_id'];

        $res = $this->db->query("INSERT INTO `{$this->table}`"
            . " (`folder`, `data`) VALUES (?, ?) ",
            $folder, json_encode($object));

        if ($this->db->is_error($res)) {
            throw new kolab_api_exception(kolab_api_exception::SERVER_ERROR);
        }

        $id = $this->db->insert_id($this->table);

        $this->send(array('id' => $id));
    }

    /**
     * Update FAI object
     */
    public function object_update($object)
    {
        $id = $object['id'];

        if (!$id) {
            throw new kolab_api_exception(kolab_api_exception::SERVER_ERROR);
        }

        if ($object['parent_id']) {
            $folder = $object['parent_id'];
        }

        // @FIXME: do we need to merge with the old data on update?

        $res = $this->db->query("UPDATE `{$this->table}`"
            . " SET `data` = ?"
            . ($folder ? ", `folder` = " . $this->db->quote($folder) : '')
            . " WHERE `id` = ?",
            json_encode($object), $id);

        if ($this->db->is_error($res)) {
            throw new kolab_api_exception(kolab_api_exception::SERVER_ERROR);
        }

        if (!$this->db->affected_rows($res)) {
            throw new kolab_api_exception(kolab_api_exception::NOT_FOUND);
        }

        $this->send(array('id' => $id));
    }

    /**
     * Delete FAI object
     */
    public function object_delete($id)
    {
        $res = $this->db->query("DELETE FROM `{$this->table}`"
            . " WHERE `id` = ?", $id);

        if ($this->db->is_error($res)) {
            throw new kolab_api_exception(kolab_api_exception::SERVER_ERROR);
        }

        if (!$this->db->affected_rows($res)) {
            throw new kolab_api_exception(kolab_api_exception::NOT_FOUND);
        }

        $this->output->send_status(kolab_api_output::STATUS_EMPTY);
    }

    /**
     * Check if FAI object exists
     */
    public function object_exists($id)
    {
        $res = $this->db->query("SELECT 1 FROM `{$this->table}`"
            . " WHERE `id` = ?", $id);

        if ($this->db->is_error($res)) {
            throw new kolab_api_exception(kolab_api_exception::SERVER_ERROR);
        }

        $row = $this->db->fetch_assoc($res);

        if (empty($row)) {
            throw new kolab_api_exception(kolab_api_exception::NOT_FOUND);
        }

        $this->output->send_status(kolab_api_output::STATUS_OK);
    }

    /**
     * Get FAI object data
     */
    public function object_info($id)
    {
        $res = $this->db->query("SELECT * FROM `{$this->table}`"
            . " WHERE `id` = ?", $id);

        if ($this->db->is_error($res)) {
            throw new kolab_api_exception(kolab_api_exception::SERVER_ERROR);
        }

        if ($row = $this->db->fetch_assoc($res)) {
            if (($object = json_decode($row['data'], true)) !== false) {
                $object['id']         = $row['id'];
                $object['parent_id']  = $row['folder'];
                $object['collection'] = 'fai';
            }
        }

        if (empty($object)) {
            throw new kolab_api_exception(kolab_api_exception::NOT_FOUND);
        }

        $this->send($object);
    }

    /**
     * List attachments of FAI object
     */
    protected function list_attachments()
    {
        // @TODO
        $this->output->send(array(), 'folder-list');
    }

    /**
     * Count attachments of FAI object
     */
    protected function count_attachments()
    {
        // @TODO
        $this->output->headers(array('X-Count' => 0));
        $this->output->send_status(kolab_api_output::STATUS_OK);
    }

    /**
     * Send successful response
     *
     * @param mixed Response data
     */
    public function send($data)
    {
        $api   = kolab_api::get_instance();
        $debug = $api->config->get('kolab_api_debug');

        // generate JSON output
        $opts   = $debug && defined('JSON_PRETTY_PRINT') ? JSON_PRETTY_PRINT : 0;
        $result = json_encode($data, $opts);

        if ($debug) {
            rcube::console($result);
        }

        header('Content-Type: "application/json; charset=utf-8"');
        header('HTTP/1.1 200 OK');

        // send JSON output
        echo $result;
        exit;
    }
}
