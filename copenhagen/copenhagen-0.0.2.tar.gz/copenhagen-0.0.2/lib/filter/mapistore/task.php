<?php

/**
 +--------------------------------------------------------------------------+
 | This file is part of the Kolab REST API                                  |
 |                                                                          |
 | Copyright (C) 2012-2015, Kolab Systems AG                                |
 |                                                                          |
 | This program is free software: you can redistribute it and/or modify     |
 | it under the terms of the GNU Affero General Public License as published |
 | by the Free Software Foundation, either version 3 of the License, or     |
 | (at your option) any later version.                                      |
 |                                                                          |
 | This program is distributed in the hope that it will be useful,          |
 | but WITHOUT ANY WARRANTY; without even the implied warranty of           |
 | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the             |
 | GNU Affero General Public License for more details.                      |
 |                                                                          |
 | You should have received a copy of the GNU Affero General Public License |
 | along with this program. If not, see <http://www.gnu.org/licenses/>      |
 +--------------------------------------------------------------------------+
 | Author: Aleksander Machniak <machniak@kolabsys.com>                      |
 +--------------------------------------------------------------------------+
*/

class kolab_api_filter_mapistore_task extends kolab_api_filter_mapistore_common
{
    protected $model = 'task';
    protected $map   = array(
        // task specific props [MS-OXOTASK]
        'PidTagProcessed'           => '',              // PtypBoolean
        'PidLidTaskMode'            => '',              // ignored
        'PidLidTaskStatus'          => '',                  // PtypInteger32
        'PidLidPercentComplete'     => 'percent-complete',  // PtypFloating64
        'PidLidTaskStartDate'       => 'dtstart',           // PtypTime
        'PidLidTaskDueDate'         => 'due',               // PtypTime
        'PidLidTaskResetReminder'   => '', // @TODO         // PtypBoolean
        'PidLidTaskAccepted'        => '', // @TODO         // PtypBoolean
        'PidLidTaskDeadOccurrence'  => '', // @TODO         // PtypBoolean
        'PidLidTaskDateCompleted'   => 'x-custom.MAPI:PidLidTaskDateCompleted',     // PtypTime
        'PidLidTaskLastUpdate'      => '',                                          // PtypTime
        'PidLidTaskActualEffort'    => 'x-custom.MAPI:PidLidTaskActualEffort',      // PtypInteger32
        'PidLidTaskEstimatedEffort' => 'x-custom.MAPI:PidLidTaskEstimatedEffort',   // PtypInteger32
        'PidLidTaskVersion'         => '',                  // PtypInteger32
        'PidLidTaskState'           => '',                  // PtypInteger32
        'PidLidTaskRecurrence'      => '',                  // PtypBinary
        'PidLidTaskAssigners'       => '',                  // PtypBinary
        'PidLidTaskStatusOnComplete' => '',                 // PtypBoolean
        'PidLidTaskHistory'         => '', // @TODO: ?      // PtypInteger32
        'PidLidTaskUpdates'         => '',                  // PtypBoolean
        'PidLidTaskComplete'        => '',                  // PtypBoolean
        'PidLidTaskFCreator'        => '',                  // PtypBoolean
        'PidLidTaskOwner'           => '', // @TODO         // PtypString
        'PidLidTaskMultipleRecipients' => '',               // PtypBoolean
        'PidLidTaskAssigner'        => '',                  // PtypString
        'PidLidTaskLastUser'        => '',                  // PtypString
        'PidLidTaskOrdinal'         => '',                  // PtypInteger32
        'PidLidTaskLastDelegate'    => '',                  // PtypString
        'PidLidTaskFRecurring'      => '',                  // PtypBoolean
        'PidLidTaskOwnership'       => '', // @TODO         // PtypInteger32
        'PidLidTaskAcceptanceState' => '',                  // PtypInteger32
        'PidLidTaskFFixOffline'     => '',                  // PtypBoolean
        'PidLidTaskGlobalId'        => '', // @TODO         // PtypBinary
        'PidLidTaskCustomFlags'     => '',                  // ignored
        'PidLidTaskRole'            => '',                  // ignored
        'PidLidTaskNoCompute'       => '',                  // ignored
        'PidLidTeamTask'            => '',                  // ignored
        // common props [MS-OXCMSG]
        'PidTagSubject'             => 'summary',
        'PidTagBody'                => '',
        'PidTagHtml'                => '',
        'PidTagNativeBody'          => '',
        'PidTagBodyHtml'            => '',
        'PidTagRtfCompressed'       => '',
        'PidTagInternetCodepage'    => '',
        'PidTagMessageClass'        => '',
        'PidLidCommonStart'         => 'dtstart',
        'PidLidCommonEnd'           => 'due',
        'PidTagIconIndex'           => '', // @TODO

        'PidTagCreationTime'         => 'created', // PtypTime, UTC
        'PidTagLastModificationTime' => 'dtstamp', // PtypTime, UTC
    );

    /**
     * Values for PidLidTaskStatus property
     */
    protected $status_map = array(
        'none'          => 0x00000000, // PidLidPercentComplete = 0
        'in-progress'   => 0x00000001, // PidLidPercentComplete > 0 and PidLidPercentComplete < 1
        'complete'      => 0x00000002, // PidLidPercentComplete = 1
        'waiting'       => 0x00000003,
        'deferred'      => 0x00000004,
    );

    /**
     * Values for PidLidTaskHistory property
     */
    protected $history_map = array(
        'none'          => 0x00000000,
        'accepted'      => 0x00000001,
        'rejected'      => 0x00000002,
        'changed'       => 0x00000003,
        'due-changed'   => 0x00000004,
        'assigned'      => 0x00000005,
    );


    /**
     * Convert Kolab to MAPI
     *
     * @param array Data
     * @param array Context (folder_uid, object_uid, object)
     *
     * @return array Data
     */
    public function output($data, $context = null)
    {
        $result = array(
            'PidTagMessageClass' => 'IPM.Task',
            // mapistore REST API specific properties
            'collection' => 'tasks',
        );

        foreach ($this->map as $mapi_idx => $kolab_idx) {
            if (empty($kolab_idx)) {
                continue;
            }

            $value = $this->get_kolab_value($data, $kolab_idx);

            if ($value === null) {
                continue;
            }

            switch ($mapi_idx) {
            case 'PidLidPercentComplete':
                $value /= 100;
                break;

            case 'PidLidTaskStartDate':
            case 'PidLidTaskDueDate':
                $value = $this->date_php2mapi($value, false, array('hour' => 0));
                break;

            case 'PidLidCommonStart':
            case 'PidLidCommonEnd':
//            case 'PidLidTaskLastUpdate':
            case 'PidTagCreationTime':
            case 'PidTagLastModificationTime':
                $value = $this->date_php2mapi($value, true);
                break;

            case 'PidLidTaskActualEffort':
            case 'PidLidTaskEstimatedEffort':
                $value = (int) $value;
                break;
            }

            if ($value === null) {
                continue;
            }

            $result[$mapi_idx] = $value;
        }

        // task description
        $this->body_from_kolab($data, $result);

        // set status
        $percent = $result['PidLidPercentComplete'];
        if ($precent == 1) {
            $result['PidLidTaskStatus'] = $this->status_map['complete'];
            // PidLidTaskDateCompleted (?)
        }
        else if ($precent > 0) {
            $result['PidLidTaskStatus'] = $this->status_map['in-progress'];
        }
        else {
            $result['PidLidTaskStatus'] = $this->status_map['none'];
        }

        // Organizer
        if (!empty($data['organizer'])) {
            $this->attendee_to_recipient($data['organizer'], $result, true);
        }

        // Attendees [MS-OXCICAL 2.1.3.1.1.20.2]
        foreach ((array) $data['attendee'] as $attendee) {
            $this->attendee_to_recipient($attendee, $result);
        }

        // Recurrence
        $this->recurrence_from_kolab($data, $result);

        // Alarms (MAPI supports only one)
        $this->alarm_from_kolab($data, $result);

        $this->parse_common_props($result, $data, $context);

        return $result;
    }

    /**
     * Convert from MAPI to Kolab
     *
     * @param array Data
     * @param array Data of the object that is being updated
     *
     * @return array Data
     */
    public function input($data, $object = null)
    {
        $result = array();

        foreach ($this->map as $mapi_idx => $kolab_idx) {
            if (empty($kolab_idx)) {
                continue;
            }

            if (!array_key_exists($mapi_idx, $data)) {
                continue;
            }

            $value = $data[$mapi_idx];

            switch ($mapi_idx) {
            case 'PidLidPercentComplete':
                $value = intval($value * 100);
                break;

            case 'PidLidTaskStartDate':
            case 'PidLidTaskDueDate':
                if (intval($value) !== 0x5AE980E0) {
                    $value = $this->date_mapi2php($value);
                    $value = $value->format('Y-m-d');
                }
                break;

            case 'PidLidCommonStart':
            case 'PidLidCommonEnd':
//                $value = $this->date_mapi2php($value, true);
                break;

            case 'PidTagCreationTime':
            case 'PidTagLastModificationTime':
                if ($value) {
                    $value = $this->date_mapi2php($value);
                    $value = $value->format('Y-m-d\TH:i:s\Z');
                }
                break;
            }

            $result[$kolab_idx] = $value;
        }

        // task description
        $this->body_to_kolab($data, $result);

        if ($data['PidLidTaskComplete']) {
            $result['status'] = 'COMPLETED';
        }

        // Recurrence
        if (array_key_exists('PidLidTaskRecurrence', $data)) {
            $this->recurrence_to_kolab($data['PidLidTaskRecurrence'], $result, 'task');
        }

        // Alarms (MAPI supports only one)
        $this->alarm_to_kolab($data, $result);

        if (array_key_exists('recipients', $data)) {
            $result['attendee']  = array();
            $result['organizer'] = array();

            foreach ((array) $data['recipients'] as $recipient) {
                $this->recipient_to_attendee($recipient, $result);
            }
        }

        $this->convert_common_props($result, $data, $object);

        return $result;
    }

    /**
     * Returns the attributes names mapping
     */
    public function map()
    {
        $map = array_filter($this->map);

        $map['PidLidTaskRecurrence'] = 'rrule';
        $map['PidTagBody']           = 'description';

        return $map;
    }
}
