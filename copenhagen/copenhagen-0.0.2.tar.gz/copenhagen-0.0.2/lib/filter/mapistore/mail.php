<?php

/**
 +--------------------------------------------------------------------------+
 | This file is part of the Kolab REST API                                  |
 |                                                                          |
 | Copyright (C) 2012-2015, Kolab Systems AG                                |
 |                                                                          |
 | This program is free software: you can redistribute it and/or modify     |
 | it under the terms of the GNU Affero General Public License as published |
 | by the Free Software Foundation, either version 3 of the License, or     |
 | (at your option) any later version.                                      |
 |                                                                          |
 | This program is distributed in the hope that it will be useful,          |
 | but WITHOUT ANY WARRANTY; without even the implied warranty of           |
 | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the             |
 | GNU Affero General Public License for more details.                      |
 |                                                                          |
 | You should have received a copy of the GNU Affero General Public License |
 | along with this program. If not, see <http://www.gnu.org/licenses/>      |
 +--------------------------------------------------------------------------+
 | Author: Aleksander Machniak <machniak@kolabsys.com>                      |
 +--------------------------------------------------------------------------+
*/

class kolab_api_filter_mapistore_mail extends kolab_api_filter_mapistore_common
{
    protected $model = 'mail';
    protected $map   = array(
        // MS-OXCMSG properties
        'PidTagMessageClass'       => '',           // PtypString
        'PidTagHasAttachments'     => 'has-attach', // PtypBoolean
        'PidTagMessageCodepage'    => '',           // PtypInteger32
        'PidTagMessageLocaleId'    => '',           // PtypInteger32
        'PidTagMessageFlags'       => '',           // PtypInteger32, @TODO
        'PidTagMessageSize'        => 'size',       // PtypInteger32, size in bytes
        'PidTagMessageStatus'      => '',           // PtypInteger32
        'PidTagNormalizedSubject'  => '',           // PtypString
        'PidTagImportance'         => '',           // PtypInteger32
        'PidTagPriority'           => 'priority',   // PtypInteger32,
        'PidTagSensitivity'        => '',           // PtypInteger32
        'PidLidSmartNoAttach'      => '',           // PtypBoolean
        'PidLidPrivate'            => '',           // PtypBoolean
        'PidLidSideEffects'        => '',           // PtypInteger32
        'PidLidCommonStart'        => '',           // PtypTime
        'PidLidCommonEnd'          => '',           // PtypTime
        'PidTagAutoForwarded'      => '',           // PtypBoolean
        'PidTagAutoForwardComment' => '',           // PtypString
        'PidTagCategories'         => '',           // PtypMultipleString
        'PidLidClassification'     => '',           // PtypString
        'PidLidClassificationDescription' => '',    // PtypString
        'PidLidClassified'         => '',           // PtypBoolean
        'PidTagInternetReferences' => '',           // PtypString, @TODO
        'PidLidInfoPathFormName'   => '',           // PtypString
        'PidTagMimeSkeleton'       => '',           // PtypBinary
        'PidTagTnefCorrelationKey' => '',           // PtypBinary
        'PidTagAddressBookDisplayNamePrintable' => '',  // PtypString
        'PidTagCreatorEntryId'     => '',           // PtypBinary
        'PidTagLastModifierEntryId' => '',          // PtypBinary
        'PidLidAgingDontAgeMe'     => '',           // PtypBoolean
        'PidLidCurrentVersion'     => '',           // PtypInteger32
        'PidLidCurrentVersionName' => '',           // PtypString, @TODO: User-Agent?
        'PidTagAlternateRecipientAllowed' => '',    // PtypBoolean
        'PidTagResponsibility'     => '',           // PtypBoolean
        'PidTagRowid'              => '',           // PtypInteger32
        'PidTagHasNamedProperties' => '',           // PtypBoolean
        'PidTagRecipientOrder'     => '',           // PtypInteger32
        'PidNameContentBase'       => '',           // PtypString, Content-Base header
        'PidNameAcceptLanguage'    => '',           // PtypString, Accept-Language header
        'PidTagPurportedSenderDomain' => '',        // PtypString
        'PidTagStoreEntryId'       => '',           // PtypBinary
        'PidTagTrustSender'        => '',           // PtypInteger32
        'PidTagSubject'            => 'subject',    // PtypString
        'PidTagMessageRecipients'  => '',           // PtypObject
        'PidNameContentClass'      => '',           // PtypString, @TODO
        'PidTagLocalCommitTime'    => '',           // PtypTime
        'PidNameContentType'       => 'content-type', // PtypString,
        'PidTagCreatorName'        => '',           // PtypString
        'PidTagMessageAttachments' => '',           // PtypObject
        'PidTagRead'               => '',           // PtypBoolean, @TODO
        'PidTagRecipientDisplayName' => '',         // PtypString
        'PidTagRecipientEntryId'   => '',           // PtypBinary
        // body properties
        'PidTagBody'                => 'text',      // PtypString
        'PidTagNativeBody'          => '',          // PtypInteger32
        'PidTagBodyHtml'            => '',          // PtypString
        'PidTagRtfCompressed'       => '',          // PtypBinary
        'PidTagRtfInSync'           => '',          // PtypBoolean
        'PidTagInternetCodepage'    => '',          // PtypInteger32
        'PidTagBodyContentId'       => '',          // PtypString
        'PidTagBodyContentLocation' => '',          // PtypString
        'PidTagHtml'                => 'html',      // PtypBinary
        // contact linking properties
        'PidLidContactLinkEntry'     => '',         // PtypBinary
        'PidLidContacts'             => '',         // PtypMultipleStrings
        'PidLidContactLinkName'      => '',         // PtypString
        'PidLidContactLinkSearchKey' => '',         // PtypBinary
        // retention and archive properties
        'PidTagArchiveTag'      => '',              // PtypBinary
        'PidTagPolicyTag'       => '',              // PtypBinary
        'PidTagRetentionPeriod' => '',              // PtypInteger32
        'PidTagStartDateEtc'    => '',              // PtypBinary
        'PidTagRetentionDate'   => '',              // PtypTime
        'PidTagRetentionFlags'  => '',              // PtypInteger32
        'PidTagArchivePeriod'   => '',              // PtypInteger32
        'PidTagArchiveDate'     => '',              // PtypTime
        // MS-OXOMSG properties
        'PidTagBlockStatus'         => '',          // PtypInteger32
        'PidTagConversationId'      => '',          // PtypBinary, @TODO
        'PidTagConversationindex'   => '',          // PtypBinary
        'PidTagConversationindexTracking' => '',    // PtypBoolean
        'PidTagConversationTopic'   => '',          // PtypString
        'DeferredDeliveryTime'      => '',          // PtypTime
        'PidTagDisplayBcc'          => '',          // PtypString
        'PidTagDisplayCc'           => '',          // PtypString
        'PidTagDisplayTo'           => '',          // PtypString
        'PidTagIconIndex'           => '',          // PtypInteger32, @TODO
        'PidTagInternetMailOverrideFormat' => '',   // PtypInteger32
        'PidTagInternetMessageId'   => 'message-id',  // PtypString
        'PidTagInReplyToId'         => 'in-reply-to', // PtypString,
        'PidTagLastVerbExecuted'    => '',          // PtypInteger32
        'PidTagLastVerbExecutionTime' => '',        // PtypTime
        'PidTagMessageToMe'         => '',          // PtypBoolean, @TODO
        'PidTagMessageCcMe'         => '',          // PtypBoolean, @TODO
        'PidTagMessageRecipientMe'  => '',          // PtypBoolean, @TODO
        'PidTagOriginatorDeliveryReportRequested'    => '', // PtypBoolean, @TODO
        'PidTagOriginatorNonDeliveryReportRequested' => '', // PtypBoolean
        'PidTagOriginalSensitivity' => '',          // PtypInteger32
        'PidTagReceivedRepresentingAddressType'  => '',  // PtypString
        'PidTagReceivedRepresentingEmailAddress' => '',  // PtypString
        'PidTagReceivedRepresentingEntryId'      => '',  // PtypBinary
        'PidTagReceivedRepresentingName'         => '',  // PtypString
        'PidTagReceivedRepresentingSearchKey'    => '',  // PtypBinary
        'PidTagReceivedRepresentingSmtpAddress'  => '',  // PtypString
        'PidTagReadReceiptRequested'             => '',  // PtypBoolean, @TODO
        'PidTagReadReceiptSmtpAddress'           => '',  // PtypString, @TODO
        'PidTagNonReceiptNotificationRequested'  => '',  // PtypBoolean
        'PidTagOriginalAuthorEntryId'            => '',  // PtypBinary
        'PidTagOriginalAuthorName'               => '',  // PtypString
        'PidTagReportDisposition'                => '',  // PtypString, @TODO
        'PidTagReportDispositionMode'            => '',  // PtypString, @TODO
        'PidTagReceivedByAddressType'            => '',  // PtypString
        'PidTagReceivedByEmailAddress'           => '',  // PtypString
        'PidTagReceivedByEntryId'                => '',  // PtypBinary
        'PidTagReceivedBySearchKey'              => '',  // PtypBinary
        'PidTagReceivedByName'                   => '',  // PtypString
        'PidTagReceivedBySmtpAddress'            => '',  // PtypString
        'PidTagRecipientReassignmentProhibited'  => '',  // PtypBoolean
        'PidTagReplyRecipientEntries'            => '',  // PtypBinary
        'PidTagReplyRecipientNames'              => '',  // PtypString
        'PidTagReplyRequested'                   => '',  // PtypBoolean
        'PidTagResponseRequested'                => '',  // PtypBoolean
        'PidTagSendRichInfo'                     => '',  // PtypBoolean
        'PidTagSenderAddressType'            => '',  // PtypString, @TODO
        'PidTagSenderEmailAddress'           => '',  // PtypString
        'PidTagSenderEntryId'                => '',  // PtypBinary
        'PidTagSenderSearchKey'              => '',  // PtypBinary
        'PidTagSenderName'                   => '',  // PtypString
        'PidTagSenderSmtpAddress'            => '',  // PtypString
        'PidTagSentRepresentingAddressType'            => '',  // PtypString, @TODO
        'PidTagSentRepresentingEmailAddress'           => '',  // PtypString
        'PidTagSentRepresentingEntryId'                => '',  // PtypBinary
        'PidTagSentRepresentingSearchKey'              => '',  // PtypBinary
        'PidTagSentRepresentingName'                   => '',  // PtypString
        'PidTagSentRepresentingSmtpAddress'            => '',  // PtypString
        'PidTagSubjectPrefix'           => '',  // PtypString
        'PidTagTransportMessageHeaders' => '',  // PtypString
        'PidLidInternetAccountName'     => '',  // PtypString
        'PidLidInternetAccountStamp'    => '',  // PtypString
        'PidTagPrimarySendAccount'      => '',  // PtypString
        'PidTagNextSendAcct'            => '',  // PtypString
        'PidLidUseTnef'                 => '',  // PtypBoolean
        'PidLidAutoProcessState'        => '',  // PtypInteger32
        'PidLidVerbStream'              => '',  // PtypBinary
        'PidLidVerbResponse'            => '',  // PtypString
        'PidTagTargetEntryId'           => '',  // PtypBinary
        'PidTagAutoResponseSuppress'    => '',  // PtypInteger32
        'PidTagMessageEditorFormat'     => '',  // PtypInteger32
        'PidTagMessageSubmissionId'     => '',  // PtypBinary
        'PidTagSenderIdStatus'          => '',  // PtypInteger32
        'PidTagListHelp'                => '',  // PtypString, List-Help header
        'PidTagListSubscribe'           => '',  // PtypString, List-Subscribe header
        'PidTagListUnsubscribe'         => '',  // PtypString, List-Unsubscribe header
        'PidTagDelegatedByRule'         => '',  // PtypBoolean
        'PidTagOriginalMessageId'       => '',  // PtypString, @TODO
        'PidTagOriginalMessageClass'    => '',  // PtypString
        // @TODO MS-OXOMSG 2.2.2 Message Status Reports
        // @TODO MS-OXOFLAG
    );

    /**
     * Message flags for PidTagMessageFlags as defined in [MS-OXCMSG]
     */
    protected $flags = array(
        'mfRead'         => 0x00000001,
        'mfUnsent'       => 0x00000008,
        'mfResend'       => 0x00000080,
        'mfUnmodified'   => 0x00000002,
        'mfSubmitted'    => 0x00000004,
        'mfHasAttach'    => 0x00000010,
        'mfFromMe'       => 0x00000020,
        'mfFAI'          => 0x00000040,
        'mfNotifyRead'   => 0x00000100,
        'mfNotifyUnread' => 0x00000200,
        'mfEventRead'    => 0x00000400,
        'mfInternet'     => 0x00002000,
        'mfUntrusted'    => 0x00008000,
    );

    /**
     * Message status for PidTagMessageStatus as defined in [MS-OXCMSG]
     */
    protected $status = array(
        'msRemoteDownload' => 0x00001000,
        'msInConflict'     => 0x00000800,
        'msRemoteDelete'   => 0x00002000,
    );

    /**
     * Message importance for PidTagImportance as defined in [MS-OXCMSG]
     */
    protected $importance = array(
        'low'    => 0x00000000,
        'normal' => 0x00000001,
        'high'   => 0x00000002,
    );

    /**
     * Message priority for PidTagPriority as defined in [MS-OXCMSG]
     */
    protected $priority = array(
        'urgent'     => 0x00000001,
        'normal'     => 0x00000000,
        'not-urgent' => 0xFFFFFFFF,
    );

    /**
     * Message sesnitivity for PidTagSensitivity as defined in [MS-OXCMSG]
     */
    protected $sensitivity = array(
        'normal'       => 0x00000000,
        'personal'     => 0x00000001,
        'private'      => 0x00000002,
        'confidential' => 0x00000003,
    );

    /**
     * Recipient type for PidTagRecipientType as defined in [MS-OXOMSG]
     */
    protected $recipient_types = array(
        'to'  => 0x00000001,
        'cc'  => 0x00000002,
        'bcc' => 0x00000003,
    );

    protected $body_types = array(
        'plain'  => 0x00000001,
        'rtf'    => 0x00000002,
        'html'   => 0x00000003,
        'signed' => 0x00000004,
    );


    /**
     * Convert Kolab to MAPI
     *
     * @param array Data
     * @param array Context (folder_uid, object_uid, object)
     *
     * @return array Data
     */
    public function output($data, $context = null)
    {
        $result = array(
            'PidTagMessageClass' => 'IPM.Note',
            // mapistore REST API specific properties
            'collection' => 'mails',
        );

        foreach ($this->map as $mapi_idx => $kolab_idx) {
            if (empty($kolab_idx)) {
                continue;
            }

            $value = $this->get_kolab_value($data, $kolab_idx);

            switch ($mapi_idx) {
            case 'PidTagInternetMessageId':
            case 'PidTagInReplyToId':
                if ($value) {
                    $value = trim($value, '<>');
                }
                break;

            case 'PidTagHtml':
                if ($value) {
                    $value = base64_encode($value);
                }
                break;

            case 'PidTagPriority':
                if ($value == 1 || $value == 2) {
                    $value = $this->priority['urgent'];
                }
                else if ($value > 3) {
                    $value = $this->priority['not-urgent'];
                }
                else {
                    $value = null;
                }
                break;

            case 'PidTagHasAttachments':
                $value = !empty($value) ? true : null;
                break;
            }

            if ($value === null) {
                continue;
            }

            $result[$mapi_idx] = $value;
        }

        // Recipients (To, Cc, Bcc)
        foreach (array('to', 'cc', 'bcc') as $idx) {
            foreach ((array) $data[$idx] as $address) {
                // @TODO: PidTagEntryId, PidTagEmailAddress
                if ($address['address']) {
                    $recipient = array(
                        'PidTagSmtpAddress'   => $address['address'],
                        'PidTagAddressType'   => 'EX',
                        'PidTagRecipientType' => $this->recipient_types[$idx],
                    );

                    if ($address['name']) {
                        $recipient['PidTagDisplayName'] = $address['name'];
                    }

                    $result['recipients'][] = $recipient;
                }
            }
        }

        if ($data['html']) {
            $result['PidTagNativeBody'] = $this->body_types['html'];
        }
        else {
            $result['PidTagNativeBody'] = $this->body_types['plain'];
        }


        $this->parse_common_props($result, $data, $context);

        return $result;
    }

    /**
     * Convert from MAPI to Kolab
     *
     * @param array Data
     * @param array Data of the object that is being updated
     *
     * @return array Data
     */
    public function input($data, $object = null)
    {
        $result = array();

        foreach ($this->map as $mapi_idx => $kolab_idx) {
            if (empty($kolab_idx)) {
                continue;
            }

            if (!array_key_exists($mapi_idx, $data)) {
                continue;
            }

            $value = $data[$mapi_idx];

            switch ($mapi_idx) {
            case 'PidTagInternetMessageId':
            case 'PidTagInReplyToId':
                if ($value) {
                    $value = '<' . trim($value, '<>') . '>';
                }
                break;

            case 'PidTagHtml':
                if ($value) {
                    $value = base64_decode($value);
                }
                break;

            case 'PidTagPriority':
                if ($value == $this->priority['urgent']) {
                    $value = 1;
                }
                else if ($value == $this->priority['not-urgent']) {
                    $value = 5;
                }
                else {
                    $value = null;
                }
                break;

            case 'PidTagHasAttachments':
                continue 2;
            }

            $result[$kolab_idx] = $value;
        }

        // API supports only html and text, we convert RTF to HTML if needed
        if ($data['PidTagRtfCompressed'] && empty($data['PidTagHtml']) && class_exists('rtf')) {
            // The same class is used in kolab-syncroton
            $rtf = new rtf();
            $rtf->loadrtf($data['PidTagRtfCompressed']);

            // @TODO: Conversion to HTML is broken, convert to text
            $rtf->output('ascii');
            $rtf->parse();
            $result['text'] = trim($rtf->out);
        }

        // Recipients (To, Cc, Bcc)
        if (array_key_exists('recipients', $data)) {
            $types = array_flip($this->recipient_types);

            foreach ($data['recipients'] as $recip) {
                // @TODO: PidTagEntryId, PidTagEmailAddress
                $address = $recip['PidTagSmtpAddress'];
                $name    = $recip['PidTagDisplayName'];

                if ($address && ($type = $types[$recip['PidTagRecipientType']])) {
                    $result[$type][] = array(
                        'address' => $address,
                        'name'    => $name,
                    );
                }
            }
        }

        $this->convert_common_props($result, $data, $object);

        return $result;
    }

    /**
     * Returns the attributes names mapping
     */
    public function map()
    {
        $map = array_filter($this->map);

        return $map;
    }
}
