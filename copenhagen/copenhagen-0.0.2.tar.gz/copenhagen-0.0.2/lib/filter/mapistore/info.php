<?php

/**
 +--------------------------------------------------------------------------+
 | This file is part of the Kolab REST API                                  |
 |                                                                          |
 | Copyright (C) 2012-2015, Kolab Systems AG                                |
 |                                                                          |
 | This program is free software: you can redistribute it and/or modify     |
 | it under the terms of the GNU Affero General Public License as published |
 | by the Free Software Foundation, either version 3 of the License, or     |
 | (at your option) any later version.                                      |
 |                                                                          |
 | This program is distributed in the hope that it will be useful,          |
 | but WITHOUT ANY WARRANTY; without even the implied warranty of           |
 | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the             |
 | GNU Affero General Public License for more details.                      |
 |                                                                          |
 | You should have received a copy of the GNU Affero General Public License |
 | along with this program. If not, see <http://www.gnu.org/licenses/>      |
 +--------------------------------------------------------------------------+
 | Author: Aleksander Machniak <machniak@kolabsys.com>                      |
 +--------------------------------------------------------------------------+
*/

class kolab_api_filter_mapistore_info
{
    protected $model = 'info';
    protected $map   = array(
        'name'            => 'name',
        'version'         => 'version',
        'capabilities'    => 'capabilities', // @TODO
    );


    /**
     * Convert Kolab to MAPI
     *
     * @param array Data
     * @param array Context (folder_uid, object_uid, object)
     *
     * @return array Data
     */
    public function output($data, $context = null)
    {
        $result = array();

        foreach ($this->map as $mapi_idx => $kolab_idx) {
            if (empty($kolab_idx)) {
                continue;
            }

            $value = $data[$kolab_idx];

            if ($value === null) {
                continue;
            }

            $result[$mapi_idx] = $value;
        }

        $result['contexts'] = $this->contexts_list();

        $result = array_filter($result, function($v) { return $v !== null; });

        return $result;
    }

    /**
     * Convert from MAPI to Kolab
     *
     * @param array Data
     * @param array Data of the object that is being updated
     *
     * @return array Data
     */
    public function input($data, $object = null)
    {
        return null;
    }

    /**
     * Returns the attributes names mapping
     */
    public function map()
    {
        $map = array_filter($this->map);

        return $map;
    }

    /**
     * Get 'contexts' property
     */
    protected function contexts_list()
    {
        $api      = kolab_api::get_instance();
        $builtins = kolab_api_filter_mapistore_folder::$builtin_folders;
        $folders  = $api->backend ? $api->backend->folders_list() : array();
        $contexts = array();

        foreach ($builtins as $idx => $folder) {
            if ($folder['parent'] == kolab_api_filter_mapistore_folder::FOLDER_MSGROOT) {
                // find real folder
                if ($folder['type']) {
                    reset($folders);
                    foreach ($folders as $f) {
                        if ($folder['name'] == 'INBOX' && $f->name == 'INBOX') {
                            $idx = $f->uid;
                            break;
                        }
                        else if ($folder['type'] == $f->type) {
                            $idx = $f->uid;
                            $folder['name'] = $f->name;
                        }
                    }
                }

                $url = $folder['url'] ?: "/folders/$idx/";

                $contexts[] = array(
                    'main_folder' => true,
                    'name'        => $folder['name'],
                    'role'        => $folder['role'],
                    'system_idx'  => $idx,
                    'url'         => $url,
                );
            }
        }

        return $contexts;
    }
}
