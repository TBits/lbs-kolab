<?php

/**
 +--------------------------------------------------------------------------+
 | This file is part of the Kolab REST API                                  |
 |                                                                          |
 | Copyright (C) 2012-2015, Kolab Systems AG                                |
 |                                                                          |
 | This program is free software: you can redistribute it and/or modify     |
 | it under the terms of the GNU Affero General Public License as published |
 | by the Free Software Foundation, either version 3 of the License, or     |
 | (at your option) any later version.                                      |
 |                                                                          |
 | This program is distributed in the hope that it will be useful,          |
 | but WITHOUT ANY WARRANTY; without even the implied warranty of           |
 | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the             |
 | GNU Affero General Public License for more details.                      |
 |                                                                          |
 | You should have received a copy of the GNU Affero General Public License |
 | along with this program. If not, see <http://www.gnu.org/licenses/>      |
 +--------------------------------------------------------------------------+
 | Author: Aleksander Machniak <machniak@kolabsys.com>                      |
 +--------------------------------------------------------------------------+
*/

class kolab_api_filter_mapistore extends kolab_api_filter
{
    public $input;
    public $api;
    public $attrs_filter    = array();
    public $output_metadata = array();


    /**
     * Modify request path
     *
     * @param array (Exploded) request path
     */
    public function path(&$path)
    {
        // handle differences between OpenChange API and Kolab API
        // here we do only very basic modifications, just to be able
        // to select apprioprate api action class
        if ($path[0] == 'calendars') {
            $path[0] = 'events';
        }
        // Mapistore-specific requests we'll use an existing API class
        // and handle this separately, see self::input()
        else if ($path[0] == 'fai') {
            $path[0] = 'info'; // use existing API path
            $path[]  = 'mapi-fai';
        }
    }

    /**
     * Executed before every api action
     *
     * @param kolab_api_input Request
     */
    public function input(&$input)
    {
        // bring back fai action
        if ($input->action == 'info' && ($size = count($input->path)) && $input->path[$size-1] == 'mapi-fai') {
            $input->action = 'fai';
            array_pop($input->path);
        }

        // handle differences between OpenChange API and Kolab API

        $this->input         = $input;
        $this->api           = $input->api;
        $this->common_action = !in_array($input->action, array('folders', 'info'));

        // convert <action>/<id> to <action>/<folder>/<id> or <action>/<folder>/<message>/<attach>
        if ($this->common_action && ($uid = $input->path[0])) {
            list($folder, $msg, $attach) = self::uid_decode($uid);

            $path = array($folder);
            if ($msg) {
                $path[] = $msg;
            }
            if ($attach) {
                $path[] = $attach;
            }

            array_splice($input->path, 0, 1, $path);
        }

        // convert parent_id into path on object create request
        if ($input->method == 'POST' && $this->common_action && !count($input->path)) {
            $data = $input->input(null, true);

            if ($data['parent_id']) {
                $input->path[0] = $data['parent_id'];
            }
            else {
                throw new kolab_api_exception(kolab_api_exception::INVALID_REQUEST);
            }
        }
        // convert parent_id into path on object update request
        else if ($input->method == 'PUT' && $folder && count($input->path) == 2) {
            $data = $input->input(null, true);

            if ($data['parent_id'] && $data['parent_id'] != $folder) {
                $this->parent_change_handler($data);
            }
        }
        // properties filter, map MAPI attribute names to Kolab attributes
        else if ($input->method == 'GET' && $input->args['properties']) {
            if ($input->action == 'folders' && $input->path[1] == 'messages') {
                if (!$this->is_builtin_folder($input->path[0])) {
                    $type = $this->api->backend->folder_type($input->path[0]);
                    list($type, ) = explode('.', $type);
                }
            }
            else {
                $type = $input->action[strlen($input->action)-1] == 's' ? substr($input->action, 0, -1) : $input->action;
            }

            $this->attrs_filter        = explode(',', $input->args['properties']);
            $properties                = $this->attributes_filter($this->attrs_filter, $type);
            $input->args['properties'] = implode(',', $properties);
        }

        switch ($input->action) {
        case 'attachments':
            $this->attachment_actions_handler();
            break;

        case 'folders':
            $this->folder_actions_handler();
            break;

        case 'fai':
            $fai = $this->get_model_class('fai');
            $fai->actions_handler($input);
            break;

        case 'notes':
            // Notes do not have attachments in Exchange
            if ($input->path[1] === 'attachments' || count($input->path) > 2) {
                throw new kolab_api_exception(kolab_api_exception::NOT_FOUND);
            }
            break;
        }
    }

    /**
     * Executed when parsing request body
     *
     * @param string Request data
     * @param string Expected object type
     * @param string Original object data (set on update requests)
     */
    public function input_body(&$data, $type = null, $original_object = null)
    {
        // handle differences between OpenChange API and Kolab API
        // Note: input->path is already modified by input() and path() above

        switch ($this->input->action) {
        case 'folders':
            // folders/<id>/deletemessages input
            if ($this->input->path[1] == 'deleteobjects') {
                // Kolab API expects just a list of identifiers, I.e.:
                // [{"id": "1"}, {"id": "2"}]  =>  ["1", "2"]
                foreach ((array) $data as $idx => $element) {
                    $data[$idx] = $element['id'];
                }
            }
            // always add folder ID to the request on folder update
            else if ($this->input->method == 'PUT' && empty($data['id'])) {
                $data['id'] = $this->input->path[0];
            }

            break;
        }

        switch ($type) {
        case 'attachment':
        case 'event':
        case 'note':
        case 'task':
        case 'contact':
        case 'mail':
        case 'folder':
            $model = $this->get_model_class($type);
            $data  = $model->input($data, $original_object);
            break;
        }
    }

    /**
     * Apply filter on output data
     *
     * @param array  Result data
     * @param string Object type
     * @param array  Context (folder_uid, object_uid, object)
     * @param array  Optional attributes filter
     */
    public function output(&$result, $type, $context = null, $attrs_filter = array())
    {
        // handle differences between OpenChange API and Kolab API
        $model = $this->get_model_class($type);

        if (!empty($this->attrs_filter)) {
            $attrs_filter = array_combine($this->attrs_filter, $this->attrs_filter);
        }
        else if (!empty($attrs_filter)) {
            $attrs_filter = $this->attributes_filter($attrs_filter, $type, true);

            if (!empty($attrs_filter)) {
                $attrs_filter = array_combine($attrs_filter, $attrs_filter);
            }
        }

        // Add contact photo to attachments list
        if ($this->input->action == 'contacts' && $this->input->path[2] == 'attachments'
            && $context && !empty($context['object'])
        ) {
            if ($attachment = kolab_api_filter_mapistore_contact::photo_attachment($context['object'])) {
                $result[] = $attachment;
            }
        }
        // Add event exceptions to attachments list
        else if ($this->input->action == 'events' && $this->input->path[2] == 'attachments'
            && $context && !empty($context['object'])
        ) {
            $event_model  = $this->get_model_class('event');
            $event_output = new kolab_api_output_json_event($this->api->output);
            $event        = $event_output->element($context['object']);
            $attachments  = $event_model->exception_attachments($event);

            if (!empty($attachments)) {
                $result = array_merge($result, $attachments);
            }
        }

        foreach ($result as $idx => $data) {
            if ($filtered = $model->output($data, $context)) {
                // apply properties filter (again)
                if (!empty($attrs_filter)) {
                    $filtered = array_intersect_key($filtered, $attrs_filter);
                }

                $result[$idx] = $filtered;
            }
            else {
                unset($result[$idx]);
                $unset = true;
            }
        }

        if ($unset) {
            $result = array_values($result);
        }

        // Save extra object data on update/create
        // e.g. set folder metadata (after folder update or create)
        if ($this->output_metadata[$type]) {
            // add ID of the created object
            if (is_array($result[0]) && $result[0]['id']) {
                $this->output_metadata[$type]['id'] = $result[0]['id'];
            }

            $model->save_metadata($this->output_metadata[$type]);
        }

        // cleanup
        unset($_SESSION['uploads']['MAPIATTACH']);
    }

    /**
     * Executed for response headers
     *
     * @param array Response headers
     * @param array Context (folder_uid, object_uid, object)
     */
    public function headers(&$headers, $context = null)
    {
        // handle differences between OpenChange API and Kolab API
        foreach ($headers as $name => $value) {
            switch ($name) {
            case 'X-Count':
                // Add contact photo to attachments count
                if ($this->input->action == 'contacts' && $this->input->path[2] == 'attachments'
                    && $context && !empty($context['object'])
                    && kolab_api_filter_mapistore_contact::photo_attachment($context['object'])
                ) {
                    $value += 1;
                }

                // Add event exceptions to attachments count
                if ($this->input->action == 'events' && $this->input->path[2] == 'attachments'
                    && $context && !empty($context['object'])
                ) {
                    $event_model  = $this->get_model_class('event');
                    $event_output = new kolab_api_output_json_event($this->api->output);
                    $event        = $event_output->element($context['object']);
                    $value       += count($event_model->exception_attachments($event));
                }

                $headers['X-mapistore-rowcount'] = $value;
                unset($headers[$name]);
                break;
            }
        }
    }

    /**
     * Executed for empty response status
     *
     * @param int Status code
     */
    public function send_status(&$status)
    {
        // handle differences between OpenChange API and Kolab API

        if ($this->input->method == 'PUT' && !in_array($input->action, array('info'))) {
            // Mapistore expects 204 on object updates
            // however, we'd like to send modified UID of the object sometimes
            // $status = kolab_api_output::STATUS_EMPTY;
        }
    }

    /**
     * Converts kolab identifiers describind the object into
     * MAPI identifier that can be easily used in URL.
     *
     * @param string Folder UID
     * @param string Object UID
     * @param string Optional attachment identifier
     *
     * @return string Object identifier
     */
    public static function uid_encode($folder_uid, $msg_uid, $attach_id = null)
    {
        $result = array($folder_uid, $msg_uid);

        if ($attach_id) {
            $result[] = $attach_id;
        }

        $result = array_map(array('kolab_api_filter_mapistore', 'uid_encode_item'), $result);

        return implode('.', $result);
    }

    /**
     * Converts back the MAPI identifier into kolab folder/object/attachment IDs
     *
     * @param string Object identifier
     *
     * @return array Object identifiers
     */
    public static function uid_decode($uid)
    {
        $result = explode('.', $uid);
        $result = array_map(array('kolab_api_filter_mapistore', 'uid_decode_item'), $result);

        return $result;
    }

    /**
     * Encodes UID element
     */
    protected static function uid_encode_item($str)
    {
        $fn  = function($match) { return '_' . ord($match[1]); };
        $str = preg_replace_callback('/([^0-9a-zA-Z-])/', $fn, $str);

        return $str;
    }

    /**
     * Decodes UID element
     */
    protected static function uid_decode_item($str)
    {
        $fn  = function($match) { return chr($match[1]); };
        $str = preg_replace_callback('/_([0-9]{2})/', $fn, $str);

        return $str;
    }

    /**
     * Filter property names
     */
    protected function attributes_filter($attrs, $type = null, $reverse = false)
    {
        $model = $this->get_model_class($type);
        return $model->attributes_filter($attrs, $reverse);
    }

    /**
     * Return instance of model class object
     */
    protected function get_model_class($type)
    {
        $class = "kolab_api_filter_mapistore_$type";
        return new $class;
    }

    /**
     * Handles object parent modification (move)
     */
    protected function parent_change_handler($data)
    {
        $folder = $this->input->path[0];
        $uid    = $this->input->path[1];
        $target = $data['parent_id'];
        $api    = kolab_api::get_instance();

        // move the object
        $api->backend->objects_move($folder, $target, array($uid));

        // replace folder uid in input arguments
        $this->input->path[0] = $target;

        // exit if the rest of input is empty
        if (count($data) < 2) {
            $api->output->send_status(kolab_api_output::STATUS_EMPTY);
        }
    }

    /**
     * Overwrite attachment actions for contact photos
     */
    protected function attachment_actions_handler()
    {
        // contact photo attachment
        if ($this->input->path[2] == kolab_api_filter_mapistore_contact::PHOTO_ATTACHMENT_ID) {
            $folder     = $this->input->path[0];
            $object_uid = $this->input->path[1];
            $attach_uid = $this->input->path[2];
            $object     = $this->api->backend->object_get($folder, $object_uid);
            $attachment = kolab_api_filter_mapistore_contact::photo_attachment($object);
            $context    = array(
                'folder_uid' => $folder,
                'object_uid' => $object_uid,
                'object'     => $object
            );

            if (!$attachment) {
                throw new kolab_api_exception(kolab_api_exception::NOT_FOUND);
            }

            // fetch photo info/body
            if ($this->input->method == 'GET') {
                $this->api->output->send($attachment, 'attachment', $context);
            }
            // photo existence check
            else if ($this->input->method == 'HEAD') {
                $this->api->output->send_status(kolab_api_output::STATUS_OK);
            }
            // photo delete
            else if ($this->input->method == 'DELETE') {
                $object['photo'] = '';
                $this->api->backend->object_update($folder, $object, 'contact');
                $this->api->output->send_status(kolab_api_output::STATUS_OK);
            }
            // photo update
            else if ($this->input->method == 'PUT') {
                $data = file_get_contents('php://input');
                $data = trim($data);
                $data = json_decode($data, true);

                if (empty($data) || empty($data['PidTagAttachDataBinary'])) {
                    $error = "Invalid input for contact photo update request";
                    throw new kolab_api_exception(kolab_api_exception::INVALID_REQUEST, null, $error);
                }

                $object['photo'] = base64_decode($data['PidTagAttachDataBinary']);
                $this->api->backend->object_update($folder, $object, 'contact');

                $this->api->output->send_status(kolab_api_output::STATUS_OK);
            }
        }
        // event exception attachment
        else if ($this->input->path[2] >= 1000000 && $this->api->backend->folder_type($this->input->path[0]) == 'event') {
            $folder     = $this->input->path[0];
            $object_uid = $this->input->path[1];
            $attach_uid = $this->input->path[2];
            $object     = $this->api->backend->object_get($folder, $object_uid);
            $context    = array(
                'folder_uid' => $folder,
                'object_uid' => $object_uid,
                'object'     => $object
            );

            $model        = $this->get_model_class('event');
            $event_output = new kolab_api_output_json_event($this->api->output);
            $event        = $event_output->element($object);
            $attachments  = $model->exception_attachments($event);

            foreach ($attachments as $attach_idx => $att) {
                if ($att['id'] == $attach_uid) {
                    $attachment = $att;
                    break;
                }
            }

            if (!$attachment) {
                throw new kolab_api_exception(kolab_api_exception::NOT_FOUND);
            }

            // fetch attachment info
            if ($this->input->method == 'GET') {
                $this->api->output->send($attachment, 'attachment', $context);
            }
            // attachment existence check
            else if ($this->input->method == 'HEAD') {
                $this->api->output->send_status(kolab_api_output::STATUS_OK);
            }
            // attachment delete
            else if ($this->input->method == 'DELETE') {
                unset($object['exceptions'][$attach_idx]);
                $this->api->backend->object_update($folder, $object, 'event');
                $this->api->output->send_status(kolab_api_output::STATUS_OK);
            }
            // exception update
            else if ($this->input->method == 'PUT') {
                $data = file_get_contents('php://input');
                $data = trim($data);
                $data = json_decode($data, true);

                if (empty($data['PidTagAttachDataObject'])) {
                    $error = "Invalid input for event exception update request";
                    throw new kolab_api_exception(kolab_api_exception::INVALID_REQUEST, null, $error);
                }

                if ($data['PidTagAttachDataObject']['PidTagMessageClass'] != kolab_api_filter_mapistore_event::EXCEPTION_CLASS) {
                    // as of now we do not support other DataObject attachments
                    $error = "Unsupported input for DataObject attachment";
                    throw new kolab_api_exception(kolab_api_exception::INVALID_REQUEST, null, $error);
                }

                // parse exception data
                $exception = $model->input($data['PidTagAttachDataObject']);

                // Convert the exception into internal format
                $input = new kolab_api_input_json_event;
                $input->input($exception, $object['exceptions'][$attach_idx]);

                if ($exception['start']) {
                    $dt = $exception['start'];
                }
                else if ($data['PidTagExceptionReplaceTime']) {
                    $dt = $model->date_mapi2php($data['PidTagExceptionReplaceTime']);
                }

                if (empty($dt)) {
                    $error = "Invalid input for event exception";
                    throw new kolab_api_exception(kolab_api_exception::INVALID_REQUEST, null, $error);
                }

                $exception['recurrence_date'] = $dt;

                // Exception attachment id
                $id = $model->recurrence_id($dt, $event['dtstart']);

                // Replace the exception and remove other exceptions with the same new recurrence-id
                reset($attachments);
                foreach ($attachments as $idx => $att) {
                    if ($idx == $attach_idx) {
                        $object['exceptions'][$attach_idx] = $exception;
                    }
                    else if ($att['id'] == $id) {
                        unset($object['exceptions'][$idx]);
                    }
                }

                // Save the event
                $this->api->backend->object_update($folder, $object, 'event');
                $this->api->output->send(array('id' => $id), 'attachment', $context, array('id'));
            }
        }
        // new attachment...
        else if ($this->input->path[0] && $this->input->path[1] && $this->input->method == 'POST') {
            $data = $this->input->input(null, true);

            // add photo to a contact?
            if ($data['PidTagAttachmentContactPhoto']) {
                $folder     = $this->input->path[0];
                $object_uid = $this->input->path[1];
                $object     = $this->api->backend->object_get($folder, $object_uid);

                if (empty($data['PidTagAttachDataBinary'])) {
                    $error = "Invalid input for contact photo create request";
                    throw new kolab_api_exception(kolab_api_exception::INVALID_REQUEST, null, $error);
                }

                $id      = kolab_api_filter_mapistore_contact::PHOTO_ATTACHMENT_ID;
                $context = array(
                    'folder_uid' => $folder,
                    'object_uid' => $object_uid,
                    'object'     => $object
                );

                $object['photo'] = base64_decode($data['PidTagAttachDataBinary']);

                $this->api->backend->object_update($folder, $object, 'contact');
                $this->api->output->send(array('id' => $id), 'attachment', $context, array('id'));
            }
            // embedded message, e.g. calendar event exception
            else if ($data['PidTagAttachMethod'] == 0x00000005) {
                $folder     = $this->input->path[0];
                $object_uid = $this->input->path[1];
                $object     = $this->api->backend->object_get($folder, $object_uid);

                if (empty($data['PidTagAttachDataObject'])) {
                    $error = "Invalid input for event exception create request";
                    throw new kolab_api_exception(kolab_api_exception::INVALID_REQUEST, null, $error);
                }

                if ($data['PidTagAttachDataObject']['PidTagMessageClass'] != kolab_api_filter_mapistore_event::EXCEPTION_CLASS) {
                    // as of now we do not support other DataObject attachments
                    $error = "Unsupported input for DataObject attachment";
                    throw new kolab_api_exception(kolab_api_exception::INVALID_REQUEST, null, $error);
                }

                $context = array(
                    'folder_uid' => $folder,
                    'object_uid' => $object_uid,
                    'object'     => $object
                );

                // parse exception data
                $model     = $this->get_model_class('event');
                $exception = $model->input($data['PidTagAttachDataObject']);
                $dt = kolab_api_input_json::to_datetime($exception['recurrence-id'] ?: $exception['dtstart']);

                if (empty($dt) && $data['PidTagExceptionReplaceTime']) {
                    $dt = $model->date_mapi2php($data['PidTagExceptionReplaceTime']);
                }

                if (empty($dt)) {
                    $error = "Invalid input for event exception";
                    throw new kolab_api_exception(kolab_api_exception::INVALID_REQUEST, null, $error);
                }

                // Convert the exception into internal format
                $input = new kolab_api_input_json_event;
                $input->input($exception);

                // Exception attachment id
                $id = $model->recurrence_id($dt, $object['start']);

                // Append the exception and save event
                $object['exceptions'][] = $exception;
                $this->api->backend->object_update($folder, $object, 'event');
                $this->api->output->send(array('id' => $id), 'attachment', $context, array('id'));
            }
        }
    }

    /**
     * Overwrite folders actions
     */
    protected function folder_actions_handler()
    {
        $input = $this->input;

        // in OpenChange folders/1/folders means get folders of the IPM Subtree
        if ($input->method == 'GET' && $input->path[0] === '1' && $input->path[1] == 'folders') {
            $input->path = array();
        }
        // in OpenChange folders/0/folders means get the hierarchy of the NON-IPM Subtree
        else if ($input->method == 'GET' && $input->path[0] === '0' && $input->path[1] == 'folders') {
            $list = $this->get_builtin_folder_list(0);
            $this->api->output->send($list, 'folder-list', null);
        }
        else if ($input->path[1] == 'messages') {
            $input->path[1] = 'objects';
        }
        else if ($input->path[1] == 'deletemessages') {
            $input->path[1] = 'deleteobjects';
        }

        // FAI
        if ($input->path[1] === 'fai') {
            // get FAI objects
            if ($input->method == 'GET') {
                $this->list_fai_objects($input->path[0]);
            }
            // count FAI objects
            else if ($input->method == 'HEAD') {
                $this->count_fai_objects($input->path[0]);
            }

            throw new kolab_api_exception(kolab_api_exception::NOT_IMPLEMENTED);
        }
        // request for built-in folder
        else if ($this->is_builtin_folder($input->path[0])) {
            $folder = $this->get_builtin_folder($input->path[0]);

            if (count($input->path) == 1) {
                // folder info
                if ($input->method == 'GET') {
                    $this->api->output->send($folder, 'folder', null);
                }
                // folder exists
                else if ($input->method == 'HEAD') {
                    $this->api->output->send_status(kolab_api_output::STATUS_OK);
                }

                throw new kolab_api_exception(kolab_api_exception::NOT_IMPLEMENTED);
            }
            else {
                switch (strtolower((string) $input->path[1])) {
                case 'objects':
                    if ($input->method == 'HEAD') {
                        $this->builtin_folder_count_objects();
                    }
                    else if ($input->method == 'GET') {
                        $this->builtin_folder_list_objects();
                    }
                    break;

                case 'folders':
                    if ($input->method == 'HEAD') {
                        $this->builtin_folder_count_folders();
                    }
                    else if ($input->method == 'GET') {
                        $this->builtin_folder_list_folders();
                    }
                    break;

                case 'empty':
                    if ($input->method == 'POST') {
                        $this->builtin_folder_empty();
                    }
                    break;

                case 'deleteobjects':
                    if ($input->method == 'POST') {
                        $this->builtin_folder_delete_objects();
                    }
                    break;
                }
            }

            throw new kolab_api_exception(kolab_api_exception::NOT_FOUND);
        }
    }

    /**
     * Returns list of built-in folders (NON-IPM subtree)
     */
    protected function get_builtin_folder_list($parent = null)
    {
        $folders = kolab_api_filter_mapistore_folder::$builtin_folders;

        foreach ($folders as $idx => $folder) {
            if ($parent !== null && $parent != $folder['parent']) {
                unset($folders[$idx]);
                continue;
            }

            $folders[$idx] = array_merge(array(
                    'comment'    => $folder['name'],
                    'uid'        => $idx,
                    'hidden'     => true,
                    'role'       => 10,
                    'system_idx' => $idx,
            ), $folder);
        }

        return $folders;
    }

    /**
     * Returns built-in folder information
     */
    protected function get_builtin_folder($uid)
    {
        $list = $this->get_builtin_folder_list();

        $result = $list[$uid];

        if (!$result) {
            throw new kolab_api_exception(kolab_api_exception::NOT_FOUND);
        }

        return $result;
    }

    /**
     * Check if specified uid is an uid of builtin folder
     */
    protected function is_builtin_folder($uid)
    {
        return is_numeric($uid) && strlen($uid) < 4;
    }

    /**
     * Coun objects in built-in folder
     */
    protected function builtin_folder_count_objects()
    {
        // @TODO
        $this->api->output->headers(array('X-Count' => 0));
        $this->api->output->send_status(kolab_api_output::STATUS_OK);
    }

    /**
     * List objects in built-in folder
     */
    protected function builtin_folder_list_objects()
    {
        // @TODO
        $this->api->output->send(array(), 'folder-list');
    }

    /**
     * Count sub-folders of built-in folder
     */
    protected function builtin_folder_count_folders()
    {
        // @TODO
        $this->api->output->headers(array('X-Count' => 0));
        $this->api->output->send_status(kolab_api_output::STATUS_OK);
    }

    /**
     * List sub-folders in built-in folder
     */
    protected function builtin_folder_list_folders()
    {
        // @TODO
        $this->api->output->send(array(), 'folder-list');
    }

    /**
     * Delete all objects in built-in folder
     */
    protected function builtin_folder_empty()
    {
        throw new kolab_api_exception(kolab_api_exception::NOT_IMPLEMENTED);
    }

    /**
     * Delete objects in built0in folder
     */
    protected function builtin_folder_delete_objects()
    {
        throw new kolab_api_exception(kolab_api_exception::NOT_IMPLEMENTED);
    }

    /**
     * Count FAI objects in a folder
     */
    protected function count_fai_objects($folder)
    {
        $fai   = $this->get_model_class('fai');
        $count = $fai->count_objects($folder);

        $this->api->output->headers(array('X-Count' => $count));
        $this->api->output->send_status(kolab_api_output::STATUS_OK);
    }

    /**
     * List FAI objects in a folder
     */
    protected function list_fai_objects($folder)
    {
        $fai  = $this->get_model_class('fai');
        $list = $fai->list_objects($folder);

        $fai->send($list, true);
    }
}
