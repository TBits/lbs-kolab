<?php

/**
 +--------------------------------------------------------------------------+
 | This file is part of the Kolab REST API                                  |
 |                                                                          |
 | Copyright (C) 2011-2015, Kolab Systems AG                                |
 |                                                                          |
 | This program is free software: you can redistribute it and/or modify     |
 | it under the terms of the GNU Affero General Public License as published |
 | by the Free Software Foundation, either version 3 of the License, or     |
 | (at your option) any later version.                                      |
 |                                                                          |
 | This program is distributed in the hope that it will be useful,          |
 | but WITHOUT ANY WARRANTY; without even the implied warranty of           |
 | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the             |
 | GNU Affero General Public License for more details.                      |
 |                                                                          |
 | You should have received a copy of the GNU Affero General Public License |
 | along with this program. If not, see <http://www.gnu.org/licenses/>      |
 +--------------------------------------------------------------------------+
 | Author: Aleksander Machniak <machniak@kolabsys.com>                      |
 +--------------------------------------------------------------------------+
*/

/**
 * Main exception class for Kolab REST API responses
 */
class kolab_api_exception extends Exception
{
    const UNAUTHORIZED     = 401;
    const FORBIDDEN        = 403;
    const NOT_FOUND        = 404;
    const TIMEOUT          = 408;
    const INVALID_REQUEST  = 422;
    const SERVER_ERROR     = 500;
    const NOT_IMPLEMENTED  = 501;
    const UNAVAILABLE      = 503;

    private $messages = array(
        self::UNAUTHORIZED    => 'Unauthorized',
        self::FORBIDDEN       => 'Forbidden',
        self::NOT_FOUND       => 'Not found',
        self::TIMEOUT         => 'Request timeout',
        self::INVALID_REQUEST => 'Invalid request',
        self::SERVER_ERROR    => 'Internal server error',
        self::NOT_IMPLEMENTED => 'Not implemented',
        self::UNAVAILABLE     => 'Service unavailable',
    );


    /**
     * Constructor
     *
     * @param int    HTTP error code (default 500)
     * @param array  Optional error info to log
     * @param string Optional error message
     */
    function __construct($code = 0, $error = array(), $message = null)
    {
        if (!$message) {
            $message = $this->messages[$code];
        }

        if (!$message) {
            $code    = self::SERVER_ERROR;
            $message = $this->messages[self::SERVER_ERROR];
        }

        if (!empty($error)) {
            rcube::raise_error($error, true, false);
        }
        else {
            $api = kolab_api::get_instance();
            if ($api->config->get('kolab_api_debug')) {
                rcube::console('Error: ' . $code);
            }
        }


        parent::__construct($message, $code);
    }
}
