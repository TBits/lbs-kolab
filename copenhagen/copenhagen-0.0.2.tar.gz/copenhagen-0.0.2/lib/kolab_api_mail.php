<?php

/**
 +--------------------------------------------------------------------------+
 | This file is part of the Kolab REST API                                  |
 |                                                                          |
 | Copyright (C) 2012-2015, Kolab Systems AG                                |
 |                                                                          |
 | This program is free software: you can redistribute it and/or modify     |
 | it under the terms of the GNU Affero General Public License as published |
 | by the Free Software Foundation, either version 3 of the License, or     |
 | (at your option) any later version.                                      |
 |                                                                          |
 | This program is distributed in the hope that it will be useful,          |
 | but WITHOUT ANY WARRANTY; without even the implied warranty of           |
 | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the             |
 | GNU Affero General Public License for more details.                      |
 |                                                                          |
 | You should have received a copy of the GNU Affero General Public License |
 | along with this program. If not, see <http://www.gnu.org/licenses/>      |
 +--------------------------------------------------------------------------+
 | Author: Aleksander Machniak <machniak@kolabsys.com>                      |
 +--------------------------------------------------------------------------+
*/

class kolab_api_mail
{
    /**
     * List of supported header fields
     *
     * @var array
     */
    public static $header_fields = array(
        'uid',
        'subject',
        'from',
        'sender',
        'to',
        'cc',
        'bcc',
        'reply-to',
        'in-reply-to',
        'message-id',
        'references',
        'date',
        'internaldate',
        'content-type',
        'priority',
        'size',
        'flags',
        'categories',
        'has-attach',
    );

    /**
     * Original message
     *
     * @var rcube_message
     */
    protected $message;

    /**
     * Modified properties
     *
     * @var array
     */
    protected $data = array();

    /**
     * Validity status
     *
     * @var bool
     */
    protected $valid = true;

    /**
     * Headers-only mode flag
     *
     * @var bool
     */
    protected $is_header = false;

    /**
     * Line separator
     *
     * @var string
     */
    protected $endln = "\r\n";

    protected $body_text;
    protected $body_html;
    protected $boundary;
    protected $attach_data = array();
    protected $recipients  = array();
    protected $from_address;


    /**
     * Object constructor
     *
     * @param rcube_message|rcube_message_header Original message
     */
    public function __construct($message = null)
    {
        $this->message   = $message;
        $this->is_header = $this->message instanceof rcube_message_header;
    }

    /**
     * Properties setter
     *
     * @param string $name  Property name
     * @param mixed  $value Property value
     */
    public function __set($name, $value)
    {
        switch ($name) {
        case 'flags':
            $value = (array) $value;
            break;

        case 'priority':
            $value = (int) $value; /* values: 1, 2, 4, 5 */
            break;

        case 'date':
        case 'subject':
        case 'from':
        case 'sender':
        case 'to':
        case 'cc':
        case 'bcc':
        case 'reply-to':
        case 'in-reply-to':
        case 'references':
        case 'categories':
        case 'message-id':
        case 'text':
        case 'html':
            // make sure the value is utf-8
            if ($value !== null && $value !== '' && (!is_array($value) || !empty($value))) {
                // make sure we have utf-8 here
                $value = rcube_charset::clean($value);
            }
            break;

        case 'uid':
        case 'internaldate':
        case 'content-type':
        case 'size':
            // ignore
            return;

        default:
            // unsupported property, log error?
            return;
        }

        if (!$changed && in_array($name, self::$header_fields)) {
            $changed = $this->{$name} !== $value;
        }
        else {
            $changed = true;
        }

        if ($changed) {
            $this->data[$name] = $value;
        }
    }

    /**
     * Properties getter
     *
     * @param string $name Property name
     *
     * @param mixed Property value
     */
    public function __get($name)
    {
        if (array_key_exists($name, $this->data)) {
            return $this->data[$name];
        }

        if (empty($this->message)) {
            return;
        }

        $headers = $this->is_header ? $this->message : $this->message->headers;
        $value   = null;

        switch ($name) {
            case 'uid':
                return (string) $headers->uid;

            case 'folder':
                return $headers->folder;

            case 'priority':
            case 'size':
                if (isset($headers->{$name})) {
                    $value = (int) $headers->{$name};
                }
                break;

            case 'content-type':
                $value = $headers->ctype;
                break;

            case 'date':
            case 'internaldate':
                $value = $headers->{$name};
                break;

            case 'subject':
                $value = trim(rcube_mime::decode_header($headers->subject, $headers->charset));
                break;

            case 'flags':
                $value = array_change_key_case((array) $headers->flags);
                $value = array_filter($value);
                $value = array_keys($value);
                break;

            case 'from':
            case 'sender':
            case 'to':
            case 'cc':
            case 'bcc':
            case 'reply-to':
                $addresses = $headers->{$name == 'reply-to' ? 'replyto' : $name};
                $addresses = rcube_mime::decode_address_list($addresses, null, true, $headers->charset);
                $value     = array();

                foreach ((array) $addresses as $addr) {
                    $idx = count($value);
                    if ($addr['mailto']) {
                        $value[$idx]['address'] = $addr['mailto'];
                    }
                    if ($addr['name']) {
                        $value[$idx]['name'] = $addr['name'];
                    }
                }

                if ($name == 'from' && !empty($value)) {
                    $value = $value[0];
                }

                break;

            case 'categories':
                $api   = kolab_api::get_instance();
                $value = (array) $api->backend->get_tags($this);
                break;

            case 'references':
            case 'in-reply-to':
            case 'message-id':
                $value = $headers->get($name);
                break;

            case 'text':
            case 'html':
                $value = $this->body($name == 'html');
                break;

            case 'has-attach':
                if (isset($this->message->attachments)) {
                    $value = !empty($this->message->attachments);
                }
                else if (isset($headers->attachments)) {
                    $value = !empty($headers->attachments);
                }
                else {
                    // We don't have the whole structure,
                    // we can only make a guess based on message mimetype
                    $regex = '/^(application\/|multipart\/(m|signed|report))/i';
                    $value = (bool) preg_match($regex, $headers->ctype);
                }

                break;

            case 'attachments':
                if ($message = $this->get_message()) {
                    return $message->attachments;
                }
                return array();
        }

        // add the value to the result
        if ($value !== null && $value !== '' && (!is_array($value) || !empty($value))) {
            // make sure we have utf-8 here
            $value = rcube_charset::clean($value);
        }

        return $value;
    }

    /**
     * Return message data as an array
     *
     * @param array $filetr Optional properties filter
     *
     * @return array Message/headers data
     */
    public function data($filter = array())
    {
        $result = array();
        $fields = self::$header_fields;

        if (!empty($filter)) {
            $fields = array_intersect($fields, $filter);
        }

        foreach ($fields as $field) {
            $value = $this->{$field};

            // add the value to the result
            if ($value !== null && $value !== '') {
                $result[$field] = $value;
            }
        }

        // complete rcube_message object, we can set more props, e.g. body content
        if (!$this->is_header) {
            foreach (array('text', 'html') as $prop) {
                if ($value = $this->{$prop}) {
                    $result[$prop] = $value;
                }
            }
        }

        return $result;
    }

    /**
     * Check if the original message has been modified
     *
     * @return bool True if the message has been modified
     *              since the object creation
     */
    public function changed()
    {
        return !empty($this->data);
    }

    /**
     * Check object validity
     *
     * @return bool True if the object is valid
     */
    public function valid()
    {
        if (empty($this->message)) {
            // @TODO: check required properties of a new message?
        }

        return $this->valid;
    }

    /**
     * Get content of a specific part of this message
     *
     * @param string  $mime_id   Part ID
     * @param boolean $formatted Enables formatting of text/* parts bodies
     * @param int     $max_bytes Only return/read this number of bytes
     * @param mixed   $mode      NULL to return a string, -1 to print body
     *                           or file pointer to save the body into
     *
     * @return string|bool Part content or operation status
     */
    public function get_part_body($mime_id, $formatted = false, $max_bytes = 0, $mode = null)
    {
        if ($message = $this->get_message()) {
            return $message->get_part_body($mime_id, $formatted, $max_bytes, $mode);
        }

        return false;
    }

    /**
     * Save the message in specified folder
     *
     * @param string $folder IMAP folder name
     *
     * @return string New message UID
     * @throws kolab_api_exception
     */
    public function save($folder = null)
    {
        if (empty($this->data)) {
            throw new kolab_api_exception(kolab_api_exception::SERVER_ERROR, array(
                    'file'    => __FILE__,
                    'line'    => __LINE__,
                    'message' => 'Nothing to save. Did you use kolab_api_mail::changed()?'
            ));
        }

        $message = $this->get_message();

        if (empty($message) && !strlen($folder)) {
            throw new kolab_api_exception(kolab_api_exception::SERVER_ERROR, array(
                    'file'    => __FILE__,
                    'line'    => __LINE__,
                    'message' => 'Folder not specified'
            ));
        }

        // Create message content
        if ($stream = $this->create_message_stream()) {
            // Save the message
            $uid = $this->save_message($stream, $folder ?: $message->folder);
        }
        // it is a message update without its source change
        // e.g. only flags/categories changed
        else {
            $uid = $this->uid;
        }

        // Update IMAP flags and categories/tags if needed
        $this->update_flags($uid, $folder);
        $this->update_categories($uid, $folder, $message);

        return $uid;
    }

    /**
     * Send the message
     *
     * @return bool True on success
     * @throws kolab_api_exception
     */
    public function send()
    {
        // Create message content
        $stream = $this->create_message_stream(true);

        if (empty($this->from_address)) {
            throw new kolab_api_exception(kolab_api_exception::INVALID_REQUEST, null, "No sender found");
        }

        if (empty($this->recipients)) {
            throw new kolab_api_exception(kolab_api_exception::INVALID_REQUEST, null, "No recipients found");
        }

        $this->send_message_stream($stream);

        return true;
    }

    /**
     * Add an attachment to the message
     *
     * @param rcube_message_part $attachment Attachment data
     *
     * @return string New message UID on success
     * @throws kolab_api_exception
     */
    public function attachment_add($attachment)
    {
        if (!($message = $this->get_message())) {
            throw new kolab_api_exception(kolab_api_exception::SERVER_ERROR);
        }

        $this->attach_data['create'][] = $attachment;

        // Create message content
        $stream = $this->create_message_stream();

        // Save the message
        return $this->save_message($stream, $message->folder);
    }

    /**
     * Remove attachment from the message
     *
     * @param string $id Attachment id
     *
     * @return string New message UID on success
     * @throws kolab_api_exception
     */
    public function attachment_delete($id)
    {
        if (!($message = $this->get_message())) {
            throw new kolab_api_exception(kolab_api_exception::SERVER_ERROR);
        }

        foreach ((array) $message->attachments as $attach) {
            if ($attach->mime_id == $id) {
                $attachment = $attach;
            }
        }

        if (empty($attachment)) {
            throw new kolab_api_exception(kolab_api_exception::NOT_FOUND);
        }

        $this->attach_data['delete'][] = $attachment;

        // Create message content
        $stream = $this->create_message_stream();

        // Save the message
        return $this->save_message($stream, $message->folder);
    }

    /**
     * Update specified attachment in the message
     *
     * @param rcube_message_part $attachment Attachment data
     *
     * @return string New message UID on success
     * @throws kolab_api_exception
     */
    public function attachment_update($attachment)
    {
        if (!($message = $this->get_message())) {
            throw new kolab_api_exception(kolab_api_exception::SERVER_ERROR);
        }

        $this->attach_data['update'][] = $attachment;

        // Create message content
        $stream = $this->create_message_stream();

        // Save the message
        return $this->save_message($stream, $message->folder);
    }

    /**
     * Create message stream
     */
    protected function create_message_stream($send_mode = false)
    {
        $api      = kolab_api::get_instance();
        $message  = $this->get_message();
        $specials = array('flags', 'categories');
        $diff     = array_diff($this->data, $specials);
        $headers  = array();
        $endln    = $this->endln;
        $body_mod = $message && (!empty($diff) || !empty($this->attach_data));

        // header change requested, get old headers
        if ($body_mod) {
            $api->backend->storage->set_folder($message->folder);

            $headers = $api->backend->storage->get_raw_headers($message->uid);
            $headers = self::parse_headers($headers);
        }

        foreach ($this->data as $name => $value) {
            $normalized = self::normalize_header_name($name);
            unset($headers[$normalized]);

            switch ($name) {
            case 'priority':
                unset($headers['X-Priority']);
                $priority   = intval($value);
                $priorities = array(1 => 'highest', 2 => 'high', 4 => 'low', 5 => 'lowest');

                if ($str_priority = $priorities[$priority]) {
                    $headers['X-Priority'] = sprintf("%d (%s)", $priority, ucfirst($str_priority));
                }
                break;

            case 'date':
                // @TODO: date-time format
                $headers['Date'] = $value;
                break;

            case 'from':
                if (!empty($value)) {
                    if (empty($value['address']) || !strpos($value['address'], '@')) {
                        throw new kolab_api_exception(kolab_api_exception::INVALID_REQUEST);
                    }

                    $value = format_email_recipient($value['address'], $value['name']);
                }

                $headers[$normalized] = $value;
                break;

            case 'to':
            case 'cc':
            case 'bcc':
            case 'reply-to':
                $recipients = array();
                foreach ((array) $value as $adr) {
                    if (!is_array($adr) || empty($adr['address']) || !strpos($adr['address'], '@')) {
                        throw new kolab_api_exception(kolab_api_exception::INVALID_REQUEST);
                    }

                    $recipients[] = format_email_recipient($adr['address'], $adr['name']);
                }

                $headers[$normalized] = implode(',', $recipients);
                break;

            case 'references':
            case 'in-reply-to':
            case 'message-id':
            case 'subject':
                if ($value) {
                    $headers[$normalized] = $value;
                }
                break;
            }
        }

        // Prepare message body
        $body_mod = $this->prepare_body($headers);

        // We're going to send this message, we need more data/checks
        if ($send_mode) {
            if (empty($headers['From'])) {
                // get From: address from default identity of the user?
                if ($identity = $api->backend->user->get_identity()) {
                    $headers['From'] = format_email_recipient(
                        format_email($identity['email']), $identity['name']);
                }
            }

            $addresses = rcube_mime::decode_address_list($headers['From'], null, false, null, true);
            $this->from_address = array_shift($addresses);

            // extract mail recipients
            foreach (array('To', 'Cc', 'Bcc') as $idx) {
                if ($headers[$idx]) {
                    $addresses = rcube_mime::decode_address_list($headers[$idx], null, false, null, true);
                    $this->recipients = array_merge($this->recipients, $addresses);
                }
            }

            $this->recipients = array_unique($this->recipients);

            unset($headers['Bcc']);

            $headers['Date'] = $api->user_date();
/*
            if ($mdn_enabled) {
                $headers['Return-Receipt-To']           = $this->from_address;
                $headers['Disposition-Notification-To'] = $this->from_address;
            }
*/
        }

        // Write message headers to the stream
        if (!empty($headers) || empty($message) || $body_mod) {
            // Place Received: headers at the beginning of the message
            // Spam detectors often flag messages with it after the Subject: as spam
            if (!empty($headers['Received'])) {
                $received = $headers['Received'];
                unset($headers['Received']);
                $headers = array('Received' => $received) + $headers;
            }

            if (empty($headers['MIME-Version'])) {
                $headers['MIME-Version'] = '1.0';
            }

            // always add User-Agent header
            if (empty($headers['User-Agent'])) {
                $headers['User-Agent'] .= kolab_api::APP_NAME . ' ' . kolab_api::VERSION;
                if ($agent = $api->config->get('useragent')) {
                    $headers['User-Agent'] .= '/' . $agent;
                }
            }

            if (empty($headers['Message-ID'])) {
                $headers['Message-ID'] = $this->data['message-id'] = $this->gen_message_id();
            }

            // create new message header
            if ($stream = fopen('php://temp/maxmemory:10240000', 'r+')) {
                foreach ($headers as $header_name => $header_value) {
                    if (strlen($header_value)) {
                        $header_value = $this->encode_header($header_name, $header_value);
                        fwrite($stream, $header_name . ": " . $header_value . $endln);
                    }
                }

                fwrite($stream, $endln);
            }
            else {
                throw new kolab_api_exception(kolab_api_exception::SERVER_ERROR, array(
                        'file' => __FILE__,
                        'line' => __LINE__,
                        'message' => 'Failed to open file stream for mail message'
                ));
            }
        }

        // Save/update the message body into the stream
        if ($stream) {
            $this->write_body($stream, $headers);
        }

        return $stream;
    }

    /**
     * Send the message stream using configured method
     */
    protected function send_message_stream($stream)
    {
        $api = kolab_api::get_instance();

        // send thru SMTP server using custom SMTP library
        if ($api->config->get('smtp_server')) {
            // send message
            if (!is_object($api->smtp)) {
                $api->smtp_init(true);
            }

            rewind($stream);

            $headers = null;
            $sent    = $api->smtp->send_mail(
                $this->from_address, $this->recipients, $headers, $stream, $smtp_opts);

            // log error
            if (!$sent) {
                $smtp_response = $api->smtp->get_response();
//                $smtp_error    = $api->smtp->get_error();

                throw new kolab_api_exception(kolab_api_exception::SERVER_ERROR, array(
                        'line'    => __LINE__,
                        'file'    => __FILE__,
                        'code'    => 800,
                        'type'    => 'smtp',
                        'message' => "SMTP error: " . join("\n", $smtp_response),
                ));
            }
        }
        else {
            throw new kolab_api_exception(kolab_api_exception::SERVER_ERROR, array(
                    'line'    => __LINE__,
                    'file'    => __FILE__,
                    'code'    => 800,
                    'type'    => 'smtp',
                    'message' => "SMTP server not configured. Really need smtp_server option to be set.",
            ));
        }

        // $api->plugins->exec_hook('message_sent', array('headers' => array(), 'body' => $stream));

        if ($api->config->get('smtp_log')) {
            rcube::write_log('sendmail', sprintf("User %s [%s]; Message for %s; %s",
                $api->get_user_name(),
                $_SERVER['REMOTE_ADDR'],
                implode(',', $this->recipients),
                !empty($smtp_response) ? join('; ', $smtp_response) : ''));
        }

        return true;
    }

    /**
     * Prepare message body and content headers
     */
    protected function prepare_body(&$headers)
    {
        $message  = $this->get_message();
        $body_mod = array_key_exists('text', $this->data)
            || array_key_exists('html', $this->data)
            || !empty($this->attach_data);

        if (!$body_mod) {
            return false;
        }

        if (!empty($this->attach_data['create']) || !empty($this->attach_data['update'])) {
            $ctype = 'multipart/mixed';
        }
        else {
            $ctype = $this->data['html'] ? 'multipart/alternative' : 'text/plain';
        }

        // Get/set Content-Type header of the modified message
        if ($old_ctype = $headers['Content-Type']) {
            if (preg_match('/boundary="?([a-z0-9-\'\(\)+_\,\.\/:=\? ]+)"?/i', $old_ctype, $matches)) {
                $boundary = $matches[1];
            }

            if ($pos = strpos($old_ctype, ';')) {
                $old_ctype = substr($old_ctype, 0, $pos);
            }

            if ($old_ctype == 'multipart/mixed') {
                // replace first part (if it is text/plain or multipart/alternative)
                $ctype = $old_ctype;
            }
        }

        $headers['Content-Type'] = $ctype;

        if ($ctype == 'text/plain') {
            $headers['Content-Type'] .= '; charset=' . RCUBE_CHARSET;
        }
        else if (!$boundary) {
            $boundary = '_' . md5(rand() . microtime());
        }

        if ($boundary) {
            $headers['Content-Type'] .= ';' . $this->endln . " boundary=\"$boundary\"";
        }

        // create message body
        if ($html = $this->data['html']) {
            $text = $this->data['text'];

            if ($text === null) {
                $h2t  = new rcube_html2text($html);
                $text = $h2t->get_text();
            }

            $this->body_text = quoted_printable_encode($text);
            $this->body_html = quoted_printable_encode($html);
        }
        else if ($text = $this->data['text']) {
            $headers['Content-Transfer-Encoding'] = 'quoted-printable';
            $this->body_text = quoted_printable_encode($text);
        }

        $this->boundary = $boundary;

        // make sure all line endings are CRLF
        $this->body_text = preg_replace('/\r?\n/', $this->endln, $this->body_text);
        $this->body_html = preg_replace('/\r?\n/', $this->endln, $this->body_html);

        return true;
    }

    /**
     * Write message body to the stream
     */
    protected function write_body($stream, $headers)
    {
        $api      = kolab_api::get_instance();
        $endln    = $this->endln;
        $message  = $this->get_message();
        $body_mod = array_key_exists('text', $this->data) || array_key_exists('html', $this->data);
        $modified = $body_mod || !empty($this->attach_data);

        // @TODO: related parts for inline images

        // nothing changed in the modified message body...
        if (!$modified && !empty($message)) {
            // just copy the content to the output stream
            $api->backend->storage->get_raw_body($message->uid, $stream, 'TEXT');
        }
        // new message creation, or the message does not have any attachments
        else if (empty($message) || ($message->headers->ctype != 'multipart/mixed' && empty($this->attach_data))) {
            // Here we do not have attachments yet, so we only have two
            // simple options: multipart/alternative or text/plain
            $this->write_body_content($stream, $this->boundary);
        }
        // body changed or attachments added, non-multipart message
        else if ($message->headers->ctype != 'multipart/mixed') {
            fwrite($stream, '--' . $this->boundary . $endln);
            // write body
            if (array_key_exists('text', $this->data) || array_key_exists('html', $this->data)) {
                // new body
                $this->write_body_content($stream, $this->boundary);
            }
            else {
                // existing body, just copy old content to the stream
                $api->backend->storage->get_raw_body($message->uid, $stream, 'TEXT');
            }

            fwrite($stream, $endln);

            // write attachments, here we can only have new attachments
            foreach ((array) $this->attach_data['create'] as $attachment) {
                fwrite($stream, '--' . $this->boundary . $endln);
                $this->write_attachment($stream, $attachment);
            }

            fwrite($stream, $endln . '--' . $this->boundary . '--' . $endln);
        }
        // body or attachments changed, multipart/mixed message
        else {
            // get old TEXT of the message
            $body_stream = fopen('php://temp/maxmemory:10240000', 'r+');
            $api->backend->storage->get_raw_body($message->uid, $body_stream, 'TEXT');
            rewind($body_stream);

            $num    = 0;
            $ignore = false;
            $regexp = '/^--' . preg_quote($this->boundary, '/') . '(--|)\r?\n$/';

            // Go and replace bodies...
            while (($line = fgets($body_stream, 4096)) !== false) {
                // boundary line
                if ($line[0] === '-' && $line[1] === '-' && preg_match($regexp, $line, $m)) {
                    // this is the end of the message, add new attachment(s) here
                    if ($m[1] == '--') {
                        foreach ((array) $this->attach_data['create'] as $attachment) {
                            fwrite($stream, '--' . $this->boundary . $endln);
                            $this->write_attachment($stream, $attachment);
                        }

                        fwrite($stream, $line);
                        break;
                    }

                    $num++;
                    $ignore = false;

                    // delete this part
                    foreach ((array) $this->attach_data['delete'] as $attachment) {
                        if ($attachment->mime_id == $num) {
                            $ignore = true;
                            continue 2;
                        }
                    }

                    // update this part
                    foreach ((array) $this->attach_data['update'] as $attachment) {
                        if ($attachment->mime_id == $num) {
                            fwrite($stream, $line);
                            $this->write_attachment($stream, $attachment);
                            $ignore = true;
                            continue 2;
                        }
                    }

                    // find the first part (expected to be the text or alternative
                    if ($num == 1 && $body_mod) {
                        $ignore   = true;
                        $boundary = '_' . md5(rand() . microtime());
                        fwrite($stream, $line);
                        $this->write_body_content($stream, $boundary, true);
                        continue;
                    }
                }
                else if ($ignore) {
                    continue;
                }

                fwrite($stream, $line);
            }

            fclose($body_stream);
        }
    }

    /**
     * Write configured text/plain or multipart/alternative
     * part content into message stream
     */
    protected function write_body_content($stream, $boundary, $with_headers = false)
    {
        $endln = $this->endln;

        // multipart/alternative
        if (strlen($this->body_html)) {
            if ($with_headers) {
                fwrite($stream, 'Content-Type: multipart/alternative;' . $endln
                    . " boundary=\"$boundary\"" . $endln . $endln);
            }

            fwrite($stream, '--' . $boundary . $endln
                . 'Content-Transfer-Encoding: quoted-printable' . $endln
                . 'Content-Type: text/plain; charset=UTF-8' . $endln . $endln);
            fwrite($stream, $this->body_text);
            fwrite($stream, $endln . '--' . $boundary . $endln
                . 'Content-Transfer-Encoding: quoted-printable' . $endln
                . 'Content-Type: text/html; charset=UTF-8' . $endln . $endln);
            fwrite($stream, $this->body_html);
            fwrite($stream, $endln . '--' . $boundary . '--' . $endln);
        }
        // text/plain
        else if (strlen($this->body_text)) {
            if ($with_headers) {
                fwrite($stream, 'Content-Transfer-Encoding: quoted-printable' . $endln
                    . 'Content-Type: text/plain; charset=UTF-8' . $endln . $endln);
            }

            // make sure all line endings are CRLF
            $plainTextPart = preg_replace('/\r?\n/', "\r\n", $plainTextPart);

            fwrite($stream, $this->body_text);
        }
    }

    /**
     * Get rcube_message object of the assigned message
     */
    protected function get_message()
    {
        if ($this->message && !($this->message instanceof rcube_message)) {
            $this->message = new rcube_message($this->message->uid, $this->message->folder);

            if (empty($this->message->headers)) {
                throw new kolab_api_exception(kolab_api_exception::SERVER_ERROR);
            }
        }

        return $this->message;
    }

    /**
     * Parse message source with headers
     */
    protected static function parse_headers($headers)
    {
        // Parse headers
        $headers = str_replace("\r\n", "\n", $headers);
        $headers = explode("\n", trim($headers));

        $ln    = 0;
        $lines = array();

        foreach ($headers as $line) {
            if (ord($line[0]) <= 32) {
                $lines[$ln] .= (empty($lines[$ln]) ? '' : "\r\n") . $line;
            }
            else {
                $lines[++$ln] = trim($line);
            }
        }

        // Unify char-case of header names
        $headers = array();
        foreach ($lines as $line) {
            list($field, $string) = explode(':', $line, 2);
            if ($field = self::normalize_header_name($field)) {
                $headers[$field] = trim($string);
            }
        }

        return $headers;
    }

    /**
     * Normalize (fix) header names
     */
    protected static function normalize_header_name($name)
    {
        $headers_map = array(
            'subject' => 'Subject',
            'from'    => 'From',
            'to'      => 'To',
            'cc'      => 'Cc',
            'bcc'     => 'Bcc',
            'date'    => 'Date',
            'reply-to'     => 'Reply-To',
            'in-reply-to'  => 'In-Reply-To',
            'x-priority'   => 'X-Priority',
            'message-id'   => 'Message-ID',
            'references'   => 'References',
            'content-type' => 'Content-Type',
            'content-transfer-encoding' => 'Content-Transfer-Encoding',
        );

        $name_lc = strtolower($name);

        return isset($headers_map[$name_lc]) ? $headers_map[$name_lc] : $name;
    }

    /**
     * Save the message into IMAP folder and delete the old one
     */
    protected function save_message($stream, $folder)
    {
        $api     = kolab_api::get_instance();
        $message = $this->get_message();

        // save the message
        $data  = array($stream);
        $saved = $api->backend->storage->save_message($folder, $data);

        @fclose($stream);

        if (empty($saved)) {
            throw new kolab_api_exception(kolab_api_exception::SERVER_ERROR, array(
                    'file' => __FILE__,
                    'line' => __LINE__,
                    'message' => 'Failed to save the message in storage'
            ));
        }

        // delete the old message
        if ($saved && $message && $message->uid) {
            $api->backend->storage->delete_message($message->uid, $folder);
        }

        return $saved;
    }

    /**
     * Return message body (in specified format, html or text)
     */
    protected function body($html = true)
    {
        if ($message = $this->get_message()) {
            if ($html) {
                $html = $message->first_html_part($part, true);

                if ($html) {
                    // charset was converted to UTF-8 in rcube_storage::get_message_part(),
                    // change/add charset specification in HTML accordingly
                    $meta = '<meta http-equiv="Content-Type" content="text/html; charset=' . RCUBE_CHARSET . '" />';

                    // remove old meta tag and add the new one, making sure
                    // that it is placed in the head
                    $html = preg_replace('/<meta[^>]+charset=[a-z0-9-_]+[^>]*>/Ui', '', $html);
                    $html = preg_replace('/(<head[^>]*>)/Ui', '\\1' . $meta, $html, -1, $rcount);

                    if (!$rcount) {
                        $html = '<head>' . $meta . '</head>' . $html;
                    }
                }

                return $html;
            }

            $plain = $message->first_text_part($part, true);

            if ($part === null && $message->body) {
                $plain = $message->body;
            }
            else if ($part->ctype_secondary == 'plain' && $part->ctype_parameters['format'] == 'flowed') {
                $plain = rcube_mime::unfold_flowed($plain);
            }

            return $plain;
        }
    }

    /**
     * Encode header value
     */
    protected function encode_header($name, $value)
    {
        $mime_part = new Mail_mimePart;
        return $mime_part->encodeHeader($name, $value, RCUBE_CHARSET, 'quoted-printable', $this->endln);
    }

    /**
     * Unique Message-ID generator.
     *
     * @return string Message-ID
     */
    public function gen_message_id()
    {
        $api         = kolab_api::get_instance();
        $local_part  = md5(uniqid('kolab'.mt_rand(), true));
        $domain_part = $api->backend->user->get_username('domain');

        // Try to find FQDN, some spamfilters doesn't like 'localhost' (#1486924)
        if (!preg_match('/\.[a-z]+$/i', $domain_part)) {
            foreach (array($_SERVER['HTTP_HOST'], $_SERVER['SERVER_NAME']) as $host) {
                $host = preg_replace('/:[0-9]+$/', '', $host);
                if ($host && preg_match('/\.[a-z]+$/i', $host)) {
                    $domain_part = $host;
                }
            }
        }

        return sprintf('<%s@%s>', $local_part, $domain_part);
    }

    /**
     * Write attachment body with headers into the output stream
     */
    protected function write_attachment($stream, $attachment)
    {
        $api      = kolab_api::get_instance();
        $message  = $this->get_message();
        $temp_dir = $api->config->get('temp_dir');

        // use Mail_mimePart functionality for simplicity
        $params = array(
            'eol'          => $this->endln,
            'encoding'     => $attachment->mimetype == 'message/rfc822' ? '8bit' : 'base64',
            'content_type' => $attachment->mimetype,
            'body_file'    => $attachment->path,
            'disposition'  => 'attachment',
            'filename'     => $attachment->filename,
            'name_encoding'   => 'quoted-printable',
            'headers_charset' => RCUBE_CHARSET,
        );

        if ($attachment->content_id) {
            $params['cid'] = rtrim($attachment->content_id, '<>');
        }

        if ($attachment->content_location) {
            $params['location'] = $attachment->content_location;
        }

        // Get attachment body if both 'path' and 'data' are NULL
        // this is the case when we modify only attachment metadata, e.g. filename
        if (empty($attachment->path) && $attachment->data === null
            && !empty($message) && !empty($attachment->mime_id)
        ) {
            // @TODO: do this with temp files
            $api->backend->storage->set_folder($message->folder);
            $body = $api->backend->storage->get_raw_body($message->uid, null, $attachment->mime_id . '.TEXT');

            if ($attachment->encoding == 'base64') {
                $body = base64_decode($body);
            }
            else if ($attachment->encoding == 'quoted-printable') {
                $body = quoted_printable_decode($body);
            }

            $attachment->data = $body;
        }

        $mime      = new Mail_mimePart($attachment->data, $params);
        $temp_file = tempnam($temp_dir, 'msgPart');

        // @TODO: implement encodeToStream()
        $result = $mime->encodeToFile($temp_file);

        if ($result instanceof PEAR_Error) {
            throw new kolab_api_exception(kolab_api_exception::SERVER_ERROR, $result);
        }

        if ($fd = fopen($temp_file, 'r')) {
            stream_copy_to_stream($fd, $stream);
            fwrite($stream, $this->endln);
            fclose($fd);
            @unlink($temp_file);
        }
        else {
            throw new kolab_api_exception(kolab_api_exception::SERVER_ERROR);
        }
    }

    /**
     * Apply flag changes
     */
    protected function update_flags($uid, $folder)
    {
        // IMAP flags change requested
        if (!array_key_exists('flags', $this->data)) {
            return;
        }

        $api        = kolab_api::get_instance();
        $old_flags  = $this->flags;
        $folder     = $folder ?: $this->folder;
        $old_folder = $this->folder ?: $folder;

        // set new flags
        foreach ((array) $this->data['flags'] as $flag) {
            if (($key = array_search($flag, $old_flags)) !== false) {
                unset($old_flags[$key]);
            }
            else {
                $flag = strtoupper($flag);
                $api->backend->storage->set_flag($uid, $flag, $folder);
            }
        }

        // unset remaining old flags
        foreach ($old_flags as $flag) {
            $flag = 'UN' . strtoupper($flag);
            $api->backend->storage->set_flag($uid, $flag, $old_folder);
        }
    }

    /**
     * Apply categories changes
     */
    protected function update_categories($uid, $folder, $message)
    {
        // IMAP flags change requested
        if (!array_key_exists('categories', $this->data) && $uid == $this->uid) {
            return;
        }

        $config        = kolab_storage_config::get_instance();
        $api           = kolab_api::get_instance();
        $old_uid       = $this->uid;
        $folder        = $folder ?: $this->folder;
        $old_folder    = $this->folder ?: $folder;
        $categories    = (array) $this->data['categories'];
        $categories_lc = array_map('mb_strtolower', $categories);

        $delete_member = $config->build_member_url(array(
                'folder' => $old_folder,
                'uid'    => $old_uid ?: $uid
        ));

        $create_member = $config->build_member_url(array(
                'folder'     => $folder,
                'uid'        => $uid,
                'message-id' => $this->{'message-id'},
                'date'       => $this->date,
                'subject'    => $this->subject,
        ));

        foreach ($config->get_tags() as $tag) {
            $tag_name = mb_strtolower($tag['name']);
            $modified = false;
            $is_new   = ($i = array_search($tag_name, $categories_lc)) !== false;

            // remove a member of the relation
            if (!$is_new || ($old_uid && $old_uid != $uid)) {
                foreach ($tag['members'] as $idx => $member) {
                    if ($member == $delete_member || strpos($member, $delete_member . '?') === 0) {
                        unset($tag['members'][$idx]);
                        $modified = true;
                    }
                }
            }

            // add a member to the relation
            if ($is_new) {
                unset($categories[$i]);

                if ($modified || $old_uid != $uid) {
                    $tag['members'][] = $create_member;
                    $modified = true;
                }
            }

            // update tag/relation object
            if ($modified) {
                $config->save($tag, 'relation', $tag['uid']);
            }
        }

        // add non-existing categories
        foreach ($categories as $cat) {
            $tag = array(
                'name'     => $cat,
                'category' => 'tag',
                'members'  => array($create_member),
            );

            $config->save($tag, 'relation');
        }
    }
}
