<?php

/**
 +--------------------------------------------------------------------------+
 | This file is part of the Kolab REST API                                  |
 |                                                                          |
 | Copyright (C) 2012-2015, Kolab Systems AG                                |
 |                                                                          |
 | This program is free software: you can redistribute it and/or modify     |
 | it under the terms of the GNU Affero General Public License as published |
 | by the Free Software Foundation, either version 3 of the License, or     |
 | (at your option) any later version.                                      |
 |                                                                          |
 | This program is distributed in the hope that it will be useful,          |
 | but WITHOUT ANY WARRANTY; without even the implied warranty of           |
 | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the             |
 | GNU Affero General Public License for more details.                      |
 |                                                                          |
 | You should have received a copy of the GNU Affero General Public License |
 | along with this program. If not, see <http://www.gnu.org/licenses/>      |
 +--------------------------------------------------------------------------+
 | Author: Aleksander Machniak <machniak@kolabsys.com>                      |
 +--------------------------------------------------------------------------+
*/

class kolab_api_attachments extends kolab_api
{
    protected $model = 'attachment';

    public function run()
    {
        $this->initialize_handler();

        // Load required attachments plugin (for uploads handling)
        if (!class_exists('filesystem_attachments', false)) {
            $this->plugins->load_plugin('filesystem_attachments', true);
        }

        $path   = $this->input->path;
        $method = $this->input->method;

        if ($path[0] == 'upload' && count($path) == 1 && $method == 'POST') {
            $this->api_attachment_upload();
        }
        else if ($path[0] && $path[1] && $method == 'POST') {
            $this->api_attachment_create();
        }
        else if ($path[2]) {
            if ($method == 'GET') {
                if ($path[3] === 'get') {
                    $this->api_attachment_body();
                }
                else {
                    $this->api_attachment_info();
                }
            }
            else if ($method == 'PUT') {
                $this->api_attachment_update();
            }
            else if ($method == 'HEAD') {
                $this->api_attachment_exists();
            }
            else if ($method == 'DELETE') {
                $this->api_attachment_delete();
            }
        }

        throw new kolab_api_exception(kolab_api_exception::NOT_FOUND);
    }

    /**
     * Fetch attachment info
     */
    protected function api_attachment_info()
    {
        $folder     = $this->input->path[0];
        $object_uid = $this->input->path[1];
        $attach_uid = $this->input->path[2];
        $object     = $this->backend->object_get($folder, $object_uid);
        $context    = array(
            'folder_uid' => $folder,
            'object_uid' => $object_uid,
            'object'     => $object
        );

        // get attachment part from the object
        $attachment = $this->get_attachment($object, $attach_uid);

        $this->output->send($attachment, $this->model, $context);
    }

    /**
     * Create an attachment
     */
    protected function api_attachment_create()
    {
        $folder     = $this->input->path[0];
        $object_uid = $this->input->path[1];
        $object     = $this->backend->object_get($folder, $object_uid);
        $context    = array(
            'folder_uid' => $folder,
            'object_uid' => $object_uid,
            'object'     => $object
        );

        // parse input, attach uploaded file, set input properties
        $attachment = $this->handle_attachment_input();

        // add the attachment to the message/object
        $uid = $this->backend->attachment_create($object, $attachment);

        // @TODO: should we keep the uploaded file for longer?
        if ($attachment->upload_id) {
            unset($_SESSION['uploads'][$attachment->upload_id]);
        }

        $this->output->send(array('uid' => $uid), $this->model, $context, array('uid'));
    }

    /**
     * Update specified attachment
     */
    protected function api_attachment_update()
    {
        $folder     = $this->input->path[0];
        $object_uid = $this->input->path[1];
        $attach_uid = $this->input->path[2];
        $object     = $this->backend->object_get($folder, $object_uid);
        $context    = array(
            'folder_uid' => $folder,
            'object_uid' => $object_uid,
            'object'     => $object
        );

        // get attachment part from the object
        $old_attachment = $this->get_attachment($object, $attach_uid);

        // parse input, attach uploaded file, set input properties
        $attachment = $this->handle_attachment_input();

        // merge attachment properties
        $modified = false;
        $fields   = array('path', 'data', 'size', 'filename', 'mimetype',
            'disposition', 'content_id', 'content_location');

        foreach ($fields as $idx) {
            if (isset($attachment->{$idx})) {
                $old_attachment->{$idx} = $attachment->{$idx};
                $modified = true;
            }
        }

        if (!$modified) {
            throw new kolab_api_exception(kolab_api_exception::INVALID_REQUEST);
        }

        // update the attachment
        $uid = $this->backend->attachment_update($object, $old_attachment);

        // @TODO: should we keep the uploaded file for longer?
        if ($attachment->upload_id) {
            unset($_SESSION['uploads'][$atttachment->upload_id]);
        }

        $this->output->send(array('uid' => $uid), $this->model, $context, array('uid'));
    }

    /**
     * Check if specified attachment exists
     */
    protected function api_attachment_exists()
    {
        $folder     = $this->input->path[0];
        $object_uid = $this->input->path[1];
        $attach_uid = $this->input->path[2];
        $object     = $this->backend->object_get($folder, $object_uid);

        // get attachment part from the object
        $attachment = $this->get_attachment($object, $attach_uid);

        $this->output->send_status(kolab_api_output::STATUS_OK);
    }

    /**
     * Remove specified attachment
     */
    protected function api_attachment_delete()
    {
        $folder     = $this->input->path[0];
        $object_uid = $this->input->path[1];
        $attach_uid = $this->input->path[2];
        $object     = $this->backend->object_get($folder, $object_uid);
        $context    = array(
            'folder_uid' => $folder,
            'object_uid' => $object_uid,
            'object'     => $object
        );

        $uid = $this->backend->attachment_delete($object, $attach_uid);

        $this->output->send(array('uid' => $uid), $this->model, $context, array('uid'));
    }

    /**
     * Fetch attachment body
     */
    protected function api_attachment_body()
    {
        $folder     = $this->input->path[0];
        $object_uid = $this->input->path[1];
        $attach_uid = $this->input->path[2];
        $object     = $this->backend->object_get($folder, $object_uid);

        // get attachment part from the object
        $attachment = $this->get_attachment($object, $attach_uid);

        // @TODO: set headers

        // print attachment body
        $this->backend->attachment_get($object, $attach_uid, -1);
        exit;
    }

    /**
     * Upload attachment body
     */
    protected function api_attachment_upload()
    {
        // Binary file content in POST body
        if (strtolower(rcube_utils::request_header('Content-Type')) == 'application/octet-stream') {
            $length   = rcube_utils::request_header('Content-Length');
            $temp_dir = unslashify($this->config->get('temp_dir'));
            $path     = tempnam($temp_dir, 'kolabUpload');

            // Create stream to copy input into a temp file
            $input = fopen('php://input', 'r');
            $file  = fopen($path, 'w');

            if (!$input || !$file) {
                throw new kolab_api_exception(kolab_api_exception::SERVER_ERROR, array(
                        'line'    => __LINE__,
                        'file'    => __FILE__,
                        'message' => "Failed opening input or temp file stream",
                ));
            }

            // Create temp file from the input
            $copied = stream_copy_to_stream($input, $file);

            fclose($input);
            fclose($file);

            if ($copied < $length) {
                // @FIXME: can we distinguish reliably when size error should be displayed?
                if ($maxsize = parse_bytes(ini_get('post_max_size'))) {
                    $error = "Maximum file size exceeded (" . $this->show_bytes($maxsize) . ")";
                    throw new kolab_api_exception(kolab_api_exception::INVALID_REQUEST, null, $error);
                }

                throw new kolab_api_exception(kolab_api_exception::SERVER_ERROR, array(
                        'line'    => __LINE__,
                        'file'    => __FILE__,
                        'message' => "Failed copying file upload into a temp file",
                ));
            }

            $name = rcube_utils::request_header('X-Filename') ?: $this->input->args['filename'];

            // Use Roundcube attachments functionality to give
            // redundant_attachments/database_attachments plugins a chance
            $attachment = array(
                'group'    => 'kolab_upload',
                'name'     => $name,
                'mimetype' => rcube_mime::file_content_type($path, $name),
                'path'     => $path,
                'size'     => filesize($path),
            );

            $attachment = $this->plugins->exec_hook('attachment_save', $attachment);

            if ($attachment['status']) {
                unset($attachment['data'], $attachment['status'], $attachment['content_id'], $attachment['abort']);
                $_SESSION['uploads'][$id = $attachment['id']] = $attachment;
            }
            else {
                @unlink($path);
                throw new kolab_api_exception(kolab_api_exception::SERVER_ERROR, array(
                        'line'    => __LINE__,
                        'file'    => __FILE__,
                        'message' => "Failed handling file upload",
                ));
            }
        }
/*
        else if (($path = $_FILES['file']['tmp_name']) && is_string($path)) {
            $err = $_FILES['file']['error'];

            if (!$err) {
                $attachment = $this->plugins->exec_hook('attachment_upload', array(
                    'path'     => $path,
                    'size'     => $_FILES['file']['size'],
                    'name'     => $_FILES['file']['name'],
                    'mimetype' => rcube_mime::file_content_type($path, $_FILES['file']['name'], $_FILES['file']['type']),
                    'group'    => 'kolab_upload',
                ));
            }

            if (!$err && $attachment['status']) {
                $id = $attachment['id'];

                // store new attachment in session
                unset($attachment['status'], $attachment['abort']);
                $_SESSION['uploads'][$id] = $attachment;
            }
            else {  // upload failed
                if ($err == UPLOAD_ERR_INI_SIZE || $err == UPLOAD_ERR_FORM_SIZE) {
                    $maxsize = parse_bytes(ini_get('upload_max_filesize'));
                    $error   = "Maximum file size exceeded (" . $this->show_bytes($maxsize) . ")";

                    throw new kolab_api_exception(kolab_api_exception::INVALID_REQUEST, null, $error);
                }

                throw new kolab_api_exception(kolab_api_exception::SERVER_ERROR, array(
                        'line'    => __LINE__,
                        'file'    => __FILE__,
                        'message' => "Failed handling file upload",
                ));
            }
        }
        else {
            // if filesize exceeds post_max_size then $_FILES array is empty,
            // show filesizeerror instead of fileuploaderror
            if ($maxsize = parse_bytes(ini_get('post_max_size'))) {
                $error = "Maximum file size exceeded (" . $this->show_bytes($maxsize) . ")";
                throw new kolab_api_exception(kolab_api_exception::INVALID_REQUEST, null, $error);
            }

            throw new kolab_api_exception(kolab_api_exception::SERVER_ERROR, array(
                    'line'    => __LINE__,
                    'file'    => __FILE__,
                    'message' => "Failed handling file upload",
            ));
        }
*/
        else {
            throw new kolab_api_exception(kolab_api_exception::INVALID_REQUEST);
        }

        $this->output->send(array('upload-id' => $id), $this->model);
    }

    /**
     * Find attachment in an object/message
     */
    protected function get_attachment($object, $id)
    {
        if ($object) {
            $attachments = (array) $this->get_object_attachments($object);

            foreach ($attachments as $attachment) {
                if ($attachment->mime_id == $id) {
                    return $attachment;
                }
            }
        }

        throw new kolab_api_exception(kolab_api_exception::NOT_FOUND);
    }

    /**
     * Create a human readable string for a number of bytes
     *
     * @param int Number of bytes
     *
     * @return string Byte string
     */
    public static function show_bytes($bytes)
    {
        if ($bytes >= 1073741824) {
            $gb  = $bytes/1073741824;
            $str = sprintf($gb >= 10 ? "%d " : "%.1f ", $gb) . 'GB';
        }
        else if ($bytes >= 1048576) {
            $mb  = $bytes/1048576;
            $str = sprintf($mb >= 10 ? "%d " : "%.1f ", $mb) . 'MB';
        }
        else if ($bytes >= 1024) {
            $str = sprintf("%d ",  round($bytes/1024)) . 'KB';
        }
        else {
            $str = sprintf('%d ', $bytes) . 'B';
        }

        return $str;
    }

    /**
     * Handle attachment input data with uploads handling
     */
    protected function handle_attachment_input()
    {
        $attachment = $this->input->input('attachment');

        // if upload-id is specified check if it exists
        $upload_id = $attachment->upload_id ?: 0;
        $session   = $_SESSION['uploads'][$upload_id];

        if ($upload_id && empty($session)) {
            $error = "Invalid file upload identifier";
            throw new kolab_api_exception(kolab_api_exception::INVALID_REQUEST, null, $error);
        }

        if ($session) {
            // get attachment from attachment storage
            $session = $this->plugins->exec_hook('attachment_get', $session);

            $fallback_fields = array(
                'name'     => 'filename',
                'mimetype' => 'mimetype',
            );

            foreach ($fallback_fields as $sess_idx => $attach_idx) {
                if (!empty($session[$sess_idx])) {
                    $attachment->{$attach_idx} = $session[$sess_idx];
                }
            }

            $fields = array('path', 'data', 'size');

            foreach ($fields as $idx) {
                $attachment->{$idx} = $session[$idx];
            }
        }
        else {
            // unset some fields
            $attachment->size = null;
        }

        return $attachment;
    }
}
