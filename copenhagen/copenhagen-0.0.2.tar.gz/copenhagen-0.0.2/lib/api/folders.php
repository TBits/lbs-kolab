<?php

/**
 +--------------------------------------------------------------------------+
 | This file is part of the Kolab REST API                                  |
 |                                                                          |
 | Copyright (C) 2012-2015, Kolab Systems AG                                |
 |                                                                          |
 | This program is free software: you can redistribute it and/or modify     |
 | it under the terms of the GNU Affero General Public License as published |
 | by the Free Software Foundation, either version 3 of the License, or     |
 | (at your option) any later version.                                      |
 |                                                                          |
 | This program is distributed in the hope that it will be useful,          |
 | but WITHOUT ANY WARRANTY; without even the implied warranty of           |
 | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the             |
 | GNU Affero General Public License for more details.                      |
 |                                                                          |
 | You should have received a copy of the GNU Affero General Public License |
 | along with this program. If not, see <http://www.gnu.org/licenses/>      |
 +--------------------------------------------------------------------------+
 | Author: Aleksander Machniak <machniak@kolabsys.com>                      |
 +--------------------------------------------------------------------------+
*/

class kolab_api_folders extends kolab_api
{
    protected $model = 'folder';

    public function run()
    {
        $this->initialize_handler();

        $path           = $this->input->path;
        $method         = $this->input->method;
        $request_length = count($path);

        if (!$request_length && $method == 'POST') {
            $this->api_folder_create();
        }
        else if (!$request_length && $method == 'GET') {
            $this->api_folder_list_folders();
        }
        else if ($request_length >= 1) {
            switch (strtolower((string) $path[1])) {
            case 'objects':
                if ($method == 'HEAD') {
                    $this->api_folder_count_objects();
                }
                else if ($method == 'GET') {
                    $this->api_folder_list_objects();
                }
                break;

            case 'folders':
                if ($method == 'HEAD') {
                    $this->api_folder_count_folders();
                }
                else if ($method == 'GET') {
                    $this->api_folder_list_folders();
                }
                break;

            case 'empty':
                if ($method == 'POST') {
                    $this->api_folder_empty();
                }
                break;

            case 'deleteobjects':
                if ($method == 'POST') {
                    $this->api_folder_delete_objects();
                }
                break;

            case 'move':
                if ($method == 'POST') {
                    $this->api_folder_move_objects();
                }
                break;

            case '':
                if ($request_length == 1) {
                    if ($method == 'GET') {
                        $this->api_folder_info();
                    }
                    else if ($method == 'PUT') {
                        $this->api_folder_update();
                    }
                    else if ($method == 'HEAD') {
                        $this->api_folder_exists();
                    }
                    else if ($method == 'DELETE') {
                        $this->api_folder_delete();
                    }
                }
            }
        }

        throw new kolab_api_exception(kolab_api_exception::NOT_FOUND);
    }

    /**
     * Returns list of folders (all or subfolders of specified folder)
     */
    protected function api_folder_list_folders()
    {
        $root  = $this->input->path[0];
        $list  = $this->backend->folders_list();
        $props = $this->input->args['properties'] ? explode(',', $this->input->args['properties']) : null;

        // filter by parent
        if ($root) {
            $this->filter_folders($list, $root);
        }

        $this->output->send($list, $this->model . '-list', null, $props);
    }

    /**
     * Returns count of folders (all or subfolders of specified folder)
     */
    protected function api_folder_count_folders()
    {
        $root = $this->input->path[0];
        $list = $this->backend->folders_list();

        // filter by parent
        if ($root) {
            $this->filter_folders($list, $root);
        }

        $this->output->headers(array('X-Count' => count($list)));
        $this->output->send_status(kolab_api_output::STATUS_OK);
    }

    /**
     * Returns folders info
     */
    protected function api_folder_info()
    {
        $folder  = $this->input->path[0];
        $info    = $this->backend->folder_info($folder);
        $context = array('object' => $info);
        $props   = $this->input->args['properties'] ? explode(',', $this->input->args['properties']) : null;

        $this->output->send($info, $this->model, $context, $props);
    }

    /**
     * Checks if folder exists
     */
    protected function api_folder_exists()
    {
        $folder = $this->input->path[0];
        $folder = $this->backend->folder_info($folder);

        $this->output->send_status(kolab_api_output::STATUS_OK);
    }

    /**
     * Delete a folder
     */
    protected function api_folder_delete()
    {
        $folder = $this->input->path[0];
        $folder = $this->backend->folder_info($folder);

        $folder->delete();

        $this->output->send_status(kolab_api_output::STATUS_EMPTY);
    }

    /**
     * Update specified folder (rename or set folder type, or state)
     */
    protected function api_folder_update()
    {
        $folder = $this->input->path[0];
        $info   = $this->backend->folder_info($folder);
        $input  = $this->input->input($this->model, false, $info);

        $input->save();

        $this->output->send(array('uid' => $folder), $this->model, null, array('uid'));
    }

    /**
     * Create a folder
     */
    protected function api_folder_create()
    {
        $input = $this->input->input($this->model);
        $uid   = $input->save();

        $this->output->send(array('uid' => $uid), $this->model, null, array('uid'));
    }

    /**
     * Returns list of objects (not folders) in specified folder
     */
    protected function api_folder_list_objects()
    {
        $folder  = $this->input->path[0];
        $type    = $this->backend->folder_type($folder);
        $list    = $this->backend->objects_list($folder);
        $props   = $this->input->args['properties'] ? explode(',', $this->input->args['properties']) : null;
        $context = array('folder_uid' => $folder);

        $this->output->send($list, $type . '-list', $context, $props);
    }

    /**
     * Returns count of objects (not folders) in specified folder
     */
    protected function api_folder_count_objects()
    {
        $folder = $this->input->path[0];
        $count  = $this->backend->objects_count($folder);

        $this->output->headers(array('X-Count' => $count));
        $this->output->send_status(kolab_api_output::STATUS_OK);
    }

    /**
     * Delete objects in specified folder
     */
    protected function api_folder_delete_objects()
    {
        $folder = $this->input->path[0];
        $set    = $this->input->input();

        if (empty($set)) {
            throw new kolab_api_exception(kolab_api_exception::INVALID_REQUEST);
        }

        $this->backend->objects_delete($folder, $set);

        $this->output->send_status(kolab_api_output::STATUS_OK);
    }

    /**
     * Move objects into specified folder
     */
    protected function api_folder_move_objects()
    {
        $folder = $this->input->path[0];
        $target = $this->input->path[2];
        $set    = $this->input->input();

        if (empty($set)) {
            throw new kolab_api_exception(kolab_api_exception::INVALID_REQUEST);
        }

        if ($target === null || $target === '' || $target === $folder) {
            throw new kolab_api_exception(kolab_api_exception::INVALID_REQUEST);
        }

        $this->backend->objects_move($folder, $target, $set);

        $this->output->send_status(kolab_api_output::STATUS_OK);
    }

    /**
     * Remove all objects in specified folder
     */
    protected function api_folder_empty()
    {
        $folder = $this->input->path[0];
        $this->backend->objects_delete($folder, '*');

        $this->output->send_status(kolab_api_output::STATUS_OK);
    }

    /**
     * Filter folders by parent
     */
    protected function filter_folders(&$list, $parent)
    {
        // filter by parent
        if ($parent && ($parent = $this->backend->folder_info($parent))) {
            // we'll compare with 'fullpath' which is in UTF-8
            $path = $parent->fullpath . $this->backend->delimiter;

            foreach ($list as $idx => $folder) {
                if (strpos($folder->fullpath, $path) !== 0) {
                    unset($list[$idx]);
                }
            }
        }

        $list = array_values($list);
    }
}
