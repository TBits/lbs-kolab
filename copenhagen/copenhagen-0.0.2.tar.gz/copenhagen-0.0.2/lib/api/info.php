<?php

/**
 +--------------------------------------------------------------------------+
 | This file is part of the Kolab REST API                                  |
 |                                                                          |
 | Copyright (C) 2012-2015, Kolab Systems AG                                |
 |                                                                          |
 | This program is free software: you can redistribute it and/or modify     |
 | it under the terms of the GNU Affero General Public License as published |
 | by the Free Software Foundation, either version 3 of the License, or     |
 | (at your option) any later version.                                      |
 |                                                                          |
 | This program is distributed in the hope that it will be useful,          |
 | but WITHOUT ANY WARRANTY; without even the implied warranty of           |
 | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the             |
 | GNU Affero General Public License for more details.                      |
 |                                                                          |
 | You should have received a copy of the GNU Affero General Public License |
 | along with this program. If not, see <http://www.gnu.org/licenses/>      |
 +--------------------------------------------------------------------------+
 | Author: Aleksander Machniak <machniak@kolabsys.com>                      |
 +--------------------------------------------------------------------------+
*/

class kolab_api_info extends kolab_api
{
    public function run()
    {
        $this->initialize_handler();

        if ($this->input->method == 'GET' && empty($this->input->path)) {
            // @TODO: It's just a sample
            $info = array(
                'name'         => kolab_api::APP_NAME,
                'version'      => kolab_api::VERSION,
                'capabilities' => array(),
            );

            $this->output->send($info, 'info');
        }

        throw new kolab_api_exception(kolab_api_exception::NOT_FOUND);
    }
}
