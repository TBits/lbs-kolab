<?php

/**
 +--------------------------------------------------------------------------+
 | This file is part of the Kolab REST API                                  |
 |                                                                          |
 | Copyright (C) 2012-2015, Kolab Systems AG                                |
 |                                                                          |
 | This program is free software: you can redistribute it and/or modify     |
 | it under the terms of the GNU Affero General Public License as published |
 | by the Free Software Foundation, either version 3 of the License, or     |
 | (at your option) any later version.                                      |
 |                                                                          |
 | This program is distributed in the hope that it will be useful,          |
 | but WITHOUT ANY WARRANTY; without even the implied warranty of           |
 | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the             |
 | GNU Affero General Public License for more details.                      |
 |                                                                          |
 | You should have received a copy of the GNU Affero General Public License |
 | along with this program. If not, see <http://www.gnu.org/licenses/>      |
 +--------------------------------------------------------------------------+
 | Author: Aleksander Machniak <machniak@kolabsys.com>                      |
 +--------------------------------------------------------------------------+
*/

class kolab_api_mails extends kolab_api
{
    protected $model = 'mail';

    public function run()
    {
        $this->initialize_handler();

        $path   = $this->input->path;
        $method = $this->input->method;

        if ($path[0] === 'submit' && $method == 'POST') {
            // submit a new message
            $this->api_message_submit();
        }
        else if (!$path[1] && $path[0] && $method == 'POST') {
            $this->api_object_create();
        }
        else if ($path[1]) {
            switch (strtolower($path[2])) {
            case 'attachments':
                if ($method == 'HEAD') {
                    $this->api_message_count_attachments();
                }
                else if ($method == 'GET') {
                    $this->api_message_list_attachments();
                }
                break;
/*
            case 'submit':
                if ($method == 'POST') {
                    // submit an existing message
                    $this->api_message_submit($path[0], $path[1]);
                }
                break;
*/
            case '':
                if ($method == 'GET') {
                    $this->api_object_info();
                }
                else if ($method == 'PUT') {
                    $this->api_object_update();
                }
                else if ($method == 'HEAD') {
                    $this->api_object_exists();
                }
                else if ($method == 'DELETE') {
                    $this->api_object_delete();
                }
            }
        }

        throw new kolab_api_exception(kolab_api_exception::NOT_FOUND);
    }

    /**
     * Submit a message object into SMTP server
     */
    protected function api_message_submit($folder = null, $uid = null)
    {
        // parse input and merge with current data (returns kolab_api_mail)
        $input = $this->input->input($this->model, false);

        // send the message
        $input->send();

        // @TODO: option to save message in Sent folder
        // @TODO: option to send existing message
        // @TODO: option to remove message from Drafts

        $this->output->send_status(kolab_api_output::STATUS_EMPTY);
    }

    /**
     * Count message attachments
     */
    protected function api_message_count_attachments()
    {
        $folder  = $this->input->path[0];
        $uid     = $this->input->path[1];
        $object  = $this->backend->object_get($folder, $uid);
        $context = array(
            'folder_uid' => $folder,
            'object_uid' => $uid,
            'object'     => $object,
        );

        $count = count($object->attachments);

        $this->output->headers(array('X-Count' => $count), $context);
        $this->output->send_status(kolab_api_output::STATUS_OK);
    }

    /**
     * List message attachments
     */
    protected function api_message_list_attachments()
    {
        $folder  = $this->input->path[0];
        $uid     = $this->input->path[1];
        $object  = $this->backend->object_get($folder, $uid);
        $props   = $this->input->args['properties'] ? explode(',', $this->input->args['properties']) : null;
        $context = array('folder_uid' => $folder, 'object_uid' => $uid, 'object' => $object);
        $list    = $object->attachments;

        $this->output->send($list, 'attachment-list', $context, $props);
    }
}
