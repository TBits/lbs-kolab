<?php

/**
 * Test class to test tasks API
 *
 * @package Tests
 */
class API_Tasks extends PHPUnit_Framework_TestCase
{
    public static $api;

    /**
     * Setup
     */
    public static function setUpBeforeClass()
    {
        // start from the beginning...
        kolab_api_tests::reset_backend();

        self::$api = kolab_api_tests::get_request('json');
    }

    /**
     * Test tasks listing (folders API)
     */
    function test_listing()
    {
        // non-existing folder
        self::$api->get('folders/' . kolab_api_tests::folder_uid('Tasks') . '/objects');

        $code = self::$api->response_code();
        $body = self::$api->response_body();
        $body = json_decode($body, true);

        $this->assertEquals(200, $code);
        $this->assertSame(2, count($body));
        $this->assertSame('10-10-10-10', $body[0]['uid']);
        $this->assertSame('task title', $body[0]['summary']);
        $this->assertSame('20-20-20-20', $body[1]['uid']);
        $this->assertSame('task', $body[1]['summary']);
    }

    /**
     * Test task existence
     */
    function test_task_exists()
    {
        self::$api->head('tasks/' . kolab_api_tests::folder_uid('Tasks') . '/10-10-10-10');

        $code = self::$api->response_code();
        $body = self::$api->response_body();

        $this->assertEquals(200, $code);
        $this->assertSame('', $body);

        // and non-existing task
        self::$api->head('tasks/' . kolab_api_tests::folder_uid('Tasks') . '/12345');

        $code = self::$api->response_code();
        $body = self::$api->response_body();

        $this->assertEquals(404, $code);
        $this->assertSame('', $body);
    }

    /**
     * Test task info
     */
    function test_task_info()
    {
        self::$api->get('tasks/' . kolab_api_tests::folder_uid('Tasks') . '/10-10-10-10');

        $code = self::$api->response_code();
        $body = self::$api->response_body();
        $body = json_decode($body, true);

        $this->assertEquals(200, $code);
        $this->assertSame('10-10-10-10', $body['uid']);
        $this->assertSame('task title', $body['summary']);
        $this->assertSame(array('tag1'), $body['categories']);
    }

    /**
     * Test task create
     */
    function test_task_create()
    {
        $post = json_encode(array(
            'summary'     => 'Test summary',
            'description' => 'Test description'
        ));
        self::$api->post('tasks/' . kolab_api_tests::folder_uid('Tasks'), array(), $post);

        $code = self::$api->response_code();
        $body = self::$api->response_body();
        $body = json_decode($body, true);

        $this->assertEquals(200, $code);
        $this->assertCount(1, $body);
        $this->assertTrue(!empty($body['uid']));

        // folder does not exists
        $post = json_encode(array(
            'summary' => 'Test summary 2',
        ));
        self::$api->post('tasks/' . kolab_api_tests::folder_uid('non-existing'), array(), $post);

        $code = self::$api->response_code();
        $this->assertEquals(404, $code);

        // invalid object data
        $post = json_encode(array(
            'test' => 'Test summary 2',
        ));
        self::$api->post('tasks/' . kolab_api_tests::folder_uid('Tasks'), array(), $post);

        $code = self::$api->response_code();
        $this->assertEquals(422, $code);
    }

    /**
     * Test task update
     */
    function test_task_update()
    {
        $post = json_encode(array(
            'summary'     => 'modified summary',
            'description' => 'modified description',
            'class'       => 'PRIVATE',
            'dtstart'     => '2014-01-10',
            'categories'  => array('test'),
        ));
        self::$api->put('tasks/' . kolab_api_tests::folder_uid('Tasks') . '/10-10-10-10', array(), $post);

        $code = self::$api->response_code();
        $body = self::$api->response_body();
        $body = json_decode($body, true);

        $this->assertEquals(200, $code);
        $this->assertSame('10-10-10-10', $body['uid']);

        self::$api->get('tasks/' . kolab_api_tests::folder_uid('Tasks') . '/10-10-10-10');

        $body = self::$api->response_body();
        $body = json_decode($body, true);

        $this->assertSame('modified summary', $body['summary']);
        $this->assertSame('modified description', $body['description']);
        $this->assertSame('PRIVATE', $body['class']);
        $this->assertSame(array('test'), $body['categories']);

        // test unsetting some properties
        $post = json_encode(array(
            'due'         => null,
            'related-to'  => null,
            'location'    => null,
            'unknown'     => 'test',
        ));
        self::$api->put('tasks/' . kolab_api_tests::folder_uid('Tasks') . '/10-10-10-10', array(), $post);

        $code = self::$api->response_code();
        $body = self::$api->response_body();
        $body = json_decode($body, true);

        $this->assertEquals(200, $code);

        self::$api->get('tasks/' . kolab_api_tests::folder_uid('Tasks') . '/10-10-10-10');

        $body = self::$api->response_body();
        $body = json_decode($body, true);

        $this->assertSame('2014-01-10', $body['dtstart']);
        $this->assertSame(null, $body['due']);
        $this->assertSame(null, $body['related-to']);
        $this->assertSame(null, $body['location']);
        $this->assertSame(null, $body['unknown']);
    }

    /**
     * Test task delete
     */
    function test_task_delete()
    {
        // delete existing task
        self::$api->delete('tasks/' . kolab_api_tests::folder_uid('Tasks') . '/20-20-20-20');

        $code = self::$api->response_code();
        $body = self::$api->response_body();

        $this->assertEquals(204, $code);
        $this->assertSame('', $body);

        // and non-existing task
        self::$api->delete('tasks/' . kolab_api_tests::folder_uid('Tasks') . '/12345');

        $code = self::$api->response_code();
        $body = self::$api->response_body();

        $this->assertEquals(404, $code);
        $this->assertSame('', $body);
    }

    /**
     * Test counting task attachments
     */
    function test_count_attachments()
    {
        self::$api->head('tasks/' . kolab_api_tests::folder_uid('Tasks') . '/10-10-10-10/attachments');

        $code  = self::$api->response_code();
        $body  = self::$api->response_body();
        $count = self::$api->response_header('X-Count');

        $this->assertEquals(200, $code);
        $this->assertSame('', $body);
        $this->assertSame(1, (int) $count);
    }

    /**
     * Test listing task attachments
     */
    function test_list_attachments()
    {
        self::$api->get('tasks/' . kolab_api_tests::folder_uid('Tasks') . '/10-10-10-10/attachments');

        $code = self::$api->response_code();
        $body = self::$api->response_body();
        $body = json_decode($body, true);

        $this->assertEquals(200, $code);
        $this->assertCount(1, $body);
        $this->assertSame('3',          $body[0]['id']);
        $this->assertSame('text/plain', $body[0]['mimetype']);
        $this->assertSame('test.txt',   $body[0]['filename']);
        $this->assertSame('attachment', $body[0]['disposition']);
        $this->assertSame(4,            $body[0]['size']);
    }
}
