<?php

/**
 * Test class to test notes API
 *
 * @package Tests
 */
class API_Notes extends PHPUnit_Framework_TestCase
{
    public static $api;

    /**
     * Setup
     */
    public static function setUpBeforeClass()
    {
        // start from the beginning...
        kolab_api_tests::reset_backend();

        self::$api = kolab_api_tests::get_request('json');
    }

    /**
     * Test notes listing (folders API)
     */
    function test_listing()
    {
        // non-existing folder
        self::$api->get('folders/' . kolab_api_tests::folder_uid('Notes') . '/objects');

        $code = self::$api->response_code();
        $body = self::$api->response_body();
        $body = json_decode($body, true);

        $this->assertEquals(200, $code);
        $this->assertSame(2, count($body));
        $this->assertSame('1-1-1-1', $body[0]['uid']);
        $this->assertSame('test', $body[0]['summary']);
        $this->assertSame('2-2-2-2', $body[1]['uid']);
        $this->assertSame('wwww', $body[1]['summary']);
    }

    /**
     * Test note existence
     */
    function test_note_exists()
    {
        self::$api->head('notes/' . kolab_api_tests::folder_uid('Notes') . '/1-1-1-1');

        $code = self::$api->response_code();
        $body = self::$api->response_body();

        $this->assertEquals(200, $code);
        $this->assertSame('', $body);

        // and non-existing note
        self::$api->head('notes/' . kolab_api_tests::folder_uid('Notes') . '/12345');

        $code = self::$api->response_code();
        $body = self::$api->response_body();

        $this->assertEquals(404, $code);
        $this->assertSame('', $body);
    }

    /**
     * Test note info
     */
    function test_note_info()
    {
        self::$api->get('notes/' . kolab_api_tests::folder_uid('Notes') . '/1-1-1-1');

        $code = self::$api->response_code();
        $body = self::$api->response_body();
        $body = json_decode($body, true);

        $this->assertEquals(200, $code);
        $this->assertSame('1-1-1-1', $body['uid']);
        $this->assertSame('test', $body['summary']);
        $this->assertSame(array('tag1'), $body['categories']);
    }

    /**
     * Test note create
     */
    function test_note_create()
    {
        $post = json_encode(array(
            'summary'     => 'Test summary',
            'description' => 'Test description'
        ));
        self::$api->post('notes/' . kolab_api_tests::folder_uid('Notes'), array(), $post);

        $code = self::$api->response_code();
        $body = self::$api->response_body();
        $body = json_decode($body, true);

        $this->assertEquals(200, $code);
        $this->assertCount(1, $body);
        $this->assertTrue(!empty($body['uid']));

        // folder does not exists
        $post = json_encode(array(
            'summary' => 'Test summary 2',
        ));
        self::$api->post('notes/' . kolab_api_tests::folder_uid('non-existing'), array(), $post);

        $code = self::$api->response_code();
        $this->assertEquals(404, $code);

        // invalid object data
        $post = json_encode(array(
            'test' => 'Test summary 2',
        ));
        self::$api->post('notes/' . kolab_api_tests::folder_uid('Notes'), array(), $post);

        $code = self::$api->response_code();
        $this->assertEquals(422, $code);
    }

    /**
     * Test note update
     */
    function test_note_update()
    {
        $post = json_encode(array(
            'summary'        => 'Modified summary',
            'description'    => 'Modified description',
            'classification' => 'PRIVATE',
            'categories'     => array('test'),
            'unknown'        => 'test'
        ));

        self::$api->put('notes/' . kolab_api_tests::folder_uid('Notes') . '/1-1-1-1', array(), $post);

        $code = self::$api->response_code();
        $body = self::$api->response_body();
        $body = json_decode($body, true);

        $this->assertEquals(200, $code);
        $this->assertSame('1-1-1-1', $body['uid']);

        self::$api->get('notes/' . kolab_api_tests::folder_uid('Notes') . '/1-1-1-1');

        $body = self::$api->response_body();
        $body = json_decode($body, true);

        $this->assertSame('Modified summary', $body['summary']);
        $this->assertSame('Modified description', $body['description']);
        $this->assertSame('PRIVATE', $body['classification']);
        $this->assertSame(array('test'), $body['categories']);
        $this->assertSame(null, $body['unknown']);

        // test unsetting some data
        $post = json_encode(array(
            'description' => null,
            'categories'  => null,
        ));
        self::$api->put('notes/' . kolab_api_tests::folder_uid('Notes') . '/1-1-1-1', array(), $post);

        $code = self::$api->response_code();
        $body = self::$api->response_body();

        $this->assertEquals(200, $code);

        self::$api->get('notes/' . kolab_api_tests::folder_uid('Notes') . '/1-1-1-1');

        $body = self::$api->response_body();
        $body = json_decode($body, true);

        $this->assertSame(null, $body['description']);
        $this->assertTrue(empty($body['categories']));
    }

    /**
     * Test counting task attachments
     */
    function test_count_attachments()
    {
        // @TODO
    }

    /**
     * Test listing task attachments
     */
    function test_list_attachments()
    {
        // @TODO
    }

    /**
     * Test note delete
     */
    function test_note_delete()
    {
        // delete existing note
        self::$api->delete('notes/' . kolab_api_tests::folder_uid('Notes') . '/1-1-1-1');

        $code = self::$api->response_code();
        $body = self::$api->response_body();

        $this->assertEquals(204, $code);
        $this->assertSame('', $body);

        // and non-existing note
        self::$api->delete('notes/' . kolab_api_tests::folder_uid('Notes') . '/12345');

        $code = self::$api->response_code();
        $body = self::$api->response_body();

        $this->assertEquals(404, $code);
        $this->assertSame('', $body);
    }
}
