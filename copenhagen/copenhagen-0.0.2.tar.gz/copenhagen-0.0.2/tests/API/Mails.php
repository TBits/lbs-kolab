<?php

/**
 * Test class to test mails API
 *
 * @package Tests
 */
class API_Mails extends PHPUnit_Framework_TestCase
{
    public static $api;

    protected static $created;

    /**
     * Setup
     */
    public static function setUpBeforeClass()
    {
        // start from the beginning...
        kolab_api_tests::reset_backend();

        self::$api = kolab_api_tests::get_request('json');
    }

    /**
     * Test mails listing (folders API)
     */
    function test_listing()
    {
        // non-existing folder
        self::$api->get('folders/' . kolab_api_tests::folder_uid('INBOX') . '/objects');

        $code = self::$api->response_code();
        $body = self::$api->response_body();
        $body = json_decode($body, true);

        $this->assertEquals(200, $code);
        $this->assertSame(5, count($body));
        $this->assertSame(kolab_api_tests::msg_uid('1'), $body[0]['uid']);
        $this->assertSame('"test" wurde aktualisiert', $body[0]['subject']);
        $this->assertSame(kolab_api_tests::msg_uid('2'), $body[1]['uid']);
        $this->assertSame('Re: dsda', $body[1]['subject']);
    }

    /**
     * Test mail existence check
     */
    function test_mail_exists()
    {
        self::$api->head('mails/' . kolab_api_tests::folder_uid('INBOX') . '/' . kolab_api_tests::msg_uid('1'));

        $code = self::$api->response_code();
        $body = self::$api->response_body();

        $this->assertEquals(200, $code);
        $this->assertSame('', $body);

        // and non-existing mail
        self::$api->head('mails/' . kolab_api_tests::folder_uid('INBOX') . '/12345');

        $code = self::$api->response_code();
        $body = self::$api->response_body();

        $this->assertEquals(404, $code);
        $this->assertSame('', $body);
    }

    /**
     * Test mail info
     */
    function test_mail_info()
    {
        self::$api->get('mails/' . kolab_api_tests::folder_uid('INBOX') . '/' . kolab_api_tests::msg_uid('1'));

        $code = self::$api->response_code();
        $body = self::$api->response_body();
        $body = json_decode($body, true);

        $this->assertEquals(200, $code);
        $this->assertSame(kolab_api_tests::msg_uid('1'), $body['uid']);
        $this->assertSame('"test" wurde aktualisiert', $body['subject']);
        $this->assertSame(624, $body['size']);
        $this->assertSame(array('tag1'), $body['categories']);

        self::$api->get('mails/' . kolab_api_tests::folder_uid('INBOX') . '/' . kolab_api_tests::msg_uid('6'));

        $code = self::$api->response_code();
        $body = self::$api->response_body();
        $body = json_decode($body, true);

        $this->assertEquals(200, $code);
        $this->assertSame(kolab_api_tests::msg_uid('6'), $body['uid']);
    }

    /**
     * Test counting mail attachments
     */
    function test_count_attachments()
    {
        self::$api->head('mails/' . kolab_api_tests::folder_uid('INBOX') . '/' . kolab_api_tests::msg_uid('2') . '/attachments');

        $code  = self::$api->response_code();
        $body  = self::$api->response_body();
        $count = self::$api->response_header('X-Count');

        $this->assertEquals(200, $code);
        $this->assertSame('', $body);
        $this->assertSame(0, (int) $count);

        self::$api->head('mails/' . kolab_api_tests::folder_uid('INBOX') . '/' . kolab_api_tests::msg_uid('6') . '/attachments');

        $code  = self::$api->response_code();
        $body  = self::$api->response_body();
        $count = self::$api->response_header('X-Count');

        $this->assertEquals(200, $code);
        $this->assertSame('', $body);
        $this->assertSame(2, (int) $count);
    }

    /**
     * Test listing mail attachments
     */
    function test_list_attachments()
    {
        self::$api->get('mails/' . kolab_api_tests::folder_uid('INBOX') . '/' . kolab_api_tests::msg_uid('2') . '/attachments');

        $code = self::$api->response_code();
        $body = self::$api->response_body();
        $body = json_decode($body, true);

        $this->assertEquals(200, $code);
        $this->assertSame(array(), $body);

        self::$api->get('mails/' . kolab_api_tests::folder_uid('INBOX') . '/' . kolab_api_tests::msg_uid('6') . '/attachments');

        $code = self::$api->response_code();
        $body = self::$api->response_body();
        $body = json_decode($body, true);

        $this->assertEquals(200, $code);
        $this->assertCount(2, $body);
        $this->assertSame('2',          $body[0]['id']);
        $this->assertSame('text/plain', $body[0]['mimetype']);
        $this->assertSame('test.txt',   $body[0]['filename']);
        $this->assertSame('attachment', $body[0]['disposition']);
        $this->assertSame(4,            $body[0]['size']);
    }

    /**
     * Test mail create
     */
    function test_mail_create()
    {
        $post = json_encode(array(
            'subject'    => 'Test summary',
            'text'       => 'This is the body.',
            'categories' => array('tag1'),
        ));
        self::$api->post('mails/' . kolab_api_tests::folder_uid('INBOX'), array(), $post);

        $code = self::$api->response_code();
        $body = self::$api->response_body();
        $body = json_decode($body, true);

        $this->assertEquals(200, $code);
        $this->assertCount(1, $body);
        $this->assertTrue(!empty($body['uid']));

        self::$created = $body['uid'];

        self::$api->get('mails/' . kolab_api_tests::folder_uid('INBOX') . '/' . self::$created);

        $code = self::$api->response_code();
        $body = self::$api->response_body();
        $body = json_decode($body, true);

        $this->assertEquals(200, $code);
        $this->assertSame('Test summary', $body['subject']);
        $this->assertSame('This is the body.', $body['text']);
        $this->assertSame(array('tag1'), $body['categories']);

        // folder does not exists
        $post = json_encode(array(
            'subject' => 'Test summary 2',
        ));
        self::$api->post('mails/' . kolab_api_tests::folder_uid('non-existing'), array(), $post);

        $code = self::$api->response_code();
        $this->assertEquals(404, $code);

        // invalid object data
        $post = json_encode(array(
            'test' => 'Test summary 2',
        ));
        self::$api->post('mails/' . kolab_api_tests::folder_uid('INBOX'), array(), $post);

        $code = self::$api->response_code();
        $this->assertEquals(422, $code);

        // test HTML message creation
        $post = json_encode(array(
            'subject' => 'HTML',
            'html'    => '<html><body>now it iś HTML</body></html>',
        ));
        self::$api->post('mails/' . kolab_api_tests::folder_uid('INBOX'), array(), $post);

        $code = self::$api->response_code();
        $body = self::$api->response_body();
        $body = json_decode($body, true);

        $this->assertEquals(200, $code);
        $this->assertTrue(!empty($body['uid']));

        self::$api->get('mails/' . kolab_api_tests::folder_uid('INBOX') . '/' . $body['uid']);

        $code = self::$api->response_code();
        $body = self::$api->response_body();
        $body = json_decode($body, true);

        $this->assertEquals(200, $code);
        $this->assertSame('HTML', $body['subject']);
        $this->assertRegexp('|<body>now it iś HTML</body>|', (string) $body['html']);
    }

    /**
     * Test mail update
     */
    function test_mail_update()
    {
        $post = json_encode(array(
            'subject' => 'Modified summary',
            'html'    => '<html><body>now it is HTML</body></html>',
            'categories' => array('test'),
        ));

        self::$api->put('mails/' . kolab_api_tests::folder_uid('INBOX') . '/' . self::$created, array(), $post);

        $code = self::$api->response_code();
        $body = self::$api->response_body();
        $body = json_decode($body, true);

        $this->assertEquals(200, $code);
        $this->assertTrue(!empty($body['uid']));

        self::$api->get('mails/' . kolab_api_tests::folder_uid('INBOX') . '/' . $body['uid']);

        $code = self::$api->response_code();
        $body = self::$api->response_body();
        $body = json_decode($body, true);

        $this->assertEquals(200, $code);
        $this->assertSame('Modified summary', $body['subject']);
        $this->assertRegexp('|<body>now it is HTML</body>|', (string) $body['html']);
        $this->assertSame('now it is HTML', trim($body['text']));
        $this->assertSame(array('test'), $body['categories']);

        // test replacing message body in multipart/mixed message
        $post = json_encode(array(
            'html'     => '<html><body>now it is HTML</body></html>',
            'priority' => 5,
        ));

        self::$api->put('mails/' . kolab_api_tests::folder_uid('INBOX') . '/' . kolab_api_tests::msg_uid('6'), array(), $post);

        $code = self::$api->response_code();
        $body = self::$api->response_body();
        $body = json_decode($body, true);

        $this->assertEquals(200, $code);

        self::$api->get('mails/' . kolab_api_tests::folder_uid('INBOX') . '/' . $body['uid']);

        $code = self::$api->response_code();
        $body = self::$api->response_body();
        $body = json_decode($body, true);

        $this->assertRegexp('|<body>now it is HTML</body>|', (string) $body['html']);
        $this->assertSame('now it is HTML', trim($body['text']));
        $this->assertSame(5, $body['priority']);
    }

    /**
     * Test mail submit
     */
    function test_mail_submit()
    {
        // send the message to self
        $post = json_encode(array(
            'subject' => 'Test summary',
            'text'    => 'This is the body.',
            'from'    => array(
                'name'    => "Test' user",
                'address' => self::$api->username,
            ),
            'to'    => array(
                array(
                    'name'    => "Test' user",
                    'address' => self::$api->username,
                ),
            ),
        ));

        self::$api->post('mails/submit', array(), $post);

        $code = self::$api->response_code();

        $this->assertEquals(204, $code);

        // @TODO: test submitting an existing message
    }

    /**
     * Test mail delete
     */
    function test_mail_delete()
    {
        // delete existing mail
        self::$api->delete('mails/' . kolab_api_tests::folder_uid('INBOX') . '/' . kolab_api_tests::msg_uid('1'));

        $code = self::$api->response_code();
        $body = self::$api->response_body();

        $this->assertEquals(204, $code);
        $this->assertSame('', $body);

        // and non-existing mail
        self::$api->delete('mails/' . kolab_api_tests::folder_uid('INBOX') . '/12345');

        $code = self::$api->response_code();
        $body = self::$api->response_body();

        $this->assertEquals(404, $code);
        $this->assertSame('', $body);
    }
}
