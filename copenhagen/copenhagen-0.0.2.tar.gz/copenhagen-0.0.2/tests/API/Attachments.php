<?php

/**
 * Test class to test attachments API
 *
 * @package Tests
 */
class API_Attachments extends PHPUnit_Framework_TestCase
{
    public static $api;
    public static $uploaded;
    public static $modified;

    /**
     * Setup
     */
    public static function setUpBeforeClass()
    {
        // start from the beginning...
        kolab_api_tests::reset_backend();

        self::$api = kolab_api_tests::get_request('json');
    }

    /**
     * Test attachment existence check
     */
    function test_attachment_exists()
    {
        self::$api->head('attachments/' . kolab_api_tests::folder_uid('INBOX') . '/' . kolab_api_tests::msg_uid('6') . '/2');

        $code = self::$api->response_code();
        $body = self::$api->response_body();

        $this->assertEquals(200, $code);
        $this->assertSame('', $body);

        // and non-existing attachment
        self::$api->head('attachments/' . kolab_api_tests::folder_uid('INBOX') . '/' . kolab_api_tests::msg_uid('6') . '/2345');

        $code = self::$api->response_code();
        $body = self::$api->response_body();

        $this->assertEquals(404, $code);
        $this->assertSame('', $body);

        // test attachments of non-mail objects
        self::$api->head('attachments/' . kolab_api_tests::folder_uid('Calendar') . '/100-100-100-100/3');

        $code = self::$api->response_code();
        $body = self::$api->response_body();

        $this->assertEquals(200, $code);
        $this->assertSame('', $body);
    }

    /**
     * Test attachment info
     */
    function test_attachment_info()
    {
        self::$api->get('attachments/' . kolab_api_tests::folder_uid('INBOX') . '/' . kolab_api_tests::msg_uid('6') . '/2');

        $code = self::$api->response_code();
        $body = self::$api->response_body();
        $body = json_decode($body, true);

        $this->assertEquals(200, $code);
        $this->assertSame('2',          $body['id']);
        $this->assertSame('text/plain', $body['mimetype']);
        $this->assertSame('test.txt',   $body['filename']);
        $this->assertSame(4,            $body['size']);

        // and non-existing attachment
        self::$api->get('attachments/' . kolab_api_tests::folder_uid('INBOX') . '/' . kolab_api_tests::msg_uid('6') . '/2345');

        $code = self::$api->response_code();
        $body = self::$api->response_body();

        $this->assertEquals(404, $code);
        $this->assertSame('', $body);

        // test attachments of kolab objects
        self::$api->get('attachments/' . kolab_api_tests::folder_uid('Calendar') . '/100-100-100-100/3');

        $code = self::$api->response_code();
        $body = self::$api->response_body();
        $body = json_decode($body, true);

        $this->assertEquals(200, $code);
        $this->assertSame('3',              $body['id']);
        $this->assertSame('image/jpeg',     $body['mimetype']);
        $this->assertSame('photo-mini.jpg', $body['filename']);
        $this->assertSame('attachment',     $body['disposition']);
        $this->assertSame(793,              $body['size']);
    }

    /**
     * Test attachment body
     */
    function test_attachment_get()
    {
        // mail attachment
        self::$api->get('attachments/' . kolab_api_tests::folder_uid('INBOX') . '/' . kolab_api_tests::msg_uid('6') . '/3/get');

        $code = self::$api->response_code();
        $body = self::$api->response_body();

        $this->assertEquals(200, $code);
        $this->assertSame(793, strlen($body));
        $this->assertSame('/9j/4AAQSkZJRgAB', substr(base64_encode($body), 0, 16));

        // @TODO: headers

        // test attachments of kolab objects
        self::$api->get('attachments/' . kolab_api_tests::folder_uid('Tasks') . '/10-10-10-10/3/get');

        $code = self::$api->response_code();
        $body = self::$api->response_body();

        $this->assertEquals(200, $code);
        $this->assertSame(4, strlen($body));
        $this->assertSame('test', $body);
    }

    /**
     * Test attachment uploads
     */
    function test_attachment_upload()
    {
        // do many uploads that we use later in create/update tests
        $post = 'Some text file';
        self::$api->post('attachments/upload', array(), $post, 'application/octet-stream');

        $code = self::$api->response_code();
        $body = self::$api->response_body();
        $body = json_decode($body, true);

        $this->assertEquals(200, $code);
        $this->assertCount(1, $body);
        $this->assertTrue(!empty($body['upload-id']));

        self::$uploaded[] = $body['upload-id'];

        $post = 'Some text file';

        self::$api->post('attachments/upload', array('filename' => 'some.txt'), $post, 'application/octet-stream');

        $code = self::$api->response_code();
        $body = self::$api->response_body();
        $body = json_decode($body, true);

        $this->assertEquals(200, $code);
        $this->assertCount(1, $body);
        $this->assertTrue(!empty($body['upload-id']));

        self::$uploaded[] = $body['upload-id'];

        $post = base64_decode('R0lGODlhDwAPAIAAAMDAwAAAACH5BAEAAAAALAAAAAAPAA8AQAINhI+py+0Po5y02otnAQA7');
        self::$api->post('attachments/upload', array(), $post, 'application/octet-stream');

        $code = self::$api->response_code();
        $body = self::$api->response_body();
        $body = json_decode($body, true);

        $this->assertEquals(200, $code);
        $this->assertCount(1, $body);
        $this->assertTrue(!empty($body['upload-id']));

        self::$uploaded[] = $body['upload-id'];

        $post = base64_decode('R0lGODlhDwAPAIAAAMDAwAAAACH5BAEAAAAALAAAAAAPAA8AQAINhI+py+0Po5y02otnAQA7');
        self::$api->post('attachments/upload', array('filename' => 'empty.gif'), $post, 'application/octet-stream');

        $code = self::$api->response_code();
        $body = self::$api->response_body();
        $body = json_decode($body, true);

        $this->assertEquals(200, $code);
        $this->assertCount(1, $body);
        $this->assertTrue(!empty($body['upload-id']));

        self::$uploaded[] = $body['upload-id'];
    }

    /**
     * Test attachment create
     */
    function test_attachment_create()
    {
        // attach text file to a calendar event
        $post = json_encode(array(
            'upload-id' => self::$uploaded[0],
            'filename'  => 'test.txt',
            'mimetype'  => 'text/plain'
        ));
        self::$api->post('attachments/' . kolab_api_tests::folder_uid('Calendar') . '/100-100-100-100', array(), $post);

        $code = self::$api->response_code();
        $body = self::$api->response_body();
        $body = json_decode($body, true);

        $this->assertEquals(200, $code);
        $this->assertCount(1, $body);
        $this->assertTrue(!empty($body['uid']));

        self::$api->get('events/' . kolab_api_tests::folder_uid('Calendar') . '/100-100-100-100/attachments');

        $code = self::$api->response_code();
        $body = self::$api->response_body();
        $body = json_decode($body, true);

        $this->assertEquals(200, $code);
        $this->assertCount(2, $body);
        $this->assertSame('4',              $body[1]['id']);
        $this->assertSame('text/plain',     $body[1]['mimetype']);
        $this->assertSame('test.txt',       $body[1]['filename']);
        $this->assertSame('attachment',     $body[1]['disposition']);
        $this->assertSame(14,               $body[1]['size']);

        // attach text file to a mail message
        $post = json_encode(array(
            'upload-id' => self::$uploaded[1],
        ));
        self::$api->post('attachments/' . kolab_api_tests::folder_uid('INBOX') . '/' . kolab_api_tests::msg_uid('6'), array(), $post);

        $code = self::$api->response_code();
        $body = self::$api->response_body();
        $body = json_decode($body, true);

        $this->assertEquals(200, $code);
        $this->assertCount(1, $body);
        $this->assertTrue(!empty($body['uid']) && $body['uid'] != kolab_api_tests::msg_uid('6'));

        self::$modified = $body['uid'];

        self::$api->get('mails/' . kolab_api_tests::folder_uid('INBOX') . '/' . $body['uid'] . '/attachments');

        $code = self::$api->response_code();
        $body = self::$api->response_body();
        $body = json_decode($body, true);

        $this->assertEquals(200, $code);
        $this->assertCount(3, $body);
        $this->assertSame('4',              $body[2]['id']);
        $this->assertSame('text/plain',     $body[2]['mimetype']);
        $this->assertSame('some.txt',       $body[2]['filename']);
        $this->assertSame('attachment',     $body[2]['disposition']);
        $this->assertSame(14,               $body[2]['size']);
    }

    /**
     * Test attachment update
     */
    function test_attachment_update()
    {
        $post = json_encode(array(
            'upload-id' => self::$uploaded[2],
        ));
        self::$api->put('attachments/' . kolab_api_tests::folder_uid('Calendar') . '/100-100-100-100/4', array(), $post);

        $code = self::$api->response_code();
        $body = self::$api->response_body();
        $body = json_decode($body, true);

        $this->assertEquals(200, $code);
        $this->assertCount(1, $body);
        $this->assertTrue(!empty($body['uid']));

        self::$api->get('attachments/' . kolab_api_tests::folder_uid('Calendar') . '/100-100-100-100/4');

        $code = self::$api->response_code();
        $body = self::$api->response_body();
        $body = json_decode($body, true);

        $this->assertEquals(200, $code);
        $this->assertSame('4',              $body['id']);
        $this->assertSame('image/gif',      $body['mimetype']);
        $this->assertSame(null,             $body['filename']);
        $this->assertSame(54,               $body['size']);

        // just rename the existing attachment
        $post = json_encode(array(
            'filename' => 'changed.gif',
        ));
        self::$api->put('attachments/' . kolab_api_tests::folder_uid('Calendar') . '/100-100-100-100/4', array(), $post);

        $code = self::$api->response_code();
        $body = self::$api->response_body();
        $body = json_decode($body, true);

        $this->assertEquals(200, $code);
        $this->assertCount(1, $body);
        $this->assertTrue(!empty($body['uid']));

        self::$api->get('attachments/' . kolab_api_tests::folder_uid('Calendar') . '/100-100-100-100/4');

        $code = self::$api->response_code();
        $body = self::$api->response_body();
        $body = json_decode($body, true);

        $this->assertEquals(200, $code);
        $this->assertSame('changed.gif',  $body['filename']);
        $this->assertSame(54,             $body['size']);
    }

    /**
     * Test attachment delete
     */
    function test_attachment_delete()
    {
        // delete existing attachment
        self::$api->delete('attachments/' . kolab_api_tests::folder_uid('Tasks') . '/10-10-10-10/3');

        $code = self::$api->response_code();
        $body = self::$api->response_body();
        $body = json_decode($body, true);

        $this->assertEquals(200, $code);
        $this->assertCount(1, $body);
        $this->assertTrue(!empty($body['uid']) && $body['uid'] == '10-10-10-10');

        // delete non-existing attachment in an existing object
        self::$api->delete('attachments/' . kolab_api_tests::folder_uid('Tasks') . '/10-10-10-10/3');

        $code = self::$api->response_code();
        $body = self::$api->response_body();

        $this->assertEquals(404, $code);
        $this->assertSame('', $body);

        // delete existing attachment
        self::$api->delete('attachments/' . kolab_api_tests::folder_uid('INBOX') . '/' . kolab_api_tests::msg_uid('7') . '/2');

        $code = self::$api->response_code();
        $body = self::$api->response_body();
        $body = json_decode($body, true);

        $this->assertEquals(200, $code);
        $this->assertCount(1, $body);
        $this->assertTrue(!empty($body['uid']) && $body['uid'] != kolab_api_tests::msg_uid('7'));

        // and non-existing attachment
        self::$api->delete('attachments/' . kolab_api_tests::folder_uid('INBOX') . '/' . kolab_api_tests::msg_uid('7') . '/20');

        $code = self::$api->response_code();
        $body = self::$api->response_body();

        $this->assertEquals(404, $code);
        $this->assertSame('', $body);
    }
}
