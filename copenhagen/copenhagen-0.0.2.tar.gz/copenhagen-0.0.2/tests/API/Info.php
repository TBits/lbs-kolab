<?php

/**
 * Test class to test info API
 *
 * @package Tests
 */
class API_Info extends PHPUnit_Framework_TestCase
{
    public static $api;

    /**
     * Setup
     */
    public static function setUpBeforeClass()
    {
        // start from the beginning...
        kolab_api_tests::reset_backend();

        self::$api = kolab_api_tests::get_request('json');
    }

    /**
     * Test notes listing (folders API)
     */
    function test_info()
    {
        // non-existing folder
        self::$api->get('info');

        $code = self::$api->response_code();
        $body = self::$api->response_body();
        $body = json_decode($body, true);

        $this->assertEquals(200, $code);

        $this->assertSame(kolab_api::APP_NAME, $body['name']);
        $this->assertSame(kolab_api::VERSION, $body['version']);
    }

    /**
     * Test non-existing request
     */
    function test_nonexisting()
    {
        self::$api->post('info');

        $code = self::$api->response_code();

        $this->assertEquals(404, $code);
    }
}
