<?php

/**
 * Test class to test folders API
 *
 * @package Tests
 */
class API_Folders extends PHPUnit_Framework_TestCase
{
    public static $api;

    /**
     * Setup
     */
    public static function setUpBeforeClass()
    {
        // start from the beginning...
        kolab_api_tests::reset_backend();

        self::$api = kolab_api_tests::get_request('json');
    }

    /**
     * Test non-existing actions
     */
    function test_nonexisting()
    {
        // non-existing folder
        self::$api->get('folders/test');

        $code = self::$api->response_code();
        $this->assertEquals(404, $code);

        // non-existing action
        self::$api->get('folders/' . kolab_api_tests::folder_uid('INBOX') . '/test');

        $code = self::$api->response_code();
        $this->assertEquals(404, $code);

        // existing action and folder, but wrong method
        self::$api->get('folders/' . kolab_api_tests::folder_uid('Mail-Test') . '/empty');

        $code = self::$api->response_code();
        $this->assertEquals(404, $code);
    }

    /**
     * Test listing all folders
     */
    function test_folder_list_folders()
    {
        // get all folders
        self::$api->get('folders');

        $code = self::$api->response_code();
        $body = self::$api->response_body();
        $body = json_decode($body, true);

        $this->assertEquals(200, $code);
        $this->assertTrue(count($body) >= 15);
        $this->assertSame('Calendar', $body[0]['fullpath']);
        $this->assertSame('event.default', $body[0]['type']);
        $this->assertSame(kolab_api_tests::folder_uid('Calendar'), $body[0]['uid']);
        $this->assertNull($body[0]['parent']);

        // test listing subfolders of specified folder
        self::$api->get('folders/' . kolab_api_tests::folder_uid('Calendar') . '/folders');

        $code = self::$api->response_code();
        $body = self::$api->response_body();
        $body = json_decode($body, true);

        $this->assertEquals(200, $code);
        $this->assertCount(1, $body);
        $this->assertSame('Calendar/Personal Calendar', $body[0]['fullpath']);
        $this->assertSame(kolab_api_tests::folder_uid('Calendar'), $body[0]['parent']);

        // get all folders with properties filter
        self::$api->get('folders', array('properties' => 'uid'));

        $code = self::$api->response_code();
        $body = self::$api->response_body();
        $body = json_decode($body, true);

        $this->assertEquals(200, $code);
        $this->assertCount(1, $body[0]);
        $this->assertSame(kolab_api_tests::folder_uid('Calendar'), $body[0]['uid']);
    }

    /**
     * Test folder delete
     */
    function test_folder_delete()
    {
        // delete existing folder
        self::$api->delete('folders/' . kolab_api_tests::folder_uid('Mail-Test'));

        $code = self::$api->response_code();
        $body = self::$api->response_body();

        $this->assertEquals(204, $code);
        $this->assertSame('', $body);

        // and non-existing folder
        self::$api->delete('folders/12345');

        $code = self::$api->response_code();
        $body = self::$api->response_body();

        $this->assertEquals(404, $code);
        $this->assertSame('', $body);
    }

    /**
     * Test folder existence
     */
    function test_folder_exists()
    {
        self::$api->head('folders/' . kolab_api_tests::folder_uid('INBOX'));

        $code = self::$api->response_code();
        $body = self::$api->response_body();

        $this->assertEquals(200, $code);
        $this->assertSame('', $body);

        // and non-existing folder - deleted in test_folder_delete()
        self::$api->head('folders/' . kolab_api_tests::folder_uid('Mail-Test'));

        $code = self::$api->response_code();
        $body = self::$api->response_body();

        $this->assertEquals(404, $code);
        $this->assertSame('', $body);
    }

    /**
     * Test folder update
     */
    function test_folder_update()
    {
        $post = json_encode(array(
            'name' => 'Mail-Test22',
            'type' => 'mail'
        ));
        self::$api->put('folders/' . kolab_api_tests::folder_uid('Mail-Test2'), array(), $post);

        $code = self::$api->response_code();
        $body = self::$api->response_body();
        $body = json_decode($body, true);

        $this->assertEquals(200, $code);
        $this->assertSame(kolab_api_tests::folder_uid('Mail-Test2'), $body['uid']);

        // move into an existing folder
        $post = json_encode(array(
            'name' => 'Trash',
        ));
        self::$api->put('folders/' . kolab_api_tests::folder_uid('Mail-Test22'), array(), $post);

        $code = self::$api->response_code();
        $this->assertEquals(500, $code);

        // change parent to an existing folder
        $post = json_encode(array(
            'parent' => kolab_api_tests::folder_uid('Trash'),
        ));
        self::$api->put('folders/' . kolab_api_tests::folder_uid('Mail-Test22'), array(), $post);

        $code = self::$api->response_code();
        $this->assertEquals(200, $code);
    }

    /**
     * Test folder create
     */
    function test_folder_create()
    {
        $post = json_encode(array(
            'name' => 'Test-create',
            'type' => 'mail'
        ));
        self::$api->post('folders', array(), $post);

        $code = self::$api->response_code();
        $body = self::$api->response_body();
        $body = json_decode($body, true);

        $this->assertEquals(200, $code);
        $this->assertSame(kolab_api_tests::folder_uid('Test-create'), $body['uid']);

        // folder already exists
        $post = json_encode(array(
            'name' => 'Test-create',
        ));
        self::$api->post('folders', array(), $post);

        $code = self::$api->response_code();
        $this->assertEquals(500, $code);

        // create a subfolder
        $post = json_encode(array(
            'name'   => 'Test',
            'parent' => kolab_api_tests::folder_uid('Test-create'),
            'type'   => 'mail'
        ));
        self::$api->post('folders', array(), $post);

        $code = self::$api->response_code();
        $body = self::$api->response_body();
        $body = json_decode($body, true);

        $this->assertEquals(200, $code);
        $this->assertSame(kolab_api_tests::folder_uid('Test-create/Test'), $body['uid']);

        // parent folder does not exists
        $post = json_encode(array(
            'name'   => 'Test-create-2',
            'parent' => '123456789',
        ));
        self::$api->post('folders', array(), $post);

        $code = self::$api->response_code();
        $this->assertEquals(404, $code);
    }

    /**
     * Test folder info
     */
    function test_folder_info()
    {
        self::$api->get('folders/' . kolab_api_tests::folder_uid('INBOX'));

        $code = self::$api->response_code();
        $body = self::$api->response_body();
        $body = json_decode($body, true);

        $this->assertEquals(200, $code);
        $this->assertSame('INBOX', $body['name']);
        $this->assertSame(kolab_api_tests::folder_uid('INBOX'), $body['uid']);

        $args = array('properties' => 'name,exists,unread,size');
        self::$api->get('folders/' . kolab_api_tests::folder_uid('Calendar'), $args);

        $code = self::$api->response_code();
        $body = self::$api->response_body();
        $body = json_decode($body, true);

        $this->assertEquals(200, $code);
        $this->assertSame('Calendar', $body['name']);
        $this->assertSame(null, $body['uid']);
        $this->assertSame(16102, $body['size']);
        $this->assertSame(3, $body['exists']);
        $this->assertSame(3, $body['unread']);
    }

    /**
     * Test folder create
     */
    function test_folder_empty()
    {
        self::$api->post('folders/' . kolab_api_tests::folder_uid('Trash') . '/empty');

        $code = self::$api->response_code();
        $body = self::$api->response_body();

        $this->assertEquals(200, $code);
        $this->assertSame('', $body);
    }

    /**
     * Test listing folder content
     */
    function test_folder_list_objects()
    {
        self::$api->get('folders/' . kolab_api_tests::folder_uid('Calendar/Personal Calendar') . '/objects');

        $code = self::$api->response_code();
        $body = self::$api->response_body();
        $body = json_decode($body, true);

        $this->assertEquals(200, $code);
        $this->assertSame(array(), $body);

        // get all objects with properties filter
        self::$api->get('folders/' . kolab_api_tests::folder_uid('Notes') . '/objects', array('properties' => 'uid'));

        $code = self::$api->response_code();
        $body = self::$api->response_body();
        $body = json_decode($body, true);

        $this->assertEquals(200, $code);
        $this->assertCount(2, $body);
        $this->assertCount(1, $body[0]);
        $this->assertSame('1-1-1-1', $body[0]['uid']);
    }

    /**
     * Test counting folder content
     */
    function test_folder_count_objects()
    {
        self::$api->head('folders/' . kolab_api_tests::folder_uid('INBOX') . '/objects');

        $code  = self::$api->response_code();
        $body  = self::$api->response_body();
        $count = self::$api->response_header('X-Count');

        $this->assertEquals(200, $code);
        $this->assertSame('', $body);
        $this->assertSame(5, (int) $count);

        // folder emptied in test_folder_empty()
        self::$api->head('folders/' . kolab_api_tests::folder_uid('Trash') . '/objects');

        $count = self::$api->response_header('X-Count');
        $this->assertSame(0, (int) $count);

        // one item removed in test_folder_delete_objects()
        self::$api->head('folders/' . kolab_api_tests::folder_uid('Notes') . '/objects');

        $count = self::$api->response_header('X-Count');
        $this->assertSame(2, (int) $count);
    }

    /**
     * Test moving objects from one folder to another
     */
    function test_folder_move_objects()
    {
        $post = json_encode(array('100-100-100-100'));

        // invalid request: target == source
        self::$api->post('folders/' . kolab_api_tests::folder_uid('Calendar') . '/move/' . kolab_api_tests::folder_uid('Calendar'), array(), $post);

        $code = self::$api->response_code();

        $this->assertEquals(422, $code);

        // move one object
        self::$api->post('folders/' . kolab_api_tests::folder_uid('Calendar') . '/move/' . kolab_api_tests::folder_uid('Calendar/Personal Calendar'), array(), $post);

        $code = self::$api->response_code();
        $body = self::$api->response_body();

        $this->assertEquals(200, $code);
        $this->assertSame('', $body);

        self::$api->get('folders/' . kolab_api_tests::folder_uid('Calendar/Personal Calendar') . '/objects');

        $code = self::$api->response_code();
        $body = self::$api->response_body();
        $body = json_decode($body, true);

        $this->assertEquals(200, $code);
        $this->assertCount(1, $body);
        $this->assertSame('100-100-100-100', $body[0]['uid']);

        self::$api->get('folders/' . kolab_api_tests::folder_uid('Calendar') . '/objects');

        $code = self::$api->response_code();
        $body = self::$api->response_body();
        $body = json_decode($body, true);

        $this->assertEquals(200, $code);
        $this->assertCount(2, $body);
        $this->assertSame('101-101-101-101', $body[0]['uid']);

        // @TODO: the same for mail
    }

    /**
     * Test deleting objects in a folder
     */
    function test_folder_delete_objects()
    {
        // delete non-existing object
        $post = json_encode(array('1-1-1-1'));
        self::$api->post('folders/' . kolab_api_tests::folder_uid('Notes') . '/deleteobjects', array(), $post);

        $code = self::$api->response_code();
        $body = self::$api->response_body();

        $this->assertEquals(200, $code);
        $this->assertSame('', $body);
    }
}
