<?php

/**
 * Test class to test contacts API
 *
 * @package Tests
 */
class API_Contacts extends PHPUnit_Framework_TestCase
{
    public static $api;

    /**
     * Setup
     */
    public static function setUpBeforeClass()
    {
        // start from the beginning...
        kolab_api_tests::reset_backend();

        self::$api = kolab_api_tests::get_request('json');
    }

    /**
     * Test contacts listing (folders API)
     */
    function test_listing()
    {
        // non-existing folder
        self::$api->get('folders/' . kolab_api_tests::folder_uid('Contacts') . '/objects');

        $code = self::$api->response_code();
        $body = self::$api->response_body();
        $body = json_decode($body, true);

        $this->assertEquals(200, $code);

        // check objects count to make sure distribution-lists are returned
        $this->assertCount(3, $body);
        $this->assertSame('a-b-c-d', $body[0]['uid']);
        $this->assertSame('displname', $body[0]['fn']);
    }

    /**
     * Test contact existence
     */
    function test_contact_exists()
    {
        self::$api->head('contacts/' . kolab_api_tests::folder_uid('Contacts') . '/a-b-c-d');

        $code = self::$api->response_code();
        $body = self::$api->response_body();

        $this->assertEquals(200, $code);
        $this->assertSame('', $body);

        // and non-existing contact
        self::$api->head('contacts/' . kolab_api_tests::folder_uid('Contacts') . '/12345');

        $code = self::$api->response_code();
        $body = self::$api->response_body();

        $this->assertEquals(404, $code);
        $this->assertSame('', $body);

        // distribution-list
        self::$api->head('contacts/' . kolab_api_tests::folder_uid('Contacts') . '/i-j-k-l');

        $code = self::$api->response_code();
        $body = self::$api->response_body();

        $this->assertEquals(200, $code);
        $this->assertSame('', $body);
    }

    /**
     * Test contact info
     */
    function test_contact_info()
    {
        self::$api->get('contacts/' . kolab_api_tests::folder_uid('Contacts') . '/a-b-c-d');

        $code = self::$api->response_code();
        $body = self::$api->response_body();
        $body = json_decode($body, true);

        $this->assertEquals(200, $code);
        $this->assertSame('a-b-c-d', $body['uid']);
        $this->assertSame('displname',    $body['fn']);
        $this->assertSame(array('tag1'), $body['categories']);
        $this->assertSame('individual', $body['kind']);

        // distribution-list
        self::$api->get('contacts/' . kolab_api_tests::folder_uid('Contacts') . '/i-j-k-l');

        $code = self::$api->response_code();
        $body = self::$api->response_body();
        $body = json_decode($body, true);

        $this->assertEquals(200, $code);
        $this->assertSame('i-j-k-l', $body['uid']);
        $this->assertSame('group', $body['kind']);
    }

    /**
     * Test contact create
     */
    function test_contact_create()
    {
        $post = json_encode(array(
            'n' => array(
                'surname' => 'lastname',
            ),
            'note' => 'Test description',
        ));
        self::$api->post('contacts/' . kolab_api_tests::folder_uid('Contacts'), array(), $post);

        $code = self::$api->response_code();
        $body = self::$api->response_body();
        $body = json_decode($body, true);

        $this->assertEquals(200, $code);
        $this->assertCount(1, $body);
        $this->assertTrue(!empty($body['uid']));

        // folder does not exists
        $post = json_encode(array(
            'n' => array(
                'surname' => 'lastname',
            ),
            'note' => 'Test description',
        ));
        self::$api->post('contacts/' . kolab_api_tests::folder_uid('non-existing'), array(), $post);

        $code = self::$api->response_code();
        $this->assertEquals(404, $code);

        // invalid object data
        $post = json_encode(array(
            'test' => 'Test summary 2',
        ));
        self::$api->post('contacts/' . kolab_api_tests::folder_uid('Contacts'), array(), $post);

        $code = self::$api->response_code();
        $this->assertEquals(422, $code);

        // distribution-list
        $post = json_encode(array(
            'kind'   => 'group',
            'fn'     => 'test gr',
            'member' => array('urn:uuid:a-b-c-d'),
        ));
        self::$api->post('contacts/' . kolab_api_tests::folder_uid('Contacts'), array(), $post);

        $code = self::$api->response_code();
        $body = self::$api->response_body();
        $body = json_decode($body, true);

        $this->assertEquals(200, $code);
        $this->assertCount(1, $body);
        $this->assertTrue(!empty($body['uid']));

        self::$api->get('contacts/' . kolab_api_tests::folder_uid('Contacts') . '/' . $body['uid']);

        $code = self::$api->response_code();
        $body = self::$api->response_body();
        $body = json_decode($body, true);

        $this->assertEquals(200, $code);
        $this->assertSame('group', $body['kind']);
        $this->assertSame('urn:uuid:a-b-c-d', $body['member'][0]);
    }

    /**
     * Test contact update
     */
    function test_contact_update()
    {
        $post = json_encode(array(
            'note'       => 'note1',
            'categories' => array('test'),
        ));

        self::$api->put('contacts/' . kolab_api_tests::folder_uid('Contacts') . '/a-b-c-d', array(), $post);

        $code = self::$api->response_code();
        $body = self::$api->response_body();
        $body = json_decode($body, true);

        $this->assertEquals(200, $code);
        $this->assertSame('a-b-c-d', $body['uid']);

        self::$api->get('contacts/' . kolab_api_tests::folder_uid('Contacts') . '/a-b-c-d');

        $body = self::$api->response_body();
        $body = json_decode($body, true);

        $this->assertSame('note1', $body['note']);
        $this->assertSame(array('test'), $body['categories']);
    }

    /**
     * Test contact delete
     */
    function test_contact_delete()
    {
        // delete existing contact
        self::$api->delete('contacts/' . kolab_api_tests::folder_uid('Contacts') . '/a-b-c-d');

        $code = self::$api->response_code();
        $body = self::$api->response_body();

        $this->assertEquals(204, $code);
        $this->assertSame('', $body);

        // and non-existing contact
        self::$api->delete('contacts/' . kolab_api_tests::folder_uid('Contacts') . '/12345');

        $code = self::$api->response_code();
        $body = self::$api->response_body();

        $this->assertEquals(404, $code);
        $this->assertSame('', $body);

        // delete existing distribution-list
        self::$api->delete('contacts/' . kolab_api_tests::folder_uid('Contacts') . '/i-j-k-l');

        $code = self::$api->response_code();
        $body = self::$api->response_body();

        $this->assertEquals(204, $code);
        $this->assertSame('', $body);
    }

    /**
     * Test counting task attachments
     */
    function test_count_attachments()
    {
        $this->markTestIncomplete('TODO');
    }

    /**
     * Test listing task attachments
     */
    function test_list_attachments()
    {
        $this->markTestIncomplete('TODO');
    }
}
