<?php

/**
 * Test class to test events API
 *
 * @package Tests
 */
class API_Events extends PHPUnit_Framework_TestCase
{
    public static $api;

    /**
     * Setup
     */
    public static function setUpBeforeClass()
    {
        // start from the beginning...
        kolab_api_tests::reset_backend();

        self::$api = kolab_api_tests::get_request('json');
    }

    /**
     * Test events listing (folders API)
     */
    function test_listing()
    {
        // non-existing folder
        self::$api->get('folders/' . kolab_api_tests::folder_uid('Calendar') . '/objects');

        $code = self::$api->response_code();
        $body = self::$api->response_body();
        $body = json_decode($body, true);

        $this->assertEquals(200, $code);
        $this->assertSame('100-100-100-100', $body[0]['uid']);
        $this->assertSame('Summary', $body[0]['summary']);

        $this->assertSame('101-101-101-101', $body[1]['uid']);
        $this->assertSame('PUBLIC', $body[1]['class']);
    }

    /**
     * Test event existence
     */
    function test_event_exists()
    {
        self::$api->head('events/' . kolab_api_tests::folder_uid('Calendar') . '/100-100-100-100');

        $code = self::$api->response_code();
        $body = self::$api->response_body();

        $this->assertEquals(200, $code);
        $this->assertSame('', $body);

        // and non-existing event
        self::$api->head('events/' . kolab_api_tests::folder_uid('Calendar') . '/12345');

        $code = self::$api->response_code();
        $body = self::$api->response_body();

        $this->assertEquals(404, $code);
        $this->assertSame('', $body);
    }

    /**
     * Test event info
     */
    function test_event_info()
    {
        self::$api->get('events/' . kolab_api_tests::folder_uid('Calendar') . '/100-100-100-100');

        $code = self::$api->response_code();
        $body = self::$api->response_body();
        $body = json_decode($body, true);

        $this->assertEquals(200, $code);
        $this->assertSame('100-100-100-100', $body['uid']);
        $this->assertSame('Summary', $body['summary']);
        $this->assertSame(array('tag1', 'Work'), $body['categories']);
    }

    /**
     * Test event create
     */
    function test_event_create()
    {
        $post = json_encode(array(
            'summary' => 'Test description',
            'dtstart' => '2015-01-01',
        ));
        self::$api->post('events/' . kolab_api_tests::folder_uid('Calendar'), array(), $post);

        $code = self::$api->response_code();
        $body = self::$api->response_body();
        $body = json_decode($body, true);

        $this->assertEquals(200, $code);
        $this->assertCount(1, $body);
        $this->assertTrue(!empty($body['uid']));

        // folder does not exists
        $post = json_encode(array(
            'summary' => 'Test description',
            'dtstart' => '2015-01-01',
        ));
        self::$api->post('events/' . kolab_api_tests::folder_uid('non-existing'), array(), $post);

        $code = self::$api->response_code();
        $this->assertEquals(404, $code);

        // invalid object data
        $post = json_encode(array(
            'test' => 'Test summary 2',
        ));
        self::$api->post('events/' . kolab_api_tests::folder_uid('Calendar'), array(), $post);

        $code = self::$api->response_code();
        $this->assertEquals(422, $code);
    }

    /**
     * Test event update
     */
    function test_event_update()
    {
        // @TODO: test modification of all supported properties
        $post = json_encode(array(
            'summary' => 'Modified summary (1)',
            'dtstart' => '2015-01-01',
            'categories' => array('test'),
        ));
        self::$api->put('events/' . kolab_api_tests::folder_uid('Calendar') . '/100-100-100-100', array(), $post);

        $code = self::$api->response_code();
        $body = self::$api->response_body();
        $body = json_decode($body, true);

        $this->assertEquals(200, $code);
        $this->assertSame('100-100-100-100', $body['uid']);

        self::$api->get('events/' . kolab_api_tests::folder_uid('Calendar') . '/100-100-100-100');

        $body = self::$api->response_body();
        $body = json_decode($body, true);

        $this->assertSame('Modified summary (1)', $body['summary']);
        $this->assertSame(array('test'), $body['categories']);
    }

    /**
     * Test counting event attachments
     */
    function test_count_attachments()
    {
        self::$api->head('events/' . kolab_api_tests::folder_uid('Calendar') . '/100-100-100-100/attachments');

        $code  = self::$api->response_code();
        $body  = self::$api->response_body();
        $count = self::$api->response_header('X-Count');

        $this->assertEquals(200, $code);
        $this->assertSame('', $body);
        $this->assertSame(1, (int) $count);

        self::$api->head('events/' . kolab_api_tests::folder_uid('Calendar') . '/101-101-101-101/attachments');

        $code  = self::$api->response_code();
        $body  = self::$api->response_body();
        $count = self::$api->response_header('X-Count');

        $this->assertEquals(200, $code);
        $this->assertSame('', $body);
        $this->assertSame(0, (int) $count);
    }

    /**
     * Test listing event attachments
     */
    function test_list_attachments()
    {
        self::$api->get('events/' . kolab_api_tests::folder_uid('Calendar') . '/100-100-100-100/attachments');

        $code = self::$api->response_code();
        $body = self::$api->response_body();
        $body = json_decode($body, true);

        $this->assertEquals(200, $code);
        $this->assertCount(1, $body);
        $this->assertSame('3',              $body[0]['id']);
        $this->assertSame('image/jpeg',     $body[0]['mimetype']);
        $this->assertSame('photo-mini.jpg', $body[0]['filename']);
        $this->assertSame('attachment',     $body[0]['disposition']);
        $this->assertSame(793,              $body[0]['size']);
    }

    /**
     * Test event delete
     */
    function test_event_delete()
    {
        // delete existing event
        self::$api->delete('events/' . kolab_api_tests::folder_uid('Calendar') . '/101-101-101-101');

        $code = self::$api->response_code();
        $body = self::$api->response_body();

        $this->assertEquals(204, $code);
        $this->assertSame('', $body);

        // and non-existing event
        self::$api->delete('events/' . kolab_api_tests::folder_uid('Calendar') . '/12345');

        $code = self::$api->response_code();
        $body = self::$api->response_body();

        $this->assertEquals(404, $code);
        $this->assertSame('', $body);
    }
}
