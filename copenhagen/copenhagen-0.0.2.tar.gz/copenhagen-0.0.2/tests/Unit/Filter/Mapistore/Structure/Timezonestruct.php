<?php

/**
 * Test class to test kolab_api_filter_mapistore_structure_timezonestruct
 *
 * @package Tests
 */
class KolabApiFilterMapistoreStructureTimezonestruct extends PHPUnit_Framework_TestCase
{
    // example data from MS-OXOCAL 4.1.5
    static $sample = array(
        'Bias'         => 'E0010000',
        'StandardBias' => '00000000',
        'DaylightBias' => 'C4FFFFFF',
        'StandardYear' => '0000',
        'StandardDate' => '00000B00000001000200000000000000',
        'DaylightYear' => '0000',
        'DaylightDate' => '00000300000002000200000000000000',
    );


    /**
     * Test output method
     */
    function test_output()
    {
        $structure = new kolab_api_filter_mapistore_structure_timezonestruct;
        $structure->Bias = 480;
        $structure->StandardBias = 0;
        $structure->DaylightBias = -60;
        $structure->StandardYear = 0;
        $structure->DaylightYear = 0;
        $structure->StandardDate = new kolab_api_filter_mapistore_structure_systemtime(array(
                'Year'      => 0,
                'Month'     => 11,
                'DayOfWeek' => 0,
                'Day'       => 1,
                'Hour'      => 2,
        ));
        $structure->DaylightDate = new kolab_api_filter_mapistore_structure_systemtime(array(
                'Year'      => 0,
                'Month'     => 3,
                'DayOfWeek' => 0,
                'Day'       => 2,
                'Hour'      => 2,
        ));

        $result = $structure->output();

        $this->assertSame(strtoupper(bin2hex($result)), implode('', self::$sample));
    }

    /**
     * Test input method
     */
    function test_input()
    {
        $structure = new kolab_api_filter_mapistore_structure_timezonestruct;

        // convert input data into binary format
        $in   = pack("H*" , implode('', self::$sample));
        $len  = strlen($in);

        $result = $structure->input($in);

        $this->assertSame($len, $result);
        $this->assertSame(480, $structure->Bias);
        $this->assertSame(0, $structure->StandardBias);
        $this->assertSame(-60, $structure->DaylightBias);
        $this->assertSame(0, $structure->StandardYear);
        $this->assertSame(0, $structure->DaylightYear);
        $this->assertInstanceOf('kolab_api_filter_mapistore_structure_systemtime', $structure->StandardDate);
        $this->assertInstanceOf('kolab_api_filter_mapistore_structure_systemtime', $structure->DaylightDate);
        $this->assertSame(0, $structure->StandardDate->Year);
        $this->assertSame(11, $structure->StandardDate->Month);
        $this->assertSame(0, $structure->StandardDate->DayOfWeek);
        $this->assertSame(1, $structure->StandardDate->Day);
        $this->assertSame(2, $structure->StandardDate->Hour);
        $this->assertSame(0, $structure->StandardDate->Minute);
        $this->assertSame(0, $structure->StandardDate->Second);
        $this->assertSame(0, $structure->StandardDate->Milliseconds);
        $this->assertSame(0, $structure->DaylightDate->Year);
        $this->assertSame(3, $structure->DaylightDate->Month);
        $this->assertSame(0, $structure->DaylightDate->DayOfWeek);
        $this->assertSame(2, $structure->DaylightDate->Day);
        $this->assertSame(2, $structure->DaylightDate->Hour);
        $this->assertSame(0, $structure->DaylightDate->Minute);
        $this->assertSame(0, $structure->DaylightDate->Second);
        $this->assertSame(0, $structure->DaylightDate->Milliseconds);
    }

    /**
     * Test to_tzname() method
     */
    function test_to_tzname()
    {
        $structure = new kolab_api_filter_mapistore_structure_timezonestruct;

        // convert input data into binary format
        $in   = pack("H*" , implode('', self::$sample));
        $len  = strlen($in);

        $structure->input($in);

        $this->assertSame('America/Vancouver', $structure->to_tzname('America/Vancouver'));
    }

    /**
     * Test from_datetime() method
     */
    function test_from_datetime()
    {
        $dt  = new DateTime('2015-11-01 00:00:00', new DateTimeZone('Europe/Warsaw'));
        $tzs = kolab_api_filter_mapistore_structure_timezonestruct::from_datetime($dt);

        $this->assertSame(-60, $tzs->Bias);
        $this->assertSame(2015, $tzs->StandardYear);
        $this->assertSame(10, $tzs->StandardDate->Month);
        $this->assertSame(5, $tzs->StandardDate->Day);
        $this->assertSame(3, $tzs->StandardDate->Hour);
        $this->assertSame(3, $tzs->DaylightDate->Month);
        $this->assertSame(5, $tzs->DaylightDate->Day);
        $this->assertSame(2, $tzs->DaylightDate->Hour);
    }
}
