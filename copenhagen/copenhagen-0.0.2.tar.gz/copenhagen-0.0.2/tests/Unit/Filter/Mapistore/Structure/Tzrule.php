<?php

/**
 * Test class to test kolab_api_filter_mapistore_structure_tzrule
 *
 * @package Tests
 */
class KolabApiFilterMapistoreStructureTzrule extends PHPUnit_Framework_TestCase
{
    // example data from MS-OXOCAL 4.1.4
    static $sample = array(
        'MajorVersion' => '02',
        'MinorVersion' => '01',
        'Reserved'     => '3E00',
        'Flags'        => '0000',
        'Year'         => 'D607',
        'X'            => '0000000000000000000000000000',
        'Bias'         => 'E0010000',
        'StandardBias' => '00000000',
        'DaylightBias' => 'C4FFFFFF',
        'StandardDate' => '00000A00000005000200000000000000',
        'DaylightDate' => '00000400000001000200000000000000',
    );


    /**
     * Test output method
     */
    function test_output()
    {
        $structure = new kolab_api_filter_mapistore_structure_tzrule;
        $structure->Bias = 480;
        $structure->Year = 2006;
        $structure->StandardBias = 0;
        $structure->DaylightBias = -60;
        $structure->StandardDate = new kolab_api_filter_mapistore_structure_systemtime(array(
                'Year'      => 0,
                'Month'     => 10,
                'DayOfWeek' => 0,
                'Day'       => 5,
                'Hour'      => 2,
        ));
        $structure->DaylightDate = new kolab_api_filter_mapistore_structure_systemtime(array(
                'Year'      => 0,
                'Month'     => 4,
                'DayOfWeek' => 0,
                'Day'       => 1,
                'Hour'      => 2,
        ));

        $result = $structure->output();

        $this->assertSame(strtoupper(bin2hex($result)), implode('', self::$sample));
    }

    /**
     * Test input method
     */
    function test_input()
    {
        $structure = new kolab_api_filter_mapistore_structure_tzrule;

        // convert input data into binary format
        $in   = pack("H*" , implode('', self::$sample));
        $len  = strlen($in);

        $result = $structure->input($in);

        $this->assertSame($len, $result);
        $this->assertSame(0, $structure->Flags);
        $this->assertSame(2006, $structure->Year);
        $this->assertSame(480, $structure->Bias);
        $this->assertSame(0, $structure->StandardBias);
        $this->assertSame(-60, $structure->DaylightBias);
        $this->assertInstanceOf('kolab_api_filter_mapistore_structure_systemtime', $structure->StandardDate);
        $this->assertInstanceOf('kolab_api_filter_mapistore_structure_systemtime', $structure->DaylightDate);

        // Note: systemtime structures are tested in a different place
    }

    /**
     * Test to_tzname() method
     */
    function test_to_tzname()
    {
        // @TODO
        $this->markTestIncomplete('TODO');
    }

    /**
     * Test from_datetime() method
     */
    function test_from_datetime()
    {
        $dt  = new DateTime('2015-11-01 00:00:00', new DateTimeZone('Europe/Warsaw'));
        $tzs = kolab_api_filter_mapistore_structure_tzrule::from_datetime($dt);

        $this->assertSame(-60, $tzs->Bias);
        $this->assertSame(2015, $tzs->Year);
        $this->assertSame(10, $tzs->StandardDate->Month);
        $this->assertSame(5, $tzs->StandardDate->Day);
        $this->assertSame(3, $tzs->StandardDate->Hour);
        $this->assertSame(3, $tzs->DaylightDate->Month);
        $this->assertSame(5, $tzs->DaylightDate->Day);
        $this->assertSame(2, $tzs->DaylightDate->Hour);
    }
}
