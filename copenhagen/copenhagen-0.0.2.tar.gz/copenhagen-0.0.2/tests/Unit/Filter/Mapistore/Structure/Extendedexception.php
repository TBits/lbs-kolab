<?php

/**
 * Test class to test kolab_api_filter_mapistore_structure_extendedexception
 *
 * @package Tests
 */
class KolabApiFilterMapistoreStructureExtendedException extends PHPUnit_Framework_TestCase
{
    // example data from MS-OXOCAL 4.1.1.2
    static $sample = array(
        'ChangeHighlight'       => '0400000004000000',
        'ReservedBlockEE1Size'  => '00000000',
        'StartDateTime'         => '3499BC0C',
        'EndDateTime'           => '5299BC0C',
        'OriginalStartDate'     => 'F898BC0C',
        'WideCharSubjectLength' => '2100',
        'WideCharSubject'       => '530069006D0070006C006500200052006500630075007200720065006E006300650020007700690074006800200065007800630065007000740069006F006E007300',
        'WideCharLocationLength' => '0700',
        'WideCharLocation'      => '330034002F003400310034003100',
        'ReservedBlockEE2Size'  => '00000000',
    );


    /**
     * Test output method
     */
    function test_output()
    {
        $structure = new kolab_api_filter_mapistore_structure_extendedexception;
        $highlight = new kolab_api_filter_mapistore_structure_changehighlight;

        $highlight->ChangeHighlightValue = 4;
        $structure->ChangeHighlight   = $highlight;
        $structure->StartDateTime     = 0x0CBC9934;
        $structure->EndDateTime       = 0x0CBC9952;
        $structure->OriginalStartDate = 0x0CBC98F8;
        $structure->WideCharSubject   = 'Simple Recurrence with exceptions';
        $structure->WideCharLocation  = '34/4141';

        $result = $structure->output();

        $this->assertSame(strtoupper(bin2hex($result)), implode('', self::$sample));
    }

    /**
     * Test input method
     */
    function test_input()
    {
        $structure = new kolab_api_filter_mapistore_structure_extendedexception;
        $parent    = new kolab_api_filter_mapistore_structure_appointmentrecurrencepattern;
        $exception = new kolab_api_filter_mapistore_structure_exceptioninfo;

        $exception->OverrideFlags = 17;
        $parent->ExceptionInfo    = array($exception);

        // convert input data into binary format
        $in   = pack("H*" , implode('', self::$sample));
        $len  = strlen($in);

        $result = $structure->input($in, false, $parent, 0);

        $this->assertSame($len, $result);
        $this->assertInstanceOf('kolab_api_filter_mapistore_structure_changehighlight', $structure->ChangeHighlight);
        $this->assertSame(0, $structure->ReservedBlockEE1Size);
        $this->assertSame(0x0CBC9934, $structure->StartDateTime);
        $this->assertSame(0x0CBC9952, $structure->EndDateTime);
        $this->assertSame(0x0CBC98F8, $structure->OriginalStartDate);
        $this->assertSame(33, $structure->WideCharSubjectLength);
        $this->assertSame('Simple Recurrence with exceptions', $structure->WideCharSubject);
        $this->assertSame(7, $structure->WideCharLocationLength);
        $this->assertSame('34/4141', $structure->WideCharLocation);
        $this->assertSame(0, $structure->ReservedBlockEE2Size);
    }
}
