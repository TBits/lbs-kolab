<?php

/**
 * Test class to test kolab_api_filter_mapistore_structure_timezonedefinition
 *
 * @package Tests
 */
class KolabApiFilterMapistoreStructureTimezonedefinition extends PHPUnit_Framework_TestCase
{
    // example data from MS-OXOCAL 4.1.4
    static $sample = array(
        'MajorVersion' => '02',
        'MinorVersion' => '01',
        'cbHeader'     => '3000',
        'Reserved'     => '0200',
        'cchKeyName'   => '1500',
        'KeyName'      => '500061006300690066006900630020005300740061006E0064006100720064002000540069006D006500',
        'cRules'       => '0200',
        'TZRule1'      => '02013E000000D6070000000000000000000000000000E001000000000000C4FFFFFF00000A0000000500020000000000000000000400000001000200000000000000',
        'TZRule2'      => '02013E000200D7070000000000000000000000000000E001000000000000C4FFFFFF00000B0000000100020000000000000000000300000002000200000000000000',
    );


    /**
     * Test output method
     */
    function test_output()
    {
        // @TODO
        $this->markTestIncomplete('TODO');
    }

    /**
     * Test input method
     */
    function test_input()
    {
        $structure = new kolab_api_filter_mapistore_structure_timezonedefinition;

        // convert input data into binary format
        $in   = pack("H*" , implode('', self::$sample));
        $len  = strlen($in);

        $result = $structure->input($in);

        $this->assertSame($len, $result);
        $this->assertSame(48, $structure->cbHeader);
        $this->assertSame(21, $structure->cchKeyName);
        $this->assertSame('Pacific Standard Time', $structure->KeyName);
        $this->assertSame(2, $structure->cRules);
        $this->assertCount(2, $structure->TZRules);
        $this->assertInstanceOf('kolab_api_filter_mapistore_structure_tzrule', $structure->TZRules[0]);
        $this->assertInstanceOf('kolab_api_filter_mapistore_structure_tzrule', $structure->TZRules[1]);

        // Note: TZrule contents is tested in another place
    }
}
