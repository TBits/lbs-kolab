<?php

/**
 * Test class to test kolab_api_filter_mapistore_structure_exceptioninfo
 *
 * @package Tests
 */
class KolabApiFilterMapistoreStructureExceptioninfo extends PHPUnit_Framework_TestCase
{
    // example data from MS-OXOCAL 4.1.1.2
    static $sample = array(
        'StartDateTime'     => '3499BC0C',
        'EndDateTime'       => '5299BC0C',
        'OriginalStartDate' => 'F898BC0C',
        'OverrideFlags'     => '1100',
        'SubjectLength'     => '2200',
        'SubjectLength2'    => '2100',
        'Subject'           => '53696D706C6520526563757272656E6365207769746820657863657074696F6E73',
        'LocationLength'    => '0800',
        'LocationLength2'   => '0700',
        'Location'          => '33342F34313431',
    );


    /**
     * Test output method
     */
    function test_output()
    {
        $structure = new kolab_api_filter_mapistore_structure_exceptioninfo;

        $structure->StartDateTime    = 0x0CBC9934;
        $structure->EndDateTime      = 0x0CBC9952;
        $structure->OriginalStartDate = 0x0CBC98F8;
        $structure->Subject          = 'Simple Recurrence with exceptions';
        $structure->Location         = '34/4141';

        $result = $structure->output();

        $this->assertSame(strtoupper(bin2hex($result)), implode('', self::$sample));
    }

    /**
     * Test input method
     */
    function test_input()
    {
        $structure = new kolab_api_filter_mapistore_structure_exceptioninfo;

        // convert input data into binary format
        $in   = pack("H*" , implode('', self::$sample));
        $len  = strlen($in);

        $result = $structure->input($in);

        $this->assertSame($len, $result);
        $this->assertSame(0x0CBC9934, $structure->StartDateTime);
        $this->assertSame(0x0CBC9952, $structure->EndDateTime);
        $this->assertSame(0x0CBC98F8, $structure->OriginalStartDate);
        $this->assertSame(0x0011, $structure->OverrideFlags);
        $this->assertSame(34, $structure->SubjectLength);
        $this->assertSame(33, $structure->SubjectLength2);
        $this->assertSame('Simple Recurrence with exceptions', $structure->Subject);
        $this->assertSame(8, $structure->LocationLength);
        $this->assertSame(7, $structure->LocationLength2);
        $this->assertSame('34/4141', $structure->Location);
    }
}
