<?php

/**
 * Test class to test kolab_api_filter_mapistore_structure_systemtime
 *
 * @package Tests
 */
class KolabApiFilterMapistoreStructureSystemtime extends PHPUnit_Framework_TestCase
{
    static $sample = '00000A00000005000200000000000000';


    /**
     * Test output method
     */
    function test_output()
    {
        $structure = new kolab_api_filter_mapistore_structure_systemtime;
        $structure->Year = 0;
        $structure->Month = 10;
        $structure->DayOfWeek = 0;
        $structure->Day = 5;
        $structure->Hour = 2;

        $result = $structure->output();

        $this->assertSame(strtoupper(bin2hex($result)), self::$sample);
    }

    /**
     * Test input method
     */
    function test_input()
    {
        $structure = new kolab_api_filter_mapistore_structure_systemtime;

        // convert input data into binary format
        $in   = pack("H*" , self::$sample);
        $len  = strlen($in);

        $result = $structure->input($in);

        $this->assertSame($len, $result);
        $this->assertSame(0, $structure->Year);
        $this->assertSame(10, $structure->Month);
        $this->assertSame(0, $structure->DayOfWeek);
        $this->assertSame(5, $structure->Day);
        $this->assertSame(2, $structure->Hour);
        $this->assertSame(0, $structure->Minute);
        $this->assertSame(0, $structure->Second);
        $this->assertSame(0, $structure->Milliseconds);
    }
}
