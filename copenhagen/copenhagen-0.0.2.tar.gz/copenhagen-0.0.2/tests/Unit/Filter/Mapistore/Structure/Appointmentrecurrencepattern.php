<?php

/**
 * Test class to test kolab_api_filter_mapistore_structure_appointmentrecurrencepattern
 *
 * @package Tests
 */
class KolabApiFilterMapistoreStructureAppointmentrecurrencepattern extends PHPUnit_Framework_TestCase
{
    // example data from MS-OXOCAL 4.1.1.2
    static $sample = array(
        'RecurrencePattern'     => '', // taken from recurrencepattern test
        'ReaderVersion'         => '06300000',
        'WriterVersion'         => '09300000',
        'StartTimeOffset'       => '58020000',
        'EndTimeOffset'         => '76020000',
        'ExceptionCount'        => '0100',
        'ExceptionInfo'         => '', // taken from exceptioninfo test
        'ReservedBlock1Size'    => '00000000',
        'ExtendedException'     => '', // taken from extendedexception test
        'ReservedBlock2Size'    => '00000000',
    );


    /**
     * Test output method
     */
    function test_output()
    {
        $structure         = new kolab_api_filter_mapistore_structure_appointmentrecurrencepattern;
        $exceptioninfo     = new kolab_api_filter_mapistore_structure_exceptioninfo;
        $recurrencepattern = new kolab_api_filter_mapistore_structure_recurrencepattern;
        $extendedexception = new kolab_api_filter_mapistore_structure_extendedexception;
        $highlight         = new kolab_api_filter_mapistore_structure_changehighlight;

        $highlight->ChangeHighlightValue = 4;
        $extendedexception->ChangeHighlight   = $highlight;
        $extendedexception->StartDateTime     = 0x0CBC9934;
        $extendedexception->EndDateTime       = 0x0CBC9952;
        $extendedexception->OriginalStartDate = 0x0CBC98F8;
        $extendedexception->WideCharSubject   = 'Simple Recurrence with exceptions';
        $extendedexception->WideCharLocation  = '34/4141';

        $recurrencepattern->RecurFrequency          = 0x200b;
        $recurrencepattern->PatternType             = 1;
        $recurrencepattern->CalendarType            = 0;
        $recurrencepattern->FirstDateTime           = 0x000021C0;
        $recurrencepattern->Period                  = 1;
        $recurrencepattern->SlidingFlag             = 0;
        $recurrencepattern->PatternTypeSpecific     = 0x00000032;
        $recurrencepattern->EndType                 = 0x00002022;
        $recurrencepattern->OccurrenceCount         = 12;
        $recurrencepattern->FirstDOW                = 0;
        $recurrencepattern->DeletedInstanceDates    = array(0x0CBC96A0);
        $recurrencepattern->ModifiedInstanceDates   = array(0x0CBC96A0);
        $recurrencepattern->StartDate               = 213655680;
        $recurrencepattern->EndDate                 = 0x0CBCAD20;

        $exceptioninfo->StartDateTime    = 0x0CBC9934;
        $exceptioninfo->EndDateTime      = 0x0CBC9952;
        $exceptioninfo->OriginalStartDate = 0x0CBC98F8;
        $exceptioninfo->Subject          = 'Simple Recurrence with exceptions';
        $exceptioninfo->Location         = '34/4141';

        $structure->StartTimeOffset     = 600;
        $structure->EndTimeOffset       = 630;
        $structure->ExceptionInfo       = array($exceptioninfo);
        $structure->RecurrencePattern   = $recurrencepattern;
        $structure->ExtendedException   = array($extendedexception);

        $result = $structure->output();

        require_once __DIR__ . '/Recurrencepattern.php';
        require_once __DIR__ . '/Exceptioninfo.php';
        require_once __DIR__ . '/Extendedexception.php';

        $expected = self::$sample;
        $expected['RecurrencePattern'] = implode('', KolabApiFilterMapistoreStructureRecurrencepattern::$sample);
        $expected['ExceptionInfo']     = implode('', KolabApiFilterMapistoreStructureExceptioninfo::$sample);
        $expected['ExtendedException'] = implode('', KolabApiFilterMapistoreStructureExtendedexception::$sample);

        $this->assertSame(strtoupper(bin2hex($result)), implode('', $expected));
    }

    /**
     * Test input method
     */
    function test_input()
    {
        $structure = new kolab_api_filter_mapistore_structure_appointmentrecurrencepattern;

        require_once __DIR__ . '/Recurrencepattern.php';
        require_once __DIR__ . '/Exceptioninfo.php';
        require_once __DIR__ . '/Extendedexception.php';

        $in = self::$sample;
        $in['RecurrencePattern'] = implode('', KolabApiFilterMapistoreStructureRecurrencepattern::$sample);
        $in['ExceptionInfo']     = implode('', KolabApiFilterMapistoreStructureExceptioninfo::$sample);
        $in['ExtendedException'] = implode('', KolabApiFilterMapistoreStructureExtendedexception::$sample);

        // convert input data into binary format
        $in   = pack("H*" , implode('', $in));
        $len  = strlen($in);

        $result = $structure->input($in);

        $this->assertSame($len, $result);
        $this->assertInstanceOf('kolab_api_filter_mapistore_structure_recurrencepattern', $structure->RecurrencePattern);
        $this->assertSame(0x00003006, $structure->ReaderVersion);
        $this->assertSame(0x00003009, $structure->WriterVersion);
        $this->assertSame(600, $structure->StartTimeOffset);
        $this->assertSame(630, $structure->EndTimeOffset);
        $this->assertSame(1, $structure->ExceptionCount);
        $this->assertInternalType('array', $structure->ExceptionInfo);
        $this->assertInstanceOf('kolab_api_filter_mapistore_structure_exceptioninfo', $structure->ExceptionInfo[0]);
        $this->assertInternalType('array', $structure->ExtendedException);
        $this->assertInstanceOf('kolab_api_filter_mapistore_structure_extendedexception', $structure->ExtendedException[0]);
        $this->assertSame(0, $structure->ReservedBlock1Size);
        $this->assertSame(0, $structure->ReservedBlock2Size);
    }
}
