<?php

/**
 * Test class to test kolab_api_filter_mapistore_structure_recipientrow
 *
 * @package Tests
 */
class KolabApiFilterMapistoreStructureRecipientrow extends PHPUnit_Framework_TestCase
{
    static $sample = array(
    );


    /**
     * Test output method
     */
    function test_output()
    {
        // @TODO
        $this->markTestIncomplete('TODO');
    }

    /**
     * Test input method
     */
    function test_input()
    {
        // @TODO
        $this->markTestIncomplete('TODO');
    }
}
