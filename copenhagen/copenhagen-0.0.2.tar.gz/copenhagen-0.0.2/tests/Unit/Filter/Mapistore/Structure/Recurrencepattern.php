<?php

/**
 * Test class to test kolab_api_filter_mapistore_structure_recurrencepattern
 *
 * @package Tests
 */
class KolabApiFilterMapistoreStructureRecurrencepattern extends PHPUnit_Framework_TestCase
{
    // example data from MS-OXOCAL 4.1.1.2
    static $sample = array(
        'ReaderVersion'         => '0430',
        'WriterVersion'         => '0430',
        'RecurFrequency'        => '0B20',
        'PatternType'           => '0100',
        'CalendarType'          => '0000',
        'FirstDateTime'         => 'C0210000',
        'Period'                => '01000000',
        'SlidingFlag'           => '00000000',
        'PatternTypeSpecific'   => '32000000',
        'EndType'               => '22200000',
        'OccurrenceCount'       => '0C000000',
        'FirstDOW'              => '00000000',
        'DeletedInstanceCount'  => '01000000',
        'DeletedInstanceDates'  => 'A096BC0C',
        'ModifiedInstanceCount' => '01000000',
        'ModifiedInstanceDates' => 'A096BC0C',
        'StartDate'             => '8020BC0C',
        'EndDate'               => '20ADBC0C',
    );


    /**
     * Test output method
     */
    function test_output()
    {
        $structure = new kolab_api_filter_mapistore_structure_recurrencepattern;

        $structure->RecurFrequency          = 0x200b;
        $structure->PatternType             = 1;
        $structure->CalendarType            = 0;
        $structure->FirstDateTime           = 0x000021C0;
        $structure->Period                  = 1;
        $structure->SlidingFlag             = 0;
        $structure->PatternTypeSpecific     = 0x00000032;
        $structure->EndType                 = 0x00002022;
        $structure->OccurrenceCount         = 12;
        $structure->FirstDOW                = 0;
        $structure->DeletedInstanceDates    = array(0x0CBC96A0);
        $structure->ModifiedInstanceDates   = array(0x0CBC96A0);
        $structure->StartDate               = 213655680;
        $structure->EndDate                 = 0x0CBCAD20;

        $result = $structure->output();

        $this->assertSame(strtoupper(bin2hex($result)), implode('', self::$sample));
    }

    /**
     * Test input method
     */
    function test_input()
    {
        $structure = new kolab_api_filter_mapistore_structure_recurrencepattern;

        // convert input data into binary format
        $in   = pack("H*" , implode('', self::$sample));
        $len  = strlen($in);

        $result = $structure->input($in);

        $this->assertSame($len, $result);
        $this->assertSame(0x3004, $structure->ReaderVersion);
        $this->assertSame(0x3004, $structure->WriterVersion);
        $this->assertSame(0x200b, $structure->RecurFrequency);
        $this->assertSame(0x0001, $structure->PatternType);
        $this->assertSame(0, $structure->CalendarType);
        $this->assertSame(0x000021C0, $structure->FirstDateTime);
        $this->assertSame(0x0001, $structure->Period);
        $this->assertSame(0, $structure->SlidingFlag);
        $this->assertSame(0x00000032, $structure->PatternTypeSpecific);
        $this->assertSame(0x00002022, $structure->EndType);
        $this->assertSame(12, $structure->OccurrenceCount);
        $this->assertSame(0, $structure->FirstDOW);
        $this->assertSame(1, $structure->DeletedInstanceCount);
        $this->assertSame(array(0x0CBC96A0), $structure->DeletedInstanceDates);
        $this->assertSame(1, $structure->ModifiedInstanceCount);
        $this->assertSame(array(0x0CBC96A0), $structure->ModifiedInstanceDates);
        $this->assertSame(213655680, $structure->StartDate);
        $this->assertSame(0x0CBCAD20, $structure->EndDate);
    }
}
