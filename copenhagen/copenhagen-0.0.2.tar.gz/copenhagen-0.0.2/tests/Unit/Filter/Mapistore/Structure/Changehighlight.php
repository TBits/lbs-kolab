<?php

/**
 * Test class to test kolab_api_filter_mapistore_structure_changehighlight
 *
 * @package Tests
 */
class KolabApiFilterMapistoreStructureChangehighlight extends PHPUnit_Framework_TestCase
{
    // example data from MS-OXOCAL 4.1.1.2
    static $sample = array(
        'ChangeHighlightSize'  => '04000000',
        'ChangeHighlightValue' => '04000000',
    );


    /**
     * Test output method
     */
    function test_output()
    {
        $structure = new kolab_api_filter_mapistore_structure_changehighlight;

        $structure->ChangeHighlightValue = 4;

        $result = $structure->output();

        $this->assertSame(strtoupper(bin2hex($result)), implode('', self::$sample));
    }

    /**
     * Test input method
     */
    function test_input()
    {
        $structure = new kolab_api_filter_mapistore_structure_changehighlight;

        // convert input data into binary format
        $in   = pack("H*" , implode('', self::$sample));
        $len  = strlen($in);

        $result = $structure->input($in);

        $this->assertSame($len, $result);
        $this->assertSame(4, $structure->ChangeHighlightSize);
        $this->assertSame(4, $structure->ChangeHighlightValue);
        $this->assertSame(null, $structure->Reserved);
    }
}
