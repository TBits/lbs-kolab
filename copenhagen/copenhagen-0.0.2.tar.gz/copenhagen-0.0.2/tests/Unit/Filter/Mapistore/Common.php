<?php

/**
 * Test class to test kolab_api_filter_mapistore_common
 *
 * @package Tests
 */
class KolabApiFilterMapistoreCommon extends PHPUnit_Framework_TestCase
{
    /**
     * Test get_kolab_value method
     */
    function test_get_kolab_value()
    {
        $data = array(
            'n1' => array(
                'n2' => 'test2',
            ),
            'n3' => 'test3',
            'x-custom' => array(
                array('identifier' => 'i', value => 'val_i'),
            ),
        );

        $value = kolab_api_filter_mapistore_common::get_kolab_value($data, 'n1.n2');
        $this->assertSame('test2', $value);

        $value = kolab_api_filter_mapistore_common::get_kolab_value($data, 'n3');
        $this->assertSame('test3', $value);

        $value = kolab_api_filter_mapistore_common::get_kolab_value($data, 'n30');
        $this->assertSame(null, $value);

        $value = kolab_api_filter_mapistore_common::get_kolab_value($data, 'x-custom.i');
        $this->assertSame('val_i', $value);
    }

    /**
     * Test set_kolab_value method
     */
    function test_set_kolab_value()
    {
        $data = array();

        kolab_api_filter_mapistore_common::set_kolab_value($data, 'n1.n2', 'test');
        $this->assertSame('test', $data['n1']['n2']);

        kolab_api_filter_mapistore_common::set_kolab_value($data, 'n1', 'test');
        $this->assertSame('test', $data['n1']);

        kolab_api_filter_mapistore_common::set_kolab_value($data, 'x-custom.i', 'test1');
        $this->assertSame('test1', $data['x-custom.i']);
    }

    /**
     * Test attributes_filter method
     */
    function test_attributes_filter()
    {
        $api = new kolab_api_filter_mapistore_common;

        $input = array(
            'creation-date',
            'uid',
            'unknown',
        );

        $expected = array(
            'PidTagCreationTime',
            'id',
        );

        $result = $api->attributes_filter($input, true);
        $this->assertSame($expected, $result);

        $input    = $expected;
        $expected = array(
            'creation-date',
            'uid',
        );

        $result = $api->attributes_filter($input);
        $this->assertSame($expected, $result);

        $result = $api->attributes_filter(array());
        $this->assertSame(array(), $result);
    }

    /**
     * Test parse_categories method
     */
    function test_parse_categories()
    {
        $categories = array(
            "test\x3Btest",
            "test\x2Ctest",
            "a\x06\x1Ba",
            "b\xFE\x54b",
            "c\xFF\x1Bc",
            "test    ",
            "    test",
        );

        $expected = array(
            "testtest",
            "aa",
            "bb",
            "cc",
            "test",
        );

        $result = kolab_api_filter_mapistore_common::parse_categories($categories);

        $this->assertSame($expected, $result);
    }

    /**
     * Test date_php2mapi method
     */
    function test_date_php2mapi()
    {
        $date = kolab_api_filter_mapistore_common::date_php2mapi('2014-01-01T00:00:00+00:00');
        $this->assertSame(13033008000.0, $date);

        $date = kolab_api_filter_mapistore_common::date_php2mapi('2014-01-01');
        $this->assertSame(13033008000.0, $date);

        $date = kolab_api_filter_mapistore_common::date_php2mapi('1970-01-01T00:00:00Z');
        $this->assertSame(11644473600.0, $date);

        $date = kolab_api_filter_mapistore_common::date_php2mapi('1601-01-01T00:00:00Z');
        $this->assertSame(0.0, $date);

        $date = new DateTime('1601-01-01T00:00:00Z');
        $date = kolab_api_filter_mapistore_common::date_php2mapi($date);
        $this->assertSame(0.0, $date);
/*
        $date = new DateTime('1970-01-01 00:00:00.1000 +0000');
        $date = kolab_api_filter_mapistore::date_php2mapi($date);
        $this->assertSame(11644473600.1, $date);
*/
        $date = kolab_api_filter_mapistore_common::date_php2mapi('');
        $this->assertSame(null, $date);
    }

    /**
     * Test date_mapi2php method
     */
    function test_date_mapi2php()
    {
        $format = 'c';
        $data   = array(
            13033008000       => '2014-01-01T00:00:00+00:00',
            11644473600       => '1970-01-01T00:00:00+00:00',
//            11644473600.00001 => '1970-01-01T00:00:00.10+00:00',
            0                 => '1601-01-01T00:00:00+00:00',
        );

        foreach ($data as $mapi => $exp) {
            $date = kolab_api_filter_mapistore_common::date_mapi2php($mapi);
            $this->assertSame($exp, $date->format($format));
        }
    }

    /**
     * Test input date_minutes2php
     */
    function test_date_minutes2php()
    {
        // @TODO
        $this->markTestIncomplete('TODO');
    }

    /**
     * Test input date_php2minutes
     */
    function test_date_php2minutes()
    {
        // @TODO
        $this->markTestIncomplete('TODO');
    }
}
