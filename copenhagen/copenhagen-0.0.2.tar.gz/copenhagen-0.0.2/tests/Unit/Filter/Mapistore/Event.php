<?php

/**
 * Test class to test kolab_api_filter_mapistore_event
 *
 * @package Tests
 */
class KolabApiFilterMapistoreEvent extends PHPUnit_Framework_TestCase
{
    static $original;

    /**
     * Test output method
     */
    function test_output()
    {
        kolab_api::$now = new DateTime('2015-05-10 00:00:00 UTC');

        $api    = new kolab_api_filter_mapistore_event;
        $data   = kolab_api_tests::get_data('100-100-100-100', 'Calendar', 'event', 'json', $context);
        $result = $api->output($data, $context);

        $this->assertSame(kolab_api_tests::mapi_uid('Calendar', false, '100-100-100-100'), $result['id']);
        $this->assertSame('calendars', $result['collection']);
        $this->assertSame('IPM.Appointment', $result['PidTagMessageClass']);
        $this->assertSame(kolab_api_filter_mapistore_common::date_php2mapi('2015-05-14T13:03:33Z'), $result['PidTagCreationTime']);
        $this->assertSame(kolab_api_filter_mapistore_common::date_php2mapi('2015-05-14T13:50:18Z'), $result['PidTagLastModificationTime']);
        $this->assertSame(30, $result['PidLidAppointmentDuration']);
        $this->assertSame(2, $result['PidLidAppointmentSequence']);
        $this->assertSame(3, $result['PidTagSensitivity']);
        $this->assertSame(true, $result['PidTagHasAttachments']);
        $this->assertSame(array('tag1'), $result['PidNameKeywords']);
/*
        $this->assertSame('/kolab.org/Europe/Berlin', $result['dtstart']['parameters']['tzid']);
        $this->assertSame('2015-05-15T10:00:00', $result['dtstart']['date-time']);
        $this->assertSame('/kolab.org/Europe/Berlin', $result['dtend']['parameters']['tzid']);
        $this->assertSame('2015-05-15T10:30:00', $result['dtend']['date-time']);
        $this->assertSame('https://some.url', $result['url']);
*/
        $this->assertSame('Summary', $result['PidTagSubject']);
        $this->assertSame('Description', $result['PidTagBody']);
        $this->assertSame(2, $result['PidTagImportance']);
        $this->assertSame('Location', $result['PidLidLocation']);
        $this->assertSame('German, Mark',               $result['recipients'][0]['PidTagDisplayName']);
        $this->assertSame('mark.german@example.org',    $result['recipients'][0]['PidTagEmailAddress']);
        $this->assertSame(1,                            $result['recipients'][0]['PidTagRecipientType']);
        $this->assertSame(3,                            $result['recipients'][0]['PidTagRecipientFlags']);
        $this->assertSame('Manager, Jane',              $result['recipients'][1]['PidTagDisplayName']);
        $this->assertSame(1,                            $result['recipients'][1]['PidTagRecipientType']);
        $this->assertSame('jane.manager@example.org',   $result['recipients'][1]['PidTagEmailAddress']);
        $this->assertSame(0,                            $result['recipients'][1]['PidTagRecipientTrackStatus']);
        $this->assertSame(1,                            $result['recipients'][1]['PidTagRecipientFlags']);
        $this->assertSame(15, $result['PidLidReminderDelta']);
        $this->assertSame(true, $result['PidLidReminderSet']);
        $this->assertTrue($result['PidLidAppointmentTimeZoneDefinitionStartDisplay'] == $result['PidLidAppointmentTimeZoneDefinitionStartDisplay']);

        // PidLidTimeZoneDefinition
        $tzd = new kolab_api_filter_mapistore_structure_timezonedefinition;
        $tzd->input($result['PidLidAppointmentTimeZoneDefinitionStartDisplay'], true);

        $this->assertSame('Europe/Berlin', $tzd->KeyName);
        $this->assertCount(1, $tzd->TZRules);
        $this->assertSame(2015, $tzd->TZRules[0]->Year);
        $this->assertSame(-60, $tzd->TZRules[0]->Bias);

        $data   = kolab_api_tests::get_data('101-101-101-101', 'Calendar', 'event', 'json', $context);
        $result = $api->output($data, $context);

        $this->assertSame(kolab_api_tests::mapi_uid('Calendar', false, '101-101-101-101'), $result['id']);
        $this->assertSame('calendars', $result['collection']);
        $this->assertSame('IPM.Appointment', $result['PidTagMessageClass']);
        $this->assertSame(0, $result['PidTagSensitivity']);
        $this->assertSame(kolab_api_filter_mapistore_common::date_php2mapi('2015-05-15T00:00:00Z'), $result['PidLidAppointmentStartWhole']);
        $this->assertSame(kolab_api_filter_mapistore_common::date_php2mapi('2015-05-16T00:00:00Z'), $result['PidLidAppointmentEndWhole']);
        $this->assertSame(24 * 60, $result['PidLidAppointmentDuration']);
        $this->assertSame(1, $result['PidLidAppointmentSubType']);
        $this->assertSame(null, $result['PidTagHasAttachments']);

        // EXDATE
        $arp = new kolab_api_filter_mapistore_structure_appointmentrecurrencepattern;
        $arp->input($result['PidLidAppointmentRecur'], true);

        $this->assertSame(1, $arp->RecurrencePattern->Period);
        $this->assertSame(0x200B, $arp->RecurrencePattern->RecurFrequency);
        $this->assertSame(1, $arp->RecurrencePattern->PatternType);
        $this->assertSame(2, $arp->RecurrencePattern->DeletedInstanceCount);
        $this->assertCount(2, $arp->RecurrencePattern->DeletedInstanceDates);

        // RDATE
        $data   = kolab_api_tests::get_data('102-102-102-102', 'Calendar', 'event', 'json', $context);
        $result = $api->output($data, $context);

        // recurrence
        $arp = new kolab_api_filter_mapistore_structure_appointmentrecurrencepattern;
        $arp->input($result['PidLidAppointmentRecur'], true);

        $this->assertSame(2, $arp->RecurrencePattern->DeletedInstanceCount);
        $this->assertCount(2, $arp->RecurrencePattern->DeletedInstanceDates);
        $this->assertSame(2, $arp->RecurrencePattern->ModifiedInstanceCount);
        $this->assertCount(2, $arp->RecurrencePattern->ModifiedInstanceDates);
        $this->assertSame(2, $arp->ExceptionCount);
        $this->assertCount(2, $arp->ExceptionInfo);
        $this->assertCount(2, $arp->ExtendedException);

        // PidLidTimeZoneStruct
        $tz = new kolab_api_filter_mapistore_structure_timezonestruct;
        $tz->input($result['PidLidTimeZoneStruct'], true);

        $this->assertSame(-60, $tz->Bias);
        $this->assertSame(0, $tz->StandardYear);
        $this->assertSame(10, $tz->StandardDate->Month);
        $this->assertSame('(GMT+01:00) Europe/Berlin', $result['PidLidTimeZoneDescription']);
    }

    /**
     * Test recurrences output
     */
    function test_output_recurrence()
    {
        $data = array(
            'dtstart' => '2015-01-01T00:00:00Z',
            'rrule'   => array(
                'recur' => array(
                    'freq'       => 'MONTHLY',
                    'bymonthday' => 5,
                    'count'      => 10,
                    'interval'   => 2,
                ),
            ),
            'exdate' => array(
                'date' => array(
                    '2015-01-01',
                    '2016-01-01',
                ),
            ),
            'rdate' => array(
                'date' => array(
                    '2015-02-01',
                ),
            ),
        );

        $api    = new kolab_api_filter_mapistore_event;
        $arp    = new kolab_api_filter_mapistore_structure_appointmentrecurrencepattern;
        $result = $api->output($data, $context);
        $arp->input($result['PidLidAppointmentRecur'], true);

        $this->assertSame(kolab_api_filter_mapistore_structure_recurrencepattern::PATTERNTYPE_MONTH, $arp->RecurrencePattern->PatternType);
        $this->assertSame(kolab_api_filter_mapistore_structure_recurrencepattern::RECURFREQUENCY_MONTHLY, $arp->RecurrencePattern->RecurFrequency);

        $this->assertSame(5, $arp->RecurrencePattern->PatternTypeSpecific);
        $this->assertSame(10, $arp->RecurrencePattern->OccurrenceCount);
        $this->assertSame(2, $arp->RecurrencePattern->Period);
        $this->assertSame(3, $arp->RecurrencePattern->DeletedInstanceCount);
        $this->assertCount(3, $arp->RecurrencePattern->DeletedInstanceDates);
        $this->assertSame(1, $arp->RecurrencePattern->ModifiedInstanceCount);
        $this->assertCount(1, $arp->RecurrencePattern->ModifiedInstanceDates);
        $this->assertSame(1, $arp->ExceptionCount);
        $this->assertCount(1, $arp->ExceptionInfo);
        $this->assertCount(1, $arp->ExtendedException);

        $this->assertSame(null, $result['PidLidAppointmentDuration']);
    }

    /**
     * Test alarms output
     */
    function test_output_alarms()
    {
        kolab_api::$now = new DateTime('2015-01-20 00:00:00 UTC');

        $data = array(
            'dtstart' => '2015-01-01T00:00:00Z',
            'rrule'   => array(
                'recur' => array(
                    'freq'       => 'MONTHLY',
                    'bymonthday' => 5,
                    'count'      => 10,
                    'interval'   => 1,
                ),
            ),
            'valarm' => array(
                array(
                    'properties' => array(
                        'action'  => 'DISPLAY',
                        'trigger' => array(
                            'duration' => '-PT15M',
                        ),
                    ),
                ),
            ),
            'duration' => 'PT10M',
        );

        $api    = new kolab_api_filter_mapistore_event;
        $result = $api->output($data, $context);

        $this->assertSame(15, $result['PidLidReminderDelta']);
        $this->assertSame(true, $result['PidLidReminderSet']);
        $this->assertSame('2015-02-20T00:00:00+00:00', kolab_api_filter_mapistore_common::date_mapi2php($result['PidLidReminderTime'])->format('c'));
        $this->assertSame('2015-02-19T23:45:00+00:00', kolab_api_filter_mapistore_common::date_mapi2php($result['PidLidReminderSignalTime'])->format('c'));
        $this->assertSame(10, $result['PidLidAppointmentDuration']);
    }

    /**
     * Test exceptions output
     */
    function test_output_exceptions()
    {
        kolab_api::$now = new DateTime('2015-05-10 00:00:00 UTC');

        $api    = new kolab_api_filter_mapistore_event;
        $arp    = new kolab_api_filter_mapistore_structure_appointmentrecurrencepattern;
        $exi    = new kolab_api_filter_mapistore_structure_exceptioninfo;
        $data   = kolab_api_tests::get_data('103-103-103-103', 'Calendar', 'event', 'json', $context);
        $result = $api->output($data, $context);

        $this->assertSame(true, $result['PidTagHasAttachments']);

        $arp->input($result['PidLidAppointmentRecur'], true);

        $this->assertSame(kolab_api_filter_mapistore_structure_recurrencepattern::PATTERNTYPE_WEEK, $arp->RecurrencePattern->PatternType);
        $this->assertSame(kolab_api_filter_mapistore_structure_recurrencepattern::RECURFREQUENCY_WEEKLY, $arp->RecurrencePattern->RecurFrequency);

        $this->assertSame(2, $arp->RecurrencePattern->ModifiedInstanceCount);
        $this->assertCount(2, $arp->RecurrencePattern->ModifiedInstanceDates);
        $this->assertSame(1, $arp->RecurrencePattern->DeletedInstanceCount);
        $this->assertCount(1, $arp->RecurrencePattern->DeletedInstanceDates);
        $this->assertCount(2, $arp->ExtendedException);
        $this->assertCount(2, $arp->ExceptionInfo);

        $this->assertSame('Location mod', $arp->ExceptionInfo[0]->Location);
        $this->assertSame(35, $arp->ExceptionInfo[0]->ReminderDelta);
        $this->assertSame(1, $arp->ExceptionInfo[0]->ReminderSet);
        $this->assertSame(kolab_api_filter_mapistore_common::date_php2minutes(new DateTime('2015-06-22T00:00:00+00:00')), $arp->ExceptionInfo[0]->StartDateTime);
        $this->assertSame(kolab_api_filter_mapistore_common::date_php2minutes(new DateTime('2015-06-23T00:00:00+00:00')), $arp->ExceptionInfo[0]->EndDateTime);
        $this->assertSame(kolab_api_filter_mapistore_common::date_php2minutes(new DateTime('2015-06-22T00:00:00+00:00')), $arp->ExceptionInfo[0]->OriginalStartDate);

        $this->assertSame(kolab_api_filter_mapistore_common::date_php2minutes(new DateTime('2015-06-29T00:00:00+00:00')), $arp->ExceptionInfo[1]->StartDateTime);
        $this->assertSame(kolab_api_filter_mapistore_common::date_php2minutes(new DateTime('2015-06-30T00:00:00+00:00')), $arp->ExceptionInfo[1]->EndDateTime);
        $this->assertSame(kolab_api_filter_mapistore_common::date_php2minutes(new DateTime('2015-06-29T00:00:00+00:00')), $arp->ExceptionInfo[1]->OriginalStartDate);

        $this->assertSame('Location mod', $arp->ExtendedException[0]->WideCharLocation);
        $this->assertSame($arp->ExceptionInfo[0]->StartDateTime,    $arp->ExtendedException[0]->StartDateTime);
        $this->assertSame($arp->ExceptionInfo[0]->EndDateTime,      $arp->ExtendedException[0]->EndDateTime);
        $this->assertSame($arp->ExceptionInfo[0]->OriginalStartDate, $arp->ExtendedException[0]->OriginalStartDate);

        $this->assertSame(null, $arp->ExtendedException[1]->StartDateTime);
        $this->assertSame(null, $arp->ExtendedException[1]->EndDateTime);
        $this->assertSame(null, $arp->ExtendedException[1]->OriginalStartDate);
    }

    /**
     * Test input method
     */
    function test_input()
    {
        $api  = new kolab_api_filter_mapistore_event;
        $tzs  = new kolab_api_filter_mapistore_structure_timezonestruct(array(
                'Bias'         => -60,
                'StandardBias' => 0,
                'DaylightBias' => -60,
                'StandardDate' => new kolab_api_filter_mapistore_structure_systemtime(array(
                        'Month'     => 10,
                        'DayOfWeek' => 0,
                        'Day'       => 5,
                        'Hour'      => 3,
                )),
                'DaylightDate' => new kolab_api_filter_mapistore_structure_systemtime(array(
                        'Month'     => 3,
                        'Day'       => 5,
                        'DayOfWeek' => 0,
                        'Hour'      => 2,
                )),
        ));

        $data = array(
            'PidTagCreationTime'         => kolab_api_filter_mapistore_common::date_php2mapi('2015-05-14T13:03:33Z'),
            'PidTagLastModificationTime' => kolab_api_filter_mapistore_common::date_php2mapi('2015-05-14T13:50:18Z'),
            'PidLidAppointmentSequence' => 10,
            'PidTagSensitivity'         => 3,
            'PidNameKeywords'           => array('work'),
            'PidTagSubject'             => 'subject',
            'PidTagBody'                => 'body',
            'PidTagImportance'          => 2,
            'PidLidLocation'            => 'location',
            'PidLidAppointmentStartWhole'   => kolab_api_filter_mapistore_common::date_php2mapi('2015-05-14T13:03:33Z'),
            'PidLidAppointmentEndWhole'     => kolab_api_filter_mapistore_common::date_php2mapi('2015-05-14T16:00:00Z'),
            'PidLidReminderDelta'       => 15,
            'PidLidReminderSet'         => true,
            'PidLidTimeZoneStruct'      => $tzs->output(true),
            'recipients'                => array(
                array(
                    'PidTagDisplayName'   => 'German, Mark',
                    'PidTagEmailAddress'  => 'mark.german@example.org',
                    'PidTagRecipientType' => 1,
                    'PidTagRecipientFlags' => 3,
                ),
                array(
                    'PidTagDisplayName'   => 'Manager, Jane',
                    'PidTagEmailAddress'  => 'manager@example.org',
                    'PidTagRecipientType' => 1,
                    'PidTagRecipientTrackStatus' => 2,
                ),
            ),
        );

        $result = $api->input($data);

        $this->assertSame('subject', $result['summary']);
        $this->assertSame('body', $result['description']);
        $this->assertSame(10, $result['sequence']);
        $this->assertSame('confidential', $result['class']);
        $this->assertSame(array('work'), $result['categories']);
        $this->assertSame('location', $result['location']);
        $this->assertSame(1, $result['priority']);
        $this->assertSame('2015-05-14T13:03:33Z', $result['created']);
        $this->assertSame('2015-05-14T13:50:18Z', $result['dtstamp']);
        $this->assertSame('2015-05-14T15:03:33', $result['dtstart']['date-time']);
        $this->assertSame('2015-05-14T18:00:00', $result['dtend']['date-time']);
        $this->assertRegexp('/kolab.org/', $result['dtstart']['parameters']['tzid']);
        $this->assertRegexp('/kolab.org/', $result['dtend']['parameters']['tzid']);
        $this->assertSame('DISPLAY',  $result['valarm'][0]['properties']['action']);
        $this->assertSame('-PT15M',   $result['valarm'][0]['properties']['trigger']['duration']);

        $this->assertSame('Manager, Jane',                $result['attendee'][0]['parameters']['cn']);
        $this->assertSame('TENTATIVE',                    $result['attendee'][0]['parameters']['partstat']);
        $this->assertSame('REQ-PARTICIPANT',              $result['attendee'][0]['parameters']['role']);
//        $this->assertSame(true,                           $result['attendee'][0]['parameters']['rsvp']);
        $this->assertSame('mailto:manager%40example.org', $result['attendee'][0]['cal-address']);
        $this->assertSame('German, Mark',                     $result['organizer']['parameters']['cn']);
        $this->assertSame('mailto:mark.german%40example.org', $result['organizer']['cal-address']);

        self::$original = $result;

        $tzdef = base64_encode(pack("H*", '0201300002001500'
            . '500061006300690066006900630020005300740061006E0064006100720064002000540069006D006500'
            . '0100'
            . '02013E000000D6070000000000000000000000000000E001000000000000C4FFFFFF00000A0000000500020000000000000000000400000001000200000000000000'
        ));
        $data = array(
            'PidLidAppointmentStartWhole'   => kolab_api_filter_mapistore_common::date_php2mapi('2015-05-14T05:00:00Z'),
            'PidLidAppointmentEndWhole'     => kolab_api_filter_mapistore_common::date_php2mapi('2015-05-14T05:00:00Z'),
            'PidLidAppointmentTimeZoneDefinitionStartDisplay' => $tzdef,
            'PidLidReminderSet'             => false,
            // @TODO: recurrence, exceptions, alarms
        );

        $result = $api->input($data);

        $this->assertSame('2015-05-13T22:00:00', $result['dtstart']['date-time']);
        $this->assertSame('2015-05-14T05:00:00Z', $result['dtend']['date-time']);
        $this->assertSame(array(), $result['valarm']);
    }

    /**
     * Test input method with merge
     */
    function test_input2()
    {
        $api  = new kolab_api_filter_mapistore_event;
        $data = array(
//            'PidTagCreationTime'         => kolab_api_filter_mapistore_common::date_php2mapi('2015-05-14T13:03:33Z'),
//            'PidTagLastModificationTime' => kolab_api_filter_mapistore_common::date_php2mapi('2015-05-14T13:50:18Z'),
            'PidLidAppointmentSequence' => 20,
            'PidTagSensitivity'         => 2,
            'PidNameKeywords'           => array('work1'),
            'PidTagSubject'             => 'subject1',
            'PidTagBody'                => 'body1',
            'PidTagImportance'          => 1,
            'PidLidLocation'            => 'location1',
            'PidLidAppointmentStartWhole'   => kolab_api_filter_mapistore_common::date_php2mapi('2015-05-15T13:03:33Z'),
            'PidLidAppointmentEndWhole'     => kolab_api_filter_mapistore_common::date_php2mapi('2015-05-15T16:00:00Z'),
            'PidLidReminderDelta'       => 25,
            'PidLidReminderSet'         => true,
        );

        $result = $api->input($data, self::$original);

        $this->assertSame('subject1', $result['summary']);
        $this->assertSame('body1', $result['description']);
        $this->assertSame(20, $result['sequence']);
        $this->assertSame('private', $result['class']);
        $this->assertSame(array('work1'), $result['categories']);
        $this->assertSame('location1', $result['location']);
        $this->assertSame(5, $result['priority']);
//        $this->assertSame('2015-05-14T13:03:33Z', $result['created']);
//        $this->assertSame('2015-05-14T13:50:18Z', $result['dtstamp']);
        $this->assertSame('2015-05-15T13:03:33Z', $result['dtstart']['date-time']);
        $this->assertSame('2015-05-15T16:00:00Z', $result['dtend']['date-time']);
        $this->assertSame('DISPLAY', $result['valarm'][0]['properties']['action']);
        $this->assertSame('-PT25M', $result['valarm'][0]['properties']['trigger']['duration']);

        // @TODO: exceptions, attendees
    }

    /**
     * Test input recurrence
     */
    function test_input_recurrence()
    {
        $api = new kolab_api_filter_mapistore_event;

        // build complete AppointmentRecurrencePattern structure
        $structure         = new kolab_api_filter_mapistore_structure_appointmentrecurrencepattern;
        $exceptioninfo     = new kolab_api_filter_mapistore_structure_exceptioninfo;
        $recurrencepattern = new kolab_api_filter_mapistore_structure_recurrencepattern;
        $extendedexception = new kolab_api_filter_mapistore_structure_extendedexception;
        $highlight         = new kolab_api_filter_mapistore_structure_changehighlight;

        $highlight->ChangeHighlightValue = 4;
        $extendedexception->ChangeHighlight   = $highlight;
        $extendedexception->StartDateTime     = 0x0CBC9934;
        $extendedexception->EndDateTime       = 0x0CBC9952;
        $extendedexception->OriginalStartDate = 0x0CBC98F8;
        $extendedexception->WideCharSubject   = 'Simple Recurrence with exceptions';
        $extendedexception->WideCharLocation  = '34/4141';

        $recurrencepattern->RecurFrequency          = 0x200b;
        $recurrencepattern->PatternType             = 1;
        $recurrencepattern->CalendarType            = 0;
        $recurrencepattern->FirstDateTime           = 0x000021C0;
        $recurrencepattern->Period                  = 1;
        $recurrencepattern->SlidingFlag             = 0;
        $recurrencepattern->PatternTypeSpecific     = 0x00000032;
        $recurrencepattern->EndType                 = 0x00002022;
        $recurrencepattern->OccurrenceCount         = 12;
        $recurrencepattern->FirstDOW                = 0;
        $recurrencepattern->DeletedInstanceDates    = array(217742400, 218268000, 217787040);
        $recurrencepattern->ModifiedInstanceDates   = array(217787040);
        $recurrencepattern->StartDate               = 213655680;
        $recurrencepattern->EndDate                 = 0x0CBCAD20;

        $exceptioninfo->StartDateTime    = 0x0CBC9934;
        $exceptioninfo->EndDateTime      = 0x0CBC9952;
        $exceptioninfo->OriginalStartDate = 0x0CBC98F8;
        $exceptioninfo->Subject          = 'Simple Recurrence with exceptions';
        $exceptioninfo->Location         = '34/4141';

        $structure->StartTimeOffset     = 600;
        $structure->EndTimeOffset       = 630;
        $structure->ExceptionInfo       = array($exceptioninfo);
        $structure->RecurrencePattern   = $recurrencepattern;
        $structure->ExtendedException   = array($extendedexception);

        $rule = $structure->output(true);
        $result = $api->input(array('PidLidAppointmentRecur' => $rule), $context);

        $this->assertSame('WEEKLY', $result['rrule']['recur']['freq']);
        $this->assertSame('SU', $result['rrule']['recur']['wkst']);
        $this->assertSame('SU,TU,MO,TH,FR', $result['rrule']['recur']['byday']);
        $this->assertSame(12, $result['rrule']['recur']['count']);
        $this->assertSame('2015-01-01', $result['exdate']['date'][0]);
        $this->assertSame('2016-01-01', $result['exdate']['date'][1]);
        $this->assertSame('2015-02-01', $result['rdate']['date'][0]);
    }

    /**
     * Test input body
     */
    function test_input_body()
    {
        $api  = new kolab_api_filter_mapistore_event;
        $body = '0QAAAB0CAABMWkZ1Pzsq5D8ACQMwAQMB9wKnAgBjaBEKwHNldALRcHJx4DAgVGFoA3ECgwBQ6wNUDzcyD9MyBgAGwwKDpxIBA+MReDA0EhUgAoArApEI5jsJbzAVwzEyvjgJtBdCCjIXQRb0ORIAHxeEGOEYExjgFcMyNTX/CbQaYgoyGmEaHBaKCaUa9v8c6woUG3YdTRt/Hwwabxbt/xyPF7gePxg4JY0YVyRMKR+dJfh9CoEBMAOyMTYDMUksgSc1FGAnNhqAJ1Q3My3BNAqFfS7A';

        $result = $api->input(array('PidTagRtfCompressed' => $body), $context);

        $this->assertSame('<html><body>Test<br></body></html>', $result['description']);

        $result = $api->input(array('PidTagBody' => 'test'), $context);

        $this->assertSame('test', $result['description']);

        $result = $api->input(array('PidTagHtml' => '<html><body>test</body></html>'), $context);

        $this->assertSame('<html><body>test</body></html>', $result['description']);
    }

    /**
     * Test map method
     */
    function test_map()
    {
        $api = new kolab_api_filter_mapistore_event;
        $map = $api->map();

        $this->assertInternalType('array', $map);
        $this->assertTrue(!empty($map));
    }
}
