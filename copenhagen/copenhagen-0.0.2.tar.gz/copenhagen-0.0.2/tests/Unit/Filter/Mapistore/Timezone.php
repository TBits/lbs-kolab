<?php

/**
 * Test class to test kolab_api_filter_mapistore_timezone
 *
 * @package Tests
 */
class KolabApiFilterMapistoreTimezone extends PHPUnit_Framework_TestCase
{
    /**
     * Test from_date() method
     */
    function test_from_date()
    {
        $dt     = new DateTime('2015-10-10 01:01:00', new DateTimeZone('Europe/Berlin'));
        $result = kolab_api_filter_mapistore_timezone::from_date($dt);

        $this->assertSame(-60, $result->Bias);
        $this->assertSame(0, $result->StandardBias);
        $this->assertSame(2015, $result->StandardYear);
        $this->assertSame(10, $result->StandardMonth);
        $this->assertSame(0, $result->StandardDayOfWeek);
        $this->assertSame(5, $result->StandardDay);
        $this->assertSame(3, $result->StandardHour);
        $this->assertSame(0, $result->StandardMinute);
        $this->assertSame(-60, $result->DaylightBias);
        $this->assertSame(2015, $result->DaylightYear);
        $this->assertSame(3, $result->DaylightMonth);
        $this->assertSame(0, $result->DaylightDayOfWeek);
        $this->assertSame(5, $result->DaylightDay);
        $this->assertSame(2, $result->DaylightHour);
        $this->assertSame(0, $result->DaylightMinute);
    }

    /**
     * Test get_int_from_date() method
     */
    function test_get_int_from_date()
    {
        $dt     = new DateTime('2015-10-10 01:01:00', new DateTimeZone('Europe/Berlin'));
        $result = kolab_api_filter_mapistore_timezone::get_int_from_date($dt);

        $this->assertSame(3, $result);
    }

    /**
     * Test get_timezone() method
     */
    function test_get_timezone()
    {
        $tz = new kolab_api_filter_mapistore_timezone;
        $tz->Bias = -60;
        $tz->StandardYear  = 2015;
        $tz->StandardMonth = 10;
        $tz->StandardDay   = 5;
        $tz->StandardHour  = 3;
        $tz->DaylightBias  = -60;
        $tz->DaylightYear  = 2015;
        $tz->DaylightMonth = 3;
        $tz->DaylightDay   = 5;
        $tz->DaylightHour  = 2;

        $result = $tz->get_timezone('Europe/Berlin');
        $this->assertSame('Europe/Berlin', $result);

        // invalid, expect 'UTC'
        $tz->Bias = -6000;
        $result = $tz->get_timezone('Europe/Berlin');
        $this->assertSame('UTC', $result);
    }

    /**
     * Test get_timezone_from_int() method
     */
    function test_get_timezone_from_int()
    {
        $result = kolab_api_filter_mapistore_timezone::get_timezone_from_int(3, 'Europe/Berlin');

        $this->assertSame('Europe/Berlin', $result);
    }
}
