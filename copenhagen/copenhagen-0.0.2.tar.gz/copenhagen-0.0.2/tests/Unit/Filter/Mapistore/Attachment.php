<?php

/**
 * Test class to test kolab_api_filter_mapistore_attachment
 *
 * @package Tests
 */
class KolabApiFilterMapistoreAttachment extends PHPUnit_Framework_TestCase
{

    /**
     * Test output method
     */
    function test_output()
    {
        $api     = new kolab_api_filter_mapistore_attachment;
        $context = array('folder_uid' => 'folder', 'object_uid' => 'msg');
        $attach  = array(
            'id'            => 'id',
            'mimetype'      => 'mimetype',
            'size'          => 100,
            'filename'      => 'filename.txt',
            'disposition'   => 'disposition',
            'content-id'    => 'content-id',
            'content-location' => 'content-location',
        );

        $result = $api->output($attach, $context);

        $this->assertSame(kolab_api_filter_mapistore::uid_encode('folder', 'msg', 'id'), $result['id']);
        $this->assertSame('attachments',    $result['collection']);
        $this->assertSame('mimetype',       $result['PidTagAttachMimeTag']);
        $this->assertSame(100,              $result['PidTagAttachSize']);
        $this->assertSame('filename.txt',   $result['PidTagDisplayName']);
        $this->assertSame('.txt',           $result['PidTagAttachExtension']);
        $this->assertSame('content-id',     $result['PidTagAttachContentId']);
        $this->assertSame('content-location', $result['PidTagAttachContentLocation']);
        $this->assertSame(1,                $result['PidTagAttachMethod']);
        $this->assertSame(7,                $result['PidTagObjectType']);
        $this->assertSame(null,             $result['PidTagAttachDataBinary']);

        // @TODO: test attachment body handling
    }

    /**
     * Test input method
     */
    function test_input()
    {
        $api  = new kolab_api_filter_mapistore_attachment;
        $data = array(
            'id'                    => 'id',
            'PidTagAttachMimeTag'   => 'mimetype',
            'PidTagAttachSize'      => 100,
            'PidTagDisplayName'     => 'filename.txt',
            'PidTagAttachContentId'       => 'content-id',
            'PidTagAttachContentLocation' => 'content-location',
            'PidTagAttachmentContactPhoto' => true,
        );

        $result = $api->input($data);

//        $this->assertSame(kolab_api_filter_mapistore::uid_encode('folder', 'msg', 'id'), $result['id']);
        $this->assertSame('mimetype',       $result['mimetype']);
        $this->assertSame(100,              $result['size']);
        $this->assertSame('filename.txt',   $result['filename']);
        $this->assertSame('content-id',     $result['content-id']);
        $this->assertSame('content-location', $result['content-location']);
        $this->assertSame(true,             $result['is-photo']);
    }

    /**
     * Test input method with merge
     */
    function test_input2()
    {
        // @TODO
        $this->markTestIncomplete('TODO');
    }

    /**
     * Test map method
     */
    function test_map()
    {
        $api = new kolab_api_filter_mapistore_attachment;
        $map = $api->map();

        $this->assertInternalType('array', $map);
        $this->assertTrue(!empty($map));
    }
}
