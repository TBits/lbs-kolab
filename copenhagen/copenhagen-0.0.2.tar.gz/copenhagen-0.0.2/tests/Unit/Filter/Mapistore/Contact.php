<?php

/**
 * Test class to test kolab_api_filter_mapistore_contact
 *
 * @package Tests
 */
class KolabApiFilterMapistoreContact extends PHPUnit_Framework_TestCase
{
    static $original;

    /**
     * Test output method
     */
    function test_output()
    {
        $api    = new kolab_api_filter_mapistore_contact;
        $data   = kolab_api_tests::get_data('a-b-c-d', 'Contacts', 'contact', 'json', $context);
        $result = $api->output($data, $context);

        $this->assertSame('IPM.Contact', $result['PidTagMessageClass']);
        $this->assertSame('contacts', $result['collection']);
        $this->assertSame(kolab_api_tests::mapi_uid('Contacts', false, 'a-b-c-d'), $result['id']);
        $this->assertSame(kolab_api_tests::folder_uid('Contacts', false), $result['parent_id']);
        $this->assertSame(kolab_api_filter_mapistore_common::date_php2mapi('20150420T141533Z'), $result['PidTagLastModificationTime']);
        $this->assertSame(kolab_api_filter_mapistore_common::date_php2mapi('20150330', false),  $result['PidTagBirthday']);
        $this->assertSame(kolab_api_filter_mapistore_common::date_php2mapi('20150301', false),  $result['PidTagWeddingAnniversary']);
        $this->assertSame(null, $result['PidTagHasAttachments']);
        $this->assertSame('displname',    $result['PidTagDisplayName']);
        $this->assertSame('last',         $result['PidTagSurname']);
        $this->assertSame('test',         $result['PidTagGivenName']);
        $this->assertSame('middlename',   $result['PidTagMiddleName']);
        $this->assertSame('prefx',        $result['PidTagDisplayNamePrefix']);
        $this->assertSame('suff',         $result['PidTagGeneration']);
        $this->assertSame('dsfsdfsdfsdf sdfsdfsdf sdfsdfsfd', $result['PidTagBody']);
        $this->assertSame('free-busy url', $result['PidLidFreeBusyLocation']);
        $this->assertSame('title',        $result['PidTagTitle']);
        $this->assertSame('Org',          $result['PidTagCompanyName']);
        $this->assertSame('dept',         $result['PidTagDepartmentName']);
        $this->assertSame('profeion',     $result['PidTagProfession']);
        $this->assertSame('manager name', $result['PidTagManagerName']);
        $this->assertSame('assist',       $result['PidTagAssistant']);
        $this->assertSame('website',      $result['PidTagPersonalHomePage']);

        $this->assertSame('office street',  $result['PidTagOtherAddressStreet']);
        $this->assertSame('office city',    $result['PidTagOtherAddressCity']);
        $this->assertSame('office state',   $result['PidTagOtherAddressStateOrProvince']);
        $this->assertSame('office zip',     $result['PidTagOtherAddressPostalCode']);
        $this->assertSame('office country', $result['PidTagOtherAddressCountry']);
//        $this->assertSame('office pobox',   $result['PidTagOtherAddressPostOfficeBox']);
        $this->assertSame('home street',    $result['PidTagHomeAddressStreet']);
        $this->assertSame('home city',      $result['PidTagHomeAddressCity']);
        $this->assertSame('home state',     $result['PidTagHomeAddressStateOrProvince']);
        $this->assertSame('home zip',       $result['PidTagHomeAddressPostalCode']);
        $this->assertSame('home country',   $result['PidTagHomeAddressCountry']);
//        $this->assertSame('home pobox',     $result['PidTagHomeAddressPostOfficeBox']);
        $this->assertSame('work street',    $result['PidLidWorkAddressStreet']);
        $this->assertSame('work city',      $result['PidLidWorkAddressCity']);
        $this->assertSame('work state',     $result['PidLidWorkAddressState']);
        $this->assertSame('work zip',       $result['PidLidWorkAddressPostalCode']);
        $this->assertSame('work country',   $result['PidLidWorkAddressCountry']);
//        $this->assertSame('work pobox',     $result['PidLidWorkAddressPostOfficeBox']);
        $this->assertSame(2,   $result['PidLidPostalAddressId']);

        $this->assertSame('nick',      $result['PidTagNickname']);
        $this->assertSame(2,           $result['PidTagGender']);
        $this->assertSame('spouse',    $result['PidTagSpouseName']);
        $this->assertSame(array('children', 'children2'),  $result['PidTagChildrensNames']);

        $this->assertSame('home phone',  $result['PidTagHomeTelephoneNumber']);
        $this->assertSame('work phone',  $result['PidTagBusinessTelephoneNumber']);
        $this->assertSame('home fax',    $result['PidTagHomeFaxNumber']);
        $this->assertSame('work fax',    $result['PidTagBusinessFaxNumber']);
        $this->assertSame('mobile',      $result['PidTagMobileTelephoneNumber']);
        $this->assertSame('pager',       $result['PidTagPagerTelephoneNumber']);
        $this->assertSame('car phone',   $result['PidTagCarTelephoneNumber']);
        $this->assertSame('other phone', $result['PidTagOtherTelephoneNumber']);
        $this->assertSame('im gg',       $result['PidLidInstantMessagingAddress']);

        $this->assertSame('test@mail.ru',   $result['PidLidEmail1EmailAddress']);
        $this->assertSame('work@email.pl',  $result['PidLidEmail2EmailAddress']);
        $this->assertSame('other@email.pl', $result['PidLidEmail3EmailAddress']);
        $this->assertRegExp('/^cy9.*/', $result['PidTagUserX509Certificate']);
        $this->assertSame(true,         $result['PidLidHasPicture']);
        $this->assertSame(array('tag1'), $result['PidNameKeywords']);

//        $this->assertRegExp('|^data:application/pgp-keys;base64,|',   $result['key'][0]);
//        $this->assertRegExp('|^data:image/jpeg;base64,|', $result['photo']);
//        $this->assertSame('individual',   $result['kind']);

        // Distribution List
        $api    = new kolab_api_filter_mapistore_contact;
        $data   = kolab_api_tests::get_data('i-j-k-l', 'Contacts', 'contact', 'json', $context);
        $result = $api->output($data, $context);

        $this->assertSame('IPM.DistList', $result['PidTagMessageClass']);
        $this->assertSame('contacts', $result['collection']);
        $this->assertSame(kolab_api_tests::mapi_uid('Contacts', false, 'i-j-k-l'), $result['id']);
        $this->assertSame(kolab_api_tests::folder_uid('Contacts', false), $result['parent_id']);
        $this->assertSame('test group',   $result['PidTagDisplayName']);
        // @TODO: list members
    }

    /**
     * Test input method
     */
    function test_input()
    {
        $api  = new kolab_api_filter_mapistore_contact;
        $data = array(
            'id'        => kolab_api_tests::mapi_uid('Contacts', false, 'a-b-c-d'),
            'parent_id' => kolab_api_tests::folder_uid('Contacts', false),
            'PidTagMessageClass'        => 'IPM.Contact',
            'PidTagLastModificationTime' => kolab_api_filter_mapistore_common::date_php2mapi('20150421T145607Z'),
            'PidTagBirthday'            => kolab_api_filter_mapistore_common::date_php2mapi('20150330', true),
            'PidTagWeddingAnniversary'  => kolab_api_filter_mapistore_common::date_php2mapi('20150301', true),
            'PidTagDisplayName'         => 'displname',
            'PidTagSurname'             => 'last',
            'PidTagGivenName'           => 'test',
            'PidTagMiddleName'          => 'middlename',
            'PidTagDisplayNamePrefix'   => 'prefx',
            'PidTagGeneration'          => 'suff',
            'PidTagBody'                => 'dsfsdfsdfsdf sdfsdfsdf sdfsdfsfd',
            'PidLidFreeBusyLocation'    => 'free-busy url',
            'PidTagTitle'               => 'title',
            'PidTagCompanyName'         => 'Org',
            'PidTagDepartmentName'      => 'dept',
            'PidTagProfession'          => 'profeion',
            'PidTagManagerName'         => 'manager name',
            'PidTagAssistant'           => 'assist',
            'PidTagPersonalHomePage'    => 'website',

            'PidTagOtherAddressStreet'  => 'office street',
            'PidTagOtherAddressCity'    => 'office city',
            'PidTagOtherAddressStateOrProvince' => 'office state',
            'PidTagOtherAddressPostalCode' => 'office zip',
            'PidTagOtherAddressCountry' => 'office country',
//            'PidTagOtherAddressPostOfficeBox' => 'office pobox',
            'PidTagHomeAddressStreet'   => 'home street',
            'PidTagHomeAddressCity'     => 'home city',
            'PidTagHomeAddressStateOrProvince' => 'home state',
            'PidTagHomeAddressPostalCode' => 'home zip',
            'PidTagHomeAddressCountry'  => 'home country',
//            'PidTagHomeAddressPostOfficeBox' => 'home pobox',
            'PidLidWorkAddressStreet'   => 'work street',
            'PidLidWorkAddressCity'     => 'work city',
            'PidLidWorkAddressState'    => 'work state',
            'PidLidWorkAddressPostalCode' => 'work zip',
            'PidLidWorkAddressCountry'  => 'work country',
//            'PidLidWorkAddressPostOfficeBox' => 'work pobox',
            'PidLidPostalAddressId'     => 1,

            'PidTagNickname'            => 'nick',
            'PidTagGender'              => 2,
            'PidTagSpouseName'          => 'spouse',
            'PidTagChildrensNames'      => array('children', 'children2'),

            'PidTagHomeTelephoneNumber' => 'home phone',
            'PidTagBusinessTelephoneNumber' => 'work phone',
            'PidTagHomeFaxNumber'       => 'home fax',
            'PidTagBusinessFaxNumber'   => 'work fax',
            'PidTagMobileTelephoneNumber' => 'mobile',
            'PidTagPagerTelephoneNumber' => 'pager',
            'PidTagCarTelephoneNumber'   => 'car phone',
            'PidTagOtherTelephoneNumber' => 'other phone',
            'PidLidInstantMessagingAddress' => 'im gg',

            'PidLidEmail1EmailAddress'  => 'test@mail.ru',
            'PidLidEmail2EmailAddress'  => 'work@email.pl',
            'PidLidEmail3EmailAddress'  => 'other@email.pl',
            'PidTagUserX509Certificate' => '1234567890',

            'PidTagInitials' => 'initials',
        );

        $result = $api->input($data);

//        $this->assertSame('a-b-c-d', $result['uid']);
        $this->assertSame('individual',   $result['kind']);
        $this->assertSame('displname',    $result['fn']);
        $this->assertSame('last',         $result['n']['surname']);
        $this->assertSame('test',         $result['n']['given']);
        $this->assertSame('middlename',   $result['n']['additional']);
        $this->assertSame('prefx',        $result['n']['prefix']);
        $this->assertSame('suff',         $result['n']['suffix']);
        $this->assertSame('dsfsdfsdfsdf sdfsdfsdf sdfsdfsfd', $result['note']);
        $this->assertSame('free-busy url', $result['fburl']);
        $this->assertSame('title',        $result['title']);
        $this->assertSame('Org',          $result['group']['org'][0]);
        $this->assertSame('dept',         $result['group']['org'][1]);
        $this->assertSame('profeion',     $result['group']['role']);
        $this->assertSame('x-manager',    $result['group']['related'][0]['parameters']['type']);
        $this->assertSame('manager name', $result['group']['related'][0]['text']);
        $this->assertSame('x-assistant',  $result['group']['related'][1]['parameters']['type']);
        $this->assertSame('assist',       $result['group']['related'][1]['text']);
//        $this->assertSame('', $result['group']['adr']['pobox']);
        $this->assertSame('office street',  $result['group']['adr']['street']);
        $this->assertSame('office city',    $result['group']['adr']['locality']);
        $this->assertSame('office state',   $result['group']['adr']['region']);
        $this->assertSame('office zip',     $result['group']['adr']['code']);
        $this->assertSame('office country', $result['group']['adr']['country']);
        $this->assertSame(array('website'), $result['url']);
        $this->assertSame('home',           $result['adr'][0]['parameters']['type']);
        $this->assertSame(1,                $result['adr'][0]['parameters']['pref']);
        $this->assertSame('home street',    $result['adr'][0]['street']);
        $this->assertSame('home city',      $result['adr'][0]['locality']);
        $this->assertSame('home state',     $result['adr'][0]['region']);
        $this->assertSame('home zip',       $result['adr'][0]['code']);
        $this->assertSame('home country',   $result['adr'][0]['country']);
        $this->assertSame('work',           $result['adr'][1]['parameters']['type']);
        $this->assertSame('work street',    $result['adr'][1]['street']);
        $this->assertSame('work city',      $result['adr'][1]['locality']);
        $this->assertSame('work state',     $result['adr'][1]['region']);
        $this->assertSame('work zip',       $result['adr'][1]['code']);
        $this->assertSame('work country',   $result['adr'][1]['country']);
        $this->assertSame('nick',      $result['nickname']);
        $this->assertSame('spouse',    $result['related'][0]['parameters']['type']);
        $this->assertSame('spouse',    $result['related'][0]['text']);
        $this->assertSame('child',     $result['related'][1]['parameters']['type']);
        $this->assertSame('children',  $result['related'][1]['text']);
        $this->assertSame('child',     $result['related'][2]['parameters']['type']);
        $this->assertSame('children2', $result['related'][2]['text']);
        $this->assertSame('2015-03-30', $result['bday']); // ?
        $this->assertSame('2015-03-01', $result['anniversary']); // ?
        $this->assertSame('M',          $result['gender']);
        $this->assertSame(array('im gg'), $result['impp']);
        $this->assertSame('home',           $result['email'][0]['parameters']['type']);
        $this->assertSame('test@mail.ru',   $result['email'][0]['text']);
        $this->assertSame('work',           $result['email'][1]['parameters']['type']);
        $this->assertSame('work@email.pl',  $result['email'][1]['text']);
        $this->assertSame('other',          $result['email'][2]['parameters']['type']);
        $this->assertSame('other@email.pl', $result['email'][2]['text']);
        $this->assertRegExp('|^data:application/pkcs7-mime;base64,|', $result['key'][0]);
//        $this->assertRegExp('|^data:application/pgp-keys;base64,|',   $result['key'][1]);
//        $this->assertRegExp('|^data:image/jpeg;base64,|', $result['photo']);
        $this->assertSame('MAPI:PidTagInitials', $result['x-custom'][0]['identifier']);
        $this->assertSame('initials', $result['x-custom'][0]['value']);

        $phones = array(
            'home'      => 'home phone',
            'work'      => 'work phone',
            'faxhome'   => 'home fax',
            'faxwork'   => 'work fax',
            'cell'      => 'mobile',
            'pager'     => 'pager',
            'x-car'     => 'car phone',
            'textphone' => 'other phone',
        );
        foreach ($result['tel'] as $tel) {
            $type = implode('', (array)$tel['parameters']['type']);
            $text = $tel['text'];

            if (!empty($phones[$type]) && $phones[$type] == $text) {
                unset($phones[$type]);
            }
        }

        $this->assertCount(8, $result['tel']);
        $this->assertCount(0, $phones);

        self::$original = $result;
    }

    /**
     * Test input method with merge
     */
    function test_input2()
    {
        $api  = new kolab_api_filter_mapistore_contact;
        $data = array(
            'id'        => kolab_api_tests::mapi_uid('Contacts', false, 'a-b-c-d'),
            'parent_id' => kolab_api_tests::folder_uid('Contacts', false),
            'PidTagBirthday'            => kolab_api_filter_mapistore_common::date_php2mapi('20150430', true),
            'PidTagWeddingAnniversary'  => kolab_api_filter_mapistore_common::date_php2mapi('20150401', true),
            'PidTagDisplayName'         => 'displname1',
            'PidTagSurname'             => 'last1',
            'PidTagGivenName'           => 'test1',
            'PidTagMiddleName'          => 'middlename1',
            'PidTagDisplayNamePrefix'   => 'prefx1',
            'PidTagGeneration'          => 'suff1',
            'PidTagBody'                => 'body1',
            'PidLidFreeBusyLocation'    => 'free-busy url1',
            'PidTagTitle'               => 'title1',
            'PidTagCompanyName'         => 'Org1',
            'PidTagDepartmentName'      => 'dept1',
            'PidTagProfession'          => 'profeion1',
            'PidTagManagerName'         => 'manager name1',
            'PidTagAssistant'           => 'assist1',
            'PidTagPersonalHomePage'    => 'website1',

            'PidTagOtherAddressStreet'  => 'office street1',
            'PidTagOtherAddressCity'    => 'office city1',
            'PidTagOtherAddressStateOrProvince' => 'office state1',
            'PidTagOtherAddressPostalCode' => 'office zip1',
            'PidTagOtherAddressCountry' => 'office country1',
            'PidTagHomeAddressStreet'   => 'home street1',
            'PidTagHomeAddressCity'     => 'home city1',
            'PidTagHomeAddressStateOrProvince' => 'home state1',
            'PidTagHomeAddressPostalCode' => 'home zip1',
            'PidTagHomeAddressCountry'  => 'home country1',
            'PidLidWorkAddressStreet'   => 'work street1',
            'PidLidWorkAddressCity'     => 'work city1',
            'PidLidWorkAddressState'    => 'work state1',
            'PidLidWorkAddressPostalCode' => 'work zip1',
            'PidLidWorkAddressCountry'  => 'work country1',

            'PidTagNickname'            => 'nick1',
            'PidTagGender'              => 1,
            'PidTagSpouseName'          => 'spouse1',
            'PidTagChildrensNames'      => array('children10', 'children20'),

            'PidTagHomeTelephoneNumber' => 'home phone1',
            'PidTagBusinessTelephoneNumber' => null,
            'PidTagHomeFaxNumber'       => 'home fax1',
            'PidTagBusinessFaxNumber'   => 'work fax1',
            'PidTagMobileTelephoneNumber' => 'mobile1',
            'PidTagPagerTelephoneNumber' => 'pager1',
            'PidTagOtherTelephoneNumber' => 'other phone1',
            'PidLidInstantMessagingAddress' => 'im gg1',

            'PidLidEmail1EmailAddress'  => 'test@mail.ru',
            'PidLidEmail2EmailAddress'  => 'work@email.pl',
            'PidTagUserX509Certificate' => '12345678901',

            'PidTagInitials'  => 'initials1',
            'PidNameKeywords' => array('work1'),
        );

        $result = $api->input($data, self::$original);

//        $this->assertSame('a-b-c-d', $result['uid']);
        $this->assertSame('displname1',    $result['fn']);
        $this->assertSame('last1',         $result['n']['surname']);
        $this->assertSame('test1',         $result['n']['given']);
        $this->assertSame('middlename1',   $result['n']['additional']);
        $this->assertSame('prefx1',        $result['n']['prefix']);
        $this->assertSame('suff1',         $result['n']['suffix']);
        $this->assertSame('body1',         $result['note']);
        $this->assertSame('free-busy url1', $result['fburl']);
        $this->assertSame('title1',        $result['title']);
        $this->assertSame('Org1',          $result['group']['org'][0]);
        $this->assertSame('dept1',         $result['group']['org'][1]);
        $this->assertSame('profeion1',     $result['group']['role']);
        $this->assertSame('x-manager',     $result['group']['related'][0]['parameters']['type']);
        $this->assertSame('manager name1', $result['group']['related'][0]['text']);
        $this->assertSame('x-assistant',   $result['group']['related'][1]['parameters']['type']);
        $this->assertSame('assist1',       $result['group']['related'][1]['text']);
        $this->assertSame('office street1',  $result['group']['adr']['street']);
        $this->assertSame('office city1',    $result['group']['adr']['locality']);
        $this->assertSame('office state1',   $result['group']['adr']['region']);
        $this->assertSame('office zip1',     $result['group']['adr']['code']);
        $this->assertSame('office country1', $result['group']['adr']['country']);
        $this->assertSame(array('website1'), $result['url']);
        $this->assertSame('home',           $result['adr'][0]['parameters']['type']);
        $this->assertSame('home street1',    $result['adr'][0]['street']);
        $this->assertSame('home city1',      $result['adr'][0]['locality']);
        $this->assertSame('home state1',     $result['adr'][0]['region']);
        $this->assertSame('home zip1',       $result['adr'][0]['code']);
        $this->assertSame('home country1',   $result['adr'][0]['country']);
        $this->assertSame('work',           $result['adr'][1]['parameters']['type']);
        $this->assertSame('work street1',    $result['adr'][1]['street']);
        $this->assertSame('work city1',      $result['adr'][1]['locality']);
        $this->assertSame('work state1',     $result['adr'][1]['region']);
        $this->assertSame('work zip1',       $result['adr'][1]['code']);
        $this->assertSame('work country1',   $result['adr'][1]['country']);
        $this->assertSame('nick1',      $result['nickname']);
        $this->assertSame('spouse',     $result['related'][0]['parameters']['type']);
        $this->assertSame('spouse1',    $result['related'][0]['text']);
        $this->assertSame('child',      $result['related'][1]['parameters']['type']);
        $this->assertSame('children10', $result['related'][1]['text']);
        $this->assertSame('child',      $result['related'][2]['parameters']['type']);
        $this->assertSame('children20', $result['related'][2]['text']);
        $this->assertSame('2015-04-30', $result['bday']); // ?
        $this->assertSame('2015-04-01', $result['anniversary']); // ?
        $this->assertSame('F',          $result['gender']);
        $this->assertSame(array('im gg1'), $result['impp']);
        $this->assertSame('home',           $result['email'][0]['parameters']['type']);
        $this->assertSame('test@mail.ru',   $result['email'][0]['text']);
        $this->assertSame('work',           $result['email'][1]['parameters']['type']);
        $this->assertSame('work@email.pl',  $result['email'][1]['text']);
        $this->assertSame(null,          $result['email'][2]);
        $this->assertRegExp('|^data:application/pkcs7-mime;base64,|', $result['key'][0]);
//        $this->assertRegExp('|^data:application/pgp-keys;base64,|',   $result['key'][1]);
//        $this->assertRegExp('|^data:image/jpeg;base64,|', $result['photo']);
        $this->assertSame('MAPI:PidTagInitials', $result['x-custom'][0]['identifier']);
        $this->assertSame('initials1', $result['x-custom'][0]['value']);
        $this->assertSame(array('work1'), $result['categories']);

        $phones = array(
            'home'      => 'home phone1',
            'faxhome'   => 'home fax1',
            'faxwork'   => 'work fax1',
            'cell'      => 'mobile1',
            'pager'     => 'pager1',
            'x-car'     => 'car phone',
            'textphone' => 'other phone1',
        );
        foreach ($result['tel'] as $tel) {
            $type = implode('', (array)$tel['parameters']['type']);
            $text = $tel['text'];

            if (!empty($phones[$type]) && $phones[$type] == $text) {
                unset($phones[$type]);
            }
        }

        $this->assertCount(7, $result['tel']);
        $this->assertCount(0, $phones);

        // @TODO: updating some deep items (e.g. adr);
    }

    /**
     * Test map method
     */
    function test_map()
    {
        $api = new kolab_api_filter_mapistore_contact;
        $map = $api->map();

        $this->assertInternalType('array', $map);
        $this->assertTrue(!empty($map));
    }

    /**
     * Test photo_attachment method
     */
    function test_photo_attachment()
    {
        $contact = array();
        $result  = kolab_api_filter_mapistore_contact::photo_attachment($contact);

        $this->assertSame(null, $result);

        $contact['photo'] = base64_decode('R0lGODlhDwAPAIAAAMDAwAAAACH5BAEAAAAALAAAAAAPAA8AQAINhI+py+0Po5y02otnAQA7');
        $result = kolab_api_filter_mapistore_contact::photo_attachment($contact);

        $this->assertSame(true,                 $result['is-photo']);
        $this->assertSame(54,                   $result['size']);
        $this->assertSame('ContactPicture.gif', $result['filename']);
        $this->assertSame('image/gif',          $result['mimetype']);
        $this->assertSame($contact['photo'],    $result['content']);
        $this->assertSame(kolab_api_filter_mapistore_contact::PHOTO_ATTACHMENT_ID, $result['id']);
    }
}
