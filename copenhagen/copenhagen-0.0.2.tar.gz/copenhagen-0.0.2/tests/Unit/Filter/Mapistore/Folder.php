<?php

/**
 * Test class to test kolab_api_filter_mapistore_folder
 *
 * @package Tests
 */
class KolabApiFilterMapistoreFolder extends PHPUnit_Framework_TestCase
{
    static $original;

    /**
     * Test output method
     */
    function test_output()
    {
        $api  = new kolab_api_filter_mapistore_folder;
        $data = array(
            'uid'    => 'test-uid',
            'parent' => 'parent',
            'name'   => 'folder name',
            'exists' => 2,
            'unread' => 3,
            'uidvalidity' => 123456789,
            'size'        => 10000,
            'children'    => 10,
            'deleted'     => 5,
        );

        $result = $api->output($data, $context);

        $this->assertSame('test-uid', $result['id']);
        $this->assertSame('parent', $result['parent_id']);
        $this->assertSame('folders', $result['collection']);
        $this->assertSame('folder name', $result['PidTagDisplayName']);
        $this->assertSame(1, $result['PidTagFolderType']);
        $this->assertSame(2, $result['PidTagContentCount']);
        $this->assertSame(3, $result['PidTagContentUnreadCount']);
        $this->assertSame(10000, $result['PidTagMessageSize']);
        $this->assertSame(true, $result['PidTagSubfolders']);
        $this->assertSame(5, $result['PidTagDeletedCountTotal']);
        $this->assertSame($api->date_php2mapi('@' . $data['uidvalidity']), $result['PidTagCreationTime']);

        $types = array(
            ''                => 'IPF.Note',
            'mail.inbox'      => 'IPF.Note',
            'task.default'    => 'IPF.Task',
            'note.default'    => 'IPF.StickyNote',
            'event.default'   => 'IPF.Appointment',
            'journal.default' => 'IPF.Journal',
            'contact.default' => 'IPF.Contact',
        );

        foreach ($types as $type => $exp) {
            $data   = array('uid' => 'test', 'type' => $type);
            $result = $api->output($data, $context);

            $this->assertSame($exp, $result['PidTagContainerClass']);
        }
    }

    /**
     * Test input method
     */
    function test_input()
    {
        $api  = new kolab_api_filter_mapistore_folder;
        $data = array(
            'id'                => 'test-uid',
            'parent_id'         => 'parent',
            'PidTagDisplayName' => 'folder name',
            'PidTagContainerClass' => 'IPF.Contact',
        );

        $result = $api->input($data);

        $this->assertSame('test-uid', $result['uid']);
        $this->assertSame('parent', $result['parent']);
        $this->assertSame('folder name', $result['name']);
        $this->assertSame('contact', $result['type']);

        self::$original = $result;
    }

    /**
     * Test input method with merge
     */
    function test_input2()
    {
        $api  = new kolab_api_filter_mapistore_folder;
        $data = array(
//            'id'                => 'test-uid',
//            'parent_id'         => 'parent',
            'PidTagDisplayName' => 'folder name1',
            'PidTagContainerClass' => 'IPF.Appointment',
        );

        $result = $api->input($data, self::$original);

//        $this->assertSame('test-uid', $result['uid']);
//        $this->assertSame('parent', $result['parent']);
        $this->assertSame('folder name1', $result['name']);
        $this->assertSame('event', $result['type']);
    }

    /**
     * Test map method
     */
    function test_map()
    {
        $api = new kolab_api_filter_mapistore_folder;
        $map = $api->map();

        $this->assertInternalType('array', $map);
        $this->assertTrue(!empty($map));
    }
}
