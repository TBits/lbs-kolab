<?php

/**
 * Test class to test kolab_api_filter_mapistore_info
 *
 * @package Tests
 */
class KolabApiFilterMapistoreInfo extends PHPUnit_Framework_TestCase
{

    /**
     * Test output method
     */
    function test_output()
    {
        $api  = new kolab_api_filter_mapistore_info;
        $data = array(
            'name'    => 'test1',
            'version' => 'version1',
        );

        $result = $api->output($data, $context);

        $this->assertSame('test1', $result['name']);
        $this->assertSame('version1', $result['version']);
    }

    /**
     * Test input method
     */
    function test_input()
    {
        $api  = new kolab_api_filter_mapistore_info;
        $data = array(
            'name'    => 'test1',
            'version' => 'version1',
        );

        $result = $api->input($data);

        $this->assertSame(null, $result);
    }

    /**
     * Test input method with merge
     */
    function test_input2()
    {
        // there's nothing to test here
    }

    /**
     * Test map method
     */
    function test_map()
    {
        $api = new kolab_api_filter_mapistore_info;
        $map = $api->map();

        $this->assertInternalType('array', $map);
        $this->assertTrue(!empty($map));
    }
}
