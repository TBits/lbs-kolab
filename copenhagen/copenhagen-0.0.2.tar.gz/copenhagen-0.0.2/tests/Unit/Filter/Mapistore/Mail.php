<?php

/**
 * Test class to test kolab_api_filter_mapistore_mail
 *
 * @package Tests
 */
class KolabApiFilterMapistoreMail extends PHPUnit_Framework_TestCase
{
    static $original;

    /**
     * Test output method
     */
    function test_output()
    {
        $api    = new kolab_api_filter_mapistore_mail;
        $data   = kolab_api_tests::get_data('1', 'INBOX', 'mail', 'json', $context);
        $result = $api->output($data, $context);

        $this->assertSame(kolab_api_tests::mapi_uid('INBOX', false, '1'), $result['id']);
        $this->assertSame(kolab_api_tests::folder_uid('INBOX', false), $result['parent_id']);
        $this->assertSame('mails', $result['collection']);
        $this->assertSame('IPM.Note', $result['PidTagMessageClass']);
        $this->assertSame('"test" wurde aktualisiert', $result['PidTagSubject']);
        $this->assertSame(624, $result['PidTagMessageSize']);
        $this->assertCount(1,                        $result['recipients']);
        $this->assertSame('mark.german@example.org', $result['recipients'][0]['PidTagSmtpAddress']);
        $this->assertSame(1,                         $result['recipients'][0]['PidTagRecipientType']);
        $this->assertSame('text/plain', $result['PidNameContentType']);
        $this->assertSame('20140722140159.420B4A105A@kolab32.example.org', $result['PidTagInternetMessageId']);
        $this->assertSame(array('tag1'), $result['PidNameKeywords']);

        $data   = kolab_api_tests::get_data('2', 'INBOX', 'mail', 'json', $context);
        $result = $api->output($data, $context);

        $this->assertSame('IPM.Note', $result['PidTagMessageClass']);
        $this->assertSame('Re: dsda', $result['PidTagSubject']);
        $this->assertSame(849, $result['PidTagMessageSize']);
        $this->assertCount(2,                        $result['recipients']);
        $this->assertSame('mark.german@example.org', $result['recipients'][0]['PidTagSmtpAddress']);
        $this->assertSame('German, Mark',            $result['recipients'][0]['PidTagDisplayName']);
        $this->assertSame(1,                         $result['recipients'][0]['PidTagRecipientType']);
        $this->assertSame('brad.pitt@example.org',   $result['recipients'][1]['PidTagSmtpAddress']);
        $this->assertSame('Pitt, Brad',              $result['recipients'][1]['PidTagDisplayName']);
        $this->assertSame(2,                         $result['recipients'][1]['PidTagRecipientType']);
        $this->assertSame(null, $result['PidTagHtml']);
        $this->assertSame('text/plain', $result['PidNameContentType']);
        $this->assertSame('5071c053c207e5916123b0aa36959f03@example.org', $result['PidTagInternetMessageId']);
        $this->assertSame('c0e5147fc63045dedfe668877876c478@example.org', $result['PidTagInReplyToId']);

        $data   = kolab_api_tests::get_data('5', 'INBOX', 'mail', 'json', $context);
        $result = $api->output($data, $context);

        $this->assertRegexp('/TEST CONTENT/', $result['PidTagBody']);
        $this->assertRegexp('/<strong>test content/', base64_decode($result['PidTagHtml']));
        $this->assertSame('multipart/alternative', $result['PidNameContentType']);
        $this->assertSame(null, $result['PidTagHasAttachments']);

        // @TODO: sender/from
        $data   = kolab_api_tests::get_data('6', 'INBOX', 'mail', 'json', $context);
        $result = $api->output($data, $context);

        $this->assertSame(true, $result['PidTagHasAttachments']);
    }

    /**
     * Test input method
     */
    function test_input()
    {
        $api  = new kolab_api_filter_mapistore_mail;
        $data = array(
            'id'        => kolab_api_tests::mapi_uid('INBOX', false, '1000'),
            'parent_id' => kolab_api_tests::folder_uid('INBOX', false),
            'PidTagSubject'     => 'subject',
            'PidTagBody'        => 'body',
            'PidTagHtml'        => base64_encode('html'),
            'PidTagPriority'    => 0xFFFFFFFF,
            'PidTagInternetMessageId' => 'test-id',
            'PidNameKeywords'   => array('work1'),
            'recipients'        => array(
                array(
                    'PidTagRecipientType' => 1,
                    'PidTagDisplayName'   => 'test-to',
                    'PidTagSmtpAddress'   => 'test-to@domain.tld',
                ),
                array(
                    'PidTagRecipientType' => 2,
                    'PidTagDisplayName'   => 'test-cc',
                    'PidTagSmtpAddress'   => 'test-cc@domain.tld',
                ),
            ),
        );

        $result = $api->input($data);

//        $this->assertSame(kolab_api_tests::mapi_uid('INBOX', false, '1000'), $result['uid']);
//        $this->assertSame(kolab_api_tests::folder_uid('INBOX', false), $result['parent']);
        $this->assertSame('subject', $result['subject']);
        $this->assertSame('body', $result['text']);
        $this->assertSame('html', $result['html']);
        $this->assertSame(5, $result['priority']);
        $this->assertSame('<test-id>', $result['message-id']);
        $this->assertSame(array('work1'), $result['categories']);
        $this->assertSame('test-to', $result['to'][0]['name']);
        $this->assertSame('test-to@domain.tld', $result['to'][0]['address']);
        $this->assertSame('test-cc', $result['cc'][0]['name']);
        $this->assertSame('test-cc@domain.tld', $result['cc'][0]['address']);

        // @TODO: PidTagRtfCompressed, sender/from

        self::$original = $result;
    }

    /**
     * Test input method with merge
     */
    function test_input2()
    {
        $api  = new kolab_api_filter_mapistore_mail;
        $data = array(
            'recipients' => array(
                array(
                    'PidTagRecipientType' => 1,
                    'PidTagDisplayName'   => 'test-to2',
                    'PidTagSmtpAddress'   => 'test-to2@domain.tld',
                ),
                array(
                    'PidTagRecipientType' => 2,
                    'PidTagDisplayName'   => 'test-cc2',
                    'PidTagSmtpAddress'   => 'test-cc2@domain.tld',
                ),
            ),
        );

        $result = $api->input($data, self::$original);

        $this->assertCount(1, $result['to']);
        $this->assertCount(1, $result['cc']);
        $this->assertSame('test-to2', $result['to'][0]['name']);
        $this->assertSame('test-to2@domain.tld', $result['to'][0]['address']);
        $this->assertSame('test-cc2', $result['cc'][0]['name']);
        $this->assertSame('test-cc2@domain.tld', $result['cc'][0]['address']);
    }

    /**
     * Test map method
     */
    function test_map()
    {
        $api = new kolab_api_filter_mapistore_mail;
        $map = $api->map();

        $this->assertInternalType('array', $map);
        $this->assertTrue(!empty($map));
    }
}
