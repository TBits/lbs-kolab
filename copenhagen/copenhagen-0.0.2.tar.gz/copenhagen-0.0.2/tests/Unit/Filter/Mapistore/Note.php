<?php

/**
 * Test class to test kolab_api_filter_mapistore_note
 *
 * @package Tests
 */
class KolabApiFilterMapistoreNote extends PHPUnit_Framework_TestCase
{
    static $original;

    /**
     * Test output method
     */
    function test_output()
    {
        $api    = new kolab_api_filter_mapistore_note;
        $data   = kolab_api_tests::get_data('1-1-1-1', 'Notes', 'note', 'json', $context);
        $result = $api->output($data, $context);

        $this->assertSame(kolab_api_tests::mapi_uid('Notes', false, '1-1-1-1'), $result['id']);
        $this->assertSame(kolab_api_tests::folder_uid('Notes', false), $result['parent_id']);
        $this->assertSame(kolab_api_filter_mapistore_common::date_php2mapi('2015-01-20T11:44:59Z'), $result['PidTagCreationTime']);
        $this->assertSame(kolab_api_filter_mapistore_common::date_php2mapi('2015-01-22T11:30:17Z'), $result['PidTagLastModificationTime']);
//        $this->assertSame('PUBLIC', $result['classification']);
        $this->assertSame('test', $result['PidTagSubject']);
        $this->assertSame('test', $result['PidTagBody']);
        $this->assertSame(100, $result['PidLidNoteX']);
        $this->assertSame(200, $result['PidLidNoteY']);
        $this->assertSame(null, $result['PidTagHasAttachments']);
        $this->assertSame(array('tag1'), $result['PidNameKeywords']);
    }

    /**
     * Test input method
     */
    function test_input()
    {
        $api  = new kolab_api_filter_mapistore_note;
        $data = array(
            'id'        => kolab_api_tests::mapi_uid('Notes', false, '1-1-1-1'),
            'parent_id' => kolab_api_tests::folder_uid('Notes', false),
            'PidTagCreationTime'         => kolab_api_filter_mapistore_common::date_php2mapi('2015-01-20T11:44:59Z'),
            'PidTagLastModificationTime' => kolab_api_filter_mapistore_common::date_php2mapi('2015-01-22T11:30:17Z'),
            'PidTagSubject' => 'subject',
            'PidTagBody'    => 'body',
            'PidLidNoteColor'   => 1,
            'PidLidNoteHeight'  => 100,
            'PidLidNoteWidth'   => 200,
            'PidLidNoteX'       => 300,
            'PidLidNoteY'       => 400,
            'PidNameKeywords'   => array('work1'),
        );

        $result = $api->input($data);

//        $this->assertSame(kolab_api_tests::mapi_uid('Notes', false, '1-1-1-1'), $result['uid']);
//        $this->assertSame(kolab_api_tests::folder_uid('Notes', false), $result['parent']);
        $this->assertSame('2015-01-20T11:44:59Z', $result['creation-date']);
        $this->assertSame('2015-01-22T11:30:17Z', $result['last-modification-date']);
        $this->assertSame('subject', $result['summary']);
        $this->assertSame('body', $result['description']);
        $this->assertSame('MAPI:PidLidNoteColor', $result['x-custom'][0]['identifier']);
        $this->assertSame(1, $result['x-custom'][0]['value']);
        $this->assertSame('MAPI:PidLidNoteHeight', $result['x-custom'][1]['identifier']);
        $this->assertSame(100, $result['x-custom'][1]['value']);
        $this->assertSame('MAPI:PidLidNoteWidth', $result['x-custom'][2]['identifier']);
        $this->assertSame(200, $result['x-custom'][2]['value']);
        $this->assertSame('MAPI:PidLidNoteX', $result['x-custom'][3]['identifier']);
        $this->assertSame(300, $result['x-custom'][3]['value']);
        $this->assertSame('MAPI:PidLidNoteY', $result['x-custom'][4]['identifier']);
        $this->assertSame(400, $result['x-custom'][4]['value']);
        $this->assertSame(array('work1'), $result['categories']);

        self::$original = $result;
    }

    /**
     * Test input method with merge
     */
    function test_input2()
    {
        $api  = new kolab_api_filter_mapistore_note;
        $data = array(
            'id'        => kolab_api_tests::mapi_uid('Notes', false, '1-1-1-1'),
            'parent_id' => kolab_api_tests::folder_uid('Notes', false),
            'PidTagSubject' => 'subject1',
            'PidTagBody'    => 'body1',
            'PidLidNoteX'   => 250,
            'PidLidNoteColor' => null,
        );

        $result = $api->input($data, self::$original);

//        $this->assertSame('2015-01-20T11:44:59Z', $result['creation-date']);
//        $this->assertSame('2015-01-22T11:30:17Z', $result['last-modification-date']);
        $this->assertSame('subject1', $result['summary']);
        $this->assertSame('body1', $result['description']);
        $this->assertSame('MAPI:PidLidNoteHeight', $result['x-custom'][0]['identifier']);
        $this->assertSame(100, $result['x-custom'][0]['value']);
        $this->assertSame('MAPI:PidLidNoteWidth', $result['x-custom'][1]['identifier']);
        $this->assertSame(200, $result['x-custom'][1]['value']);
        $this->assertSame('MAPI:PidLidNoteX', $result['x-custom'][2]['identifier']);
        $this->assertSame(250, $result['x-custom'][2]['value']);
        $this->assertSame('MAPI:PidLidNoteY', $result['x-custom'][3]['identifier']);
        $this->assertSame(400, $result['x-custom'][3]['value']);

        $this->assertCount(4, $result['x-custom']);

        // test unsetting values
        $api  = new kolab_api_filter_mapistore_note;
        $data = array(
            'PidTagSubject' => '',
        );

        $result = $api->input($data, self::$original);

        $this->assertSame('', $result['summary']);
    }

    /**
     * Test map method
     */
    function test_map()
    {
        $api = new kolab_api_filter_mapistore_note;
        $map = $api->map();

        $this->assertInternalType('array', $map);
        $this->assertTrue(!empty($map));
    }
}
