<?php

/**
 * Test class to test kolab_api_filter_mapistore_task
 *
 * @package Tests
 */
class KolabApiFilterMapistoreTask extends PHPUnit_Framework_TestCase
{
    static $original;

    /**
     * Test output method
     */
    function test_output()
    {
        kolab_api::$now = new DateTime('2015-04-19 00:00:00 +00:00');

        $api    = new kolab_api_filter_mapistore_task;
        $data   = kolab_api_tests::get_data('10-10-10-10', 'Tasks', 'task', 'json', $context);
        $result = $api->output($data, $context);

        $this->assertSame(kolab_api_tests::mapi_uid('Tasks', false, '10-10-10-10'), $result['id']);
        $this->assertSame(kolab_api_tests::folder_uid('Tasks', false), $result['parent_id']);
        $this->assertSame('IPM.Task', $result['PidTagMessageClass']);
        $this->assertSame('tasks', $result['collection']);
        $this->assertSame('task title', $result['PidTagSubject']);
        $this->assertSame("task description\nsecond line", $result['PidTagBody']);
        $this->assertSame(0.56, $result['PidLidPercentComplete']);
        $this->assertSame(kolab_api_filter_mapistore_common::date_php2mapi('2015-04-20T14:22:18Z', true), $result['PidTagLastModificationTime']);
        $this->assertSame(kolab_api_filter_mapistore_common::date_php2mapi('2015-04-20T14:22:18Z', true), $result['PidTagCreationTime']);
        $this->assertSame(8, $result['PidLidTaskActualEffort']);
        $this->assertSame(true, $result['PidTagHasAttachments']);
        $this->assertSame(array('tag1'), $result['PidNameKeywords']);

        $data   = kolab_api_tests::get_data('20-20-20-20', 'Tasks', 'task', 'json', $context);
        $result = $api->output($data, $context);

        $this->assertSame(kolab_api_tests::mapi_uid('Tasks', false, '20-20-20-20'), $result['id']);
        $this->assertSame(kolab_api_tests::folder_uid('Tasks', false), $result['parent_id']);
        $this->assertSame('IPM.Task', $result['PidTagMessageClass']);
        $this->assertSame('tasks', $result['collection']);
        $this->assertSame('task', $result['PidTagSubject']);
        $this->assertSame(kolab_api_filter_mapistore_common::date_php2mapi('2015-04-20', true), $result['PidLidTaskStartDate']);
        $this->assertSame(kolab_api_filter_mapistore_common::date_php2mapi('2015-04-27', true), $result['PidLidTaskDueDate']);
        $this->assertSame(null, $result['PidTagHasAttachments']);

        // organizer/attendees
        $this->assertSame('German, Mark',            $result['recipients'][0]['PidTagDisplayName']);
        $this->assertSame('mark.german@example.org', $result['recipients'][0]['PidTagEmailAddress']);
        $this->assertSame(1,                         $result['recipients'][0]['PidTagRecipientType']);
        $this->assertSame('Manager, Jane',           $result['recipients'][1]['PidTagDisplayName']);
        $this->assertSame(1,                          $result['recipients'][1]['PidTagRecipientType']);
        $this->assertSame('jane.manager@example.org', $result['recipients'][1]['PidTagEmailAddress']);

        // reminder
        $this->assertSame(15, $result['PidLidReminderDelta']);
        $this->assertSame(true, $result['PidLidReminderSet']);

        // recurrence
        $rp = new kolab_api_filter_mapistore_structure_recurrencepattern;
        $rp->input($result['PidLidTaskRecurrence'], true);

        $this->assertSame(true, $result['PidLidTaskFRecurring']);
        $this->assertSame(kolab_api_filter_mapistore_structure_recurrencepattern::PATTERNTYPE_DAY, $rp->PatternType);
        $this->assertSame(kolab_api_filter_mapistore_structure_recurrencepattern::RECURFREQUENCY_DAILY, $rp->RecurFrequency);
    }

    /**
     * Test output recurrence
     */
    function test_output_recurrence()
    {
        // test task recurrence
        $data = array(
            'dtstart' => '2015-01-01T00:00:00Z',
            'rrule'   => array(
                'recur' => array(
                    'freq'       => 'YEARLY',
                    'bymonth'    => 5,
                    'bymonthday' => 1,
                    'count'      => 10,
                ),
            ),
        );

        $api    = new kolab_api_filter_mapistore_task;
        $rp     = new kolab_api_filter_mapistore_structure_recurrencepattern;
        $result = $api->output($data, $context);
        $rp->input($result['PidLidTaskRecurrence'], true);

        $this->assertSame(kolab_api_filter_mapistore_structure_recurrencepattern::PATTERNTYPE_MONTHNTH, $rp->PatternType);
        $this->assertSame(kolab_api_filter_mapistore_structure_recurrencepattern::RECURFREQUENCY_YEARLY, $rp->RecurFrequency);
        $this->assertSame(1, $rp->PatternTypeSpecific[1]);
        $this->assertSame(10, $rp->OccurrenceCount);
        $this->assertSame(12, $rp->Period);

        // @TODO: test other $rp properties
    }

    /**
     * Test alarms output
     */
    function test_output_alarms()
    {
        kolab_api::$now = new DateTime('2015-01-20 00:00:00 UTC');

        $data = array(
            'dtstart' => '2015-01-01T00:00:00Z',
            'rrule'   => array(
                'recur' => array(
                    'freq'       => 'MONTHLY',
                    'bymonthday' => 5,
                    'count'      => 10,
                    'interval'   => 1,
                ),
            ),
            'valarm' => array(
                array(
                    'properties' => array(
                        'action'  => 'DISPLAY',
                        'trigger' => array(
                            'duration' => '-PT15M',
                        ),
                    ),
                ),
            ),
        );

        $api    = new kolab_api_filter_mapistore_task;
        $result = $api->output($data, $context);

        $this->assertSame(15, $result['PidLidReminderDelta']);
        $this->assertSame(true, $result['PidLidReminderSet']);
        $this->assertSame('2015-02-20T00:00:00+00:00', kolab_api_filter_mapistore_common::date_mapi2php($result['PidLidReminderTime'])->format('c'));
        $this->assertSame('2015-02-19T23:45:00+00:00', kolab_api_filter_mapistore_common::date_mapi2php($result['PidLidReminderSignalTime'])->format('c'));
    }

    /**
     * Test input method
     */
    function test_input()
    {
        $api  = new kolab_api_filter_mapistore_task;
        $data = array(
            'id'            => kolab_api_tests::mapi_uid('Tasks', false, '10-10-10-10'),
            'parent_id'     => kolab_api_tests::folder_uid('Tasks', false),
            'PidTagCreationTime'         => kolab_api_filter_mapistore_common::date_php2mapi('2015-01-20T11:44:59Z'),
            'PidTagLastModificationTime' => kolab_api_filter_mapistore_common::date_php2mapi('2015-01-22T11:30:17Z'),
            'PidTagMessageClass'    => 'IPM.Task',
            'PidTagSubject'         => 'subject',
            'PidLidPercentComplete' => 0.56,
            'PidTagBody'            => 'body',
            'PidLidTaskStartDate'   => kolab_api_filter_mapistore_common::date_php2mapi('2015-04-20', true),
            'PidLidTaskDueDate'     => kolab_api_filter_mapistore_common::date_php2mapi('2015-04-27', true),
            'PidLidTaskActualEffort'    => 16,
            'PidLidTaskEstimatedEffort' => 20,
            'PidLidReminderDelta'       => 15,
            'PidLidReminderSet'         => true,
            'PidNameKeywords'           => array('work1'),
            'recipients'                => array(
                array(
                    'PidTagDisplayName'   => 'German, Mark',
                    'PidTagEmailAddress'  => 'mark.german@example.org',
                    'PidTagRecipientType' => 1,
                    'PidTagRecipientFlags' => 3,
                ),
                array(
                    'PidTagDisplayName'   => 'Manager, Jane',
                    'PidTagEmailAddress'  => 'manager@example.org',
                    'PidTagRecipientType' => 1,
                    'PidTagRecipientTrackStatus' => 2,
                ),
            ),
         );

        $result = $api->input($data);

        self::$original = $result;

        $this->assertSame('subject', $result['summary']);
        $this->assertSame('body', $result['description']);
        $this->assertSame(56, $result['percent-complete']);
        $this->assertSame('2015-01-20T11:44:59Z', $result['created']);
        $this->assertSame('2015-01-22T11:30:17Z', $result['dtstamp']);
        $this->assertSame('2015-04-20', $result['dtstart']);
        $this->assertSame('2015-04-27', $result['due']);
        $this->assertSame('MAPI:PidLidTaskActualEffort', $result['x-custom'][0]['identifier']);
        $this->assertSame(16, $result['x-custom'][0]['value']);
        $this->assertSame('MAPI:PidLidTaskEstimatedEffort', $result['x-custom'][1]['identifier']);
        $this->assertSame(20, $result['x-custom'][1]['value']);
        $this->assertSame(array('work1'), $result['categories']);

        $this->assertSame('Manager, Jane',                $result['attendee'][0]['parameters']['cn']);
        $this->assertSame('TENTATIVE',                    $result['attendee'][0]['parameters']['partstat']);
        $this->assertSame('REQ-PARTICIPANT',              $result['attendee'][0]['parameters']['role']);
//        $this->assertSame(true,                           $result['attendee'][0]['parameters']['rsvp']);
        $this->assertSame('mailto:manager%40example.org', $result['attendee'][0]['cal-address']);
        $this->assertSame('German, Mark',                     $result['organizer']['parameters']['cn']);
        $this->assertSame('mailto:mark.german%40example.org', $result['organizer']['cal-address']);

        // alarm
        $this->assertSame('DISPLAY',  $result['valarm'][0]['properties']['action']);
        $this->assertSame('-PT15M',   $result['valarm'][0]['properties']['trigger']['duration']);

        $data = array(
            'PidLidTaskComplete' => true,
            'PidLidTaskDateCompleted'   => kolab_api_filter_mapistore_common::date_php2mapi('2015-04-20', true),
            'PidLidTaskActualEffort'    => 100,
            'PidLidTaskEstimatedEffort' => 100,
            // @TODO: recurrence
        );

        $result = $api->input($data);

        $this->assertSame('COMPLETED', $result['status']);
        $this->assertSame('MAPI:PidLidTaskDateCompleted', $result['x-custom'][0]['identifier']);
        $this->assertSame(13073961600.0, $result['x-custom'][0]['value']);
    }

    /**
     * Test input method with merge
     */
    function test_input2()
    {
        $api  = new kolab_api_filter_mapistore_task;
        $data = array(
            'PidTagCreationTime'         => kolab_api_filter_mapistore_common::date_php2mapi('2015-01-20T12:44:59Z'),
            'PidTagLastModificationTime' => kolab_api_filter_mapistore_common::date_php2mapi('2015-01-22T12:30:17Z'),
//            'PidTagMessageClass'    => 'IPM.Task',
            'PidTagSubject'         => 'subject1',
            'PidLidPercentComplete' => 0.66,
            'PidTagBody'            => 'body1',
            'PidLidTaskStartDate'   => kolab_api_filter_mapistore_common::date_php2mapi('2015-04-21', true),
            'PidLidTaskDueDate'     => kolab_api_filter_mapistore_common::date_php2mapi('2015-04-28', true),
            'PidLidTaskActualEffort'    => 21,
            'PidLidTaskEstimatedEffort' => null,
        );

        $result = $api->input($data, self::$original);

        self::$original = $result;

        $this->assertSame('subject1', $result['summary']);
        $this->assertSame('body1', $result['description']);
        $this->assertSame(66, $result['percent-complete']);
        $this->assertSame('2015-01-20T12:44:59Z', $result['created']);
        $this->assertSame('2015-01-22T12:30:17Z', $result['dtstamp']);
        $this->assertSame('2015-04-21', $result['dtstart']);
        $this->assertSame('2015-04-28', $result['due']);
        $this->assertSame('MAPI:PidLidTaskActualEffort', $result['x-custom'][0]['identifier']);
        $this->assertSame(21, $result['x-custom'][0]['value']);
        $this->assertCount(1, $result['x-custom']);
    }

    /**
     * Test input body
     */
    function test_input_body()
    {
        $api  = new kolab_api_filter_mapistore_task;
        $body = '0QAAAB0CAABMWkZ1Pzsq5D8ACQMwAQMB9wKnAgBjaBEKwHNldALRcHJx4DAgVGFoA3ECgwBQ6wNUDzcyD9MyBgAGwwKDpxIBA+MReDA0EhUgAoArApEI5jsJbzAVwzEyvjgJtBdCCjIXQRb0ORIAHxeEGOEYExjgFcMyNTX/CbQaYgoyGmEaHBaKCaUa9v8c6woUG3YdTRt/Hwwabxbt/xyPF7gePxg4JY0YVyRMKR+dJfh9CoEBMAOyMTYDMUksgSc1FGAnNhqAJ1Q3My3BNAqFfS7A';

        $result = $api->input(array('PidTagRtfCompressed' => $body), $context);

        $this->assertSame('<html><body>Test<br></body></html>', $result['description']);

        $result = $api->input(array('PidTagBody' => 'test'), $context);

        $this->assertSame('test', $result['description']);

        $result = $api->input(array('PidTagHtml' => '<html><body>test</body></html>'), $context);

        $this->assertSame('<html><body>test</body></html>', $result['description']);
    }

    /**
     * Test map method
     */
    function test_map()
    {
        $api = new kolab_api_filter_mapistore_task;
        $map = $api->map();

        $this->assertInternalType('array', $map);
        $this->assertTrue(!empty($map));
    }
}
