<?php

/**
 * Test class to test kolab_api_filter_mapistore
 *
 * @package Tests
 */
class KolabApiFilterMapistore extends PHPUnit_Framework_TestCase
{

    /**
     * Test uid_encode method
     */
    function test_uid_encode()
    {
        $uid = kolab_api_filter_mapistore::uid_encode('folder', 'msg');
        $this->assertSame('folder.msg', $uid);

        $uid = kolab_api_filter_mapistore::uid_encode('folder', 'msg', 'attach');
        $this->assertSame('folder.msg.attach', $uid);

        $uid = kolab_api_filter_mapistore::uid_encode('f-ol.der', 'm-s.g', 'att.a-ch');
        $this->assertSame('f-ol_46der.m-s_46g.att_46a-ch', $uid);
    }

    /**
     * Test uid_decode method
     */
    function test_uid_decode()
    {
        $uid = kolab_api_filter_mapistore::uid_decode('f-ol_46der.m-s_46g.att_46a-ch');
        $this->assertSame(array('f-ol.der', 'm-s.g', 'att.a-ch'), $uid);
    }
}
