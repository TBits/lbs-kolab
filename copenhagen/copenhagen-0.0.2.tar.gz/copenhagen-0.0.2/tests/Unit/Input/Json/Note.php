<?php

/**
 * Test class to test kolab_api_input_json_note
 *
 * @package Tests
 */
class KolabApiInputJsonNote extends PHPUnit_Framework_TestCase
{
    static $original;

    /**
     * Test expected exception in input method
     *
     * @expectedException     kolab_api_exception
     * @expectedExceptionCode 422
     */
    function test_input_exception1()
    {
        $input = new kolab_api_input_json_note;
        $data  = array();

        $input->input($data);
    }

    /**
     * Test expected exception in input method
     *
     * @expectedException     kolab_api_exception
     * @expectedExceptionCode 422
     */
    function test_input_exception2()
    {
        $input = new kolab_api_input_json_note;
        $data  = 'test';

        $input->input($data);
    }

    /**
     * Test input method (convert JSON to internal format)
     */
    function test_input()
    {
        $input = new kolab_api_input_json_note;

        $custom = array(array('identifier' => 'test', 'value' => 'val'));
        $data   = array(
            'description'            => 'description',
            'summary'                => 'summary',
            'classification'         => 'PUBLIC',
            'categories'             => array('test'),
            'creation-date'          => '2015-04-20T14:22:18Z',
            'last-modification-date' => '2015-04-21T00:00:00Z',
            'x-custom'               => $custom,
        );

        $input->input($data);

        $this->assertSame('description', $data['description']);
        $this->assertSame('summary', $data['title']);
        $this->assertSame('public', $data['sensitivity']);
        $this->assertSame(array('test'), $data['categories']);
        $this->assertSame(kolab_api_input_json::to_datetime('2015-04-20T14:22:18Z')->format('c'), $data['created']->format('c'));
        $this->assertSame(kolab_api_input_json::to_datetime('2015-04-21T00:00:00Z')->format('c'), $data['changed']->format('c'));
        $this->assertSame(array('test', 'val'), $data['x-custom'][0]);

        // for test_input2() below
        self::$original = $data;
    }

    /**
     * Test input method with merging
     */
    function test_input2()
    {
        $input = new kolab_api_input_json_note;
        $data  = array(
            'description'            => 'description1',
            'summary'                => 'summary1',
            'classification'         => 'PRIVATE',
            'categories'             => array('test1'),
//            'creation-date'          => '2015-04-20T14:22:18Z',
//            'last-modification-date' => '2015-04-21T00:00:00Z',
        );

        $input->input($data, self::$original);

        $this->assertSame('description1', $data['description']);
        $this->assertSame('summary1', $data['title']);
        $this->assertSame('private', $data['sensitivity']);
        $this->assertSame(array('test1'), $data['categories']);
//        $this->assertSame(kolab_api_input_json::to_datetime('2015-04-20T14:22:18Z')->format('c'), $data['created']->format('c'));
//        $this->assertSame(kolab_api_input_json::to_datetime('2015-04-21T00:00:00Z')->format('c'), $data['changed']->format('c'));
    }
}
