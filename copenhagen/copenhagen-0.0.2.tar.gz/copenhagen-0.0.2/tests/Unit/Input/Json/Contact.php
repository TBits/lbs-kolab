<?php

/**
 * Test class to test kolab_api_input_json_contact
 *
 * @package Tests
 */
class KolabApiInputJsonContact extends PHPUnit_Framework_TestCase
{
    static $original;

    /**
     * Test expected exception in input method
     *
     * @expectedException     kolab_api_exception
     * @expectedExceptionCode 422
     */
    function test_input_exception1()
    {
        $input = new kolab_api_input_json_contact;
        $data  = array();

        $input->input($data);
    }

    /**
     * Test expected exception in input method
     *
     * @expectedException     kolab_api_exception
     * @expectedExceptionCode 422
     */
    function test_input_exception2()
    {
        $input = new kolab_api_input_json_contact;
        $data  = 'test';

        $input->input($data);
    }

    /**
     * Test input method (convert JSON to internal format)
     */
    function test_input()
    {
        $input = new kolab_api_input_json_contact;
        $data  = array(
            'note'        => 'note',
            'categories'  => array('test'),
            'kind'        => 'individual',
            'rev'         => '2015-04-21T00:00:00Z',
            'bday'        => '2014-01-01',
            'anniversary' => '2014-02-01',
            'fn'          => 'name',
            'nickname'    => 'nick',
            'n'           => array(
                'surname'    => 'surname',
                'given'      => 'given',
                'additional' => 'middle',
                'prefix'     => 'prefix',
                'suffix'     => 'suffix',
            ),
            'title'       => array('title'),
            'group'       => array(
                'org' => array('Org', 'dept'),
                'role' => 'profession',
                'related' => array(
                    array(
                        'text' => 'manager name',
                        'parameters' => array('type' => 'x-manager'),
                    ),
                    array(
                        'text' => 'assist',
                        'parameters' => array('type' => 'x-assistant'),
                    ),
                ),
                'adr' => array(
                    'street'    => 'office street',
                    'locality'  => 'office city',
                    'region'    => 'office state',
                    'code'      => 'office zip',
                    'country'   => 'office country',
//                    'parameters' => '',
//                    'pobox'     => '',
//                    'ext'       => '',
                ),
            ),
            'adr'         => array(
                array(
                    'parameters' => array('type' => 'home'),
                    'street'     => 'home street',
                    'locality'   => 'home city',
                    'region'     => 'home state',
                    'code'       => 'home zip',
                    'country'    => 'home country',
                ),
                array(
                    'parameters' => array('type' => 'work'),
                    'street'     => 'work street',
                    'locality'   => 'work city',
                    'region'     => 'work state',
                    'code'       => 'work zip',
                    'country'    => 'work country',
                ),
            ),
            'related'     => array(
                array('text' => 'spouse', 'parameters' => array('type' => 'spouse')),
                array('text' => 'child1', 'parameters' => array('type' => 'child')),
                array('text' => 'child2', 'parameters' => array('type' => 'child')),
            ),
            'photo'       => 'data:image/jpeg;base64,cGhvdG8x',
            'gender'      => 'M',
            'lang'        => array('lang'),
            'tel'         => array(
                array(
                    'text' => 'home phone',
                    'parameters' => array('type' => 'home'),
                ),
                array(
                    'text' => 'work phone',
                    'parameters' => array('type' => 'work'),
                ),
                array(
                    'text' => 'home fax',
                    'parameters' => array('type' => array('fax', 'home')),
                ),
                array(
                    'text' => 'work fax',
                    'parameters' => array('type' => array('fax', 'work')),
                ),
                array(
                    'text' => 'mobile',
                    'parameters' => array('type' => 'cell'),
                ),
                array(
                    'text' => 'pager',
                    'parameters' => array('type' => 'pager'),
                ),
                array(
                    'text' => 'car phone',
                    'parameters' => array('type' => 'x-car'),
                ),
                array(
                    'text' => 'other phone',
                    'parameters' => array('type' => 'textphone'),
                ),
            ),
            'impp'        => array('impp'),
            'email'       => array(
                array(
                    'text' => 'test@mail.ru',
                    'parameters' => array('type' => 'home'),
                ),
                array(
                    'text' => 'work@email.pl',
                    'parameters' => array('type' => 'work'),
                ),
                'other@email.pl',
            ),
//            'geo'         => array(),
            'key'         => array(
                'data:application/pgp-keys;base64,' . base64_encode('1'),
                'data:application/pkcs7-mime;base64,' . base64_encode('2'),
            ),
//            'x-crypto'    => array(),
            'fburl'       => 'freebusyurl',
            'url'         => array('url'),
        );

        $input->input($data);

        $this->assertSame('note', $data['notes']);
        $this->assertSame(array('test'), $data['categories']);
        $this->assertSame('individual', $data['kind']);
        $this->assertSame('name', $data['name']);
        $this->assertSame('nick', $data['nickname']);
        $this->assertSame(array('title'), $data['jobtitle']);
        $this->assertSame('freebusyurl', $data['freebusyurl']);
        $this->assertSame('male', $data['gender']);
        $this->assertSame('photo1', $data['photo']);
        $this->assertSame(array('lang'), $data['lang']);
        $this->assertSame(array('impp'), $data['im']);
        $this->assertSame(array(array('url' => 'url')), $data['website']);
        // 'n'
        $this->assertSame('surname', $data['surname']);
        $this->assertSame('given',   $data['firstname']);
        $this->assertSame('middle',  $data['middlename']);
        $this->assertSame('prefix',  $data['prefix']);
        $this->assertSame('suffix',  $data['suffix']);
        // 'email'
        $this->assertSame('home',           $data['email'][0]['type']);
        $this->assertSame('test@mail.ru',   $data['email'][0]['address']);
        $this->assertSame('work',           $data['email'][1]['type']);
        $this->assertSame('work@email.pl',  $data['email'][1]['address']);
        $this->assertSame('other@email.pl', $data['email'][2]['address']);
        // 'tel'
        $this->assertSame('home',       $data['phone'][0]['type']);
        $this->assertSame('home phone', $data['phone'][0]['number']);
        $this->assertSame('work',       $data['phone'][1]['type']);
        $this->assertSame('work phone', $data['phone'][1]['number']);
        $this->assertSame('homefax',    $data['phone'][2]['type']);
        $this->assertSame('home fax',   $data['phone'][2]['number']);
        $this->assertSame('workfax',    $data['phone'][3]['type']);
        $this->assertSame('work fax',   $data['phone'][3]['number']);
        $this->assertSame('mobile',     $data['phone'][4]['type']);
        $this->assertSame('mobile',     $data['phone'][4]['number']);
        $this->assertSame('pager',      $data['phone'][5]['type']);
        $this->assertSame('pager',      $data['phone'][5]['number']);
        $this->assertSame('car',        $data['phone'][6]['type']);
        $this->assertSame('car phone',  $data['phone'][6]['number']);
        $this->assertSame('other',      $data['phone'][7]['type']);
        $this->assertSame('other phone', $data['phone'][7]['number']);
        // 'related'
        $this->assertSame('spouse',    $data['spouse']);
        $this->assertSame(array('child1', 'child2'), $data['children']);
        // 'group'
        $this->assertSame('Org',          $data['organization']);
        $this->assertSame('dept',         $data['department']);
        $this->assertSame('profession',   $data['profession']);
        $this->assertSame('manager name', $data['manager']);
        $this->assertSame('assist',       $data['assistant']);
        $this->assertSame('office street',  $data['address'][0]['street']);
        $this->assertSame('office city',    $data['address'][0]['locality']);
        $this->assertSame('office state',   $data['address'][0]['region']);
        $this->assertSame('office zip',     $data['address'][0]['code']);
        $this->assertSame('office country', $data['address'][0]['country']);
        $this->assertSame('office',         $data['address'][0]['type']);
//        $this->assertSame('', $data['address'][0]['parameters']);
//        $this->assertSame('', $data['address'][0]['pobox']);
//        $this->assertSame('', $data['address'][0]['ext']);
        // 'adr'
        $this->assertSame('home',           $data['address'][1]['type']);
        $this->assertSame('home street',    $data['address'][1]['street']);
        $this->assertSame('home city',      $data['address'][1]['locality']);
        $this->assertSame('home state',     $data['address'][1]['region']);
        $this->assertSame('home zip',       $data['address'][1]['code']);
        $this->assertSame('home country',   $data['address'][1]['country']);
        $this->assertSame('work',           $data['address'][2]['type']);
        $this->assertSame('work street',    $data['address'][2]['street']);
        $this->assertSame('work city',      $data['address'][2]['locality']);
        $this->assertSame('work state',     $data['address'][2]['region']);
        $this->assertSame('work zip',       $data['address'][2]['code']);
        $this->assertSame('work country',   $data['address'][2]['country']);
        // 'key'
        $this->assertSame('1', $data['pgppublickey']);
        $this->assertSame('2', $data['pkcs7publickey']);

//        $this->assertSame(kolab_api_input_json::to_datetime('2015-04-20T14:22:18Z')->format('c'), $data['created']->format('c'));
        $this->assertSame(kolab_api_input_json::to_datetime('2015-04-21T00:00:00Z')->format('c'), $data['changed']->format('c'));
        $this->assertSame(kolab_api_input_json::to_datetime('2014-01-01')->format('c'), $data['birthday']->format('c'));
        $this->assertSame(kolab_api_input_json::to_datetime('2014-02-01')->format('c'), $data['anniversary']->format('c'));

        // for test_input2() below
        self::$original = $data;
    }

    /**
     * Test input method with merge
     */
    function test_input2()
    {
        $input = new kolab_api_input_json_contact;
        $data = array(
            'note'        => 'note1',
            'categories'  => array('test1'),
            'kind'        => 'individual',
//            'rev'         => '2015-04-21T00:00:00Z',
            'bday'        => '2014-01-11',
            'anniversary' => '2014-02-11',
            'fn'          => 'name1',
            'nickname'    => 'nick1',
            'n'           => array(
                'surname'    => 'surname1',
                'given'      => 'given1',
                'additional' => 'middle1',
                'prefix'     => null,
                'suffix'     => 'suffix1',
            ),
            'title'       => array('title1'),
            'group'       => array(
                'org' => array('Org1', 'dept1'),
                'role' => 'profession1',
                'adr' => array(
                    'street'    => 'office street1',
                    'locality'  => 'office city1',
                    'region'    => null,
                    'code'      => 'office zip1',
                    'country'   => 'office country1',
                ),
            ),
            'adr'         => array(
                array(
                    // @TODO: libkolab plugin does not support 'pref' yet
                    'parameters' => array('type' => 'home', 'pref' => 1),
                    'street'     => 'home street1',
                    'locality'   => 'home city1',
                    'region'     => 'home state1',
                    'code'       => null,
                    'country'    => 'home country1',
                ),
            ),
            'related'     => array(
                array('text' => 'spouse1', 'parameters' => array('type' => 'spouse')),
                array('text' => 'child11', 'parameters' => array('type' => 'child')),
                array('text' => 'child21', 'parameters' => array('type' => 'child')),
            ),
            'photo'       => 'data:image/jpeg;base64,cGhvdG8x',
            'gender'      => 'F',
            'lang'        => array('lang1'),
            'tel'         => array(
                array(
                    'text' => 'home phone1',
                    'parameters' => array('type' => 'home'),
                ),
            ),
            'impp'        => array('impp1'),
            'email'       => array('other@email.pl'),
//            'geo'         => array(),
            'key'         => array(
                'data:application/pgp-keys;base64,' . base64_encode('1'),
            ),
//            'x-crypto'    => array(),
            'fburl'       => 'freebusyurl1',
            'url'         => array('url1'),
        );

        $input->input($data, self::$original);

        $this->assertSame('note1', $data['notes']);
        $this->assertSame(array('test1'), $data['categories']);
        $this->assertSame('individual', $data['kind']);
        $this->assertSame('name1', $data['name']);
        $this->assertSame('nick1', $data['nickname']);
        $this->assertSame(array('title1'), $data['jobtitle']);
        $this->assertSame('freebusyurl1', $data['freebusyurl']);
        $this->assertSame('female', $data['gender']);
        $this->assertSame('photo1', $data['photo']);
        $this->assertSame(array('lang1'), $data['lang']);
        $this->assertSame(array('impp1'), $data['im']);
        $this->assertSame(array(array('url' => 'url1')), $data['website']);
        // 'n'
        $this->assertSame('surname1', $data['surname']);
        $this->assertSame('given1',   $data['firstname']);
        $this->assertSame('middle1',  $data['middlename']);
        $this->assertSame(null,  $data['prefix']);
        $this->assertSame('suffix1',  $data['suffix']);
        // 'email'
        $this->assertSame('other@email.pl', $data['email'][0]['address']);
        $this->assertCount(1, $data['email']);
        // 'tel'
        $this->assertSame('home',        $data['phone'][0]['type']);
        $this->assertSame('home phone1', $data['phone'][0]['number']);
        $this->assertCount(1, $data['phone']);
        // 'related'
        $this->assertSame('spouse1',    $data['spouse']);
        $this->assertSame(array('child11', 'child21'), $data['children']);
        // 'group'
        $this->assertSame('Org1',          $data['organization']);
        $this->assertSame('dept1',         $data['department']);
        $this->assertSame('profession1',   $data['profession']);
        $this->assertSame(null,             $data['manager']);
        $this->assertSame(null,             $data['assistant']);

        $this->assertSame('office',         $data['address'][0]['type']);
        $this->assertSame('office street1',  $data['address'][0]['street']);
        $this->assertSame('office city1',    $data['address'][0]['locality']);
        $this->assertSame(null,             $data['address'][0]['region']);
        $this->assertSame('office zip1',     $data['address'][0]['code']);
        $this->assertSame('office country1', $data['address'][0]['country']);
        // 'adr'
        $this->assertSame('home',           $data['address'][1]['type']);
        $this->assertSame('home street1',    $data['address'][1]['street']);
        $this->assertSame('home city1',      $data['address'][1]['locality']);
        $this->assertSame('home state1',     $data['address'][1]['region']);
        $this->assertSame(null,             $data['address'][1]['code']);
        $this->assertSame('home country1',   $data['address'][1]['country']);
        $this->assertCount(2, $data['address']);
        // 'key'
        $this->assertSame('1', $data['pgppublickey']);
        $this->assertSame(null, $data['pkcs7publickey']);

        $this->assertSame(kolab_api_input_json::to_datetime('2014-01-11')->format('c'), $data['birthday']->format('c'));
        $this->assertSame(kolab_api_input_json::to_datetime('2014-02-11')->format('c'), $data['anniversary']->format('c'));
    }

    /**
     * Test input method (convert JSON to internal format) for distribution-lists
     */
    function test_input_distlist()
    {
        $input = new kolab_api_input_json_contact;
        $data  = array(
            'uid'  => 'i-j-k-l',
            'kind' => 'group',
            'fn' => 'test group',
            'member' => array(
                'urn:uuid:a-b-c-d',
                'urn:uuid:e-f-g-h',
                'mailto:John%20Doe%3Cjdoe%40example.com%3E',
            ),
        );

        $input->input($data);

        $this->assertSame('group', $data['kind']);
        $this->assertSame('test group', $data['name']);
        $this->assertSame('a-b-c-d', $data['member'][0]['uid']);
        $this->assertSame(null, $data['member'][0]['email']);
        $this->assertSame('e-f-g-h', $data['member'][1]['uid']);
        $this->assertSame(null, $data['member'][1]['email']);
        $this->assertSame(null, $data['member'][2]['uid']);
        $this->assertSame('jdoe@example.com', $data['member'][2]['email']);
        $this->assertSame('John Doe', $data['member'][2]['name']);
    }
}
