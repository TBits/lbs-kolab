<?php

/**
 * Test class to test kolab_api_input_json_event
 *
 * @package Tests
 */
class KolabApiInputJsonEvent extends PHPUnit_Framework_TestCase
{
    static $original;

    /**
     * Test expected exception in input method
     *
     * @expectedException     kolab_api_exception
     * @expectedExceptionCode 422
     */
    function test_input_exception1()
    {
        $input = new kolab_api_input_json_event;
        $data  = array();

        $input->input($data);
    }

    /**
     * Test expected exception in input method
     *
     * @expectedException     kolab_api_exception
     * @expectedExceptionCode 422
     */
    function test_input_exception2()
    {
        $input = new kolab_api_input_json_event;
        $data  = 'test';

        $input->input($data);
    }

    /**
     * Test expected exception in input method
     *
     * @expectedException     kolab_api_exception
     * @expectedExceptionCode 422
     */
    function test_input_exception3()
    {
        $input = new kolab_api_input_json_event;
        $data  = array('test' => 'test');

        // 'dtstamp' field is required
        $input->input($data);
    }

    /**
     * Test input method (convert JSON to internal format)
     */
    function test_input()
    {
        $input = new kolab_api_input_json_event;
        $data  = array(
            'description' => 'description',
            'summary'     => 'summary',
            'sequence'    => 10,
            'class'       => 'PUBLIC',
            'categories'  => array('test'),
            'created'     => '2015-04-20T14:22:18Z',
            'dtstamp'     => '2015-04-21T00:00:00Z',
            'status'      => 'NEEDS-ACTION',
            'dtstart'     => '2014-01-01',
            'dtend'       => '2014-02-01',
            'location'    => null,
            'priority'    => 1,
            'url'         => 'url',
            'attendee'    => array(
                array(
                    'parameters' => array(
                        'cn'       => 'Manager, Jane',
                        'partstat' => 'NEEDS-ACTION',
                        'role'     => 'REQ-PARTICIPANT',
                        'rsvp'     => true,
                    ),
                    'cal-address' => 'mailto:%3Cjane.manager%40example.org%3E',
                ),
            ),
            'organizer' => array(
                'parameters' => array(
                    'cn' => 'Organizer',
                ),
                'cal-address' => 'mailto:organizer%40example.org',
            ),
            'exdate' => array(
                'date' => array(
                    '2015-06-05',
                    '2015-06-12',
                ),
            ),
            'rdate' => array(
                'date' => array(
                    '2015-06-15',
                    '2015-06-22',
                ),
            ),
            'rrule'   => array(
                'recur' => array(
                    'freq'       => 'MONTHLY',
                    'bymonthday' => 5,
                    'count'      => 10,
                    'interval'   => 2,
                ),
            ),
        );

        $input->input($data);

        $this->assertSame('description', $data['description']);
        $this->assertSame('summary', $data['title']);
        $this->assertSame('public', $data['sensitivity']);
        $this->assertSame(10, $data['sequence']);
        $this->assertSame(array('test'), $data['categories']);
        $this->assertSame(null, $data['location']);
        $this->assertSame(1, $data['priority']);
        $this->assertSame('url', $data['url']);
        $this->assertSame(kolab_api_input_json::to_datetime('2015-04-20T14:22:18Z')->format('c'), $data['created']->format('c'));
        $this->assertSame(kolab_api_input_json::to_datetime('2015-04-21T00:00:00Z')->format('c'), $data['changed']->format('c'));
        $this->assertSame(kolab_api_input_json::to_datetime('2014-01-01')->format('c'), $data['start']->format('c'));
        $this->assertSame(kolab_api_input_json::to_datetime('2014-02-01')->format('c'), $data['end']->format('c'));

        $this->assertSame('Manager, Jane',      $data['attendees'][0]['name']);
        $this->assertSame('NEEDS-ACTION',       $data['attendees'][0]['status']);
        $this->assertSame('REQ-PARTICIPANT',    $data['attendees'][0]['role']);
        $this->assertSame(true,                 $data['attendees'][0]['rsvp']);
        $this->assertSame('jane.manager@example.org', $data['attendees'][0]['email']);
        $this->assertSame('Organizer',             $data['organizer']['name']);
        $this->assertSame('organizer@example.org', $data['organizer']['email']);

        $this->assertSame('2015-06-05', $data['recurrence']['EXDATE'][0]);
        $this->assertSame('2015-06-12', $data['recurrence']['EXDATE'][1]);

        $this->assertSame('2015-06-15', $data['recurrence']['RDATE'][0]);
        $this->assertSame('2015-06-22', $data['recurrence']['RDATE'][1]);

        $this->assertSame('MONTHLY', $data['recurrence']['FREQ']);
        $this->assertSame(5, $data['recurrence']['BYMONTHDAY']);
        $this->assertSame(10, $data['recurrence']['COUNT']);
        $this->assertSame(2, $data['recurrence']['INTERVAL']);

        self::$original = $data;
    }

    /**
     * Test input method with merging
     */
    function test_input2()
    {
        $input = new kolab_api_input_json_event;
        $data  = array(
            'description' => 'description1',
            'summary'     => 'summary1',
            'sequence'    => 20,
            'class'       => 'PRIVATE',
            'categories'  => array('test1'),
//            'created'     => '2015-04-20T14:22:18Z',
//            'dtstamp'     => '2015-04-21T00:00:00Z',
//            'status'      => 'IN-PROCESS',
            'dtstart'     => '2014-01-11',
            'dtend'       => '2014-02-11',
            'location'    => 'location1',
            'priority'    => 2,
            'url'         => 'url1',
        );

        $input->input($data, self::$original);

        $this->assertSame('description1', $data['description']);
        $this->assertSame('summary1', $data['title']);
        $this->assertSame('private', $data['sensitivity']);
        $this->assertSame(20, $data['sequence']);
        $this->assertSame(array('test1'), $data['categories']);
        $this->assertSame('location1', $data['location']);
        $this->assertSame(2, $data['priority']);
        $this->assertSame('url1', $data['url']);
//        $this->assertSame(kolab_api_input_json::to_datetime('2015-04-20T14:22:18Z')->format('c'), $data['created']->format('c'));
//        $this->assertSame(kolab_api_input_json::to_datetime('2015-04-21T00:00:00Z')->format('c'), $data['changed']->format('c'));
        $this->assertSame(kolab_api_input_json::to_datetime('2014-01-11')->format('c'), $data['start']->format('c'));
        $this->assertSame(kolab_api_input_json::to_datetime('2014-02-11')->format('c'), $data['end']->format('c'));
    }
}
