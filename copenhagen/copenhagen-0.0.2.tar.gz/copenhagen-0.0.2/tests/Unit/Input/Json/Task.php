<?php

/**
 * Test class to test kolab_api_input_json_task
 *
 * @package Tests
 */
class KolabApiInputJsonTask extends PHPUnit_Framework_TestCase
{
    static $original;

    /**
     * Test expected exception in input method
     *
     * @expectedException     kolab_api_exception
     * @expectedExceptionCode 422
     */
    function test_input_exception1()
    {
        $input = new kolab_api_input_json_task;
        $data  = array();

        $input->input($data);
    }

    /**
     * Test expected exception in input method
     *
     * @expectedException     kolab_api_exception
     * @expectedExceptionCode 422
     */
    function test_input_exception2()
    {
        $input = new kolab_api_input_json_task;
        $data  = 'test';

        $input->input($data);
    }

    /**
     * Test input method (convert JSON to internal format)
     */
    function test_input()
    {
        $input = new kolab_api_input_json_task;
        $data  = array(
            'description' => 'description',
            'summary'     => 'summary',
            'sequence'    => 10,
            'class'       => 'PUBLIC',
            'categories'  => array('test'),
            'created'     => '2015-04-20T14:22:18Z',
            'dtstamp'     => '2015-04-21T00:00:00Z',
            'percent-complete' => 50,
            'status'      => 'NEEDS-ACTION',
            'dtstart'     => '2014-01-01',
            'due'         => '2014-02-01',
            'related-to'  => 'parent',
            'location'    => null,
            'priority'    => 1,
            'url'         => 'url',
            'attendee'    => array(
                array(
                    'parameters' => array(
                        'cn'       => 'Manager, Jane',
                        'partstat' => 'NEEDS-ACTION',
                        'role'     => 'OPT-PARTICIPANT',
                    ),
                    'cal-address' => 'mailto:%3Cjane.manager%40example.org%3E',
                ),
            ),
            'organizer' => array(
                'parameters' => array(
                    'cn' => 'Organizer',
                ),
                'cal-address' => 'mailto:organizer%40example.org',
            ),
        );

        $input->input($data);

        $this->assertSame('description', $data['description']);
        $this->assertSame('summary', $data['title']);
        $this->assertSame('public', $data['sensitivity']);
        $this->assertSame(10, $data['sequence']);
        $this->assertSame(array('test'), $data['categories']);
        $this->assertSame(50, $data['complete']);
        $this->assertSame('parent', $data['parent_id']);
        $this->assertSame(null, $data['location']);
        $this->assertSame(1, $data['priority']);
        $this->assertSame('url', $data['url']);
        $this->assertSame(kolab_api_input_json::to_datetime('2015-04-20T14:22:18Z')->format('c'), $data['created']->format('c'));
        $this->assertSame(kolab_api_input_json::to_datetime('2015-04-21T00:00:00Z')->format('c'), $data['changed']->format('c'));
        $this->assertSame(kolab_api_input_json::to_datetime('2014-01-01')->format('c'), $data['start']->format('c'));
        $this->assertSame(kolab_api_input_json::to_datetime('2014-02-01')->format('c'), $data['due']->format('c'));

        $this->assertSame('Manager, Jane',      $data['attendees'][0]['name']);
        $this->assertSame('NEEDS-ACTION',       $data['attendees'][0]['status']);
        $this->assertSame('OPT-PARTICIPANT',    $data['attendees'][0]['role']);
        $this->assertSame('jane.manager@example.org', $data['attendees'][0]['email']);
        $this->assertSame('Organizer',             $data['organizer']['name']);
        $this->assertSame('organizer@example.org', $data['organizer']['email']);

        // for test_input2() below
        self::$original = $data;
    }

    /**
     * Test input method with merging
     */
    function test_input2()
    {
        $input = new kolab_api_input_json_task;
        $data  = array(
            'description' => 'description1',
            'summary'     => 'summary1',
            'sequence'    => 20,
            'class'       => 'PRIVATE',
            'categories'  => array('test1'),
//            'created'     => '2015-04-20T14:22:18Z',
//            'dtstamp'     => '2015-04-21T00:00:00Z',
            'percent-complete' => 55,
            'status'      => 'NEEDS-ACTION',
            'dtstart'     => '2014-01-11',
            'due'         => '2014-02-11',
            'related-to'  => 'parent1',
            'location'    => 'location1',
            'priority'    => 2,
            'url'         => 'url1',
        );

        $input->input($data, self::$original);

        $this->assertSame('description1', $data['description']);
        $this->assertSame('summary1', $data['title']);
        $this->assertSame('private', $data['sensitivity']);
        $this->assertSame(20, $data['sequence']);
        $this->assertSame(array('test1'), $data['categories']);
        $this->assertSame(55, $data['complete']);
        $this->assertSame('parent1', $data['parent_id']);
        $this->assertSame('location1', $data['location']);
        $this->assertSame(2, $data['priority']);
        $this->assertSame('url1', $data['url']);
//        $this->assertSame(kolab_api_input_json::to_datetime('2015-04-20T14:22:18Z')->format('c'), $data['created']->format('c'));
//        $this->assertSame(kolab_api_input_json::to_datetime('2015-04-21T00:00:00Z')->format('c'), $data['changed']->format('c'));
        $this->assertSame(kolab_api_input_json::to_datetime('2014-01-11')->format('c'), $data['start']->format('c'));
        $this->assertSame(kolab_api_input_json::to_datetime('2014-02-11')->format('c'), $data['due']->format('c'));
    }
}
