<?php

/**
 * Test class to test kolab_api_input_json_attachment
 *
 * @package Tests
 */
class KolabApiInputJsonAttachment extends PHPUnit_Framework_TestCase
{
    /**
     * Test expected exception in input method
     *
     * @expectedException     kolab_api_exception
     * @expectedExceptionCode 422
     */
    function test_input_exception1()
    {
        $input = new kolab_api_input_json_attachment;
        $data  = array();

        $input->input($data);
    }

    /**
     * Test expected exception in input method
     *
     * @expectedException     kolab_api_exception
     * @expectedExceptionCode 422
     */
    function test_input_exception2()
    {
        $input = new kolab_api_input_json_attachment;
        $data  = 'test';

        $input->input($data);
    }

    /**
     * Test input method (convert JSON to internal format)
     */
    function test_input()
    {
        // @TODO
        $this->markTestIncomplete('TODO');
    }

    /**
     * Test input method with merging
     */
    function test_input2()
    {
        // @TODO
        $this->markTestIncomplete('TODO');
    }
}
