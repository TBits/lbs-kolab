<?php

/**
 * Test class to test kolab_api_input_json_mail
 *
 * @package Tests
 */
class KolabApiInputJsonMail extends PHPUnit_Framework_TestCase
{
    public static $original;

    /**
     * Test expected exception in input method
     *
     * @expectedException     kolab_api_exception
     * @expectedExceptionCode 422
     */
    function test_input_exception1()
    {
        $input = new kolab_api_input_json_mail;
        $data  = array();

        $input->input($data);
    }

    /**
     * Test expected exception in input method
     *
     * @expectedException     kolab_api_exception
     * @expectedExceptionCode 422
     */
    function test_input_exception2()
    {
        $input = new kolab_api_input_json_mail;
        $data  = 'test';

        $input->input($data);
    }

    /**
     * Test input method (convert JSON to internal format)
     */
    function test_input()
    {
        $input = new kolab_api_input_json_mail;
        $data  = array(
            'subject'  => 'subject',
            'from'     => array(
                'address' => 'mark.german@example.org',
                'name'    => 'German, Mark'
            ),
            'to' => array(array(
                    'address' => 'mark.german@example.org',
                    'name'    => 'German, Mark'
            )),
            'cc' => array(array(
                    'address' => 'cc@example.org',
            )),
            'bcc' => array(array(
                    'address' => 'bcc@example.org',
            )),
            'reply-to' => array(array(
                    'address' => 'reply@example.org',
            )),
            'priority'   => 5,
            'flags'      => array('deleted'),
            'categories' => array('test'),
            'date'       => '2015-01-01 01:00:00 UTC',
            'text'       => 'test',
            'html'       => '<body>test</body>',
        );

        $input->input($data);

        $this->assertInstanceOf('kolab_api_mail', $data);
        $this->assertSame('subject', $data->subject);
        $this->assertSame(5, $data->priority);
        $this->assertSame(null, $data->size);
        $this->assertSame('2015-01-01 01:00:00 UTC', $data->date);
        $this->assertSame(array(
                'address' => 'mark.german@example.org',
                'name'    => 'German, Mark'
                ), $data->from);
        $this->assertSame(array(array(
                    'address' => 'mark.german@example.org',
                    'name'    => 'German, Mark'
                )), $data->to);
        $this->assertSame(array(array(
                    'address' => 'cc@example.org',
                )), $data->cc);
        $this->assertSame(array(array(
                    'address' => 'bcc@example.org',
                )), $data->bcc);
        $this->assertSame(array(array(
                    'address' => 'reply@example.org',
                )), $data->{'reply-to'});
        $this->assertSame('test', $data->text);
        $this->assertSame('<body>test</body>', $data->html);

        self::$original = $data;
    }

    /**
     * Test input method with merging (?)
     */
    function test_input2()
    {
        $input = new kolab_api_input_json_mail;
        $data  = array(
            'subject'  => 'subject1',
            'from'     => array(
                'address' => 'mark1.german@example.org',
                'name'    => 'German, Mark'
            ),
            'to' => array(array(
                    'address' => 'mark1.german@example.org',
                    'name'    => 'German, Mark'
            )),
            'cc' => array(array(
                    'address' => 'cc1@example.org',
            )),
            'bcc' => array(array(
                    'address' => 'bcc1@example.org',
            )),
            'reply-to' => array(array(
                    'address' => 'reply1@example.org',
            )),
            'priority'   => 2,
            'flags'      => array('deleted1'),
            'categories' => array('test1'),
            'date'       => '2015-01-02 01:00:00 UTC',
            'text'       => 'test1',
            'html'       => '<body>test1</body>',
        );

        $input->input($data, self::$original);

        $this->assertInstanceOf('kolab_api_mail', $data);
        $this->assertSame('subject1', $data->subject);
        $this->assertSame(2, $data->priority);
        $this->assertSame('2015-01-02 01:00:00 UTC', $data->date);
        $this->assertSame(array(
                'address' => 'mark1.german@example.org',
                'name'    => 'German, Mark'
                ), $data->from);
        $this->assertSame(array(array(
                    'address' => 'mark1.german@example.org',
                    'name'    => 'German, Mark'
                )), $data->to);
        $this->assertSame(array(array(
                    'address' => 'cc1@example.org',
                )), $data->cc);
        $this->assertSame(array(array(
                    'address' => 'bcc1@example.org',
                )), $data->bcc);
        $this->assertSame(array(array(
                    'address' => 'reply1@example.org',
                )), $data->{'reply-to'});
        $this->assertSame('test1', $data->text);
        $this->assertSame('<body>test1</body>', $data->html);
    }
}
