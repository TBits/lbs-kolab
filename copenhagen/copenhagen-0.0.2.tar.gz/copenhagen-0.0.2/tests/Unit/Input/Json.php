<?php

/**
 * Test class to test kolab_api_input_json
 *
 * @package Tests
 */
class KolabApiInputJson extends PHPUnit_Framework_TestCase
{

    /**
     * Test input method
     */
    function test_input()
    {
        // @TODO
        $this->markTestIncomplete('TODO');
    }

    /**
     * Test to_datetime method
     */
    function test_to_datetime()
    {
        $result = kolab_api_input_json::to_datetime(null);

        $this->assertNull($result);

        $date   = '2014-01-01';
        $result = kolab_api_input_json::to_datetime($date);

        $this->assertInstanceOf('DateTime', $result);
        $this->assertSame('2014-01-01T00:00:00+00:00', $result->format('c'));
        $this->assertTrue($result->_dateonly);

        $date   = array('date' => '2014-01-01');
        $result = kolab_api_input_json::to_datetime($date);

        $this->assertInstanceOf('DateTime', $result);
        $this->assertSame('2014-01-01T00:00:00+00:00', $result->format('c'));
        $this->assertTrue($result->_dateonly);

        $date   = '2015-04-20T14:22:18Z';
        $result = kolab_api_input_json::to_datetime($date);

        $this->assertInstanceOf('DateTime', $result);
        $this->assertSame('2015-04-20T14:22:18+00:00', $result->format('c'));
        $this->assertFalse((bool) $result->_dateonly);

        $date   = array('date-time' => '2015-04-21T00:00:00Z');
        $result = kolab_api_input_json::to_datetime($date);

        $this->assertInstanceOf('DateTime', $result);
        $this->assertSame('2015-04-21T00:00:00+00:00', $result->format('c'));
        $this->assertFalse((bool) $result->_dateonly);

        $date = array(
            'date-time' => '2015-04-21T00:00:00',
            'parameters' => array(
                'tzid' => '/kolab.org/Europe/Zurich',
            ),
        );
        $result = kolab_api_input_json::to_datetime($date);

        $this->assertInstanceOf('DateTime', $result);
        $this->assertSame('2015-04-21T00:00:00+02:00', $result->format('c'));
        $this->assertFalse((bool) $result->_dateonly);
        $this->assertSame('Europe/Zurich', $result->getTimezone()->getName());
    }

    /**
     * Test add_x_custom
     */
    function test_add_x_custom()
    {
        kolab_api_input_json::add_x_custom($data, $result);

        $this->assertNull($result);

        $data = array('x-custom' => null);
        kolab_api_input_json::add_x_custom($data, $result);

        $this->assertSame(array(), $result['x-custom']);

        $data = array('x-custom' => array());
        kolab_api_input_json::add_x_custom($data, $result);

        $this->assertSame(array(), $result['x-custom']);

        $data = array('x-custom' => array(
            array('identifier' => 'i', 'value' => 'v'),
        ));
        kolab_api_input_json::add_x_custom($data, $result);

        $this->assertSame('i', $result['x-custom'][0][0]);
        $this->assertSame('v', $result['x-custom'][0][1]);
    }

    /**
     * Test input parse_mailto_uri
     */
    function test_parse_mailto_uri()
    {
        // @TODO
        $this->markTestIncomplete('TODO');
    }

    /**
     * Test input parse_attendees
     */
    function test_parse_attendees()
    {
        // @TODO
        $this->markTestIncomplete('TODO');
    }

    /**
     * Test input parse_recurrence
     */
    function test_parse_recurrence()
    {
        // @TODO
        $this->markTestIncomplete('TODO');
    }
}
