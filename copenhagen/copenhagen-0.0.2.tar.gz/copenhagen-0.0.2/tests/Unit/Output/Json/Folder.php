<?php

/**
 * Test class to test kolab_api_output_json_folder
 *
 * @package Tests
 */
class KolabApiOutputJsonFolder extends PHPUnit_Framework_TestCase
{

    /**
     * Test element method (Internal to JSON conversion)
     */
    function test_element()
    {
        $output = kolab_api_tests::get_output_class('json', 'folder');
        $object = array(
            'name'   => 'Calendar',
            'type'   => 'event.default',
        );

        $result = $output->element($object);

        $this->assertSame($object, $result);

        $folder = new kolab_api_folder($object);
        $result = $output->element($folder);

        $this->assertSame($object, $result);
    }
}
