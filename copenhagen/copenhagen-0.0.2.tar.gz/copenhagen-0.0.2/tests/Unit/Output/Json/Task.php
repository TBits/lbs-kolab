<?php

/**
 * Test class to test kolab_api_output_json_task
 *
 * @package Tests
 */
class KolabApiOutputJsonTask extends PHPUnit_Framework_TestCase
{

    /**
     * Test element method (Internal to JSON conversion)
     */
    function test_element()
    {
        $output = kolab_api_tests::get_output_class('json', 'task');
        $object = kolab_api_tests::get_data('10-10-10-10', 'Tasks', 'task', null, $context);
        $result = $output->element($object);

        $this->assertSame('10-10-10-10', $result['uid']);
        $this->assertSame('task title', $result['summary']);
        $this->assertSame('2015-04-20T14:22:18Z', $result['created']);
        $this->assertSame('2015-04-20T14:22:18Z', $result['dtstamp']);
        $this->assertSame(0, $result['sequence']);
        $this->assertSame('PUBLIC', $result['class']);
        $this->assertSame("task description\nsecond line", $result['description']);
        $this->assertSame(56, $result['percent-complete']);
        $this->assertSame('German, Mark', $result['organizer']['parameters']['cn']);
        $this->assertSame('mailto:%3Cmark.german%40example.org%3E', $result['organizer']['cal-address']);
        $this->assertSame('text/plain', $result['attach'][0]['parameters']['fmttype']);
        $this->assertSame('test.txt', $result['attach'][0]['parameters']['x-label']);
        $this->assertSame('cid:test.1429539738.5833.txt', $result['attach'][0]['uri']);
        $this->assertSame('MAPI:PidLidTaskActualEffort', $result['x-custom'][0]['identifier']);
        $this->assertSame('8', $result['x-custom'][0]['value']);

        $object = kolab_api_tests::get_data('20-20-20-20', 'Tasks', 'task', null, $context);
        $result = $output->element($object);

        $this->assertSame('20-20-20-20', $result['uid']);
        $this->assertSame('task', $result['summary']);
        $this->assertSame('2015-04-20', $result['dtstart']);
        $this->assertSame('2015-04-27', $result['due']);
        $this->assertSame(array('freq' => 'DAILY'), $result['rrule']['recur']);
        $this->assertSame('NEEDS-ACTION', $result['status']);
        $this->assertSame('Manager, Jane', $result['attendee'][0]['parameters']['cn']);
        $this->assertSame('NEEDS-ACTION', $result['attendee'][0]['parameters']['partstat']);
        $this->assertSame('REQ-PARTICIPANT', $result['attendee'][0]['parameters']['role']);
        $this->assertSame(true, $result['attendee'][0]['parameters']['rsvp']);
        $this->assertSame('mailto:%3Cjane.manager%40example.org%3E', $result['attendee'][0]['cal-address']);
    }
}
