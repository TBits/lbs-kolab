<?php

/**
 * Test class to test kolab_api_output_json_note
 *
 * @package Tests
 */
class KolabApiOutputJsonNote extends PHPUnit_Framework_TestCase
{

    /**
     * Test element method (Internal to JSON conversion)
     */
    function test_element()
    {
        $output = kolab_api_tests::get_output_class('json', 'note');

        $object = kolab_api_tests::get_data('1-1-1-1', 'Notes', 'note', null, $context);
        $result = $output->element($object);

        $this->assertSame('1-1-1-1', $result['uid']);
        $this->assertSame('2015-01-20T11:44:59Z', $result['creation-date']);
        $this->assertSame('2015-01-22T11:30:17Z', $result['last-modification-date']);
        $this->assertSame('PUBLIC', $result['classification']);
        $this->assertSame('test', $result['summary']);
        $this->assertRegexp('/<html>/', $result['description']);
        $this->assertSame('MAPI:PidLidNoteX', $result['x-custom'][0]['identifier']);
        $this->assertSame('100', $result['x-custom'][0]['value']);
        $this->assertSame('MAPI:PidLidNoteY', $result['x-custom'][1]['identifier']);
        $this->assertSame('200', $result['x-custom'][1]['value']);
    }
}
