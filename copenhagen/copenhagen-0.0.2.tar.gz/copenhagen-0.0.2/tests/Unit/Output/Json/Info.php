<?php

/**
 * Test class to test kolab_api_output_json_info
 *
 * @package Tests
 */
class KolabApiOutputJsonInfo extends PHPUnit_Framework_TestCase
{

    /**
     * Test element method (Internal to JSON conversion)
     */
    function test_element()
    {
        $output = kolab_api_tests::get_output_class('json', 'info');
        $object = array(
            'name'    => 'Kolab REST API',
            'test1'   => '',
            'test2'   => '',
            'version' => '1.0',
        );

        $expected = array(
            'name'    => 'Kolab REST API',
            'version' => '1.0',
        );

        $result = $output->element($object);

        $this->assertSame($expected, $result);
    }
}
