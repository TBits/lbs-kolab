<?php

/**
 * Test class to test kolab_api_output_json_contact
 *
 * @package Tests
 */
class KolabApiOutputJsonContact extends PHPUnit_Framework_TestCase
{

    /**
     * Test element method (Internal to JSON conversion)
     */
    function test_element()
    {
        $output = kolab_api_tests::get_output_class('json', 'contact');
        $object = kolab_api_tests::get_data('a-b-c-d', 'Contacts', 'contact', null, $context);
        $result = $output->element($object);

        $this->assertSame('a-b-c-d', $result['uid']);
        $this->assertSame('3.1.0', $result['x-kolab-version']);
        $this->assertSame('20150420T141533Z', $result['rev']);
        $this->assertSame('individual',   $result['kind']);
        $this->assertSame('displname',    $result['fn']);
        $this->assertSame('last',         $result['n']['surname']);
        $this->assertSame('test',         $result['n']['given']);
        $this->assertSame('middlename',   $result['n']['additional']);
        $this->assertSame('prefx',        $result['n']['prefix']);
        $this->assertSame('suff',         $result['n']['suffix']);
        $this->assertSame('dsfsdfsdfsdf sdfsdfsdf sdfsdfsfd', $result['note']);
        $this->assertSame('free-busy url', $result['fburl']);
        $this->assertSame(array('title'), $result['title']);
        $this->assertSame('Org',          $result['group']['org'][0]);
        $this->assertSame('dept',         $result['group']['org'][1]);
        $this->assertSame('profeion',     $result['group']['role']);
        $this->assertSame('x-manager',    $result['group']['related'][0]['parameters']['type']);
        $this->assertSame('manager name', $result['group']['related'][0]['text']);
        $this->assertSame('x-assistant',  $result['group']['related'][1]['parameters']['type']);
        $this->assertSame('assist',       $result['group']['related'][1]['text']);
//        $this->assertSame('', $result['group']['adr']['parameters']);
//        $this->assertSame('', $result['group']['adr']['pobox']);
//        $this->assertSame('', $result['group']['adr']['ext']);
        $this->assertSame('office street',  $result['group']['adr']['street']);
        $this->assertSame('office city',    $result['group']['adr']['locality']);
        $this->assertSame('office state',   $result['group']['adr']['region']);
        $this->assertSame('office zip',     $result['group']['adr']['code']);
        $this->assertSame('office country', $result['group']['adr']['country']);
        $this->assertSame('website',        $result['url'][0]);
        $this->assertSame('home',           $result['adr'][0]['parameters']['type']);
        $this->assertSame('home street',    $result['adr'][0]['street']);
        $this->assertSame('home city',      $result['adr'][0]['locality']);
        $this->assertSame('home state',     $result['adr'][0]['region']);
        $this->assertSame('home zip',       $result['adr'][0]['code']);
        $this->assertSame('home country',   $result['adr'][0]['country']);
        $this->assertSame('work',           $result['adr'][1]['parameters']['type']);
        $this->assertSame(1,                $result['adr'][1]['parameters']['pref']);
        $this->assertSame('work street',    $result['adr'][1]['street']);
        $this->assertSame('work city',      $result['adr'][1]['locality']);
        $this->assertSame('work state',     $result['adr'][1]['region']);
        $this->assertSame('work zip',       $result['adr'][1]['code']);
        $this->assertSame('work country',   $result['adr'][1]['country']);
        $this->assertSame('nick',      $result['nickname']);
        $this->assertSame('spouse',    $result['related'][0]['parameters']['type']);
        $this->assertSame('spouse',    $result['related'][0]['text']);
        $this->assertSame('child',     $result['related'][1]['parameters']['type']);
        $this->assertSame('children',  $result['related'][1]['text']);
        $this->assertSame('child',     $result['related'][2]['parameters']['type']);
        $this->assertSame('children2', $result['related'][2]['text']);
        $this->assertSame('20150330',  $result['bday']); // ?
        $this->assertSame('20150301',  $result['anniversary']); // ?
        $this->assertRegExp('|^data:image/jpeg;base64,|', $result['photo']);
        $this->assertSame('M',          $result['gender']);
        $this->assertSame('home',       $result['tel'][0]['parameters']['type']);
        $this->assertSame('home phone', $result['tel'][0]['text']);
        $this->assertSame('work',       $result['tel'][1]['parameters']['type']);
        $this->assertSame('work phone', $result['tel'][1]['text']);
        $this->assertSame('fax',        $result['tel'][2]['parameters']['type'][0]);
        $this->assertSame('home',       $result['tel'][2]['parameters']['type'][1]);
        $this->assertSame('home fax',   $result['tel'][2]['text']);
        $this->assertSame('fax',        $result['tel'][3]['parameters']['type'][0]);
        $this->assertSame('work',       $result['tel'][3]['parameters']['type'][1]);
        $this->assertSame('work fax',   $result['tel'][3]['text']);
        $this->assertSame('cell',       $result['tel'][4]['parameters']['type']);
        $this->assertSame('mobile',     $result['tel'][4]['text']);
        $this->assertSame('pager',      $result['tel'][5]['parameters']['type']);
        $this->assertSame('pager',      $result['tel'][5]['text']);
        $this->assertSame('x-car',      $result['tel'][6]['parameters']['type']);
        $this->assertSame('car phone',  $result['tel'][6]['text']);
        $this->assertSame('textphone',   $result['tel'][7]['parameters']['type']);
        $this->assertSame('other phone', $result['tel'][7]['text']);
        $this->assertSame('im gg',          $result['impp'][0]);
        $this->assertSame('home',           $result['email'][0]['parameters']['type']);
        $this->assertSame('test@mail.ru',   $result['email'][0]['text']);
        $this->assertSame('work',           $result['email'][1]['parameters']['type']);
        $this->assertSame('work@email.pl',  $result['email'][1]['text']);
        $this->assertSame('other@email.pl', $result['email'][2]);
        $this->assertRegExp('|^data:application/pgp-keys;base64,|',   $result['key'][0]);
        $this->assertRegExp('|^data:application/pkcs7-mime;base64,|', $result['key'][1]);
    }

    /**
     * Test element method (Internal to JSON conversion) for distribution-lists
     */
    function test_element_distlist()
    {
        $output = kolab_api_tests::get_output_class('json', 'contact');
        $object = kolab_api_tests::get_data('i-j-k-l', 'Contacts', 'contact', null, $context);
        $result = $output->element($object);

        $this->assertSame('i-j-k-l', $result['uid']);
        $this->assertSame('3.1.0', $result['x-kolab-version']);
        $this->assertSame('20150827T085101Z', $result['rev']);
        $this->assertSame('group',   $result['kind']);
        $this->assertSame('test group',    $result['fn']);
        $this->assertSame('urn:uuid:a-b-c-d',                           $result['member'][0]);
        $this->assertSame('urn:uuid:e-f-g-h',                           $result['member'][1]);
        $this->assertSame('mailto:John%20Doe%3Cjdoe%40example.com%3E',  $result['member'][2]);
    }
}
