<?php

/**
 * Test class to test kolab_api_output_json_event
 *
 * @package Tests
 */
class KolabApiOutputJsonEvent extends PHPUnit_Framework_TestCase
{

    /**
     * Test element method (Internal to JSON conversion)
     */
    function test_element()
    {
        $output = kolab_api_tests::get_output_class('json', 'event');
        $object = kolab_api_tests::get_data('100-100-100-100', 'Calendar', 'event', null, $context);
        $result = $output->element($object);

        $this->assertSame('100-100-100-100', $result['uid']);
        $this->assertSame('2015-05-14T13:03:33Z', $result['created']);
        $this->assertSame('2015-05-14T13:50:18Z', $result['dtstamp']);
        $this->assertSame(2, $result['sequence']);
        $this->assertSame('CONFIDENTIAL', $result['class']);
        $this->assertSame('tag1', $result['categories'][0]);
        $this->assertSame('/kolab.org/Europe/Berlin', $result['dtstart']['parameters']['tzid']);
        $this->assertSame('2015-05-15T10:00:00', $result['dtstart']['date-time']);
        $this->assertSame('/kolab.org/Europe/Berlin', $result['dtend']['parameters']['tzid']);
        $this->assertSame('2015-05-15T10:30:00', $result['dtend']['date-time']);
        $this->assertSame('Summary', $result['summary']);
        $this->assertSame('Description', $result['description']);
        $this->assertSame(1, $result['priority']);
        $this->assertSame('Location', $result['location']);
        $this->assertSame('German, Mark', $result['organizer']['parameters']['cn']);
        $this->assertSame('mailto:%3Cmark.german%40example.org%3E', $result['organizer']['cal-address']);
        $this->assertSame('https://some.url', $result['url']);
        $this->assertSame('Manager, Jane', $result['attendee'][0]['parameters']['cn']);
        $this->assertSame('NEEDS-ACTION', $result['attendee'][0]['parameters']['partstat']);
        $this->assertSame('REQ-PARTICIPANT', $result['attendee'][0]['parameters']['role']);
        $this->assertSame(true, $result['attendee'][0]['parameters']['rsvp']);
        $this->assertSame('mailto:%3Cjane.manager%40example.org%3E', $result['attendee'][0]['cal-address']);
        $this->assertSame('image/jpeg', $result['attach'][0]['parameters']['fmttype']);
        $this->assertSame('photo-mini.jpg', $result['attach'][0]['parameters']['x-label']);
        $this->assertSame('cid:photo-mini.1431611291.28810.jpg', $result['attach'][0]['uri']);
        $this->assertSame('DISPLAY', $result['valarm'][0]['properties']['action']);
        $this->assertSame('Summary', $result['valarm'][0]['properties']['description']);
        $this->assertSame('START', $result['valarm'][0]['properties']['trigger']['parameters']['related']);
        $this->assertSame('-PT15M', $result['valarm'][0]['properties']['trigger']['duration']);

        $object = kolab_api_tests::get_data('101-101-101-101', 'Calendar', 'event', null, $context);
        $result = $output->element($object);

        $this->assertSame('101-101-101-101', $result['uid']);
        $this->assertSame('PUBLIC', $result['class']);
        $this->assertSame('2015-05-15', $result['dtstart']);
        $this->assertSame('2015-05-15', $result['dtend']);
        $this->assertSame('WEEKLY', $result['rrule']['recur']['freq']);
        $this->assertSame('MO', $result['rrule']['recur']['byday']);
        $this->assertSame('2015-06-05', $result['exdate']['date'][0]);
        $this->assertSame('2015-06-12', $result['exdate']['date'][1]);

        $object = kolab_api_tests::get_data('102-102-102-102', 'Calendar', 'event', null, $context);
        $result = $output->element($object);

        $this->assertSame('102-102-102-102', $result['uid']);
        $this->assertSame('2015-06-25', $result['rdate']['date'][0]);
        $this->assertSame('2015-06-28', $result['rdate']['date'][1]);

        // Event with multiple <event> tags for recurrences
        $object = kolab_api_tests::get_data('103-103-103-103', 'Calendar', 'event', null, $context);
        $result = $output->element($object);

        $this->assertSame('103-103-103-103', $result['uid']);
        $this->assertCount(2, $result['exceptions']);
        $this->assertSame('2015-06-22', $result['exceptions'][0]['recurrence-id']);
        $this->assertSame('2015-06-29', $result['exceptions'][1]['recurrence-id']);
    }
}
