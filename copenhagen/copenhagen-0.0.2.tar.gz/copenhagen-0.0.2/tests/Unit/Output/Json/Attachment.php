<?php

/**
 * Test class to test kolab_api_output_json_attachment
 *
 * @package Tests
 */
class KolabApiOutputJsonAttachment extends PHPUnit_Framework_TestCase
{

    /**
     * Test element method (Internal to JSON conversion)
     */
    function test_element()
    {
        $output = kolab_api_tests::get_output_class('json', 'attachment');
        $attach = new rcube_message_part;
        $attach->mime_id     = 'id';
        $attach->mimetype    = 'mimetype';
        $attach->size        = 100;
        $attach->filename    = 'filename.txt';
        $attach->disposition = 'disposition';
        $attach->content_id  = 'content-id';
        $attach->content_location = 'content-location';

        $result = $output->element($attach);

        $this->assertSame('id',       $result['id']);
        $this->assertSame('mimetype', $result['mimetype']);
        $this->assertSame(100,        $result['size']);
        $this->assertSame('filename.txt', $result['filename']);
        $this->assertSame('disposition', $result['disposition']);
        $this->assertSame('content-id', $result['content-id']);
        $this->assertSame('content-location', $result['content-location']);
    }
}
