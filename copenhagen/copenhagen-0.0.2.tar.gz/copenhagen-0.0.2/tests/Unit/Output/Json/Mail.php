<?php

/**
 * Test class to test kolab_api_output_json_mail
 *
 * @package Tests
 */
class KolabApiOutputJsonMail extends PHPUnit_Framework_TestCase
{

    /**
     * Test element method (Internal to JSON conversion)
     */
    function test_element()
    {
        $output = kolab_api_tests::get_output_class('json', 'mail');

        $object = kolab_api_tests::get_data('1', 'INBOX', 'mail', null, $context);
        $result = $output->element($object);

        $this->assertSame('1', $result['uid']);
        $this->assertSame('"test" wurde aktualisiert', $result['subject']);
        $this->assertSame(624, $result['size']);
        $this->assertSame(array(
                'address' => 'mark.german@example.org',
                'name'    => 'Mark German'
                ), $result['from']);
        $this->assertSame(array(array(
                    'address' => 'mark.german@example.org'
                )), $result['to']);
        $this->assertSame('text/plain', $result['content-type']);

        $object = kolab_api_tests::get_data('2', 'INBOX', 'mail', null, $context);
        $result = $output->element($object);

        $this->assertSame('2', $result['uid']);
        $this->assertSame('Re: dsda', $result['subject']);
        $this->assertSame(849, $result['size']);
        $this->assertSame('text/plain', $result['content-type']);
        $this->assertSame(array(
                'address' => 'mark.german@example.org',
                'name'    => 'German, Mark'
                ), $result['from']);
        $this->assertSame(array(array(
                    'address' => 'mark.german@example.org',
                    'name'    => 'German, Mark'
                )), $result['to']);
        $this->assertRegexp('/^On 2014-08-24/', $result['text']);
        $this->assertSame(null, $result['html']);
        $this->assertSame('<5071c053c207e5916123b0aa36959f03@example.org>', $result['message-id']);
        $this->assertSame('<c0e5147fc63045dedfe668877876c478@example.org>', $result['in-reply-to']);
        $this->assertSame('<c0e5147fc63045dedfe668877876c478@example.org>', $result['references']);
        $this->assertSame(false, $result['has-attach']);

        // @TODO: categories, flags

        $object = kolab_api_tests::get_data('5', 'INBOX', 'mail', null, $context);
        $result = $output->element($object);

        $this->assertSame('5', $result['uid']);
        $this->assertRegexp('/<strong>test content/', $result['html']);
        $this->assertRegexp('/TEST CONTENT/', $result['text']);
        $this->assertSame(false, $result['has-attach']);

        $object = kolab_api_tests::get_data('6', 'INBOX', 'mail', null, $context);
        $result = $output->element($object);

        $this->assertSame(true, $result['has-attach']);
    }
}
