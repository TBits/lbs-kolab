<?php

/**
 * Test class to test kolab_api_output_json
 *
 * @package Tests
 */
class KolabApiOutputJson extends PHPUnit_Framework_TestCase
{

    /**
     * Test object_to_array method
     */
    function test_object_to_array()
    {
        $this->markTestIncomplete('TODO');
    }

    /**
     * Test xml_to_array method
     */
    function test_xml_to_array()
    {
        $this->markTestIncomplete('TODO');
    }

    /**
     * Test parse_array_result method
     */
    function test_parse_array_result()
    {
        $this->markTestIncomplete('TODO');
    }

    /**
     * Test parse_recurrence
     */
    function test_parse_recurrence()
    {
        $this->markTestIncomplete('TODO');
    }
}
