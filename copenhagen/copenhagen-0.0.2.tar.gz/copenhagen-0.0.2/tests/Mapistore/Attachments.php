<?php

/**
 * Test class to test attachments API
 *
 * @package Tests
 */
class Mapistore_Attachments extends PHPUnit_Framework_TestCase
{
    public static $api;

    /**
     * Setup
     */
    public static function setUpBeforeClass()
    {
        // start from the beginning...
        kolab_api_tests::reset_backend();

        self::$api = kolab_api_tests::get_request('json', '/mapistore');
    }

    /**
     * Test attachment existence check
     */
    function test_attachment_exists()
    {
        self::$api->head('attachments/' . kolab_api_tests::mapi_uid('INBOX', true, 6, 2));

        $code = self::$api->response_code();
        $body = self::$api->response_body();

        $this->assertEquals(200, $code);
        $this->assertSame('', $body);

        // and non-existing attachment
        self::$api->head('attachments/' . kolab_api_tests::mapi_uid('INBOX', true, 6, 2345));

        $code = self::$api->response_code();
        $body = self::$api->response_body();

        $this->assertEquals(404, $code);
        $this->assertSame('', $body);

        // test attachments of non-mail objects
        self::$api->head('attachments/' . kolab_api_tests::mapi_uid('Calendar', true, '100-100-100-100', 3));

        $code = self::$api->response_code();
        $body = self::$api->response_body();

        $this->assertEquals(200, $code);
        $this->assertSame('', $body);

        // test contact-photo attachment
        $id = kolab_api_filter_mapistore_contact::PHOTO_ATTACHMENT_ID;
        self::$api->head('attachments/' . kolab_api_tests::mapi_uid('Contacts', true, 'a-b-c-d', $id));

        $code = self::$api->response_code();
        $body = self::$api->response_body();

        $this->assertEquals(200, $code);
        $this->assertSame('', $body);

        // test event exception attachments
        self::$api->head('attachments/' . kolab_api_tests::mapi_uid('Calendar', true, '103-103-103-103', 20150622));

        $code = self::$api->response_code();
        $body = self::$api->response_body();

        $this->assertEquals(200, $code);
        $this->assertSame('', $body);
    }

    /**
     * Test attachment info
     */
    function test_attachment_info()
    {
        self::$api->get('attachments/' . kolab_api_tests::mapi_uid('INBOX', true, 6, 2));

        $code = self::$api->response_code();
        $body = self::$api->response_body();
        $body = json_decode($body, true);

        $this->assertEquals(200, $code);
        $this->assertSame(kolab_api_tests::mapi_uid('INBOX', true, 6, 2), $body['id']);
        $this->assertSame('text/plain', $body['PidTagAttachMimeTag']);
        $this->assertSame('test.txt',   $body['PidTagDisplayName']);
        $this->assertSame(4,            $body['PidTagAttachSize']);
        $this->assertSame(1,            $body['PidTagAttachMethod']);
        $this->assertSame('test',       base64_decode($body['PidTagAttachDataBinary']));

        // and non-existing attachment
        self::$api->get('attachments/' . kolab_api_tests::mapi_uid('INBOX', true, 6, 2345));

        $code = self::$api->response_code();
        $body = self::$api->response_body();

        $this->assertEquals(404, $code);
        $this->assertSame('', $body);

        // test attachments of kolab objects
        self::$api->get('attachments/' . kolab_api_tests::mapi_uid('Calendar', true, '100-100-100-100', 3));

        $code = self::$api->response_code();
        $body = self::$api->response_body();
        $body = json_decode($body, true);

        $this->assertEquals(200, $code);
        $this->assertSame(kolab_api_tests::mapi_uid('Calendar', true, '100-100-100-100', 3), $body['id']);
        $this->assertSame('image/jpeg',     $body['PidTagAttachMimeTag']);
        $this->assertSame('photo-mini.jpg', $body['PidTagDisplayName']);
        $this->assertSame(793,              $body['PidTagAttachSize']);
        $this->assertSame(1,                $body['PidTagAttachMethod']);
        $this->assertSame('/9j/4AAQSkZJRgAB', substr($body['PidTagAttachDataBinary'], 0, 16));

        // test contact photo attachment
        $id = kolab_api_filter_mapistore_contact::PHOTO_ATTACHMENT_ID;
        self::$api->get('attachments/' . kolab_api_tests::mapi_uid('Contacts', true, 'a-b-c-d', $id));

        $code = self::$api->response_code();
        $body = self::$api->response_body();
        $body = json_decode($body, true);

        $this->assertEquals(200, $code);
        $this->assertSame(kolab_api_tests::mapi_uid('Contacts', true, 'a-b-c-d', $id), $body['id']);
//        $this->assertSame('image/jpeg',     $bod['PidTagAttachMimeTag']);
        $this->assertSame(true,                 $body['PidTagAttachmentContactPhoto']);
        $this->assertSame('ContactPicture.jpg', $body['PidTagDisplayName']);
        $this->assertSame('.jpg',               $body['PidTagAttachExtension']);
        $this->assertSame(12797,                $body['PidTagAttachSize']);
        $this->assertSame('/9j/4AAQ', substr($body['PidTagAttachDataBinary'], 0, 8));

        // test event exception attachment
        self::$api->get('attachments/' . kolab_api_tests::mapi_uid('Calendar', true, '103-103-103-103', 20150622));

        $code = self::$api->response_code();
        $body = self::$api->response_body();
        $body = json_decode($body, true);

        $this->assertEquals(200, $code);
        $this->assertSame(kolab_api_tests::mapi_uid('Calendar', true, '103-103-103-103', 20150622), $body['id']);
        $this->assertTrue(!empty($body['PidTagAttachDataObject']));
        $this->assertSame('Summary', $body['PidTagDisplayName']);
        $this->assertSame(7, $body['PidTagObjectType']);
    }

    /**
     * Test attachment create
     */
    function test_attachment_create()
    {
        $post = json_encode(array(
            'PidTagAttachDataBinary' => 'R0lGODlhDwAPAIAAAMDAwAAAACH5BAEAAAAALAAAAAAPAA8AQAINhI+py+0Po5y02otnAQA7',
            'PidTagDisplayName'      => 'image.gif',
        ));
        self::$api->post('attachments/' . kolab_api_tests::mapi_uid('Calendar', true, '100-100-100-100'), array(), $post);

        $code = self::$api->response_code();
        $body = self::$api->response_body();

        $this->assertEquals(200, $code);

        self::$api->get('attachments/' . kolab_api_tests::mapi_uid('Calendar', true, '100-100-100-100', 4));

        $code = self::$api->response_code();
        $body = self::$api->response_body();
        $body = json_decode($body, true);

        $this->assertSame(kolab_api_tests::mapi_uid('Calendar', true, '100-100-100-100', 4), $body['id']);
        $this->assertSame('image/gif',  $body['PidTagAttachMimeTag']);
        $this->assertSame('image.gif',  $body['PidTagDisplayName']);
        $this->assertSame(54,           $body['PidTagAttachSize']);
        $this->assertSame(1,            $body['PidTagAttachMethod']);
        $this->assertSame('R0lGODlhDwAPAIAAAMDAwAAAACH5BAEAAAAALAAAAAAPAA8AQAINhI+py+0Po5y02otnAQA7', $body['PidTagAttachDataBinary']);

        // add contact photo
        $post = json_encode(array(
            'PidTagAttachDataBinary'       => 'R0lGODlhDwAPAIAAAMDAwAAAACH5BAEAAAAALAAAAAAPAA8AQAINhI+py+0Po5y02otnAQA7',
            'PidTagAttachmentContactPhoto' => true,
        ));
        self::$api->post('attachments/' . kolab_api_tests::mapi_uid('Contacts', true, 'e-f-g-h'), array(), $post);

        $code = self::$api->response_code();
        $body = self::$api->response_body();

        $this->assertEquals(200, $code);

        $id = kolab_api_filter_mapistore_contact::PHOTO_ATTACHMENT_ID;
        self::$api->get('attachments/' . kolab_api_tests::mapi_uid('Contacts', true, 'e-f-g-h', $id));

        $code = self::$api->response_code();
        $body = self::$api->response_body();
        $body = json_decode($body, true);

        $this->assertSame(true,       $body['PidTagAttachmentContactPhoto']);
        $this->assertSame(54,         $body['PidTagAttachSize']);
        $this->assertSame('R0lGODlh', substr($body['PidTagAttachDataBinary'], 0, 8));

        // add event exception
        $post = json_encode(array(
            'PidTagAttachDataObject' => array(
                'PidTagMessageClass' => 'IPM.OLE.CLASS.{00061055-0000-0000-C000-000000000046}',
                'PidLidAppointmentSequence' => 1,
                'PidLidLocation'            => 'LocationX',
                'PidLidAppointmentSubType'  => 1,
                'PidLidAppointmentStartWhole' => 13079404800,
                'PidLidAppointmentEndWhole' => 13079491200,
                'PidTagSubject'             => 'SummaryX',
                'PidTagSensitivity'         => 0,
                'PidLidAppointmentDuration' => 1440,
                'PidLidReminderDelta'       => 35,
            ),
            'PidTagObjectType'   => 7,
            'PidTagAttachMethod' => 5,
        ));
        self::$api->post('attachments/' . kolab_api_tests::mapi_uid('Calendar', true, '101-101-101-101'), array(), $post);

        $code = self::$api->response_code();
        $body = self::$api->response_body();
        $body = json_decode($body, true);

        $this->assertEquals(200, $code);

        self::$api->get('attachments/' . $body['id']);

        $code = self::$api->response_code();
        $body = self::$api->response_body();
        $body = json_decode($body, true);

        $this->assertSame('LocationX', $body['PidTagAttachDataObject']['PidLidLocation']);
        $this->assertSame('SummaryX', $body['PidTagAttachDataObject']['PidTagSubject']);
    }

    /**
     * Test attachment update
     */
    function test_attachment_update()
    {
        $post = json_encode(array(
            'PidTagAttachDataBinary' => base64_encode('test text file'),
            'PidTagDisplayName'      => 'test.txt',
        ));
        self::$api->put('attachments/' . kolab_api_tests::mapi_uid('Calendar', true, '100-100-100-100', 4), array(), $post);

        $code = self::$api->response_code();
        $body = self::$api->response_body();

        $this->assertEquals(200, $code);

        self::$api->get('attachments/' . kolab_api_tests::mapi_uid('Calendar', true, '100-100-100-100', 4));

        $code = self::$api->response_code();
        $body = self::$api->response_body();
        $body = json_decode($body, true);

        $this->assertSame(kolab_api_tests::mapi_uid('Calendar', true, '100-100-100-100', 4), $body['id']);
        $this->assertSame('text/plain',  $body['PidTagAttachMimeTag']);
        $this->assertSame('test.txt',  $body['PidTagDisplayName']);
        $this->assertSame(14,           $body['PidTagAttachSize']);
        $this->assertSame(1,            $body['PidTagAttachMethod']);
        $this->assertSame('test text file', base64_decode($body['PidTagAttachDataBinary']));

        // update contact photo
        $id   = kolab_api_filter_mapistore_contact::PHOTO_ATTACHMENT_ID;
        $post = json_encode(array(
            'PidTagAttachDataBinary'       => 'R0lGODlhDwAPAIAAAMDAwAAAACH5BAEAAAAALAAAAAAPAA8AQAINhI+py+0Po5y02otnAQA7',
            'PidTagAttachmentContactPhoto' => true,
        ));
        self::$api->put('attachments/' . kolab_api_tests::mapi_uid('Contacts', true, 'a-b-c-d', $id), array(), $post);

        $code = self::$api->response_code();
        $body = self::$api->response_body();

        $this->assertEquals(200, $code);

        self::$api->get('attachments/' . kolab_api_tests::mapi_uid('Contacts', true, 'a-b-c-d', $id));

        $code = self::$api->response_code();
        $body = self::$api->response_body();
        $body = json_decode($body, true);

        $this->assertSame(true,                 $body['PidTagAttachmentContactPhoto']);
        $this->assertSame('ContactPicture.gif', $body['PidTagDisplayName']);
        $this->assertSame('.gif',               $body['PidTagAttachExtension']);
        $this->assertSame(54,                   $body['PidTagAttachSize']);
        $this->assertSame('R0lGODlh', substr($body['PidTagAttachDataBinary'], 0, 8));

        // update event exception attachment
        $post = json_encode(array(
            'PidTagAttachDataObject' => array(
                'PidTagMessageClass' => 'IPM.OLE.CLASS.{00061055-0000-0000-C000-000000000046}',
                'PidLidAppointmentSequence' => 2,
                'PidLidLocation'            => 'LocationY',
                'PidLidAppointmentSubType'  => 1,
                'PidTagSubject'             => 'SummaryY',
            ),
            'PidTagObjectType'   => 7,
            'PidTagAttachMethod' => 5,
        ));
        self::$api->put('attachments/' . kolab_api_tests::mapi_uid('Calendar', true, '103-103-103-103', 20150622), array(), $post);

        $code = self::$api->response_code();
        $body = self::$api->response_body();
        $body = json_decode($body, true);

        $this->assertEquals(200, $code);

        self::$api->get('attachments/' . $body['id']);

        $code = self::$api->response_code();
        $body = self::$api->response_body();
        $body = json_decode($body, true);

        $this->assertEquals(200, $code);
        $this->assertSame('LocationY', $body['PidTagAttachDataObject']['PidLidLocation']);
        $this->assertSame('SummaryY', $body['PidTagAttachDataObject']['PidTagSubject']);
        $this->assertSame(35, $body['PidTagAttachDataObject']['PidLidReminderDelta']);
    }

    /**
     * Test attachment delete
     */
    function test_attachment_delete()
    {
        // delete existing attachment
        self::$api->delete('attachments/' . kolab_api_tests::mapi_uid('Tasks', true, '10-10-10-10', '3'));

        $code = self::$api->response_code();
        $body = self::$api->response_body();

        $this->assertEquals(200, $code);

        // delete non-existing attachment in an existing object
        self::$api->delete('attachments/' . kolab_api_tests::mapi_uid('Tasks', true, '10-10-10-10', '3'));

        $code = self::$api->response_code();
        $body = self::$api->response_body();

        $this->assertEquals(404, $code);
        $this->assertSame('', $body);

        // delete contact photo
        $id = kolab_api_filter_mapistore_contact::PHOTO_ATTACHMENT_ID;
        self::$api->delete('attachments/' . kolab_api_tests::mapi_uid('Contacts', true, 'a-b-c-d', $id));

        $code = self::$api->response_code();
        $body = self::$api->response_body();

        $this->assertEquals(200, $code);

        self::$api->get('contacts/' . kolab_api_tests::mapi_uid('Contacts', true, 'a-b-c-d'));

        $code = self::$api->response_code();
        $body = self::$api->response_body();
        $body = json_decode($body, true);

        $this->assertEquals(200, $code);
        $this->assertSame(kolab_api_tests::mapi_uid('Contacts', true, 'a-b-c-d'), $body['id']);
        $this->assertSame(null, $body['PidLidHasPicture']);

        // delete event-exception
        self::$api->delete('attachments/' . kolab_api_tests::mapi_uid('Calendar', true, '103-103-103-103', 20150629));

        $code = self::$api->response_code();
        $body = self::$api->response_body();

        $this->assertEquals(200, $code);

        self::$api->get('calendars/' . kolab_api_tests::mapi_uid('Calendar', true, '103-103-103-103') . '/attachments');

        $code = self::$api->response_code();
        $body = self::$api->response_body();
        $body = json_decode($body, true);

        $this->assertEquals(200, $code);
        $this->assertCount(1, $body);
    }
}
