<?php

/**
 * Test class to test notes API
 *
 * @package Tests
 */
class Mapistore_Notes extends PHPUnit_Framework_TestCase
{
    public static $api;

    /**
     * Setup
     */
    public static function setUpBeforeClass()
    {
        // start from the beginning...
        kolab_api_tests::reset_backend();

        self::$api = kolab_api_tests::get_request('json', '/mapistore');
    }

    /**
     * Test notes listing (folders API)
     */
    function test_listing()
    {
        self::$api->get('folders/' . kolab_api_tests::folder_uid('Notes') . '/messages');

        $code = self::$api->response_code();
        $body = self::$api->response_body();
        $body = json_decode($body, true);

        $this->assertEquals(200, $code);
        $this->assertSame(2, count($body));

        $this->assertSame(kolab_api_tests::mapi_uid('Notes', true, '1-1-1-1'), $body[0]['id']);
        $this->assertSame(kolab_api_tests::folder_uid('Notes'), $body[0]['parent_id']);
        $this->assertSame('test', $body[0]['PidTagSubject']);
        $this->assertSame('notes', $body[0]['collection']);
        $this->assertSame('IPM.StickyNote', $body[0]['PidTagMessageClass']);

        $this->assertSame(kolab_api_tests::mapi_uid('Notes', true, '2-2-2-2'), $body[1]['id']);
        $this->assertSame('wwww', $body[1]['PidTagSubject']);
        $this->assertSame('notes', $body[1]['collection']);
        $this->assertSame('IPM.StickyNote', $body[1]['PidTagMessageClass']);
    }

    /**
     * Test note existence
     */
    function test_note_exists()
    {
        self::$api->head('notes/' . kolab_api_tests::mapi_uid('Notes', true, '1-1-1-1'));

        $code = self::$api->response_code();
        $body = self::$api->response_body();

        $this->assertEquals(200, $code);
        $this->assertSame('', $body);

        // and non-existing note
        self::$api->get('notes/' . kolab_api_tests::mapi_uid('Notes', true, '12345'));

        $code = self::$api->response_code();
        $body = self::$api->response_body();

        $this->assertEquals(404, $code);
        $this->assertSame('', $body);
    }

    /**
     * Test note info
     */
    function test_note_info()
    {
        self::$api->get('notes/' . kolab_api_tests::mapi_uid('Notes', true, '1-1-1-1'));

        $code = self::$api->response_code();
        $body = self::$api->response_body();
        $body = json_decode($body, true);

        $this->assertEquals(200, $code);
        $this->assertSame(kolab_api_tests::mapi_uid('Notes', true, '1-1-1-1'), $body['id']);
        $this->assertSame(kolab_api_tests::folder_uid('Notes'), $body['parent_id']);
        $this->assertSame('test', $body['PidTagSubject']);
    }

    /**
     * Test note create
     */
    function test_note_create()
    {
        $post = json_encode(array(
            'parent_id'     => kolab_api_tests::folder_uid('Notes'),
            'PidTagSubject' => 'Test summary',
            'PidTagBody'    => 'Test description'
        ));
        self::$api->post('notes', array(), $post);

        $code = self::$api->response_code();
        $body = self::$api->response_body();
        $body = json_decode($body, true);

        $uid = $body['id'];

        $this->assertEquals(200, $code);
        $this->assertCount(1, $body);
        $this->assertTrue(!empty($uid));

        // folder does not exists
        $post = json_encode(array(
            'parent_id'     => md5('non-existing'),
            'PidTagSubject' => 'Test summary 2',
        ));
        self::$api->post('notes', array(), $post);

        $code = self::$api->response_code();
        $this->assertEquals(404, $code);

        // invalid object data
        $post = json_encode(array(
            'test' => 'Test summary 2',
        ));
        self::$api->post('notes', array(), $post);

        $code = self::$api->response_code();
        $this->assertEquals(422, $code);
    }

    /**
     * Test note update
     */
    function test_note_update()
    {
        $post = json_encode(array(
            'PidTagSubject'   => 'Modified summary',
            'PidTagBody'      => 'Modified description',
        ));
        self::$api->put('notes/' .  kolab_api_tests::mapi_uid('Notes', true, '1-1-1-1'), array(), $post);

        $code = self::$api->response_code();
        $body = self::$api->response_body();

        $this->assertEquals(200, $code);

        self::$api->get('notes/' . kolab_api_tests::mapi_uid('Notes', true, '1-1-1-1'));

        $body = self::$api->response_body();
        $body = json_decode($body, true);

        $this->assertSame('Modified summary', $body['PidTagSubject']);
        $this->assertSame('Modified description', $body['PidTagBody']);
    }

    /**
     * Test note delete
     */
    function test_note_delete()
    {
        // delete existing note
        self::$api->delete('notes/' . kolab_api_tests::mapi_uid('Notes', true, '1-1-1-1'));

        $code = self::$api->response_code();
        $body = self::$api->response_body();

        $this->assertEquals(204, $code);
        $this->assertSame('', $body);

        // and non-existing note
        self::$api->get('notes/' . kolab_api_tests::mapi_uid('Notes', true, '12345'));

        $code = self::$api->response_code();
        $body = self::$api->response_body();

        $this->assertEquals(404, $code);
        $this->assertSame('', $body);
    }

    /**
     * Test mail attachments count
     */
    function test_count_attachments()
    {
        // notes do not have attachments in MAPI
        self::$api->head('notes/' . kolab_api_tests::mapi_uid('Notes', true, '1-1-1-1') . '/attachments');

        $code = self::$api->response_code();

        $this->assertEquals(404, $code);
    }

    /**
     * Test listing mail attachments
     */
    function test_list_attachments()
    {
        // notes do not have attachments in MAPI
        self::$api->get('notes/' . kolab_api_tests::mapi_uid('Notes', true, '1-1-1-1') . '/attachments');

        $code = self::$api->response_code();

        $this->assertEquals(404, $code);
    }
}
