<?php

/**
 * Test class to test tasks API
 *
 * @package Tests
 */
class Mapistore_Tasks extends PHPUnit_Framework_TestCase
{
    public static $api;

    /**
     * Setup
     */
    public static function setUpBeforeClass()
    {
        // start from the beginning...
        kolab_api_tests::reset_backend();

        self::$api = kolab_api_tests::get_request('json', '/mapistore');
    }

    /**
     * Test tasks listing (folders API)
     */
    function test_listing()
    {
        // non-existing folder
        self::$api->get('folders/' . kolab_api_tests::folder_uid('Tasks') . '/objects');

        $code = self::$api->response_code();
        $body = self::$api->response_body();
        $body = json_decode($body, true);

        $this->assertEquals(200, $code);
        $this->assertSame(2, count($body));
        $this->assertSame(kolab_api_tests::mapi_uid('Tasks', true, '10-10-10-10'), $body[0]['id']);
        $this->assertSame(kolab_api_tests::folder_uid('Tasks'), $body[0]['parent_id']);
        $this->assertSame('IPM.Task', $body[0]['PidTagMessageClass']);
        $this->assertSame('tasks', $body[0]['collection']);
        $this->assertSame('task title', $body[0]['PidTagSubject']);

        $this->assertSame(kolab_api_tests::mapi_uid('Tasks', true, '20-20-20-20'), $body[1]['id']);
        $this->assertSame(kolab_api_tests::folder_uid('Tasks'), $body[1]['parent_id']);
        $this->assertSame('IPM.Task', $body[1]['PidTagMessageClass']);
        $this->assertSame('tasks', $body[1]['collection']);
        $this->assertSame('task', $body[1]['PidTagSubject']);
    }

    /**
     * Test task existence
     */
    function test_task_exists()
    {
        self::$api->head('tasks/' . kolab_api_tests::mapi_uid('Tasks', true, '10-10-10-10'));

        $code = self::$api->response_code();
        $body = self::$api->response_body();

        $this->assertEquals(200, $code);
        $this->assertSame('', $body);

        // and non-existing task
        self::$api->head('tasks/' . kolab_api_tests::mapi_uid('Tasks', true, '12345'));

        $code = self::$api->response_code();
        $body = self::$api->response_body();

        $this->assertEquals(404, $code);
        $this->assertSame('', $body);
    }

    /**
     * Test task info
     */
    function test_task_info()
    {
        self::$api->get('tasks/' . kolab_api_tests::mapi_uid('Tasks', true, '10-10-10-10'));

        $code = self::$api->response_code();
        $body = self::$api->response_body();
        $body = json_decode($body, true);

        $this->assertEquals(200, $code);
        $this->assertSame(kolab_api_tests::mapi_uid('Tasks', true, '10-10-10-10'), $body['id']);
        $this->assertSame('task title', $body['PidTagSubject']);
        $this->assertSame("task description\nsecond line", $body['PidTagBody']);
        $this->assertSame(true, $body['PidTagHasAttachments']);
    }

    /**
     * Test task create
     */
    function test_task_create()
    {
        $post = json_encode(array(
            'parent_id'     => kolab_api_tests::folder_uid('Tasks'),
            'PidTagSubject' => 'Test summary',
            'PidTagBody'    => 'Test description',
        ));
        self::$api->post('tasks', array(), $post);

        $code = self::$api->response_code();
        $body = self::$api->response_body();
        $body = json_decode($body, true);

        $this->assertEquals(200, $code);
        $this->assertCount(1, $body);
        $this->assertTrue(!empty($body['id']));

        // folder does not exists
        $post = json_encode(array(
            'parent_id'     => md5('non-existing'),
            'PidTagSubject' => 'Test summary 2',
        ));
        self::$api->post('tasks', array(), $post);

        $code = self::$api->response_code();
        $this->assertEquals(404, $code);

        // invalid object data
        $post = json_encode(array(
            'parent_id' => kolab_api_tests::folder_uid('Tasks'),
            'test'      => 'Test summary 2',
        ));
        self::$api->post('tasks', array(), $post);

        $code = self::$api->response_code();
        $this->assertEquals(422, $code);
    }

    /**
     * Test task update
     */
    function test_task_update()
    {
        $post = json_encode(array(
            'PidTagSubject' => 'Modified summary',
            'PidTagBody'    => 'Modified description'
        ));
        self::$api->put('tasks/' . kolab_api_tests::mapi_uid('Tasks', true, '10-10-10-10'), array(), $post);

        $code = self::$api->response_code();
        $body = self::$api->response_body();

        $this->assertEquals(200, $code);

        self::$api->get('tasks/' . kolab_api_tests::mapi_uid('Tasks', true, '10-10-10-10'));

        $body = self::$api->response_body();
        $body = json_decode($body, true);

        $this->assertSame('Modified summary', $body['PidTagSubject']);
        $this->assertSame('Modified description', $body['PidTagBody']);
    }


    /**
     * Test counting task attachments
     */
    function test_count_attachments()
    {
        // task with an attachment
        self::$api->head('tasks/' . kolab_api_tests::mapi_uid('Tasks', true,'10-10-10-10') . '/attachments');

        $code  = self::$api->response_code();
        $body  = self::$api->response_body();
        $count = self::$api->response_header('X-mapistore-rowcount');

        $this->assertEquals(200, $code);
        $this->assertSame('', $body);
        $this->assertSame(1, (int) $count);

        // task with no attachments
        self::$api->head('tasks/' . kolab_api_tests::mapi_uid('Tasks', true, '20-20-20-20') . '/attachments');

        $code  = self::$api->response_code();
        $body  = self::$api->response_body();
        $count = self::$api->response_header('X-mapistore-rowcount');

        $this->assertEquals(200, $code);
        $this->assertSame('', $body);
        $this->assertSame(0, (int) $count);
    }

    /**
     * Test listing task attachments
     */
    function test_list_attachments()
    {
        self::$api->get('tasks/' . kolab_api_tests::mapi_uid('Tasks', true, '10-10-10-10') . '/attachments');

        $code = self::$api->response_code();
        $body = self::$api->response_body();
        $body = json_decode($body, true);

        $this->assertEquals(200, $code);
        $this->assertCount(1, $body);
        $this->assertSame(kolab_api_tests::mapi_uid('Tasks', true, '10-10-10-10', 3), $body[0]['id']);
        $this->assertSame('text/plain', $body[0]['PidTagAttachMimeTag']);
        $this->assertSame('test.txt',   $body[0]['PidTagDisplayName']);
        $this->assertSame(4,            $body[0]['PidTagAttachSize']);

        // task with no attachments
        self::$api->get('tasks/' . kolab_api_tests::mapi_uid('Tasks', true, '20-20-20-20') . '/attachments');

        $code = self::$api->response_code();
        $body = self::$api->response_body();
        $body = json_decode($body, true);

        $this->assertEquals(200, $code);
        $this->assertCount(0, $body);
    }

    /**
     * Test task delete
     */
    function test_task_delete()
    {
        // delete existing task
        self::$api->delete('tasks/' . kolab_api_tests::mapi_uid('Tasks', true, '20-20-20-20'));

        $code = self::$api->response_code();
        $body = self::$api->response_body();

        $this->assertEquals(204, $code);
        $this->assertSame('', $body);

        // and non-existing task
        self::$api->delete('tasks/' . kolab_api_tests::mapi_uid('Tasks', true, '12345'));

        $code = self::$api->response_code();
        $body = self::$api->response_body();

        $this->assertEquals(404, $code);
        $this->assertSame('', $body);
    }
}
