<?php

/**
 * Test class to test events API
 *
 * @package Tests
 */
class Mapistore_Events extends PHPUnit_Framework_TestCase
{
    public static $api;

    /**
     * Setup
     */
    public static function setUpBeforeClass()
    {
        // start from the beginning...
        kolab_api_tests::reset_backend();

        self::$api = kolab_api_tests::get_request('json', '/mapistore');
    }

    /**
     * Test events listing (folders API)
     */
    function test_listing()
    {
        // non-existing folder
        self::$api->get('folders/' . kolab_api_tests::folder_uid('Calendar') . '/messages');

        $code = self::$api->response_code();
        $body = self::$api->response_body();
        $body = json_decode($body, true);

        $this->assertEquals(200, $code);
        $this->assertSame(kolab_api_tests::mapi_uid('Calendar', true, '100-100-100-100'), $body[0]['id']);
        $this->assertSame('Summary', $body[0]['PidTagSubject']);
        $this->assertSame('Description', $body[0]['PidTagBody']);
        $this->assertSame('calendars', $body[0]['collection']);
        $this->assertSame('IPM.Appointment', $body[0]['PidTagMessageClass']);

        $this->assertSame(kolab_api_tests::mapi_uid('Calendar', true, '101-101-101-101'), $body[1]['id']);
        $this->assertSame(0, $body[1]['PidTagSensitivity']);
        $this->assertSame('calendars', $body[1]['collection']);
        $this->assertSame('IPM.Appointment', $body[1]['PidTagMessageClass']);
    }

    /**
     * Test event existence
     */
    function test_event_exists()
    {
        self::$api->head('calendars/' . kolab_api_tests::mapi_uid('Calendar', true, '100-100-100-100'));

        $code = self::$api->response_code();
        $body = self::$api->response_body();

        $this->assertEquals(200, $code);
        $this->assertSame('', $body);

        // and non-existing event
        self::$api->head('calendars/' . kolab_api_tests::mapi_uid('Calendar', true, '12345'));

        $code = self::$api->response_code();
        $body = self::$api->response_body();

        $this->assertEquals(404, $code);
        $this->assertSame('', $body);
    }

    /**
     * Test event info
     */
    function test_event_info()
    {
        self::$api->get('calendars/' . kolab_api_tests::mapi_uid('Calendar', true, '100-100-100-100'));

        $code = self::$api->response_code();
        $body = self::$api->response_body();
        $body = json_decode($body, true);

        $this->assertEquals(200, $code);
        $this->assertSame(kolab_api_tests::mapi_uid('Calendar', true, '100-100-100-100'), $body['id']);
        $this->assertSame('Summary', $body['PidTagSubject']);
        $this->assertSame('calendars', $body['collection']);
        $this->assertSame('IPM.Appointment', $body['PidTagMessageClass']);
        $this->assertSame(true, $body['PidTagHasAttachments']);
    }

    /**
     * Test event create
     */
    function test_event_create()
    {
        $post = json_encode(array(
            'parent_id'     => kolab_api_tests::folder_uid('Calendar'),
            'PidTagSubject' => 'Test summary',
            'PidLidAppointmentStartWhole' => kolab_api_filter_mapistore_common::date_php2mapi('2015-01-01'),
        ));
        self::$api->post('calendars', array(), $post);

        $code = self::$api->response_code();
        $body = self::$api->response_body();
        $body = json_decode($body, true);

        $this->assertEquals(200, $code);
        $this->assertCount(1, $body);
        $this->assertTrue(!empty($body['id']));

        // folder does not exists
        $post = json_encode(array(
            'parent_id'     => md5('non-existing'),
            'PidTagSubject' => 'Test summary',
            'PidLidAppointmentStartWhole' => kolab_api_filter_mapistore_common::date_php2mapi('2015-01-01'),
        ));
        self::$api->post('calendars', array(), $post);

        $code = self::$api->response_code();
        $this->assertEquals(404, $code);

        // invalid object data
        $post = json_encode(array(
            'parent_id' => kolab_api_tests::folder_uid('Calendar'),
            'test'      => 'Test summary 2',
        ));
        self::$api->post('calendars', array(), $post);

        $code = self::$api->response_code();
        $this->assertEquals(422, $code);
    }

    /**
     * Test event update
     */
    function test_event_update()
    {
        // @TODO: test modification of all supported properties
        $post = json_encode(array(
            'PidTagSubject'               => 'Modified subject (1)',
            'PidLidAppointmentStartWhole' => kolab_api_filter_mapistore_common::date_php2mapi('2015-01-01'),
        ));

        self::$api->put('calendars/' . kolab_api_tests::mapi_uid('Calendar', true, '100-100-100-100'), array(), $post);

        $code = self::$api->response_code();
        $body = self::$api->response_body();

        $this->assertEquals(200, $code);

        self::$api->get('calendars/' . kolab_api_tests::mapi_uid('Calendar', true, '100-100-100-100'));

        $body = self::$api->response_body();
        $body = json_decode($body, true);

        $this->assertSame('Modified subject (1)', $body['PidTagSubject']);
    }

    /**
     * Test counting event attachments
     */
    function test_count_attachments()
    {
        self::$api->head('calendars/' . kolab_api_tests::mapi_uid('Calendar', true, '100-100-100-100') . '/attachments');

        $code  = self::$api->response_code();
        $body  = self::$api->response_body();
        $count = self::$api->response_header('X-mapistore-rowcount');

        $this->assertEquals(200, $code);
        $this->assertSame('', $body);
        $this->assertSame(1, (int) $count);

        self::$api->head('calendars/' . kolab_api_tests::mapi_uid('Calendar', true, '101-101-101-101') . '/attachments');

        $code  = self::$api->response_code();
        $body  = self::$api->response_body();
        $count = self::$api->response_header('X-mapistore-rowcount');

        $this->assertEquals(200, $code);
        $this->assertSame('', $body);
        $this->assertSame(0, (int) $count);

        // Count event-exception attachments
        self::$api->head('calendars/' . kolab_api_tests::mapi_uid('Calendar', true, '103-103-103-103') . '/attachments');

        $code  = self::$api->response_code();
        $body  = self::$api->response_body();
        $count = self::$api->response_header('X-mapistore-rowcount');

        $this->assertEquals(200, $code);
        $this->assertSame(2, (int) $count);
    }

    /**
     * Test listing event attachments
     */
    function test_list_attachments()
    {
        self::$api->get('calendars/' . kolab_api_tests::mapi_uid('Calendar', true, '100-100-100-100') . '/attachments');

        $code = self::$api->response_code();
        $body = self::$api->response_body();
        $body = json_decode($body, true);

        $this->assertEquals(200, $code);
        $this->assertCount(1, $body);
        $this->assertSame(kolab_api_tests::mapi_uid('Calendar', true, '100-100-100-100', '3'), $body[0]['id']);
        $this->assertSame('image/jpeg',     $body[0]['PidTagAttachMimeTag']);
        $this->assertSame('photo-mini.jpg', $body[0]['PidTagDisplayName']);
        $this->assertSame(793,              $body[0]['PidTagAttachSize']);

        // List event-exception attachments
        self::$api->get('calendars/' . kolab_api_tests::mapi_uid('Calendar', true, '103-103-103-103') . '/attachments');

        $code = self::$api->response_code();
        $body = self::$api->response_body();
        $body = json_decode($body, true);

        $this->assertEquals(200, $code);
        $this->assertCount(2, $body);

        $this->assertSame('attachments', $body[0]['collection']);
        $this->assertSame('Summary', $body[0]['PidTagDisplayName']);
        $this->assertSame(kolab_api_tests::mapi_uid('Calendar', true, '103-103-103-103', 20150622), $body[0]['id']);
        $this->assertSame(2, $body[0]['PidTagAttachmentFlags']);
        $this->assertSame(true, $body[0]['PidTagAttachmentHidden']);
        $this->assertSame(5, $body[0]['PidTagAttachMethod']);
        $this->assertSame(7, $body[0]['PidTagObjectType']);
        $this->assertSame(13079404800, $body[0]['PidTagExceptionStartTime']);
        $this->assertSame(13079491200, $body[0]['PidTagExceptionEndTime']);
        $this->assertSame('IPM.OLE.CLASS.{00061055-0000-0000-C000-000000000046}', $body[0]['PidTagAttachDataObject']['PidTagMessageClass']);
        $this->assertSame('Location mod', $body[0]['PidTagAttachDataObject']['PidLidLocation']);

        $this->assertSame('Summary', $body[1]['PidTagDisplayName']);
        $this->assertSame(kolab_api_tests::mapi_uid('Calendar', true, '103-103-103-103', 20150629), $body[1]['id']);
        $this->assertSame(2, $body[1]['PidTagAttachmentFlags']);
        $this->assertSame(true, $body[1]['PidTagAttachmentHidden']);
        $this->assertSame(13080009600, $body[1]['PidTagExceptionStartTime']);
        $this->assertSame(13080096000, $body[1]['PidTagExceptionEndTime']);
        $this->assertSame('IPM.OLE.CLASS.{00061055-0000-0000-C000-000000000046}', $body[1]['PidTagAttachDataObject']['PidTagMessageClass']);
        $this->assertSame(null, $body[1]['PidTagAttachDataObject']['PidLidLocation']);
    }

    /**
     * Test event delete
     */
    function test_event_delete()
    {
        // delete existing event
        self::$api->delete('calendars/' . kolab_api_tests::mapi_uid('Calendar', true, '101-101-101-101'));

        $code = self::$api->response_code();
        $body = self::$api->response_body();

        $this->assertEquals(204, $code);
        $this->assertSame('', $body);

        // and non-existing event
        self::$api->delete('calendars/' . kolab_api_tests::mapi_uid('Calendar', true, '12345'));

        $code = self::$api->response_code();
        $body = self::$api->response_body();

        $this->assertEquals(404, $code);
        $this->assertSame('', $body);
    }

    /**
     * Test event update with moving to another folder
     */
    function test_event_update_and_move()
    {
        // test event moving to another folder (by parent_id change)
        $post = json_encode(array(
            'PidTagSubject' => 'Modified subject (2)',
            'parent_id'     => kolab_api_tests::folder_uid('Calendar/Personal Calendar'),
        ));

        self::$api->put('calendars/' . kolab_api_tests::mapi_uid('Calendar', true, '100-100-100-100'), array(), $post);

        $code = self::$api->response_code();
        $body = self::$api->response_body();

        $this->assertEquals(200, $code);

        self::$api->get('calendars/' . kolab_api_tests::mapi_uid('Calendar/Personal Calendar', true, '100-100-100-100'));

        $body = self::$api->response_body();
        $body = json_decode($body, true);

        $this->assertSame('Modified subject (2)', $body['PidTagSubject']);
    }
}
