<?php

/**
 * Test class to test contacts API
 *
 * @package Tests
 */
class Mapistore_Contacts extends PHPUnit_Framework_TestCase
{
    public static $api;

    /**
     * Setup
     */
    public static function setUpBeforeClass()
    {
        // start from the beginning...
        kolab_api_tests::reset_backend();

        self::$api = kolab_api_tests::get_request('json', '/mapistore');
    }

    /**
     * Test contacts listing (folders API)
     */
    function test_listing()
    {
        // non-existing folder
        self::$api->get('folders/' . kolab_api_tests::folder_uid('Contacts') . '/messages');

        $code = self::$api->response_code();
        $body = self::$api->response_body();
        $body = json_decode($body, true);

        $this->assertEquals(200, $code);
        $this->assertSame(kolab_api_tests::mapi_uid('Contacts', true, 'a-b-c-d'), $body[0]['id']);
        $this->assertSame(kolab_api_tests::folder_uid('Contacts'), $body[0]['parent_id']);
        $this->assertSame('contacts', $body[0]['collection']);
        $this->assertSame('IPM.Contact', $body[0]['PidTagMessageClass']);
        $this->assertSame('displname', $body[0]['PidTagDisplayName']);
    }

    /**
     * Test contact existence
     */
    function test_contact_exists()
    {
        self::$api->head('contacts/' . kolab_api_tests::mapi_uid('Contacts', true, 'a-b-c-d'));

        $code = self::$api->response_code();
        $body = self::$api->response_body();

        $this->assertEquals(200, $code);
        $this->assertSame('', $body);

        // and non-existing contact
        self::$api->get('contacts/' . kolab_api_tests::mapi_uid('Contacts', true, '12345'));

        $code = self::$api->response_code();
        $body = self::$api->response_body();

        $this->assertEquals(404, $code);
        $this->assertSame('', $body);
    }

    /**
     * Test contact info
     */
    function test_contact_info()
    {
        self::$api->get('contacts/' . kolab_api_tests::mapi_uid('Contacts', true, 'a-b-c-d'));

        $code = self::$api->response_code();
        $body = self::$api->response_body();
        $body = json_decode($body, true);

        $this->assertEquals(200, $code);
        $this->assertSame(kolab_api_tests::mapi_uid('Contacts', true, 'a-b-c-d'), $body['id']);
        $this->assertSame(kolab_api_tests::folder_uid('Contacts'), $body['parent_id']);
        $this->assertSame('contacts', $body['collection']);
        $this->assertSame('IPM.Contact', $body['PidTagMessageClass']);
        $this->assertSame('displname', $body['PidTagDisplayName']);
        $this->assertSame(true, $body['PidLidHasPicture']);
    }

    /**
     * Test counting contact attachments
     */
    function test_count_attachments()
    {
        self::$api->head('contacts/' . kolab_api_tests::mapi_uid('Contacts', true, 'a-b-c-d') . '/attachments');

        $code  = self::$api->response_code();
        $body  = self::$api->response_body();
        $count = self::$api->response_header('X-mapistore-rowcount');

        $this->assertEquals(200, $code);
        $this->assertSame('', $body);
        $this->assertSame(1, (int) $count);
    }

    /**
     * Test listing contact attachments
     */
    function test_list_attachments()
    {
        self::$api->get('contacts/' . kolab_api_tests::mapi_uid('Contacts', true, 'a-b-c-d') . '/attachments');

        $code = self::$api->response_code();
        $body = self::$api->response_body();
        $body = json_decode($body, true);
        $id   = kolab_api_filter_mapistore_contact::PHOTO_ATTACHMENT_ID;

        $this->assertEquals(200, $code);
        $this->assertCount(1, $body);
        $this->assertSame(kolab_api_tests::mapi_uid('Contacts', true, 'a-b-c-d', $id), $body[0]['id']);
//        $this->assertSame('image/jpeg',     $body[0]['PidTagAttachMimeTag']);
        $this->assertSame('ContactPicture.jpg', $body[0]['PidTagDisplayName']);
        $this->assertSame('.jpg',               $body[0]['PidTagAttachExtension']);
        $this->assertSame(12797,                $body[0]['PidTagAttachSize']);
        $this->assertSame('/9j/4AAQ', substr($body[0]['PidTagAttachDataBinary'], 0, 8));
    }

    /**
     * Test contact create
     */
    function test_contact_create()
    {
        $post = json_encode(array(
            'parent_id'     => kolab_api_tests::folder_uid('Contacts'),
            'PidTagSurname' => 'lastname',
            'PidTagTitle'   => 'Test title',
        ));
        self::$api->post('contacts', array(), $post);

        $code = self::$api->response_code();
        $body = self::$api->response_body();
        $body = json_decode($body, true);

        $this->assertEquals(200, $code);
        $this->assertCount(1, $body);
        $this->assertTrue(!empty($body['id']));

        // folder does not exists
        $post = json_encode(array(
            'parent_id'     => kolab_api_tests::folder_uid('non-existing'),
            'PidTagSurname' => 'lastname',
            'PidTagTitle'   => 'Test title',
        ));
        self::$api->post('contacts', array(), $post);

        $code = self::$api->response_code();
        $this->assertEquals(404, $code);

        // invalid object data
        $post = json_encode(array(
            'parent_id' => kolab_api_tests::folder_uid('Contacts'),
            'test'      => 'Test summary 2',
        ));
        self::$api->post('contacts', array(), $post);

        $code = self::$api->response_code();
        $this->assertEquals(422, $code);
    }

    /**
     * Test contact update
     */
    function test_contact_update()
    {
        // @TODO: most of this should probably be in unit-tests not functional-tests
        $post = array(
            'PidTagTitle'    => 'Title',
            'PidTagNickname' => 'Nickname',
            'PidTagDisplayName'       => 'DisplayName',
            'PidTagSurname'           => 'Surname',
            'PidTagGivenName'         => 'GivenName',
            'PidTagMiddleName'        => 'MiddleName',
            'PidTagDisplayNamePrefix' => 'Prefix',
            'PidTagGeneration'        => 'Generation',
            'PidTagBody'              => 'Body',
            'PidLidFreeBusyLocation'  => 'FreeBusyLocation',
            'PidTagCompanyName'       => 'CompanyName',
            'PidTagDepartmentName'    => 'Department',
            'PidTagProfession'        => 'Profession',
            'PidTagManagerName'       => 'Manager',
            'PidTagAssistant'         => 'Assistant',
            'PidTagPersonalHomePage'  => 'HomePage',

            'PidTagOtherAddressStreet'          => 'OtherStreet',
            'PidTagOtherAddressCity'            => 'OtherCity',
            'PidTagOtherAddressStateOrProvince' => 'OtherState',
            'PidTagOtherAddressPostalCode'      => 'OtherCode',
            'PidTagOtherAddressCountry'         => 'OtherCountry',
//            'PidTagOtherAddressPostOfficeBox'   => 'OtherBox',
            'PidTagHomeAddressStreet'           => 'HomeStreet',
            'PidTagHomeAddressCity'             => 'HomeCity',
            'PidTagHomeAddressStateOrProvince'  => 'HomeState',
            'PidTagHomeAddressPostalCode'       => 'HomeCode',
            'PidTagHomeAddressCountry'          => 'HomeCountry',
//            'PidTagHomeAddressPostOfficeBox'    => 'HomeBox',
            'PidLidWorkAddressStreet'           => 'WorkStreet',
            'PidLidWorkAddressCity'             => 'WorkCity',
            'PidLidWorkAddressState'            => 'WorkState',
            'PidLidWorkAddressPostalCode'       => 'WorkCode',
            'PidLidWorkAddressCountry'          => 'WorkCountry',
//            'PidLidWorkAddressPostOfficeBox'    => 'WorkBox',

            'PidTagGender'          => 1,
            'PidTagSpouseName'      => 'Spouse',
            'PidTagChildrensNames'  => array('child'),

            'PidTagHomeTelephoneNumber'     => 'HomeNumber',
            'PidTagBusinessTelephoneNumber' => 'BusinessNumber',
            'PidTagHomeFaxNumber'           => 'HomeFax',
            'PidTagBusinessFaxNumber'       => 'BusinessFax',
            'PidTagMobileTelephoneNumber'   => 'Mobile',
            'PidTagPagerTelephoneNumber'    => 'Pager',
            'PidTagCarTelephoneNumber'      => 'Car',
            'PidTagOtherTelephoneNumber'    => 'OtherNumber',
            'PidLidInstantMessagingAddress' => 'IM',

            'PidLidEmail1EmailAddress'      => 'email1@domain.tld',
            'PidLidEmail2EmailAddress'      => 'email1@domain.tld',
            'PidLidEmail3EmailAddress'      => 'email1@domain.tld',
            'PidTagUserX509Certificate'     => base64_encode('Certificate'),
        );

        self::$api->put('contacts/' . kolab_api_tests::mapi_uid('Contacts', true, 'a-b-c-d'),
            array(), json_encode($post));

        $code = self::$api->response_code();
        $body = self::$api->response_body();

        $this->assertEquals(200, $code);

        self::$api->get('contacts/' . kolab_api_tests::mapi_uid('Contacts', true, 'a-b-c-d'));

        $body = self::$api->response_body();
        $body = json_decode($body, true);

        foreach ($post as $idx => $value) {
            $this->assertSame($value, $body[$idx], "Test for update of $idx");
        }
    }

    /**
     * Test contact delete
     */
    function test_contact_delete()
    {
        // delete existing contact
        self::$api->delete('contacts/' . kolab_api_tests::mapi_uid('Contacts', true, 'a-b-c-d'));

        $code = self::$api->response_code();
        $body = self::$api->response_body();

        $this->assertEquals(204, $code);
        $this->assertSame('', $body);

        // and non-existing contact
        self::$api->get('contacts/' . kolab_api_tests::mapi_uid('Contacts', true, '12345'));

        $code = self::$api->response_code();
        $body = self::$api->response_body();

        $this->assertEquals(404, $code);
        $this->assertSame('', $body);
    }
}
