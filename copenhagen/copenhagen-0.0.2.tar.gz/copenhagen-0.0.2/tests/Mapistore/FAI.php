<?php

/**
 * Test class to test FAI API
 *
 * @package Tests
 */
class Mapistore_FAI extends PHPUnit_Framework_TestCase
{
    public static $api;
    protected static $id;

    /**
     * Setup
     */
    public static function setUpBeforeClass()
    {
        // start from the beginning...
        kolab_api_tests::reset_backend();
        kolab_api_tests::reset_db();

        self::$api = kolab_api_tests::get_request('json', '/mapistore');
    }

    /**
     * Test object create
     */
    function test_object_create()
    {
        $post = json_encode(array(
            'SomeProperty' => 'SomeValue',
            'parent_id'    => 1,
        ));
        self::$api->post('fai', array(), $post);

        $code = self::$api->response_code();
        $body = self::$api->response_body();
        $body = json_decode($body, true);

        $this->assertEquals(200, $code);
        $this->assertNotEmpty($body['id']);

        self::$id = $body['id'];
/*
        // parent folder does not exists
        $post = json_encode(array(
            'SomeProperty' => 'Test',
            'parent_id'    => '123456789',
        ));
        self::$api->post('fai', array(), $post);

        $code = self::$api->response_code();
        $this->assertEquals(404, $code);
*/
    }

    /**
     * Test listing all FAI objects
     */
    function test_list_objects()
    {
        // get all objects
        self::$api->get('folders/1/fai');

        $code = self::$api->response_code();
        $body = self::$api->response_body();
        $body = json_decode($body, true);

        $this->assertEquals(200, $code);

        $this->assertTrue(count($body) == 1);
        $this->assertSame('1', $body[0]['parent_id']);
    }

    /**
     * Test listing all FAI objects
     */
    function test_count_objects()
    {
        // get all folders
        self::$api->head('folders/1/fai');

        $code  = self::$api->response_code();
        $body  = self::$api->response_body();
        $count = self::$api->response_header('X-mapistore-rowcount');

        $this->assertEquals(200, $code);
        $this->assertSame('', $body);
        $this->assertSame(1, (int) $count);
    }

    /**
     * Test listing FAI object attachments
     */
    function test_list_attachments()
    {
        // get all objects
        self::$api->get('fai/' . self::$id . '/attachments', array('properties' => 'id'));

        $code = self::$api->response_code();
        $body = self::$api->response_body();
        $body = json_decode($body, true);

        $this->assertEquals(200, $code);

        $this->assertTrue(is_array($body));
        $this->assertTrue(count($body) == 0);
    }

    /**
     * Test counting FAI object attachments
     */
    function test_count_attachments()
    {
        // get all objects
        self::$api->head('fai/' . self::$id . '/attachments');

        $code  = self::$api->response_code();
        $body  = self::$api->response_body();
        $count = self::$api->response_header('X-mapistore-rowcount');

        $this->assertEquals(200, $code);
        $this->assertSame('', $body);
        $this->assertSame(0, (int) $count);
    }

    /**
     * Test object existence
     */
    function test_object_exists()
    {
        self::$api->head('fai/' . self::$id);

        $code = self::$api->response_code();
        $body = self::$api->response_body();

        $this->assertEquals(200, $code);
        $this->assertSame('', $body);

        // and non-existing object
        self::$api->get('fai/abcde');

        $code = self::$api->response_code();
        $body = self::$api->response_body();

        $this->assertEquals(404, $code);
        $this->assertSame('', $body);
    }

    /**
     * Test folder update
     */
    function test_object_update()
    {
        $post = json_encode(array(
            'SomeOtherProp' => 'Test2',
        ));
        self::$api->put('fai/' . self::$id, array(), $post);

        $code = self::$api->response_code();
        $body = self::$api->response_body();

        $this->assertEquals(200, $code);
/*
        // change parent to an existing folder
        $post = json_encode(array(
            'parent_id' => kolab_api_tests::folder_uid('Trash'),
        ));
        self::$api->put('fai/' . self::$id, array(), $post);

        $code = self::$api->response_code();
        $this->assertEquals(200, $code);
*/
    }

    /**
     * Test FAI object info
     */
    function test_object_info()
    {
        self::$api->get('fai/' . self::$id);

        $code = self::$api->response_code();
        $body = self::$api->response_body();
        $body = json_decode($body, true);

        $this->assertEquals(200, $code);
//        $this->assertSame('SomeValue', $body['SomeProperty']);
        $this->assertSame('Test2', $body['SomeOtherProp']);
        $this->assertSame('1', $body['parent_id']);

        // non-existing object
        self::$api->get('fai/abcdse');

        $code = self::$api->response_code();
        $body = self::$api->response_body();
        $body = json_decode($body, true);

        $this->assertEquals(404, $code);
    }

    /**
     * Test object delete
     */
    function test_object_delete()
    {
        // delete existing object
        self::$api->delete('fai/' . self::$id);

        $code = self::$api->response_code();
        $body = self::$api->response_body();

        $this->assertEquals(204, $code);
        $this->assertSame('', $body);

        // and non-existing object
        self::$api->get('fai/abcde');

        $code = self::$api->response_code();
        $body = self::$api->response_body();

        $this->assertEquals(404, $code);
        $this->assertSame('', $body);
    }
}
