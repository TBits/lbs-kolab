<?php

/**
 * Test class to test folders API
 *
 * @package Tests
 */
class Mapistore_Folders extends PHPUnit_Framework_TestCase
{
    public static $api;
    public static $id;

    /**
     * Setup
     */
    public static function setUpBeforeClass()
    {
        // start from the beginning...
        kolab_api_tests::reset_backend();
        kolab_api_tests::reset_db();

        self::$api = kolab_api_tests::get_request('json', '/mapistore');
    }

    /**
     * Test listing all folders
     */
    function test_folder_list_folders()
    {
        // get all folders
        self::$api->get('folders/1/folders');

        $code = self::$api->response_code();
        $body = self::$api->response_body();
        $body = json_decode($body, true);

        $this->assertEquals(200, $code);
        $this->assertTrue(count($body) >= 12);
        $this->assertSame(kolab_api_tests::folder_uid('Calendar'), $body[0]['id']);
        $this->assertSame(kolab_api_tests::folder_uid('Calendar'), $body[1]['parent_id']);
        $this->assertSame(1, $body[0]['parent_id']);
        $this->assertSame('IPF.Appointment', $body[0]['PidTagContainerClass']);
        $this->assertSame('IPF.Appointment', $body[1]['PidTagContainerClass']);

        // test listing subfolders of specified folder
        self::$api->get('folders/' . kolab_api_tests::folder_uid('Calendar') . '/folders');

        $code = self::$api->response_code();
        $body = self::$api->response_body();
        $body = json_decode($body, true);

        $this->assertEquals(200, $code);
        $this->assertCount(1, $body);
        $this->assertSame(kolab_api_tests::folder_uid('Calendar'), $body[0]['parent_id']);

        // get all folders with properties filter
        self::$api->get('folders/1/folders', array('properties' => 'id'));

        $code = self::$api->response_code();
        $body = self::$api->response_body();
        $body = json_decode($body, true);

        $this->assertEquals(200, $code);
        $this->assertSame(array('id' => kolab_api_tests::folder_uid('Calendar')), $body[0]);

        // get non-ipm folders
        self::$api->get('folders/0/folders');

        $code = self::$api->response_code();
        $body = self::$api->response_body();
        $body = json_decode($body, true);

        $this->assertEquals(200, $code);
        $this->assertTrue(count($body) >= 7);
        $this->assertSame(0, $body[0]['parent_id']);
    }

    /**
     * Test folder delete
     */
    function test_folder_delete()
    {
        // delete existing folder
        self::$api->delete('folders/' . kolab_api_tests::folder_uid('Mail-Test'));

        $code = self::$api->response_code();
        $body = self::$api->response_body();

        $this->assertEquals(204, $code);
        $this->assertSame('', $body);

        // and non-existing folder
        self::$api->get('folders/12345');

        $code = self::$api->response_code();
        $body = self::$api->response_body();

        $this->assertEquals(404, $code);
        $this->assertSame('', $body);
    }

    /**
     * Test folder existence
     */
    function test_folder_exists()
    {
        self::$api->head('folders/' . kolab_api_tests::folder_uid('INBOX'));

        $code = self::$api->response_code();
        $body = self::$api->response_body();

        $this->assertEquals(200, $code);
        $this->assertSame('', $body);

        // and non-existing folder - deleted in test_folder_delete()
        self::$api->get('folders/' . kolab_api_tests::folder_uid('Mail-Test'));

        $code = self::$api->response_code();
        $body = self::$api->response_body();

        $this->assertEquals(404, $code);
        $this->assertSame('', $body);

        // special folder
        self::$api->head('folders/0');

        $code = self::$api->response_code();
        $body = self::$api->response_body();

        $this->assertEquals(200, $code);
        $this->assertSame('', $body);

    }

    /**
     * Test folder update
     */
    function test_folder_update()
    {
        // set folder property
        $post = json_encode(array(
            'CustomProperty' => 'aaa',
        ));
        self::$api->put('folders/' . kolab_api_tests::folder_uid('Calendar'), array(), $post);

        $code = self::$api->response_code();
        $body = self::$api->response_body();

        $this->assertEquals(200, $code);

        // rename a folder
        $post = json_encode(array(
            'PidTagDisplayName' => 'Mail-Test22',
        ));
        self::$api->put('folders/' . kolab_api_tests::folder_uid('Mail-Test2'), array(), $post);

        $code = self::$api->response_code();
        $body = self::$api->response_body();

        $this->assertEquals(200, $code);

        // move into an existing folder
        $post = json_encode(array(
            'PidTagDisplayName' => 'Trash',
        ));
        self::$api->put('folders/' . kolab_api_tests::folder_uid('Mail-Test22'), array(), $post);

        $code = self::$api->response_code();
        $this->assertEquals(500, $code);

        // change parent to an existing folder
        $post = json_encode(array(
            'parent_id' => kolab_api_tests::folder_uid('Trash'),
        ));
        self::$api->put('folders/' . kolab_api_tests::folder_uid('Mail-Test22'), array(), $post);

        $code = self::$api->response_code();
        $this->assertEquals(200, $code);
    }

    /**
     * Test folder create
     */
    function test_folder_create()
    {
        $post = json_encode(array(
            'PidTagDisplayName' => 'Test-create',
            'CustomProperty'    => 'bbb',
        ));
        self::$api->post('folders', array(), $post);

        $code = self::$api->response_code();
        $body = self::$api->response_body();
        $body = json_decode($body, true);

        $this->assertEquals(200, $code);
        $this->assertSame(kolab_api_tests::folder_uid('Test-create'), $body['id']);

        self::$id = $body['id'];

        // folder already exists
        $post = json_encode(array(
            'PidTagDisplayName' => 'Test-create',
        ));
        self::$api->post('folders', array(), $post);

        $code = self::$api->response_code();
        $this->assertEquals(500, $code);

        // create a subfolder
        $post = json_encode(array(
            'PidTagDisplayName' => 'Test',
            'parent_id'         => kolab_api_tests::folder_uid('Test-create'),
        ));
        self::$api->post('folders', array(), $post);

        $code = self::$api->response_code();
        $body = self::$api->response_body();
        $body = json_decode($body, true);

        $this->assertEquals(200, $code);
        $this->assertSame(kolab_api_tests::folder_uid('Test-create/Test'), $body['id']);

        // parent folder does not exists
        $post = json_encode(array(
            'PidTagDisplayName' => 'Test-create-2',
            'parent_id'         => '123456789',
        ));
        self::$api->post('folders', array(), $post);

        $code = self::$api->response_code();
        $this->assertEquals(404, $code);
    }

    /**
     * Test folder info
     */
    function test_folder_info()
    {
        self::$api->get('folders/' . kolab_api_tests::folder_uid('Calendar'));

        $code = self::$api->response_code();
        $body = self::$api->response_body();
        $body = json_decode($body, true);

        $this->assertEquals(200, $code);
        $this->assertSame('Calendar', $body['PidTagDisplayName']);
        $this->assertSame(kolab_api_tests::folder_uid('Calendar'), $body['id']);
        $this->assertSame(3, $body['PidTagContentCount']);
        $this->assertSame(3, $body['PidTagContentUnreadCount']);
        $this->assertSame(16102, $body['PidTagMessageSize']);
        $this->assertSame(true, $body['PidTagSubfolders']);
        $this->assertSame(0, $body['PidTagDeletedCountTotal']);
        $this->assertSame(true, $body['PidTagCreationTime'] > 0);
        $this->assertSame('aaa', $body['CustomProperty']);

        self::$api->get('folders/0');

        $code = self::$api->response_code();
        $body = self::$api->response_body();
        $body = json_decode($body, true);

        $this->assertEquals(200, $code);
        $this->assertSame('Root', $body['PidTagDisplayName']);
        $this->assertSame(0, $body['id']);
        $this->assertSame(0, $body['PidTagFolderType']);

        // check custom property on a created folder
        self::$api->get('folders/' . self::$id);

        $code = self::$api->response_code();
        $body = self::$api->response_body();
        $body = json_decode($body, true);

        $this->assertEquals(200, $code);
        $this->assertSame('bbb', $body['CustomProperty']);
        $this->assertSame(self::$id, $body['id']);
    }

    /**
     * Test listing folder content
     */
    function test_folder_list_objects()
    {
        self::$api->get('folders/' . kolab_api_tests::folder_uid('Calendar/Personal Calendar') . '/messages');

        $code = self::$api->response_code();
        $body = self::$api->response_body();
        $body = json_decode($body, true);

        $this->assertEquals(200, $code);
        $this->assertSame(array(), $body);

        // get all objects with properties filter
        self::$api->get('folders/' . kolab_api_tests::folder_uid('Notes') . '/messages', array('properties' => 'id,collection'));

        $code = self::$api->response_code();
        $body = self::$api->response_body();
        $body = json_decode($body, true);

        $this->assertEquals(200, $code);
        $this->assertCount(2, $body[0]);
        $this->assertTrue(!empty($body[0]['id']));
        $this->assertSame('notes', $body[0]['collection']);
    }

    /**
     * Test counting folder content
     */
    function test_folder_count_objects()
    {
        self::$api->head('folders/' . kolab_api_tests::folder_uid('INBOX') . '/messages');

        $code  = self::$api->response_code();
        $body  = self::$api->response_body();
        $count = self::$api->response_header('X-mapistore-rowcount');

        $this->assertEquals(200, $code);
        $this->assertSame('', $body);
        $this->assertSame(5, (int) $count);

        // folder emptied in test_folder_empty()
        self::$api->head('folders/' . kolab_api_tests::folder_uid('Trash') . '/mssages');

        $count = self::$api->response_header('X-mapistore-rowcount');
        $this->assertSame(0, (int) $count);

        // one item removed in test_folder_delete_objects()
        self::$api->head('folders/' . kolab_api_tests::folder_uid('Notes') . '/messages');

        $count = self::$api->response_header('X-mapistore-rowcount');
        $this->assertSame(2, (int) $count);
    }

    /**
     * Test folder create
     */
    function test_folder_delete_objects()
    {
        $post = json_encode(array(array('id' => '1-1-1-1')));
        self::$api->post('folders/' . kolab_api_tests::folder_uid('Notes') . '/deletemessages', array(), $post);

        $code = self::$api->response_code();
        $body = self::$api->response_body();

        $this->assertEquals(200, $code);
        $this->assertSame('', $body);
    }

    /**
     * Test folder empty
     */
    function test_folder_empty()
    {
        self::$api->post('folders/' . kolab_api_tests::folder_uid('Trash') . '/empty');

        $code = self::$api->response_code();
        $body = self::$api->response_body();

        $this->assertEquals(200, $code);
        $this->assertSame('', $body);
    }
}
