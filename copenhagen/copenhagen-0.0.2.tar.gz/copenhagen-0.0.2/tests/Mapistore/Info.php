<?php

/**
 * Test class to test info API
 *
 * @package Tests
 */
class Mapistore_Info extends PHPUnit_Framework_TestCase
{
    public static $api;

    /**
     * Setup
     */
    public static function setUpBeforeClass()
    {
        // start from the beginning...
        kolab_api_tests::reset_backend();

        self::$api = kolab_api_tests::get_request('json', '/mapistore');
    }

    /**
     * Test notes listing (folders API)
     */
    function test_info()
    {
        // non-existing folder
        self::$api->get('info');

        $code = self::$api->response_code();
        $body = self::$api->response_body();
        $body = json_decode($body, true);

        $this->assertEquals(200, $code);
        $this->assertSame(kolab_api::APP_NAME, $body['name']);
        $this->assertSame(kolab_api::VERSION, $body['version']);
        $this->assertTrue(count($body['contexts']) >= 5);
        $this->assertSame('INBOX', $body['contexts'][0]['name']);
        $this->assertSame(0, $body['contexts'][0]['role']);
        $this->assertSame(true, $body['contexts'][0]['main_folder']);
        $this->assertTrue(!empty($body['contexts'][0]['system_idx']));
        $this->assertSame('/folders/'.$body['contexts'][0]['system_idx'].'/', $body['contexts'][0]['url']);
    }

    /**
     * Test non-existing request
     */
    function test_nonexisting()
    {
        self::$api->post('info');

        $code = self::$api->response_code();

        $this->assertEquals(404, $code);
    }
}
