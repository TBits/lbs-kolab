<?php

/**
 * Test class to test mails API
 *
 * @package Tests
 */
class Mapistore_Mails extends PHPUnit_Framework_TestCase
{
    public static $api;

    /**
     * Setup
     */
    public static function setUpBeforeClass()
    {
        // start from the beginning...
        kolab_api_tests::reset_backend();

        self::$api = kolab_api_tests::get_request('json', '/mapistore');
    }

    /**
     * Test mails listing (folders API)
     */
    function test_listing()
    {
        // non-existing folder
        self::$api->get('folders/' . kolab_api_tests::folder_uid('INBOX') . '/messages');

        $code = self::$api->response_code();
        $body = self::$api->response_body();
        $body = json_decode($body, true);

        $this->assertEquals(200, $code);
        $this->assertSame(5, count($body));
        $this->assertSame(kolab_api_tests::mapi_uid('INBOX', true, '1'), $body[0]['id']);
        $this->assertSame(kolab_api_tests::folder_uid('INBOX'), $body[0]['parent_id']);
        $this->assertSame('mails', $body[0]['collection']);
        $this->assertSame('IPM.Note', $body[0]['PidTagMessageClass']);
        $this->assertSame('"test" wurde aktualisiert', $body[0]['PidTagSubject']);

        $this->assertSame(kolab_api_tests::mapi_uid('INBOX', true, '2'), $body[1]['id']);
        $this->assertSame(kolab_api_tests::folder_uid('INBOX'), $body[1]['parent_id']);
        $this->assertSame('IPM.Note', $body[1]['PidTagMessageClass']);
        $this->assertSame('Re: dsda', $body[1]['PidTagSubject']);

        // get all messages with properties filter
        self::$api->get('folders/' . kolab_api_tests::folder_uid('INBOX') . '/messages', array('properties' => 'id'));

        $code = self::$api->response_code();
        $body = self::$api->response_body();
        $body = json_decode($body, true);

        $this->assertEquals(200, $code);
        $this->assertSame(array('id' => kolab_api_tests::mapi_uid('INBOX', true, '1')), $body[0]);
    }

    /**
     * Test mail existence check
     */
    function test_mail_exists()
    {
        self::$api->head('mails/' . kolab_api_tests::mapi_uid('INBOX', true, '1'));

        $code = self::$api->response_code();
        $body = self::$api->response_body();

        $this->assertEquals(200, $code);
        $this->assertSame('', $body);

        // and non-existing note
        self::$api->get('mails/' . kolab_api_tests::mapi_uid('INBOX', true, '12345'));

        $code = self::$api->response_code();
        $body = self::$api->response_body();

        $this->assertEquals(404, $code);
        $this->assertSame('', $body);
    }

    /**
     * Test mail info
     */
    function test_mail_info()
    {
        self::$api->get('mails/' . kolab_api_tests::mapi_uid('INBOX', true, '1'));

        $code = self::$api->response_code();
        $body = self::$api->response_body();
        $body = json_decode($body, true);

        $this->assertEquals(200, $code);
        $this->assertSame(kolab_api_tests::mapi_uid('INBOX', true, '1'), $body['id']);
        $this->assertSame(kolab_api_tests::folder_uid('INBOX'), $body['parent_id']);
        $this->assertSame('"test" wurde aktualisiert', $body['PidTagSubject']);
        $this->assertSame(624, $body['PidTagMessageSize']);
        $this->assertSame('IPM.Note', $body['PidTagMessageClass']);
    }

    /**
     * Test mail attachments count
     */
    function test_count_attachments()
    {
        self::$api->head('mails/' . kolab_api_tests::mapi_uid('INBOX', true,  '2') . '/attachments');

        $code  = self::$api->response_code();
        $body  = self::$api->response_body();
        $count = self::$api->response_header('X-mapistore-rowcount');

        $this->assertEquals(200, $code);
        $this->assertSame('', $body);
        $this->assertSame(0, (int) $count);

        self::$api->head('mails/' . kolab_api_tests::mapi_uid('INBOX', true, '6') . '/attachments');

        $code  = self::$api->response_code();
        $body  = self::$api->response_body();
        $count = self::$api->response_header('X-mapistore-rowcount');

        $this->assertEquals(200, $code);
        $this->assertSame('', $body);
        $this->assertSame(2, (int) $count);
    }

    /**
     * Test listing mail attachments
     */
    function test_list_attachments()
    {
        self::$api->get('mails/' . kolab_api_tests::mapi_uid('INBOX', true, '2') . '/attachments');

        $code = self::$api->response_code();
        $body = self::$api->response_body();
        $body = json_decode($body, true);

        $this->assertEquals(200, $code);
        $this->assertSame(array(), $body);

        self::$api->get('mails/' . kolab_api_tests::mapi_uid('INBOX', true, '6') . '/attachments');

        $code = self::$api->response_code();
        $body = self::$api->response_body();
        $body = json_decode($body, true);

        $this->assertEquals(200, $code);
        $this->assertCount(2, $body);

        $this->assertSame(kolab_api_tests::mapi_uid('INBOX', true, '6', '2'), $body[0]['id']);
        $this->assertSame('attachments', $body[0]['collection']);
        $this->assertSame('text/plain', $body[0]['PidTagAttachMimeTag']);
        $this->assertSame('test.txt',   $body[0]['PidTagDisplayName']);
        $this->assertSame('.txt',       $body[0]['PidTagAttachExtension']);
        $this->assertSame(4,            $body[0]['PidTagAttachSize']);
    }

    /**
     * Test mail create
     */
    function test_mail_create()
    {
        $post = json_encode(array(
            'PidTagSubject' => 'Test summary',
            'PidTagBody'    => 'Test description'
        ));
        self::$api->post('mails/' . kolab_api_tests::folder_uid('INBOX'), array(), $post);

        $code = self::$api->response_code();
        $body = self::$api->response_body();
        $body = json_decode($body, true);

        $this->assertEquals(200, $code);
        $this->assertCount(1, $body);
        $this->assertTrue(!empty($body['id']));

        // folder does not exist
        $post = json_encode(array(
            'PidTagSubject' => 'Test summary 2',
        ));
        self::$api->post('mails/' . md5('non-existing'), array(), $post);

        $code = self::$api->response_code();
        $this->assertEquals(404, $code);

        // invalid object data
        $post = json_encode(array(
            'test' => 'Test summary 2',
        ));
        self::$api->post('mails/' . kolab_api_tests::folder_uid('INBOX'), array(), $post);

        $code = self::$api->response_code();
        $this->assertEquals(422, $code);
    }

    /**
     * Test mail update
     */
    function test_mail_update()
    {
        $post = json_encode(array(
            'PidTagSubject' => 'Modified summary',
            'PidTagBody'    => 'Modified description'
        ));
        self::$api->put('mails/' . kolab_api_tests::mapi_uid('INBOX', true, '2'), array(), $post);

        $code = self::$api->response_code();
        $body = self::$api->response_body();
        $body = json_decode($body, true);

        $this->assertEquals(200, $code);
        $this->assertTrue(!empty($body['id']));

        self::$api->get('mails/' . $body['id']);

        $body = self::$api->response_body();
        $body = json_decode($body, true);

        $this->assertSame('Modified summary', $body['PidTagSubject']);
        $this->assertSame('Modified description', $body['PidTagBody']);
    }

    /**
     * Test mail submit
     */
    function test_mail_submit()
    {
        // send the message to self
        $post = json_encode(array(
            'PidTagSubject' => 'Test summary',
            'PidTagBody'    => 'This is the body.',
/*
            'from'    => array(
                'name'    => "Test' user",
                'address' => self::$api->username,
            ),
*/
            'recipients' => array(
                array(
                    'PidTagRecipientType' => 1,
                    'PidTagDisplayName'   => "Test user",
                    'PidTagSmtpAddress'   => self::$api->username,
                ),
            ),
        ));

        self::$api->post('mails/submit', array(), $post);

        $code = self::$api->response_code();

        $this->assertEquals(204, $code);
    }

    /**
     * Test mail delete
     */
    function test_mail_delete()
    {
        // delete existing note
        self::$api->delete('mails/' . kolab_api_tests::mapi_uid('INBOX', true, '1'));

        $code = self::$api->response_code();
        $body = self::$api->response_body();

        $this->assertEquals(204, $code);
        $this->assertSame('', $body);

        // and non-existing note
        self::$api->get('mails/' . kolab_api_tests::mapi_uid('INBOX', true, '12345'));

        $code = self::$api->response_code();
        $body = self::$api->response_body();

        $this->assertEquals(404, $code);
        $this->assertSame('', $body);
    }
}
