<?php

/**
 +--------------------------------------------------------------------------+
 | This file is part of the Kolab REST API                                  |
 |                                                                          |
 | Copyright (C) 2012-2015, Kolab Systems AG                                |
 |                                                                          |
 | This program is free software: you can redistribute it and/or modify     |
 | it under the terms of the GNU Affero General Public License as published |
 | by the Free Software Foundation, either version 3 of the License, or     |
 | (at your option) any later version.                                      |
 |                                                                          |
 | This program is distributed in the hope that it will be useful,          |
 | but WITHOUT ANY WARRANTY; without even the implied warranty of           |
 | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the             |
 | GNU Affero General Public License for more details.                      |
 |                                                                          |
 | You should have received a copy of the GNU Affero General Public License |
 | along with this program. If not, see <http://www.gnu.org/licenses/>      |
 +--------------------------------------------------------------------------+
 | Author: Aleksander Machniak <machniak@kolabsys.com>                      |
 +--------------------------------------------------------------------------+
*/

class kolab_api_request
{
    public $username;
    public $token_header = 'X-Session-Token';

    private $request;
    private $base_url;


    /**
     * Class initialization
     */
    public function __construct($base_url, $user, $pass)
    {
        require_once 'HTTP/Request2.php';

        $this->base_url = $base_url;
        $this->request  = new HTTP_Request2();
        $this->username = $user;

        $this->request->setConfig(array(
            'ssl_verify_peer' => false,
            'ssl_verify_host' => false,
        ));

        $this->request->setAuth($user, $pass);
    }

    /**
     * Set request header
     */
    public function set_header($name, $value)
    {
        $this->request->setHeader($name, $value);
    }

    /**
     * API's GET request.
     *
     * @param string URL
     * @param array  URL arguments
     *
     * @return HTTP_Request2_Response Response object
     */
    public function get($url, $args = array())
    {
        $url = $this->build_url($url, $args);

        $this->reset();
        $this->request->setMethod(HTTP_Request2::METHOD_GET);

        return $this->get_response($url);
    }

    /**
     * API's HEAD request.
     *
     * @param string URL
     * @param array  URL arguments
     *
     * @return HTTP_Request2_Response Response object
     */
    public function head($url, $args = array())
    {
        $url = $this->build_url($url, $args);

        $this->reset();
        $this->request->setMethod(HTTP_Request2::METHOD_HEAD);

        return $this->get_response($url);
    }

    /**
     * API's DELETE request.
     *
     * @param string URL
     * @param array  URL arguments
     *
     * @return HTTP_Request2_Response Response object
     */
    public function delete($url, $args = array())
    {
        $url = $this->build_url($url, $args);

        $this->reset();
        $this->request->setMethod(HTTP_Request2::METHOD_DELETE);

        return $this->get_response($url);
    }

    /**
     * API's POST request.
     *
     * @param string URL
     * @param array  URL arguments
     * @param string POST body
     * @param string Request Content-Type (for file uploads testing)
     *
     * @return HTTP_Request2_Response Response object
     */
    public function post($url, $url_args = array(), $post = '', $ctype = '')
    {
        $url = $this->build_url($url, $url_args);

        $this->reset();
        $this->request->setMethod(HTTP_Request2::METHOD_POST);
        $this->request->setBody($post);

        if ($ctype) {
            $this->request->setHeader('Content-Type', $ctype);
        }

        return $this->get_response($url);
    }

    /**
     * API's PUT request.
     *
     * @param string URL
     * @param array  URL arguments
     * @param string PUT body
     *
     * @return HTTP_Request2_Response Response object
     */
    public function put($url, $url_args = array(), $post = '')
    {
        $url = $this->build_url($url, $url_args);

        $this->reset();
        $this->request->setMethod(HTTP_Request2::METHOD_PUT);
        $this->request->setBody($post);

        return $this->get_response($url);
    }

    public function response_code()
    {
        return $this->response->getStatus();
    }

    public function response_header($name)
    {
        return $this->response->getHeader($name);
    }

    public function response_body()
    {
        return $this->response->getBody();
    }

    /**
     * @param string Action URL
     * @param array  GET parameters (hash array: name => value)
     *
     * @return Net_URL2 URL object
     */
    private function build_url($action, $args)
    {
        $url = $this->base_url;

        if ($action) {
            $url .= '/' . $action;
        }

        $url = new Net_URL2($url);

        if (!empty($args)) {
            $url->setQueryVariables($args);
        }

        return $url;
    }

    /**
     * Reset old request data
     */
    private function reset()
    {
        // reset old body
        $this->request->setBody('');

        unset($this->response);
    }

    /**
     * HTTP Response handler.
     *
     * @param Net_URL2 URL object
     *
     * @return HTTP_Request2_Response Response object
     */
    private function get_response($url)
    {
        $this->request->setUrl($url);

        if ($this->session_token) {
            $this->request->setHeader($this->token_header, $this->session_token);
        }

        $this->response = $this->request->send();

        if ($token = $this->response->getHeader($this->token_header)) {
            $this->session_token = $token;
        }

        return $this->response;
    }
}
