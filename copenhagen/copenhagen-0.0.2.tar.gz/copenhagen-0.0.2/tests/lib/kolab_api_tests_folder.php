<?php

/**
 +--------------------------------------------------------------------------+
 | This file is part of the Kolab REST API                                  |
 |                                                                          |
 | Copyright (C) 2012-2015, Kolab Systems AG                                |
 |                                                                          |
 | This program is free software: you can redistribute it and/or modify     |
 | it under the terms of the GNU Affero General Public License as published |
 | by the Free Software Foundation, either version 3 of the License, or     |
 | (at your option) any later version.                                      |
 |                                                                          |
 | This program is distributed in the hope that it will be useful,          |
 | but WITHOUT ANY WARRANTY; without even the implied warranty of           |
 | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the             |
 | GNU Affero General Public License for more details.                      |
 |                                                                          |
 | You should have received a copy of the GNU Affero General Public License |
 | along with this program. If not, see <http://www.gnu.org/licenses/>      |
 +--------------------------------------------------------------------------+
 | Author: Aleksander Machniak <machniak@kolabsys.com>                      |
 +--------------------------------------------------------------------------+
*/

/**
 * Mock class emulating kolab_api_folder for tests
 */
class kolab_api_tests_folder extends kolab_api_folder
{
    /**
     * Properties getter
     *
     * @param string $name Property name
     *
     * @param mixed Property value
     */
    public function __get($name)
    {
        if (array_key_exists($name, $this->data)) {
            return $this->data[$name];
        }

        switch ($name) {
            case 'exists':
            case 'unseen':
            case 'highestmodseq':
            case 'uidvalidity':
                // get IMAP folder data
                $api  = kolab_api::get_instance();
                $data = $api->backend->storage->folder_data($folder);
                $data = array_change_key_case((array) $data);

                $this->data = array_merge($data, $this->data);

                return $this->data[$name];
        }

        return parent::__get($name);
    }

    /**
     * Deletes folder
     *
     * @throws kolab_api_exception
     */
    public function delete()
    {
        $api = kolab_api_backend::get_instance();
        $api->folder_delete($this->_fullpath);
    }

    /**
     * Renames a folder
     *
     * @param string $old_name Folder name (UTF-8)
     * @param string $new_name New folder name (UTF-8)
     *
     * @throws kolab_api_exception
     */
    protected function folder_rename($old_name, $new_name)
    {
        $api = kolab_api_backend::get_instance();
        $api->folder_rename($old_name, $new_name);
    }

    /**
     * Creates a folder
     *
     * @param string $name      Folder name (UTF-8)
     * @param string $type      Folder type
     * @param bool   $subscribe Subscription flag
     *
     * @throws kolab_api_exception
     */
    protected function folder_create($name, $type, $subscribe)
    {
        $api = kolab_api_backend::get_instance();
        $uid = $api->folder_create($name);

        $api->folder_update($name, array(
                'type'       => $type,
                'subscribed' => $subscribe
        ));

        return $uid;
    }

    /**
     * Change folder subscription
     *
     * @param string $name      Folder name (UTF-8)
     * @param bool   $subscribe Subscription flag
     *
     * @throws kolab_api_exception
     */
    protected function folder_subscribe($name, $subscribe)
    {
        $api = kolab_api_backend::get_instance();
        $api->folder_update($name, array('subscribed' => $subscribe));
    }

    /**
     * Change folder type
     *
     * @param string $name Folder name (UTF-8)
     * @param string $type Folder type
     *
     * @throws kolab_api_exception
     */
    protected function folder_set_type($name, $type)
    {
        $api = kolab_api_backend::get_instance();
        $api->folder_update($name, array('type' => $type));
    }

    /**
     * Returns number of subfolders in the current folder
     */
    protected function children()
    {
        return 0; // @TODO

        if ($this->_fullpath !== null) {
            $api    = kolab_api::get_instance();
            $folder = rcube_charset::convert($this->_fullpath, RCUBE_CHARSET, 'UTF7-IMAP');
            $list   = $api->backend->storage->list_folders($folder, '%', null, null, true);

            $this->data['children'] = count($list);
        }

        return $this->data['children'];
    }
}
