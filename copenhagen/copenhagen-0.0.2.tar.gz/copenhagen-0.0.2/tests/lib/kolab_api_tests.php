<?php

/**
 +--------------------------------------------------------------------------+
 | Kolab REST API - Tests                                                   |
 |                                                                          |
 | Copyright (C) 2011-2015, Kolab Systems AG <contact@kolabsys.com>         |
 |                                                                          |
 | This program is free software: you can redistribute it and/or modify     |
 | it under the terms of the GNU Affero General Public License as published |
 | by the Free Software Foundation, either version 3 of the License, or     |
 | (at your option) any later version.                                      |
 |                                                                          |
 | This program is distributed in the hope that it will be useful,          |
 | but WITHOUT ANY WARRANTY; without even the implied warranty of           |
 | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the             |
 | GNU Affero General Public License for more details.                      |
 |                                                                          |
 | You should have received a copy of the GNU Affero General Public License |
 | along with this program. If not, see <http://www.gnu.org/licenses/>      |
 +--------------------------------------------------------------------------+
 | Author: Aleksander Machniak <machniak@kolabsys.com>                      |
 +--------------------------------------------------------------------------+
*/

class kolab_api_tests
{
    static $items_map;
    static $folders_map;
    static $db;

    /**
     * Reset backend state
     */
    public static function reset_backend()
    {
        $rcube    = rcube::get_instance();
        $temp_dir = $rcube->config->get('temp_dir');
        $filename = $temp_dir . '/tests.db';

        if (file_exists($filename)) {
            unlink($filename);
        }

        $username = $rcube->config->get('tests_username');
        $password = $rcube->config->get('tests_password');

        if (!$username) {
            return;
        }

        $authenticated = self::login($username, $password);

        if (!$authenticated) {
            throw new Exception("IMAP login failed for user $username");
        }

        // get all existing folders
        $imap           = $rcube->get_storage();
        $old_folders    = $imap->list_folders('', '*');
        $old_subscribed = $imap->list_folders_subscribed('', '*');

        // get configured folders
        $json = file_get_contents(__DIR__ . '/../data/data.json');
        $data = json_decode($json, true);

        $items = array();
        $uids  = array();

        // initialize/update content in existing folders
        // create configured folders if they do not exists
        foreach ($data['folders'] as $folder_name => $folder) {
            if (($idx = array_search($folder_name, $old_folders)) !== false) {
                // cleanup messages in the folder
                $imap->delete_message('*', $folder_name);

                unset($old_folders[$idx]);

                // make sure it's subscribed
                if (!in_array($folder_name, $old_subscribed)) {
                    $imap->subscribe($folder_name);
                }
            }
            else {
                // create the folder
                $imap->create_folder($folder_name, true);
            }

            // set folder type
            kolab_storage::set_folder_type($folder_name, $folder['type']);

            list($type, ) = explode('.', $folder['type']);

            // append messages
            foreach ((array) $folder['items'] as $uid) {
                $file = file_get_contents(__DIR__ . "/../data/$type/$uid");

                // replace member message references
                if ($uid == '99-99-99-99') {
                    $repl = urlencode($username) . '/INBOX/' . $items[1];
                    $file = str_replace('mark.german%40example.org/INBOX/1', $repl, $file);
                }

                $res = $imap->save_message($folder_name, $file);

                if (is_numeric($uid)) {
                    $items[$uid] = $res;
                }
            }
        }

        // remove extra folders
        $deleted = array();
        foreach ($old_folders as $folder) {
            // ...but only personal
            if ($imap->folder_namespace($folder) == 'personal') {
                $path = explode('/', $folder);
                while (array_pop($path) !== null) {
                    if (in_array(implode('/', $path), $deleted)) {
                        $deleted[] = $folder;
                        continue 2;
                    }
                }

                if (!$imap->delete_folder($folder)) {
                    throw new Exception("Failed removing '$folder'");
                }

                $deleted[] = $folder;
            }
            else {
            }
        }

        // get folder UIDs map
        $uid_keys = array(kolab_storage::UID_KEY_CYRUS);

        // get folder identifiers
        $metadata = $imap->get_metadata('*', $uid_keys);

        if (!is_array($metadata)) {
            throw new Exception("Failed to get folders metadata");
        }

        foreach ($metadata as $folder => $meta) {
            $uids[$folder] = $meta[kolab_storage::UID_KEY_CYRUS];
        }

        self::$items_map   = $items;
        self::$folders_map = $uids;
    }

    /**
     * Initialize testing environment
     */
    public static function init()
    {
        $rcube = rcube::get_instance();

        // If tests_username is set we use real Kolab server
        // otherwise use dummy backend class which emulates a real server
        if (!$rcube->config->get('tests_username')) {
            // Load backend wrappers for tests
            // @TODO: maybe we could replace kolab_storage and rcube_imap instead?
            require_once __DIR__ . '/kolab_api_backend.php';

            // Message wrapper for unit tests
            require_once __DIR__ . '/kolab_api_tests_mail.php';

            // Folder wrapper for unit tests
            require_once __DIR__ . '/kolab_api_tests_folder.php';
        }

        // extend include path with kolab_format/kolab_storage classes
        $include_path = __DIR__ . '/../../lib/ext/plugins/libkolab/lib' . PATH_SEPARATOR . ini_get('include_path');
        set_include_path($include_path);

        require_once __DIR__ . '/../../lib/ext/plugins/libcalendaring/libcalendaring.php';

        // load HTTP_Request2 wrapper for functional/integration tests
        require_once __DIR__ . '/kolab_api_request.php';
    }

    /**
     * Initializes kolab_api_request object
     *
     * @param string Accepted response type (xml|json)
     *
     * @return kolab_api_request Request object
     */
    public static function get_request($type, $suffix = '')
    {
        $rcube    = rcube::get_instance();
        $base_uri = $rcube->config->get('tests_uri', 'http://localhost/copenhagen-tests');
        $username = $rcube->config->get('tests_username', 'test@example.org');
        $password = $rcube->config->get('tests_password', 'test@example.org');

        if ($suffix) {
            $base_uri .= $suffix;
        }

        $request = new kolab_api_request($base_uri, $username, $password);

        // set expected response type
        $request->set_header('Accept', $type == 'xml' ? 'application/xml' : 'application/json');

        return $request;
    }

    /**
     * Get data object
     */
    public static function get_data($uid, $folder_name, $type, $format = '', &$context = null)
    {
        require_once __DIR__ . '/kolab_api_tests_mail.php';

        $file       = file_get_contents(__DIR__ . "/../data/$type/$uid");
        $folder_uid = self::folder_uid($folder_name, false);

        // get message content and parse it
        $file   = str_replace("\r?\n", "\r\n", $file);
        $params = array('uid' => $uid, 'folder' => $folder_uid);
        $object = new kolab_api_tests_mail($file, $params);

        if (empty(self::$db)) {
            $json     = file_get_contents(__DIR__ . '/../data/data.json');
            self::$db = json_decode($json, true);
        }

        // get assigned tag-relations
        $tags = array();
        foreach (self::$db['tags'] as $tag_name => $tag) {
            if (in_array($uid, (array) $tag['members'])) {
                $tags[] = $tag_name;
            }
        }

        if ($type != 'mail') {
            $object = $object->to_array($type);
            $object['categories'] = $tags;
        }
        else {
            $object = new kolab_api_tests_mail($object);
            $object->set_categories($tags);
        }

        $context = array(
            'object'     => $object,
            'folder_uid' => $folder_uid,
            'object_uid' => $uid,
        );

        if ($format) {
            $model  = self::get_output_class($format, $type);
            $object = $model->element($object);
        }

        return $object;
    }

    public static function get_output_class($format, $type)
    {
        // fake GET request to have proper API class in kolab_api::get_instance
        $_GET['request'] = "{$type}s";
        $output          = "kolab_api_output_{$format}";
        $class           = "{$output}_{$type}";
        $output          = new $output(kolab_api::get_instance());
        $model           = new $class($output);

        return $model;
    }

    /**
     * Get folder UID by name
     */
    public static function folder_uid($name, $api_test = true)
    {
        if ($api_test && !empty(self::$folders_map)) {
            if (self::$folders_map[$name]) {
                return self::$folders_map[$name];
            }

            // it maybe is a newly created folder? check the metadata again
            $rcube    = rcube::get_instance();
            $imap     = $rcube->get_storage();
            $uid_keys = array(kolab_storage::UID_KEY_CYRUS);
            $metadata = $imap->get_metadata($name, $uid_keys);

            if ($uid = $metadata[$name][kolab_storage::UID_KEY_CYRUS]) {
                return self::$folders_map[$name] = $uid;
            }
        }

        return md5($name);
    }

    /**
     * Get message UID
     */
    public static function msg_uid($uid, $api_test = true)
    {
        if ($uid && $api_test && !empty(self::$items_map)) {
            if (self::$items_map[$uid]) {
                return self::$items_map[$uid];
            }
        }

        return $uid;
    }

    /**
     * Build MAPI object identifier
     */
    public static function mapi_uid($folder_name, $api_test, $msg_uid, $attachment_uid = null)
    {
        $folder_uid = self::folder_uid($folder_name, $api_test);
        $msg_uid    = self::msg_uid($msg_uid, $api_test);

        return kolab_api_filter_mapistore::uid_encode($folder_uid, $msg_uid, $attachment_uid);
    }

    protected static function login($username, $password)
    {
        $rcube        = rcube::get_instance();
        $login_lc     = $rcube->config->get('login_lc');
        $host         = $rcube->config->get('default_host');
        $default_port = $rcube->config->get('default_port', 143);

        $rcube->storage = null;
        $storage        = $rcube->get_storage();

        // parse $host
        $a_host = parse_url($host);
        if ($a_host['host']) {
            $host = $a_host['host'];
            $ssl = (isset($a_host['scheme']) && in_array($a_host['scheme'], array('ssl','imaps','tls'))) ? $a_host['scheme'] : null;
            if (!empty($a_host['port'])) {
                $port = $a_host['port'];
            }
            else if ($ssl && $ssl != 'tls' && (!$default_port || $default_port == 143)) {
                $port = 993;
            }
        }

        if (!$port) {
            $port = $default_port;
        }

        // Convert username to lowercase. If storage backend
        // is case-insensitive we need to store always the same username
        if ($login_lc) {
            if ($login_lc == 2 || $login_lc === true) {
                $username = mb_strtolower($username);
            }
            else if (strpos($username, '@')) {
                // lowercase domain name
                list($local, $domain) = explode('@', $username);
                $username = $local . '@' . mb_strtolower($domain);
            }
        }

        // Here we need IDNA ASCII
        // Only rcube_contacts class is using domain names in Unicode
        $host     = rcube_utils::idn_to_ascii($host);
        $username = rcube_utils::idn_to_ascii($username);

        // user already registered?
        if ($user = rcube_user::query($username, $host)) {
            $username = $user->data['username'];
        }

        // authenticate user in IMAP
        if (!$storage->connect($host, $username, $password, $port, $ssl)) {
            throw new Exception("Unable to connect to IMAP");
        }

        // No user in database, but IMAP auth works
        if (!is_object($user)) {
            if ($rcube->config->get('auto_create_user')) {
                // create a new user record
                $user = rcube_user::create($username, $host);

                if (!$user) {
                    throw new Exception("Failed to create a user record");
                }
            }
            else {
                throw new Exception("Access denied for new user $username. 'auto_create_user' is disabled");
            }
        }

        // overwrite config with user preferences
        $rcube->user = $user;
        $rcube->config->set_user_prefs((array)$user->get_prefs());
/*
        $_SESSION['user_id']      = $user->ID;
        $_SESSION['username']     = $user->data['username'];
        $_SESSION['storage_host'] = $host;
        $_SESSION['storage_port'] = $port;
        $_SESSION['storage_ssl']  = $ssl;
        $_SESSION['password']     = $rcube->encrypt($password);
        $_SESSION['login_time']   = time();
*/
        setlocale(LC_ALL, 'en_US.utf8', 'en_US.UTF-8');

        // clear the cache
        $storage->clear_cache('mailboxes', true);

        // to clear correctly the cache index in testing environments
        // (where we call self::reset_backend() many times in one go)
        // we need to also close() the cache
        if ($ctype = $rcube->config->get('imap_cache')) {
            $cache = $rcube->get_cache('IMAP', $ctype, $rcube->config->get('imap_cache_ttl', '10d'));
            $cache->close();
        }

        self::reset_db();

        return true;
    }

    public static function reset_db()
    {
        $rcube = rcube::get_instance();
        $db    = $rcube->get_dbh();

        // clear libkolab cache
        $db->query('DELETE FROM ' . $db->table_name('kolab_folders', true));

        // clean FAI database
        $db->query('DELETE FROM ' . $db->table_name('copenhagen_fai', true));

        // folders metadata database
        $db->query('DELETE FROM ' . $db->table_name('copenhagen_folderdata', true));
    }
}
