<?php

/**
 +--------------------------------------------------------------------------+
 | This file is part of the Kolab REST API                                  |
 |                                                                          |
 | Copyright (C) 2012-2015, Kolab Systems AG                                |
 |                                                                          |
 | This program is free software: you can redistribute it and/or modify     |
 | it under the terms of the GNU Affero General Public License as published |
 | by the Free Software Foundation, either version 3 of the License, or     |
 | (at your option) any later version.                                      |
 |                                                                          |
 | This program is distributed in the hope that it will be useful,          |
 | but WITHOUT ANY WARRANTY; without even the implied warranty of           |
 | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the             |
 | GNU Affero General Public License for more details.                      |
 |                                                                          |
 | You should have received a copy of the GNU Affero General Public License |
 | along with this program. If not, see <http://www.gnu.org/licenses/>      |
 +--------------------------------------------------------------------------+
 | Author: Aleksander Machniak <machniak@kolabsys.com>                      |
 +--------------------------------------------------------------------------+
*/

class kolab_api_backend
{
    /**
     * Singleton instace of kolab_api_backend
     *
     * @var kolab_api_backend
     */
    static protected $instance;

    public $delimiter = '/';
    public $username = 'user@example.org';
    public $storage;
    public $user;
    public $db = array();

    protected $folder = array();
    protected $data   = array();


    /**
     * This implements the 'singleton' design pattern
     *
     * @return kolab_api_backend The one and only instance
     */
    static function get_instance()
    {
        if (!self::$instance) {
            self::$instance = new kolab_api_backend;
            self::$instance->startup();  // init AFTER object was linked with self::$instance
        }

        return self::$instance;
    }

    /**
     * Class initialization
     */
    public function startup()
    {
        $api     = kolab_api::get_instance();
        $db_file = $api->config->get('temp_dir') . '/tests.db';

        if (file_exists($db_file)) {
            $db       = file_get_contents($db_file);
            $this->db = unserialize($db);
        }

        $json = file_get_contents(__DIR__ . '/../data/data.json');

        $this->data    = json_decode($json, true);
        $this->folders = $this->parse_folders_list($this->data['folders']);

        if (!array_key_exists('tags', $this->db)) {
            $this->db['tags'] = $this->data['tags'];
        }

        $this->user    = new kolab_api_user;
        $this->storage = $this;
    }

    /**
     * Authenticate a user
     *
     * @param string Username
     * @param string Password
     *
     * @return bool
     */
    public function authenticate($username, $password)
    {
        return true;
    }

    /**
     * Get list of folders
     *
     * @param string $type Folder type
     *
     * @return array|bool List of folders (kolab_api_folder), False on backend failure
     */
    public function folders_list($type = null)
    {
        $folders = array_values($this->folders);
        $folders = array_map(function($v) { return new kolab_api_tests_folder($v); }, $folders);

        return $folders;
    }

    /**
     * Returns folder type
     *
     * @param string $uid         Folder unique identifier
     * @param string $with_suffix Enable to not remove the subtype
     *
     * @return string Folder type
     */
    public function folder_type($uid, $with_suffix = false)
    {
        $folder = $this->folders[$uid];

        if (!$folder) {
            throw new kolab_api_exception(kolab_api_exception::NOT_FOUND);
        }

        $type = $folder['type'] ?: 'mail';

        if (!$with_suffix) {
            list($type, ) = explode('.', $type);
        }

        return $type;
    }

    /**
     * Folder info
     *
     * @param string $uid Folder UID
     *
     * @return kolab_api_folder Folder information
     * @throws kolab_api_exception
     */
    public function folder_info($uid)
    {
        $folder = $this->folders[$uid];

        if (!$folder) {
            throw new kolab_api_exception(kolab_api_exception::NOT_FOUND);
        }

        // some info is not very interesting here ;)
        unset($folder['items']);

        return new kolab_api_tests_folder($folder);
    }

    /**
     * Returns objects in a folder
     *
     * @param string $uid Folder unique identifier
     *
     * @return array Objects (of type kolab_api_mail or array)
     * @throws kolab_api_exception
     */
    public function objects_list($uid)
    {
        $folder = $this->folders[$uid];

        if (!$folder) {
            throw new kolab_api_exception(kolab_api_exception::NOT_FOUND);
        }

        $result  = array();
        $is_mail = empty($folder['type']) || preg_match('/^mail/', $folder['type']);

        foreach ((array) $folder['items'] as $id) {
            $object = $this->object_get($uid, $id);

            if ($is_mail) {
                $object = new kolab_api_tests_mail($object->headers, array('is_header' => true));
            }

            $result[] = $object;
        }

        return $result;
    }

    /**
     * Counts objects in a folder
     *
     * @param string $uid Folder unique identifier
     *
     * @return int Objects count
     * @throws kolab_api_exception
     */
    public function objects_count($uid)
    {
        $folder = $this->folders[$uid];

        if (!$folder) {
            throw new kolab_api_exception(kolab_api_exception::NOT_FOUND);
        }

        return count($folder['items']);
    }

    /**
     * Delete objects in a folder
     *
     * @param string       $uid Folder unique identifier
     * @param string|array $set List of object IDs or "*" for all
     *
     * @throws kolab_api_exception
     */
    public function objects_delete($uid, $set)
    {
        $folder = $this->folders[$uid];

        if (!$folder) {
            throw new kolab_api_exception(kolab_api_exception::NOT_FOUND);
        }

        if ($set === '*') {
            foreach ((array) $this->folders[$uid]['items'] as $i) {
                unset($this->db['messages'][$i]);
            }
            $this->folders[$uid]['items'] = array();
            $this->db['items'][$uid]      = array();
        }
        else {
            $this->folders[$uid]['items'] = array_values(array_diff($this->folders[$uid]['items'], $set));
            foreach ($set as $i) {
                unset($this->db['items'][$uid][$i]);
                unset($this->db['messages'][$i]);
            }
        }

        $this->db['folders'][$uid]['items'] = $this->folders[$uid]['items'];

        $this->save_db();
    }

    /**
     * Move objects into another folder
     *
     * @param string       $uid        Folder unique identifier
     * @param string       $target_uid Target folder unique identifier
     * @param string|array $set List of object IDs or "*" for all
     *
     * @throws kolab_api_exception
     */
    public function objects_move($uid, $target_uid, $set)
    {
        $folder = $this->folders[$uid];

        if (!$folder) {
            throw new kolab_api_exception(kolab_api_exception::NOT_FOUND);
        }

        $target = $this->folders[$target_uid];

        if (!$target) {
            throw new kolab_api_exception(kolab_api_exception::NOT_FOUND);
        }

        if ($set === "*") {
            $set = $this->folders[$uid]['items'];
        }

        // @TODO: we should check if all objects from the set exist

        $diff = array_values(array_diff($this->folders[$uid]['items'], $set));
        $this->folders[$uid]['items']       = $diff;
        $this->db['folders'][$uid]['items'] = $diff;

        $diff = array_values(array_merge((array) $this->folders[$target_uid]['items'], $set));
        $this->folders[$target_uid]['items']       = $diff;
        $this->db['folders'][$target_uid]['items'] = $diff;

        foreach ($set as $i) {
            if ($this->db['items'][$uid][$i]) {
                $this->db['items'][$target_uid][$i] = $this->db['items'][$uid][$i];
                unset($this->db['items'][$uid][$i]);
            }
        }

        $this->save_db();
    }

    /**
     * Get object data
     *
     * @param string $folder_uid Folder unique identifier
     * @param string $uid        Object identifier
     *
     * @return kolab_api_mail|array Object data
     * @throws kolab_api_exception
     */
    public function object_get($folder_uid, $uid)
    {
        $folder = $this->folders[$folder_uid];

        if (!$folder) {
            throw new kolab_api_exception(kolab_api_exception::NOT_FOUND);
        }

        if (!in_array($uid, (array) $folder['items'])) {
            throw new kolab_api_exception(kolab_api_exception::NOT_FOUND);
        }

        if ($data = $this->db['items'][$folder_uid][$uid]) {
            return $data;
        }

        list($type,) = explode('.', $folder['type']);

        $file = $this->get_file_content($uid, $type);

        if (empty($file)) {
            throw new kolab_api_exception(kolab_api_exception::SERVER_ERROR);
        }

        // get message content and parse it
        $file   = str_replace("\r?\n", "\r\n", $file);
        $params = array('uid' => $uid, 'folder' => $folder_uid);
        $object = new kolab_api_tests_mail($file, $params);

        // get assigned tag-relations
        $tags = array();
        foreach ($this->db['tags'] as $tag_name => $tag) {
            if (in_array($uid, (array) $tag['members'])) {
                $tags[] = $tag_name;
            }
        }

        if ($type != 'mail') {
            $object = $object->to_array($type);
            $object['categories'] = array_unique(array_merge($tags, (array) $object['categories']));
        }
        else {
            $object = new kolab_api_tests_mail($object);
            $object->set_categories($tags);
        }

        return $object;
    }

    /**
     * Create an object
     *
     * @param string $folder_uid Folder unique identifier
     * @param string $data       Object data
     * @param string $type       Object type
     *
     * @throws kolab_api_exception
     */
    public function object_create($folder_uid, $data, $type)
    {
        $folder = $this->folders[$folder_uid];

        if (!$folder) {
            throw new kolab_api_exception(kolab_api_exception::NOT_FOUND);
        }
/*
        if (strpos($folder['type'], $type) !== 0) {
            throw new kolab_api_exception(kolab_api_exception::INVALID_REQUEST);
        }
*/
        $uid = str_replace('.', '', microtime(true));

        if (is_array($data)) {
            $categories  = $data['categories'];
            $data['uid'] = $uid;
            $this->db['items'][$folder_uid][$uid] = $data;
        }
        else {
            $categories = $data->categories;
            $uid = $data->save($folder['fullpath']);
        }

        if (!empty($categories)) {
            foreach ($categories as $cat) {
                if (!$this->db['tags'][$cat]) {
                    $this->db['tags'][$cat] = array();
                }

                if (!in_array($uid, (array) $this->db['tags'][$cat]['members'])) {
                    $this->db['tags'][$cat]['members'][] = $uid;
                }
            }
        }

        $this->folders[$folder_uid]['items'][]     = $uid;
        $this->db['folders'][$folder_uid]['items'] = $this->folders[$folder_uid]['items'];
        $this->save_db();

        return $uid;
    }

    /**
     * Update an object
     *
     * @param string $folder_uid Folder unique identifier
     * @param string $data       Object data
     * @param string $type       Object type
     *
     * @throws kolab_api_exception
     */
    public function object_update($folder_uid, $data, $type)
    {
        $folder = $this->folders[$folder_uid];

        if (!$folder) {
            throw new kolab_api_exception(kolab_api_exception::NOT_FOUND);
        }
/*
        if (strpos($folder['type'], $type) !== 0) {
            throw new kolab_api_exception(kolab_api_exception::INVALID_REQUEST);
        }
*/
        // kolab object
        if (is_array($data)) {
            $uid        = $data['uid'];
            $categories = $data['categories'];

            // remove _formatobj which is problematic in serialize/unserialize
            unset($data['_formatobj']);

            $this->db['items'][$folder_uid][$uid] = $data;
        }
        // email message
        else {
            $old_uid    = $data->uid;
            $categories = $data->categories;
            $uid        = $data->save($folder['fullpath']);

            $this->folders[$folder_uid]['items'][]     = $uid;
            $this->db['folders'][$folder_uid]['items'] = $this->folders[$folder_uid]['items'];
        }

        // remove old tag assignments
        foreach ($this->db['tags'] as $tag_name => $tag) {
            if (($idx = array_search($old_uid ?: $uid, (array) $this->db['tags'][$tag_name]['members'])) !== false) {
                unset($this->db['tags'][$tag_name]['members'][$idx]);
            }
        }

        // assign new tags
        foreach ((array) $categories as $tag) {
            if (!$this->db['tags'][$tag]) {
                $this->db['tags'][$tag] = array();
            }

            $this->db['tags'][$tag]['members'][] = $uid;
        }

        $this->save_db();

        return $uid;
    }

    /**
     * Get attachment body
     *
     * @param mixed  $object  Object data (from self::object_get())
     * @param string $part_id Attachment part identifier
     * @param mixed  $mode    NULL to return a string, -1 to print body
     *                        or file pointer to save the body into
     *
     * @return string Attachment body if $mode=null
     * @throws kolab_api_exception
     */
    public function attachment_get($object, $part_id, $mode = null)
    {
        $msg_uid = is_array($object) ? $object['uid'] : $object->uid;

        // object is a mail message
        if (!($object instanceof kolab_api_tests_mail)) {
            $object = $object['_message'];
        }

        $body = $object->get_part_body($part_id);

        if (!$mode) {
            return $body;
        }
        else if ($mode === -1) {
            echo $body;
        }
    }

    /**
     * Delete an attachment from the message
     *
     * @param mixed  $object Object data (from self::object_get())
     * @param string $id     Attachment identifier
     *
     * @return string Message/object UID
     * @throws kolab_api_exception
     */
    public function attachment_delete($object, $id)
    {
        $msg_uid = is_array($object) ? $object['uid'] : $object->uid;
        $key     = $msg_uid . ":" . $part_id;

        // object is a mail message
        if (!($object instanceof kolab_api_tests_mail)) {
            $object = $object['_message'];
        }

        if ($object->get_part_body($id) === null) {
            throw new kolab_api_exception(kolab_api_exception::NOT_FOUND);
        }

        $uid = $object->attachment_delete($id);

        // change UID only for mail messages
        if (!is_numeric($msg_uid)) {
            $this->db['messages'][$msg_uid] = $this->db['messages'][$uid];
            unset($this->db['messages'][$uid]);
            $this->save_db();
            $uid = $msg_uid;
        }

        if ($msg_uid != $uid) {
            $folder_uid = $object->folder;
            $this->folders[$folder_uid]['items'][] = $uid;
            $this->db['folders'][$folder_uid]['items'] = $this->folders[$folder_uid]['items'];
            $this->save_db();
        }

        return $uid;
    }

    /**
     * Create an attachment and add to a message/object
     *
     * @param mixed              $object     Object data (from self::object_get())
     * @param rcube_message_part $attachment Attachment data
     *
     * @return string Message/object UID
     * @throws kolab_api_exception
     */
    public function attachment_create($object, $attachment)
    {
        $msg_uid = is_array($object) ? $object['uid'] : $object->uid;

        // object is a mail message
        if (!($object instanceof kolab_api_tests_mail)) {
            $object = $object['_message'];
        }

        $uid        = $object->attachment_add($attachment);
        $folder_uid = $object->folder;

        // change UID only for mail messages
        if (!is_numeric($msg_uid)) {
            $this->db['messages'][$msg_uid] = $this->db['messages'][$uid];
            unset($this->db['messages'][$uid]);

            $params = array('uid' => $msg_uid, 'folder' => $folder_uid);
            $object = new kolab_api_tests_mail(base64_decode($this->db['messages'][$msg_uid]), $params);
            $object = $object->to_array($this->folders[$folder_uid]['type']);
//            $object['categories'] = $tags;
            unset($object['_formatobj']);
            $this->db['items'][$folder_uid][$msg_uid] = $object;

            $this->save_db();
            $uid = $msg_uid;
        }

        if ($msg_uid != $uid) {
            $this->folders[$folder_uid]['items'][] = $uid;
            $this->db['folders'][$folder_uid]['items'] = $this->folders[$folder_uid]['items'];
            $this->save_db();
        }

        return $uid;
    }

    /**
     * Update an attachment in a message/object
     *
     * @param mixed              $object     Object data (from self::object_get())
     * @param rcube_message_part $attachment Attachment data
     *
     * @return string Message/object UID
     * @throws kolab_api_exception
     */
    public function attachment_update($object, $attachment)
    {
        $msg_uid = is_array($object) ? $object['uid'] : $object->uid;

        // object is a mail message
        if (!($object instanceof kolab_api_tests_mail)) {
            $object = $object['_message'];
        }

        $uid        = $object->attachment_update($attachment);
        $folder_uid = $object->folder;

        // change UID only for mail messages
        if (!is_numeric($msg_uid)) {
            $this->db['messages'][$msg_uid] = $this->db['messages'][$uid];
            unset($this->db['messages'][$uid]);

            $params = array('uid' => $msg_uid, 'folder' => $folder_uid);
            $object = new kolab_api_tests_mail(base64_decode($this->db['messages'][$msg_uid]), $params);
            $object = $object->to_array($this->folders[$folder_uid]['type']);
//            $object['categories'] = $tags;
            unset($object['_formatobj']);
            $this->db['items'][$folder_uid][$msg_uid] = $object;

            $this->save_db();
            $uid = $msg_uid;
        }

        if ($msg_uid != $uid) {
            $this->folders[$folder_uid]['items'][] = $uid;
            $this->db['folders'][$folder_uid]['items'] = $this->folders[$folder_uid]['items'];
            $this->save_db();
        }

        return $uid;
    }

    /**
     * Creates a folder
     *
     * @param string $name Folder name (UTF-8)
     *
     * @return bool Folder identifier on success
     */
    public function folder_create($folder)
    {
        $path = explode($this->delimiter, $folder);
        $name = array_pop($path);

        if (count($path)) {
            $parent        = kolab_api_tests::folder_uid(implode($path, $this->delimiter), true);
            $parent_folder = $this->folders[$parent];

            if (!$parent_folder) {
                throw new kolab_api_exception(kolab_api_exception::NOT_FOUND);
            }
        }

        $uid = kolab_api_tests::folder_uid($folder, true);

        // check if folder exists
        if ($this->folders[$uid]) {
            throw new kolab_api_exception(kolab_api_exception::SERVER_ERROR);
        }

        $this->folders[$uid] = array(
            'name'     => $name,
            'fullpath' => $folder,
            'parent'   => $parent,
            'uid'      => $uid,
            'type'     => $type ? $type : 'mail',
        );

        $this->db['folders'][$uid] = $this->folders[$uid];
        $this->save_db();

        return $uid;
    }

    /**
     * Updates a folder
     *
     * @param string $folder  Folder name
     * @param array  $updates Updates (array with keys type, subscribed, active)
     *
     * @throws kolab_api_exception
     */
    public function folder_update($folder, $updates)
    {
        $uid    = kolab_api_tests::folder_uid($folder, true);
        $folder = $this->folders[$uid];

        if (!$folder) {
            throw new kolab_api_exception(kolab_api_exception::NOT_FOUND);
        }

        foreach ($updates as $idx => $value) {
            $this->db['folders'][$uid][$idx] = $value;
            $this->folders[$uid][$idx]       = $value;
        }

        $this->save_db();
    }

    /**
     * Renames/moves a folder
     *
     * @param string $old_name Folder name (UTF8)
     * @param string $new_name New folder name (UTF8)
     *
     * @throws kolab_api_exception
     */
    public function folder_rename($old_name, $new_name)
    {
        $old_uid = kolab_api_tests::folder_uid($old_name, true);
        $new_uid = kolab_api_tests::folder_uid($new_name, true);
        $folder  = $this->folders[$old_uid];

        if (!$folder) {
            throw new kolab_api_exception(kolab_api_exception::NOT_FOUND);
        }

        if ($this->folders[$new_uid]) {
            throw new kolab_api_exception(kolab_api_exception::SERVER_ERROR);
        }

        $path = explode($this->delimiter, $new_name);
        $folder['fullpath'] = $new_name;
        $folder['name']     = array_pop($path);

        unset($this->folders[$old_uid]);
        $this->folders[$new_uid] = $folder;
        $this->db['folders'][$new_uid] = $folder;
        $this->db['deleted'][] = $old_uid;
        $this->save_db();
    }

    /**
     * Deletes folder
     *
     * @param string $folder Folder name
     *
     * @return bool True on success, False on failure
     * @throws kolab_api_exception
     */
    public function folder_delete($folder)
    {
        $uid    = kolab_api_tests::folder_uid($folder, true);
        $folder = $this->folders[$uid];

        if (!$folder) {
            throw new kolab_api_exception(kolab_api_exception::NOT_FOUND);
        }

        unset($this->folders[$uid]);
        $this->db['deleted'][] = $uid;
        $this->save_db();
    }

    /**
     * Returns IMAP folder name with full path
     *
     * @param string $uid Folder identifier
     *
     * @return string Folder full path (UTF-8)
     */
    public function folder_uid2path($uid)
    {
        if ($uid === null || $uid === '') {
            throw new kolab_api_exception(kolab_api_exception::SERVER_ERROR);
        }

        $folder = $this->folders[$uid];

        if (!$folder) {
            throw new kolab_api_exception(kolab_api_exception::NOT_FOUND);
        }

        return $folder['fullpath'];
    }

    /**
     * Parse folders list into API format
     */
    protected function parse_folders_list($list)
    {
        $folders = array();

        foreach ($list as $path => $folder) {
            $uid = kolab_api_tests::folder_uid($path, false);

            if (!empty($this->db['deleted']) && in_array($uid, $this->db['deleted'])) {
                continue;
            }

            if (strpos($path, $this->delimiter)) {
                $list      = explode($this->delimiter, $path);
                $name      = array_pop($list);
                $parent    = implode($this->delimiter, $list);
                $parent_id = kolab_api_tests::folder_uid($parent, false);
            }
            else {
                $parent_id = null;
                $name      = $path;
            }

            $data = array(
                'name'     => $name,
                'fullpath' => $path,
                'parent'   => $parent_id,
                'uid'      => $uid,
            );

            if (!empty($this->db['folders']) && !empty($this->db['folders'][$uid])) {
                $data = array_merge($data, $this->db['folders'][$uid]);
            }

            $folders[$uid] = array_merge($folder, $data);
        }

        foreach ((array) $this->db['folders'] as $uid => $folder) {
            if (!$folders[$uid]) {
                $folders[$uid] = $folder;
            }
        }

        // sort folders
        uasort($folders, array($this, 'sort_folder_comparator'));

        return $folders;
    }

    /**
     * Callback for uasort() that implements correct
     * locale-aware case-sensitive sorting
     */
    protected function sort_folder_comparator($str1, $str2)
    {
        $path1 = explode($this->delimiter, $str1['fullpath']);
        $path2 = explode($this->delimiter, $str2['fullpath']);

        foreach ($path1 as $idx => $folder1) {
            $folder2 = $path2[$idx];

            if ($folder1 === $folder2) {
                continue;
            }

            return strcoll($folder1, $folder2);
        }
    }

    /**
     * Save current database state
     */
    public function save_db()
    {
        $api     = kolab_api::get_instance();
        $db_file = $api->config->get('temp_dir') . '/tests.db';

        $db = serialize($this->db);
        file_put_contents($db_file, $db);
    }

    /**
     * Wrapper for rcube_imap::set_flag()
     */
    public function set_flag($uid, $flag)
    {
        $flag       = strtoupper($flag);
        $folder_uid = $this->folder_uid($folder);
        $flags      = (array) $this->db['flags'][$uid];

        if (strpos($flag, 'UN') === 0) {
            $flag  = substr($flag, 3);
            $flags = array_values(array_diff($flags, array($flag)));
        }
        else {
            $flags[] = $flag;
            $flags   = array_unique($flags);
        }

        $this->db['flags'][$uid] = $flags;
        $this->save_db();

        return true;
    }

    /**
     * Wrapper for rcube_imap::save_message()
     */
    public function save_message($folder, $streams)
    {
        $folder_uid = $this->folder_uid($folder);
        $uid        = '3' . count($this->db['messages']) . preg_replace('/^[0-9]+\./', '', microtime(true));
        $content    = '';

        foreach ($streams as $stream) {
            rewind($stream);
            $content .= stream_get_contents($stream);
        }

        $this->db['messages'][$uid] = base64_encode($content);
        $this->save_db();

        return $uid;
    }

    /**
     * Wrapper for rcube_imap::delete_message()
     */
    public function delete_message($uid, $folder)
    {
        $folder_uid = $this->folder_uid($folder);

        $this->folders[$folder_uid]['items'] = array_values(array_diff((array)$this->folders[$folder_uid]['items'], array($uid)));
        unset($this->db['items'][$folder_uid][$uid]);
        unset($this->db['messages'][$uid]);

        $this->db['folders'][$folder_uid]['items'] = $this->folders[$folder_uid]['items'];
        $this->save_db();

        return true;
    }

    /**
     * Wrapper for rcube_imap::get_raw_body
     */
    public function get_raw_body($uid, $fp = null, $part = null)
    {
        $file = $this->get_file_content($uid);
        $file = explode("\r\n\r\n", $file, 2);

        if (stripos($part, 'TEXT') !== false) {
            $body = $file[1];

            if (preg_match('/^([0-9]+)/', $part, $m)) {
                if (preg_match('/boundary="?([^"]+)"?/', $file[0], $mm)) {
                    $parts = explode('--' . $mm[1], $body);
                    $parts = explode("\r\n\r\n", $parts[$m[1]], 2);
                    $body = $parts[1];
                }
                else {
                    $body = '';
                }
            }
        }

        if ($fp) {
            fwrite($fp, $body);
            return true;
        }
        else {
            return $body;
        }
    }

    /**
     * Wrapper for rcube_imap::get_raw_headers
     */
    public function get_raw_headers($uid)
    {
        $file = $this->get_file_content($uid);
        $file = explode("\r\n\r\n", $file, 2);

        return $file[0];
    }

    /**
     * Wrapper for rcube_imap::set_folder
     */
    public function set_folder($folder)
    {
        // do nothing
    }

    /**
     * Wrapper for rcube_imap::folder_data
     */
    public function folder_data($folder)
    {
        // @todo
    }

    /**
     * Wrapper for rcube_imap::search_once
     */
    public function search_once($folder)
    {
        // @todo
    }

    /**
     * Wrapper for rcube_imap::folder_size
     */
    public function folder_size($folder)
    {
        // @todo
    }

    /**
     * Find folder UID by its name
     */
    protected function folder_uid($name)
    {
        foreach ($this->folders as $uid => $folder) {
            if ($folder['fullpath'] == $name) {
                return $uid;
            }
        }
    }

    /**
     * Get sample message from tests/data dir
     */
    protected function get_file_content($uid, $type = null)
    {
        if ($file = $this->db['messages'][$uid]) {
            $file = base64_decode($file);
        }
        else {
            if (empty($type)) {
                foreach (array('mail', 'event', 'task', 'note', 'contact') as $t) {
                    $file = __DIR__ . '/../data/' . $t . '/' . $uid;
                    if (file_exists($file)) {
                        $type = $t; break;
                    }
                }
            }

            $file = file_get_contents(__DIR__ . '/../data/' . $type . '/' . $uid);
        }

        return $file;
    }
}

/**
 * Dummy class imitating rcube_user
 */
class kolab_api_user
{
    public function get_username($type)
    {
        $api = kolab_api_backend::get_instance();
        list($local, $domain) = explode('@', $api->username);

        if ($type == 'domain') {
            return $domain;
        }
        else if ($type == 'local') {
            return $local;
        }

        return $api->username;
    }

    public function get_user_id()
    {
        return 10;
    }

    public function get_identity()
    {
        return array(
            'email' => 'user@example.org',
            'name'  => 'Test User',
        );
    }
}
