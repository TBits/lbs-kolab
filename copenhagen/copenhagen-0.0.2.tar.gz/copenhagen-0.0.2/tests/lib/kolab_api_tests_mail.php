<?php

/**
 +--------------------------------------------------------------------------+
 | This file is part of the Kolab REST API                                  |
 |                                                                          |
 | Copyright (C) 2012-2015, Kolab Systems AG                                |
 |                                                                          |
 | This program is free software: you can redistribute it and/or modify     |
 | it under the terms of the GNU Affero General Public License as published |
 | by the Free Software Foundation, either version 3 of the License, or     |
 | (at your option) any later version.                                      |
 |                                                                          |
 | This program is distributed in the hope that it will be useful,          |
 | but WITHOUT ANY WARRANTY; without even the implied warranty of           |
 | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the             |
 | GNU Affero General Public License for more details.                      |
 |                                                                          |
 | You should have received a copy of the GNU Affero General Public License |
 | along with this program. If not, see <http://www.gnu.org/licenses/>      |
 +--------------------------------------------------------------------------+
 | Author: Aleksander Machniak <machniak@kolabsys.com>                      |
 +--------------------------------------------------------------------------+
*/

/**
 * Mock class emulating rcube_message and kolab_api_mail
 * With some additional functionality for testing
 */
class kolab_api_tests_mail extends kolab_api_mail
{
    public $attachments = array();
    public $parts       = array();
    public $mime_parts  = array();
    public $folder;
    public $uid;
    public $headers;

    protected $_categories = array();


    /**
     * Class initialization
     */
    public function __construct($content = null, $params = array())
    {
        // kolab_api_mail mode
        if (is_object($content)) {
            $this->message    = $content;
            $this->headers    = $content->headers;
            $this->mime_parts = $content->mime_parts;

            $params['folder'] = $content->folder ?: $content->headers->folder;
            $params['uid']    = $content->uid ?: $content->headers->uid;
        }
        // rcube_message mode
        else if ($content) {
            $this->message = rcube_mime::parse_message($content);
            $this->headers = rcube_message_header::from_array($this->message->headers);

            $this->message->headers = $this->headers;
            $this->headers->ctype   = $this->message->mimetype;

            foreach ((array) $params as $idx => $val) {
                $this->headers->{$idx} = $val;
            }

            $this->headers->size = strlen($content);
            $this->set_mime_parts($this->message);
        }

        if ($this->message) {
            foreach ((array) $this->message->parts as $part) {
                if ($part->filename || $part->disposition == 'attachment') {
                    $this->attachments[] = $part;
                }

                $this->parts[$part->mime_id] = $part;
            }

            $this->message->attachments = $this->attachments;
        }

        foreach ((array) $params as $idx => $val) {
            $this->{$idx} = $val;
            $this->message->{$idx} = $val;
        }
    }

    /**
     * Returns body of the message part
     */
    public function get_part_body($id, $formatted = false, $max_bytes = 0, $mode = null)
    {
        if (!$id) {
            $body = $this->message->body;
        }
        else {
            $body = $this->mime_parts[$id]->body;
        }

        if (is_resource($mode)) {
            fwrite($mode, $body);
        }
        else {
            return $body;
        }
    }

    /**
     * Convert message into Kolab object
     *
     * @return array Kolab object
     */
    public function to_array()
    {
        $object_type  = kolab_format::mime2object_type($this->headers->others['x-kolab-type']);
        $content_type = kolab_format::KTYPE_PREFIX . $object_type;
        $attachments  = array();

        // get XML part
        foreach ((array)$this->attachments as $part) {
            if (!$xml && ($part->mimetype == $content_type || preg_match('!application/([a-z.]+\+)?xml!', $part->mimetype))) {
                $xml = $this->get_part_body($part->mime_id);
            }
            else if ($part->filename || $part->content_id || $part->disposition == 'attachment') {
                $key  = $part->content_id ? trim($part->content_id, '<>') : $part->filename;
                $size = null;

                // Use Content-Disposition 'size' as for the Kolab Format spec.
                if (isset($part->d_parameters['size'])) {
                    $size = $part->d_parameters['size'];
                }
                // we can trust part size only if it's not encoded
                else if ($part->encoding == 'binary' || $part->encoding == '7bit' || $part->encoding == '8bit') {
                    $size = $part->size;
                }
                // looks like MimeDecode does not support d_parameters (?)
                else if (preg_match('/size=([0-9]+)/', $part->headers['content-disposition'], $m)) {
                    $size = $m[1];
                }

                if (!$key) {
                    $key = $part->mime_id;
                }

                $attachments[$key] = array(
                    'id'       => $part->mime_id,
                    'name'     => $part->filename,
                    'mimetype' => $part->mimetype,
                    'encoding' => $part->encoding,
                    'size'     => $size,
                );
            }
        }

        // check kolab format version
        $format_version = $this->headers->others['x-kolab-mime-version'];
        if (empty($format_version)) {
            list($xmltype, $subtype) = explode('.', $object_type);
            $xmlhead = substr($xml, 0, 512);

            // detect old Kolab 2.0 format
            if (strpos($xmlhead, '<' . $xmltype) !== false && strpos($xmlhead, 'xmlns=') === false)
                $format_version = '2.0';
            else
                $format_version = '3.0'; // assume 3.0
        }

        // get Kolab format handler for the given type
        $format = kolab_format::factory($object_type, $format_version, $xml);

        if (is_a($format, 'PEAR_Error')) {
            return false;
        }

        // load Kolab object from XML part
        $format->load($xml);
        if ($format->is_valid()) {
            $object = $format->to_array(array('_attachments' => $attachments));
            $object['_formatobj']   = $format;
            $object['_type']        = $object_type;
            $object['_attachments'] = $attachments;
            $object['_message']     = $this;
//            $object['_msguid']    = $msguid;
//            $object['_mailbox']   = $this->name;

            return $object;
        }

        return false;
    }

    /**
     * Send the message stream using configured method
     */
    protected function send_message_stream($stream)
    {
        return true;
    }

    /**
     * Get rcube_message object of the assigned message
     */
    protected function get_message()
    {
        return $this->message;
    }

    /**
     * rcube_message::first_html_part() emulation.
     */
    public function first_html_part(&$part = null, $enriched = false)
    {
        foreach ((array) $this->mime_parts as $part) {
            if (!$part->filename && $part->mimetype == 'text/html') {
                return $this->get_part_body($part->mime_id, true);
            }
        }

        $part = null;
    }

    /**
     * rcube_message::first_text_part() emulation.
     */
    public function first_text_part(&$part = null, $strict = false)
    {
        // no message structure, return complete body
        if (empty($this->mime_parts)) {
            return $this->message->body;
        }

        foreach ((array) $this->mime_parts as $part) {
            if (!$part->filename && $part->mimetype == 'text/plain') {
                return $this->get_part_body($part->mime_id, true);
            }
        }

        $part = null;
    }

    /**
     * Properties getter
     *
     * @param string $name Property name
     *
     * @param mixed Property value
     */
    public function __get($name)
    {
        if ($name == 'categories' && !array_key_exists($name, $this->data)) {
            return (array) $this->_categories;
        }

        return parent::__get($name);
    }

    /**
     * Categories setter
     */
    public function set_categories($categories)
    {
        $this->_categories = $categories;
    }

    protected function update_flags($uid)
    {
        // @TODO
    }

    protected function update_categories($uid)
    {
        // empty, handled by kolab_api_backend of tests
    }

    /**
     * Fill aflat array with references to all parts, indexed by part numbers
     */
    private function set_mime_parts(&$part)
    {
        if (strlen($part->mime_id)) {
            $this->mime_parts[$part->mime_id] = &$part;
        }

        if (is_array($part->parts)) {
            for ($i = 0; $i < count($part->parts); $i++) {
                $this->set_mime_parts($part->parts[$i]);
            }
        }
    }
}
