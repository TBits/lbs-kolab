CREATE TABLE IF NOT EXISTS `copenhagen_fai` (
    `id`      int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
    `folder`  varchar(64) BINARY NOT NULL,
    `data`    mediumtext,
    PRIMARY KEY (`id`),
    INDEX `folder` (`folder`)
) /*!40000 ENGINE=INNODB */ /*!40101 CHARACTER SET utf8 COLLATE utf8_general_ci */;

CREATE TABLE IF NOT EXISTS `copenhagen_folderdata` (
    `folder`  varchar(64) BINARY NOT NULL,
    `data`    mediumtext,
    PRIMARY KEY (`folder`)
) /*!40000 ENGINE=INNODB */ /*!40101 CHARACTER SET utf8 COLLATE utf8_general_ci */;

INSERT INTO `system` (`name`, `value`) VALUES ('copenhagen-version', '2015121700');
